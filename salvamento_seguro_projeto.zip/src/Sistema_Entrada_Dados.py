import os
import sys
import traceback

import logging
import os
from datetime import datetime, date

# Configurar logging para arquivo
log_dir = os.path.join(os.path.expanduser('~'), 'Desktop', 'logs_sistema')
os.makedirs(log_dir, exist_ok=True)

log_file = os.path.join(log_dir, f'sistema_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt')

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()  # Também mostra no console quando disponível
    ]
)

logger = logging.getLogger(__name__)
logger.info("="*80)
logger.info("SISTEMA INICIADO")
logger.info("="*80)

# Configurar diretório de log no desktop do usuário
log_dir = os.path.join(os.path.expanduser("~"), "Desktop")
log_file = os.path.join(log_dir, "sistema_log.txt")

def log_error(message):
    """Grava mensagens de erro em arquivo no desktop"""
    try:
        with open(log_file, "a") as f:
            f.write(f"{message}\n")
    except:
        pass

# Capturar e registrar exceções não tratadas
def handle_exception(exc_type, exc_value, exc_traceback):
    """Manipulador para exceções não capturadas"""
    error_msg = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    log_error(f"\n\n--- ERRO NÃO TRATADO: {error_msg}")
    # Mostrar mensagem simples para o usuário
    import tkinter.messagebox as msgbox
    msgbox.showerror("Erro", f"Ocorreu um erro: {str(exc_value)}\nDetalhes foram registrados em: {log_file}")
    
# Substituir o manipulador de exceções padrão
sys.excepthook = handle_exception

log_error(f"\n\n--- INICIANDO APLICAÇÃO: {sys.argv[0]} ---")

# Imports da biblioteca padrão Python
import os
import sys
from pathlib import Path
import re
import calendar
from datetime import datetime, timedelta
from decimal import Decimal
from difflib import SequenceMatcher

# Imports relacionados ao Tkinter (MUITO IMPORTANTE)
import tkinter as tk
from tkinter import ttk, messagebox, StringVar
from tkinter import *
from tkcalendar import DateEntry, Calendar
from tkinter import filedialog, messagebox

# Imports para manipulação de dados e Excel
import pandas as pd
from openpyxl import load_workbook
import openpyxl
import babel
from dateutil.relativedelta import relativedelta
import unicodedata

import requests
import json
import xml.etree.ElementTree as ET

# Detectar modo PyInstaller e ajustar paths
if getattr(sys, 'frozen', False):
    # Estamos em um executável criado pelo PyInstaller
    base_dir = Path(sys._MEIPASS)
    # Garantir que src e src/config estão no path
    for subdir in ['src', os.path.join('src', 'config')]:
        path = os.path.join(base_dir, subdir)
        if path not in sys.path:
            sys.path.insert(0, path)
            logger.debug(f"PyInstaller: Adicionando {path} ao sys.path")

# Configurar caminhos de importação
def add_project_root():
    import sys
    from pathlib import Path
    current_dir = Path(__file__).resolve().parent
    project_root = current_dir.parent
    config_dir = current_dir / 'config'
    
    # Adicionar todos os caminhos necessários
    for path in [str(current_dir), str(project_root), str(config_dir)]:
        if path not in sys.path:
            sys.path.insert(0, path)
            logger.debug(f"Adicionado ao path: {path}")

add_project_root()

# Configurar logging básico para diagnóstico
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("sistema")

# Importações centralizadas com tratamento de erro
try:
    # Primeiro, tentar importação com 'src.config'
    from src.config.utils import *
    from src.config.dialogs import custom_messagebox
    from src.config.logger_config import system_logger, log_action
    from src.config.window_config import configurar_janela
    from src.config.config import (
        ARQUIVO_CLIENTES,
        ARQUIVO_MODELO,
        PASTA_CLIENTES,
        BASE_PATH,
        ARQUIVO_FORNECEDORES
    )
    logger.info("Configurações importadas com sucesso via src.config")
except ImportError:
    # Se falhar, tentar importação direta de 'config'
    try:
        from config.utils import *
        from config.logger_config import system_logger, log_action
        from config.window_config import configurar_janela
        from config.config import (
            ARQUIVO_CLIENTES,
            ARQUIVO_MODELO,
            PASTA_CLIENTES,
            BASE_PATH,
            ARQUIVO_FORNECEDORES
        )
        logger.info("Configurações importadas com sucesso via config")
    except ImportError as e:
        # Último recurso - importações relativas
        try:
            from src.config.utils import *
            from src.config.logger_config import system_logger, log_action
            from src.config.window_config import configurar_janela
            from src.config.config import (
                ARQUIVO_CLIENTES,
                ARQUIVO_MODELO,
                PASTA_CLIENTES,
                BASE_PATH,
                ARQUIVO_FORNECEDORES
            )
            logger.info("Configurações importadas com sucesso via .config")
        except Exception as e:
            logger.error(f"Erro ao importar configurações: {str(e)}")
            # Não raise aqui para permitir definições alternativas

# Arquivo para salvar preferências de ordenação
ARQUIVO_PREFERENCIAS_ORDENACAO = PASTA_CLIENTES / ".preferencias_ordenacao.json"

# Gestão de Locações
from src.gestao_locacoes import GerenciadorLocacoes
# Importador de Medições
from src.importador_medicoes import ImportadorMedicoes

# from src.nfe.sistema_nfe_unificado import substituir_sistemas_nfe_por_unificado
from src.materiais.gerenciador_materiais import inicializar_sistema_materiais_completo
from src.salvamento_seguro import salvar_planilha_segura

# Definir funções de compatibilidade, caso a importação das configurações falhe
def get_categorias_fornecedor():
    """Retorna a lista de categorias de fornecedor"""
    try:
        # Tentar importar do arquivo de configurações
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        return GerenciadorConfiguracoes.get_categorias_fornecedor()
    except:
        # Valores padrão como fallback
        return ['MO', 'MAT', 'SERV', 'DIV', 'ADM', 'LOC', 'TP']

@log_action("Carregar configurações")
def carregar_configuracoes():
    """Carrega as configurações do sistema"""
    try:
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        return GerenciadorConfiguracoes.carregar_configuracoes()
    except:
        # Configurações padrão como fallback
        return {
            'cafe': {'valor_atual': 4.0}
        }

def get_bancos():
    """Retorna a lista de bancos"""
    try:
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        return GerenciadorConfiguracoes.get_bancos()
    except:
        # Valores padrão como fallback
        return [
            '104 - CAIXA ECONÔMICA FEDERAL',
            '001 - BANCO DO BRASIL',
            '033 - BANCO SANTANDER',
            '237 - BRADESCO',
            '341 - ITAÚ',
            '077 - BANCO INTER',
            '260 - NUBANK'
        ]

# Importar configurações
try:
    from src.config.utils import (
            obter_clientes_ativos,
            validar_data,
            validar_cpf, 
            validar_cnpj,
            # validar_cnpj_cpf,
            formatar_cnpj_cpf,
            normalizar_documento,
            formatar_documento,
            validar_documento,
            buscar_dados_bancarios_fornecedor,
            custom_messagebox,
            formatar_cno_campo,
            formatar_cep_campo,
            limpar_formatacao,
            # validar_cpf_completo,
        )
    from src.configuracoes_sistema import GerenciadorConfiguracoes
    logger.info("Configurações importadas com sucesso")
except Exception as e:
    logger.error(f"Erro ao importar configurações: {str(e)}")
    raise

# =====================================================================
# CLIENTES: SUPORTE A CPF (PF) E CNPJ (PJ) NO MESMO CAMPO
# Usado SOMENTE nas telas "Novo Cliente" e "Editar Cliente".
# O cadastro de fornecedores continua usando as funções de src.config.utils.
#
# A coluna G da planilha de clientes (cabeçalho "CPF") guarda CPF
# (000.000.000-00) ou CNPJ (00.000.000/0000-00), SEMPRE como texto com
# máscara, para que zeros à esquerda nunca se percam.
# Identificação do tipo: contém letra -> CNPJ alfanumérico;
# 11 caracteres -> CPF; 14 caracteres -> CNPJ.
# CNPJ alfanumérico: IN RFB 2.229/2024 (12 posições alfanuméricas + 2 DVs numéricos).
# =====================================================================
def _tipo_chave_pix(chave, documento='', telefone=''):
    """Deduz o "Tipo de Chave" a partir da chave PIX gravada. O tipo não é
    gravado na planilha; antes, a tela de edição abria sempre "Telefone"."""
    chave = str(chave or '').strip()
    if not chave:
        return 'Telefone'                       # mesmo padrão de um cadastro novo
    if '@' in chave:
        return 'Email'
    if not chave.replace('.', '').replace('-', '').replace('/', '').replace('(', '') \
            .replace(')', '').replace(' ', '').replace('+', '').isdigit():
        return 'Selecione'                      # chave aleatória ou outro formato
    dig = ''.join(c for c in chave if c.isdigit())
    if dig == ''.join(c for c in str(documento or '') if c.isdigit()):
        return 'CNPJ/CPF'
    tel = ''.join(c for c in str(telefone or '') if c.isdigit())
    if tel and (dig == tel or dig.endswith(tel)):
        return 'Telefone'
    if (len(dig) == 11 and _cpf_digitos_validos(dig)) or (len(dig) == 14 and _cnpj_digitos_validos(dig)):
        return 'CNPJ/CPF'                       # CPF/CNPJ de outra pessoa
    return 'Telefone'


def _numero_br(texto):
    """Converte número digitado no padrão brasileiro: "1.500,25" -> 1500.25,
    "375" -> 375.0, "1,5" -> 1.5. Com vírgula, os pontos são milhar."""
    texto = str(texto or '').strip()
    if ',' in texto:
        texto = texto.replace('.', '').replace(',', '.')
    return float(texto)


def _doc_limpo(texto):
    """Mantém apenas letras e dígitos, em maiúsculas (None vira '')."""
    return ''.join(ch for ch in str(texto or '').upper() if ch.isalnum())


def _cpf_digitos_validos(cpf):
    """Confere os dígitos verificadores de um CPF (11 dígitos, sem máscara)."""
    if len(cpf) != 11 or not cpf.isdigit() or cpf == cpf[0] * 11:
        return False
    for n in (9, 10):
        soma = sum(int(cpf[i]) * (n + 1 - i) for i in range(n))
        if (soma * 10) % 11 % 10 != int(cpf[n]):
            return False
    return True


def _cnpj_digitos_validos(cnpj):
    """Confere os dígitos verificadores de um CNPJ numérico ou alfanumérico
    (14 posições, sem máscara). Cada caractere vale ord(c) - 48, o que dá o
    mesmo resultado do cálculo tradicional quando o CNPJ é só numérico."""
    if len(cnpj) != 14 or cnpj == cnpj[0] * 14:
        return False
    base, dvs = cnpj[:12], cnpj[12:]
    if not dvs.isdigit() or not all(c.isdigit() or ('A' <= c <= 'Z') for c in base):
        return False
    valores = [ord(c) - 48 for c in base]
    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    pesos2 = [6] + pesos1
    for pesos in (pesos1, pesos2):
        resto = sum(v * p for v, p in zip(valores, pesos)) % 11
        valores.append(0 if resto < 2 else 11 - resto)
    return valores[12] == int(dvs[0]) and valores[13] == int(dvs[1])


def _eh_cnpj(limpo):
    """CNPJ se tiver letra (alfanumérico) ou mais de 11 caracteres."""
    return any(c.isalpha() for c in limpo) or len(limpo) > 11


def _mascara_cpf_cnpj(limpo):
    """Aplica a máscara progressivamente (CPF ou CNPJ, conforme _eh_cnpj)."""
    limpo = limpo[:14]
    if _eh_cnpj(limpo):
        separadores = {2: '.', 5: '.', 8: '/', 12: '-'}
    else:
        separadores = {3: '.', 6: '.', 9: '-'}
    saida = ''
    for i, c in enumerate(limpo):
        if i in separadores:
            saida += separadores[i]
        saida += c
    return saida


def formatar_cpf_cnpj_campo(event):
    """Máscara automática para o Entry de cliente (substitui formatar_cpf_campo).
    Ligar em <KeyRelease> e <FocusOut>."""
    widget = event.widget
    # Ao apagar ou navegar, não reformata (senão o separador "volta" e o
    # usuário fica preso); a máscara é refeita quando o campo perde o foco.
    if event.type == tk.EventType.KeyRelease and event.keysym in (
            'BackSpace', 'Delete', 'Left', 'Right', 'Home', 'End', 'Tab',
            'Shift_L', 'Shift_R', 'Control_L', 'Control_R'):
        return
    novo = _mascara_cpf_cnpj(_doc_limpo(widget.get()))
    if widget.get() != novo:
        widget.delete(0, tk.END)
        widget.insert(0, novo)
        widget.icursor(tk.END)


def validar_documento_cliente(texto):
    """Valida o CPF/CNPJ digitado no cadastro/edição de cliente.

    Retorna (pode_salvar, documento_formatado).
    - Campo vazio: permitido (retorna '').
    - Tamanho diferente de 11 (CPF) ou 14 (CNPJ): bloqueia.
    - Dígitos verificadores errados: pergunta se deseja salvar mesmo assim.
    """
    limpo = _doc_limpo(texto)
    if not limpo:
        return True, ''
    if _eh_cnpj(limpo):
        tipo = 'CNPJ'
        if len(limpo) != 14:
            messagebox.showerror(
                "Erro",
                f"CNPJ com {len(limpo)} caracteres.\n\n"
                "O CNPJ deve ter 14 caracteres, incluindo os zeros à esquerda "
                "(ex.: 00.065.389/0001-53)."
            )
            return False, ''
        valido = _cnpj_digitos_validos(limpo)
    elif len(limpo) == 11:
        tipo, valido = 'CPF', _cpf_digitos_validos(limpo)
    else:
        messagebox.showerror(
            "Erro",
            f"CPF/CNPJ com {len(limpo)} dígitos.\n\n"
            "Informe 11 dígitos para CPF (pessoa física) ou "
            "14 para CNPJ (pessoa jurídica), incluindo os zeros à esquerda."
        )
        return False, ''
    formatado = _mascara_cpf_cnpj(limpo)
    if not valido:
        continuar = messagebox.askyesno(
            f"{tipo} inválido",
            f"O {tipo} {formatado} não passou na conferência dos dígitos "
            f"verificadores.\n\nProvavelmente há um erro de digitação. "
            f"A busca de documentos fiscais por {tipo} não vai encontrá-lo.\n\n"
            "Deseja salvar mesmo assim?"
        )
        if not continuar:
            return False, ''
    return True, formatado


# Importar configurações do sistema
try:
    from src.config.config import (
        ARQUIVO_CLIENTES,
        ARQUIVO_MODELO,
        PASTA_CLIENTES,
        BASE_PATH
    )
    logger.info("Configurações do sistema importadas com sucesso")
except Exception as e:
    logger.error(f"Erro ao importar configurações do sistema: {str(e)}")
    raise

from src.config.window_config import configurar_janela

from src.fornecedores.gerenciador_cpfs_criados import GerenciadorCPFsCriados
from src.widgets.combobox_autocompletar import ComboboxAutocompletar
from src.fornecedores.cache_fornecedores import CacheFornecedores 
from src.taxas_administracao.gestao_contratos import GestaoContratos
from src.taxas_administracao.gestor_taxas_administracao import GestorTaxasAdministracao 
from src.parcelamento.gestor_parcelas import GestorParcelas
from src.fornecedores.regularizar_fornecedor import (
    regularizar_fornecedor, fundir_fornecedores, detectar_possiveis_duplicatas, 
)
from src.fornecedores.conciliar_importacao import classificar_colaboradores
from src.fornecedores.triagem_importacao_rh import TriagemImportacaoRH

# from src.leitura_guias import (
#     extrair_dados_guia,
#     GuiaNaoReconhecida,
#     NOME_FORNECEDOR_POR_TIPO,
#     competencia_para_mm_aaaa,
# )

# Modificação para usar o método de utils.py
from src.config.utils import buscar_dados_bancarios_fornecedor


class VisualizadorLancamentos:
    def __init__(self, sistema_principal):
        self.sistema = sistema_principal
        
        # ============================================================
        # FORÇA SINCRONIZAÇÃO ANTES DE CRIAR A JANELA
        # ============================================================
        if hasattr(sistema_principal, 'root'):
            sistema_principal.root.update_idletasks()
        
        # ============================================================
        # COPIA OS DADOS IMEDIATAMENTE
        # ============================================================
        self.dados_para_incluir = sistema_principal.dados_para_incluir.copy() if hasattr(sistema_principal, 'dados_para_incluir') else []
        
        logger.info(f"🔍 Visualizador iniciado com {len(self.dados_para_incluir)} lançamentos")
        
        self.janela = tk.Toplevel(sistema_principal.root)
        configurar_janela(self.janela, "Visualização de Lançamentos Pendentes", 1000, 400)

        # Registrar esta janela para os diálogos
        try:
            from src.config.dialogs import set_main_window
            set_main_window(self.janela)
        except ImportError:
            pass

        self.alteracoes = False
        self._fechando = False
        self._dialogo_aberto = False
        
        # Configurar comportamento quando a janela é fechada
        self.janela.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # ESTRATÉGIA BALANCEADA
        self.janela.lift()
        self.janela.focus_force()

        # Frame principal
        self.frame_principal = ttk.Frame(self.janela)
        self.frame_principal.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Criar Treeview para visualização
        self.criar_treeview()
        
        # Frame para resumo
        self.frame_resumo = ttk.LabelFrame(self.frame_principal, text="Resumo")
        self.frame_resumo.pack(fill='x', pady=5)
        
        self.lbl_total_lancamentos = ttk.Label(self.frame_resumo, text="Total de Lançamentos: 0")
        self.lbl_total_lancamentos.pack(side='left', padx=5)
        
        self.lbl_valor_total = ttk.Label(self.frame_resumo, text="Valor Total: R$ 0,00")
        self.lbl_valor_total.pack(side='left', padx=5)
        
        self.lbl_selecionados = ttk.Label(self.frame_resumo, text="Marcados: 0", 
                                         foreground='blue', font=('TkDefaultFont', 9, 'bold'))
        self.lbl_selecionados.pack(side='left', padx=5)
        
        # Frame para botões de seleção
        self.frame_selecao = ttk.Frame(self.frame_principal)
        self.frame_selecao.pack(fill='x', pady=5)
        
        ttk.Label(self.frame_selecao, text="Marcar:").pack(side='left', padx=5)
        ttk.Button(self.frame_selecao, text="✓ Todos", 
                  command=self.selecionar_todos).pack(side='left', padx=2)
        ttk.Button(self.frame_selecao, text="✗ Nenhum", 
                  command=self.desmarcar_todos).pack(side='left', padx=2)
        ttk.Button(self.frame_selecao, text="⇄ Inverter", 
                  command=self.inverter_selecao).pack(side='left', padx=2)
        
        # Frame para botões principais
        self.frame_botoes = ttk.Frame(self.frame_principal)
        self.frame_botoes.pack(fill='x', pady=5)
        
        ttk.Button(self.frame_botoes, text="✏️ Editar", 
                  command=self.editar_lancamento).pack(side='left', padx=5)
        
        ttk.Button(self.frame_botoes, text="📝 Editar em Massa", 
                    command=self.editar_em_massa).pack(side='left', padx=5)
        
        # Botão de exclusão único - funciona para 1 ou vários
        self.btn_excluir = tk.Button(self.frame_botoes, text="🗑️ Excluir Marcados", 
                                     command=self.excluir_marcados,
                                     bg='#dc3545', fg='white', 
                                     font=('TkDefaultFont', 9, 'bold'),
                                     relief='raised', bd=2, cursor='hand2')
        self.btn_excluir.pack(side='left', padx=5)
        
        ttk.Button(self.frame_botoes, text="📂 Carregar Rascunho", 
                  command=self.carregar_rascunho).pack(side='left', padx=5)
        ttk.Button(self.frame_botoes, text="💾 Salvar na Planilha", 
                  command=self.salvar_na_planilha).pack(side='left', padx=5)
        ttk.Button(self.frame_botoes, text="Fechar", 
                  command=self.fechar_janela).pack(side='right', padx=5)
        
        # Monitorar perda de foco
        self.janela.bind('<FocusOut>', self._on_focus_out)
    
    def _on_focus_out(self, event):
        """Quando janela perde foco, verifica se deve trazer de volta"""
        if not self._dialogo_aberto and not self._fechando:
            self.janela.after(200, self._verificar_trazer_frente)
    
    def _verificar_trazer_frente(self):
        """Verifica se deve trazer janela para frente"""
        try:
            if (self.janela and self.janela.winfo_exists() and 
                not self._dialogo_aberto and not self._fechando):
                if not self._tem_dialogo_filho():
                    self.janela.lift()
                    self.janela.focus_force()
        except:
            pass
    
    def _tem_dialogo_filho(self):
        """Verifica se há algum diálogo filho aberto"""
        try:
            widget_com_foco = self.janela.focus_get()
            if widget_com_foco:
                parent = widget_com_foco.winfo_toplevel()
                if parent != self.janela and isinstance(parent, tk.Toplevel):
                    return True
            return False
        except:
            return False
    
    def fechar_janela(self):
        """Fecha a janela de forma segura"""
        self._fechando = True
        if hasattr(self.sistema, 'on_visualizador_close'):
            self.sistema.on_visualizador_close()
        else:
            self.janela.destroy()
    
    def on_close(self):
        """Manipula o fechamento da janela"""
        self.fechar_janela()

    def criar_treeview(self):
        """Cria a TreeView com coluna de checkbox CLICÁVEL"""
        colunas = ('☑', 'Data', 'Tipo', 'CNPJ/CPF', 'Nome', 'Referência', 'NF', 'Vr. Unit.', 
                   'Dias', 'Valor', 'Vencimento', 'Categoria', 'Forma Pagamento', 
                   'Dados Bancários', 'Observação')
        
        self.tree = ttk.Treeview(self.frame_principal, columns=colunas, show='headings')
        
        for col in colunas:
            self.tree.heading(col, text=col)
            
            if col == '☑':
                width = 30
            elif col in ['CNPJ/CPF', 'Nome', 'Referência', 'Dados Bancários', 'Observação']:
                width = 150
            elif col in ['Data', 'Vencimento']:
                width = 100
            elif col in ['Vr. Unit.', 'Valor', 'NF']:
                width = 100
            elif col == 'Forma Pagamento':
                width = 80
            else:
                width = 80
            self.tree.column(col, width=width)

        scrolly = ttk.Scrollbar(self.frame_principal, orient='vertical', command=self.tree.yview)
        scrollx = ttk.Scrollbar(self.frame_principal, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=scrolly.set, xscrollcommand=scrollx.set)
        
        self.tree.pack(fill='both', expand=True)
        scrolly.pack(side='right', fill='y')
        scrollx.pack(side='bottom', fill='x')
        
        # Clique simples marca/desmarca checkbox
        self.tree.bind('<Button-1>', self.on_tree_click)
    
    def on_tree_click(self, event):
        """Detecta clique na coluna do checkbox e alterna"""
        region = self.tree.identify_region(event.x, event.y)
        if region == "cell":
            column = self.tree.identify_column(event.x)
            if column == '#1':
                item = self.tree.identify_row(event.y)
                if item:
                    self.toggle_checkbox(item)
                    return "break"
    
    def toggle_checkbox(self, item_id):
        """Alterna o estado do checkbox de um item"""
        valores = list(self.tree.item(item_id)['values'])
        if valores[0] in ['☐', '']:
            valores[0] = '☑'
        else:
            valores[0] = '☐'
        self.tree.item(item_id, values=valores)
        self.atualizar_contador_selecionados()
    
    def selecionar_todos(self):
        """Marca todos os checkboxes"""
        for item in self.tree.get_children():
            valores = list(self.tree.item(item)['values'])
            valores[0] = '☑'
            self.tree.item(item, values=valores)
        self.atualizar_contador_selecionados()
    
    def desmarcar_todos(self):
        """Desmarca todos os checkboxes"""
        for item in self.tree.get_children():
            valores = list(self.tree.item(item)['values'])
            valores[0] = '☐'
            self.tree.item(item, values=valores)
        self.atualizar_contador_selecionados()
    
    def inverter_selecao(self):
        """Inverte a seleção dos checkboxes"""
        for item in self.tree.get_children():
            valores = list(self.tree.item(item)['values'])
            valores[0] = '☑' if valores[0] == '☐' else '☐'
            self.tree.item(item, values=valores)
        self.atualizar_contador_selecionados()
    
    def obter_indices_marcados(self):
        """Retorna lista de índices dos itens marcados"""
        indices_marcados = []
        todos_items = self.tree.get_children()
        
        for idx, item in enumerate(todos_items):
            valores = self.tree.item(item)['values']
            if valores[0] == '☑':
                indices_marcados.append(idx)
        
        return indices_marcados
    
    def excluir_marcados(self):
        """
        Exclui todos os lançamentos marcados PERMANENTEMENTE
        Funciona para 1 ou vários itens marcados
        """
        indices_marcados = self.obter_indices_marcados()
        
        if not indices_marcados:
            self._dialogo_aberto = True
            custom_messagebox("warning", "⚠️ Nenhum Item Marcado", 
                            "Para excluir lançamentos:\n\n"
                            "1. Clique no ☑ para marcar os itens desejados\n"
                            "2. Clique em 'Excluir Marcados'\n\n"
                            "💡 Dica: Use os botões 'Todos', 'Nenhum' ou 'Inverter' "
                            "para facilitar a seleção!")
            self._dialogo_aberto = False
            self.janela.lift()
            return
        
        # MARCAR que há diálogo aberto
        self._dialogo_aberto = True
        
        # Mensagem personalizada para singular/plural
        qtd = len(indices_marcados)
        if qtd == 1:
            titulo = "⚠️ Excluir 1 Lançamento"
            mensagem = (f"Você está prestes a EXCLUIR PERMANENTEMENTE "
                       f"1 lançamento!\n\n"
                       f"❌ Esta ação NÃO PODE ser desfeita!\n"
                       f"❌ O dado será removido IMEDIATAMENTE!\n"
                       f"❌ O rascunho será atualizado AGORA!\n\n"
                       f"Confirma a EXCLUSÃO DEFINITIVA?")
        else:
            titulo = f"⚠️ Excluir {qtd} Lançamentos"
            mensagem = (f"Você está prestes a EXCLUIR PERMANENTEMENTE "
                       f"{qtd} lançamentos!\n\n"
                       f"❌ Esta ação NÃO PODE ser desfeita!\n"
                       f"❌ Os dados serão removidos IMEDIATAMENTE!\n"
                       f"❌ O rascunho será atualizado AGORA!\n\n"
                       f"Confirma a EXCLUSÃO DEFINITIVA?")
        
        resposta = custom_messagebox("yesno", titulo, mensagem)
        
        # MARCAR que diálogo foi fechado
        self._dialogo_aberto = False
        
        if resposta:
            try:
                # REMOVER IMEDIATAMENTE
                itens_removidos = self.remover_itens_especificos(indices_marcados)
                
                # ATUALIZAR SISTEMA PRINCIPAL
                self.sistema.dados_para_incluir = self.dados_para_incluir.copy()
                
                # SALVAR RASCUNHO ATUALIZADO
                self.salvar_rascunho_imediatamente()
                
                # Verificar se ainda há dados
                self._dialogo_aberto = True
                if len(self.dados_para_incluir) == 0:
                    if qtd == 1:
                        msg = "1 lançamento EXCLUÍDO PERMANENTEMENTE!"
                    else:
                        msg = f"{itens_removidos} lançamentos EXCLUÍDOS PERMANENTEMENTE!"
                    
                    custom_messagebox("info", "✅ Exclusão Concluída", 
                                    f"{msg}\n\n"
                                    f"✅ Rascunho ELIMINADO!\n"
                                    f"✅ Não há mais lançamentos pendentes.")
                    self._dialogo_aberto = False
                    self.fechar_janela()
                    return
                else:
                    if qtd == 1:
                        msg = "1 lançamento EXCLUÍDO PERMANENTEMENTE!"
                    else:
                        msg = f"{itens_removidos} lançamentos EXCLUÍDOS PERMANENTEMENTE!"
                    
                    custom_messagebox("info", "✅ Exclusão Concluída", 
                                    f"{msg}\n\n✅ Rascunho ATUALIZADO!")
                self._dialogo_aberto = False
                
            except Exception as e:
                self._dialogo_aberto = True
                custom_messagebox("error", "Erro", 
                                f"Erro ao excluir lançamentos:\n{str(e)}")
                self._dialogo_aberto = False
                import traceback
                logger.debug(traceback.format_exc())
        
        # Trazer janela de volta
        self.janela.lift()
        self.janela.focus_force()
    
    def editar_em_massa(self):
        """Abre editor para alteração em massa dos lançamentos marcados"""
        indices_marcados = self.obter_indices_marcados()
        
        if not indices_marcados:
            self._dialogo_aberto = True
            custom_messagebox("warning", "⚠️ Nenhum Item Marcado", 
                            "Para editar em massa:\n\n"
                            "1. Marque os lançamentos desejados com ☑\n"
                            "2. Clique em 'Editar em Massa'\n\n"
                            "💡 Use os botões auxiliares para marcar múltiplos itens!")
            self._dialogo_aberto = False
            self.janela.lift()
            return
        
        if len(indices_marcados) == 1:
            self._dialogo_aberto = True
            resposta = custom_messagebox("yesno", 
                "Edição Individual ou em Massa?",
                "Você marcou apenas 1 lançamento.\n\n"
                "Deseja usar o editor em massa mesmo assim?\n"
                "(Não = abrirá o editor individual normal)")
            self._dialogo_aberto = False
            
            if not resposta:
                # Abrir editor individual
                item = self.tree.get_children()[indices_marcados[0]]
                self.tree.selection_set(item)
                self.editar_lancamento()
                return
        
        # Coletar dados dos lançamentos marcados
        dados_selecionados = [self.dados_para_incluir[idx] for idx in indices_marcados]
        
        # Abrir editor em massa
        self._dialogo_aberto = True
        editor = EditorEmMassa(self.janela, dados_selecionados, indices_marcados, 
                            self.atualizar_lancamento)
        self._dialogo_aberto = False

    def salvar_rascunho_imediatamente(self):
        """SALVA ou REMOVE o rascunho IMEDIATAMENTE"""
        try:
            temp_file = os.path.join(os.path.expanduser("~"), "Desktop", 
                                    "backup_lancamentos.json")
            
            if not self.dados_para_incluir or len(self.dados_para_incluir) == 0:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    logger.debug(f"✅ Rascunho DELETADO: {temp_file}")
                return
            
            backup_data = {
                'cliente': self.sistema.cliente_atual if hasattr(self.sistema, 'cliente_atual') else '',
                'total_lancamentos': len(self.dados_para_incluir),
                'data_sessao': datetime.now().isoformat(),
                'lancamentos': self.dados_para_incluir
            }
            
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, ensure_ascii=False, indent=2)
            
            logger.debug(f"✅ Rascunho SALVO: {temp_file} ({len(self.dados_para_incluir)} lançamentos)")
                
        except Exception as e:
            logger.debug(f"❌ Erro ao salvar rascunho: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
    
    def atualizar_contador_selecionados(self):
        """Atualiza o contador de itens selecionados"""
        qtd_selecionados = len(self.obter_indices_marcados())
        
        if qtd_selecionados == 1:
            texto = "Marcado: 1"
        else:
            texto = f"Marcados: {qtd_selecionados}"
        
        self.lbl_selecionados.config(text=texto)
        
        # Mudar cor do botão baseado na seleção
        if qtd_selecionados > 0:
            self.btn_excluir.config(bg='#ff0000', state='normal')
            if qtd_selecionados == 1:
                self.btn_excluir.config(text='🗑️ Excluir Marcado')
            else:
                self.btn_excluir.config(text='🗑️ Excluir Marcados')
        else:
            self.btn_excluir.config(bg='#dc3545', state='normal', 
                                   text='🗑️ Excluir Marcados')
    
    def atualizar_dados(self, dados):
        """Atualiza os dados na visualização"""
        self.dados_para_incluir = dados.copy() if dados else []
        
        if hasattr(self, 'dados_originais'):
            self.dados_originais = dados.copy() if dados else []
        else:
            self.dados_originais = dados.copy() if dados else []
        
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        if not dados:
            self.lbl_total_lancamentos.config(text="Total de Lançamentos: 0")
            self.lbl_valor_total.config(text="Valor Total: R$ 0,00")
            self.lbl_selecionados.config(text="Marcados: 0")
            if hasattr(self, 'janela'):
                self.janela.title("Visualização de Lançamentos Pendentes - 0 registros")
            return
            
        valor_total = 0
        for lancamento in self.dados_para_incluir:
            valores = (
                '☐',
                lancamento['data'],
                lancamento['tp_desp'],
                lancamento['cnpj_cpf'],
                lancamento['nome'],
                lancamento['referencia'],
                lancamento.get('nf', ''),
                lancamento['vr_unit'],
                lancamento['dias'],
                lancamento['valor'],
                lancamento['dt_vencto'],
                lancamento['categoria'],
                lancamento.get('forma_pagamento', ''),
                lancamento['dados_bancarios'],
                lancamento['observacao']
            )
            self.tree.insert('', 'end', values=valores)
            
            try:
                valor_total += float(str(lancamento['valor']).replace(',', '.'))
            except (ValueError, TypeError):
                pass
        
        self.lbl_total_lancamentos.config(text=f"Total de Lançamentos: {len(dados)}")
        self.lbl_valor_total.config(text=f"Valor Total: R$ {valor_total:,.2f}")
        self.lbl_selecionados.config(text="Marcados: 0")
        
        if hasattr(self, 'janela'):
            self.janela.title(f"Visualização de Lançamentos Pendentes - {len(dados)} registros")

    def editar_lancamento(self):
        """Abre a janela de edição para o lançamento selecionado na TreeView"""
        item_selecionado = self.tree.selection()
        if not item_selecionado:
            self._dialogo_aberto = True
            custom_messagebox("warning", "Aviso", 
                            "Para editar um lançamento:\n\n"
                            "Clique na LINHA desejada para selecioná-la\n"
                            "(não é o checkbox ☑, é a linha inteira)")
            self._dialogo_aberto = False
            self.janela.lift()
            return

        todos_items = self.tree.get_children()
        indice = todos_items.index(item_selecionado[0])
        
        valores = self.tree.item(item_selecionado)['values']
        dados = {
            'data': valores[1],
            'tp_desp': valores[2],
            'cnpj_cpf': valores[3],
            'nome': valores[4],
            'referencia': valores[5],
            'nf': valores[6],
            'vr_unit': valores[7],
            'dias': valores[8],
            'valor': valores[9],
            'dt_vencto': valores[10],
            'categoria': valores[11],
            'forma_pagamento': valores[12],
            'dados_bancarios': valores[13],
            'observacao': valores[14] if len(valores) > 14 else ''
        }
        
        editor = EditorLancamento(self.janela, dados, indice, self.atualizar_lancamento)

    def obter_tipo_pessoa_fornecedor(self, cnpj_cpf_formatado):
        """
        Busca o tipo_pessoa do fornecedor na base
        RETORNA: 'PF', 'PJ' ou None (se não encontrar)
        """
        try:
            from openpyxl import load_workbook
            from src.config.config import ARQUIVO_FORNECEDORES
            import os
            
            if not os.path.exists(ARQUIVO_FORNECEDORES):
                logger.error("❌ Arquivo de fornecedores não encontrado!")
                return None
            
            # Remover formatação do CNPJ/CPF
            cnpj_cpf_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf_formatado)))
            
            logger.debug(f"Buscando tipo_pessoa para: {cnpj_cpf_formatado}")
            logger.debug(f"Números: {cnpj_cpf_numeros}")
            
            wb = load_workbook(ARQUIVO_FORNECEDORES, data_only=True)
            ws = wb['Fornecedores']
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                
                # Coluna A: CNPJ/CPF
                # Coluna B: tipo_pessoa
                row_cnpj_cpf = row[0]
                row_tipo_pessoa = str(row[1]).strip().upper() if row[1] else None
                
                # Comparar apenas números
                row_cnpj_cpf_numeros = ''.join(filter(str.isdigit, str(row_cnpj_cpf)))
                
                if row_cnpj_cpf_numeros == cnpj_cpf_numeros:
                    logger.debug(f"✓ Fornecedor encontrado! Tipo: {row_tipo_pessoa}")
                    wb.close()
                    return row_tipo_pessoa
            
            wb.close()
            logger.error(f"❌ FORNECEDOR NÃO CADASTRADO: {cnpj_cpf_formatado}")
            return None  # Fornecedor não existe!
            
        except Exception as e:
            logger.error(f"❌ Erro ao buscar tipo_pessoa: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    def atualizar_lancamento(self, indice, novos_dados):
        """Atualiza os dados de um lançamento específico - VERSÃO FINAL COM VALIDAÇÃO"""
        try:
            logger.info("="*60)
            logger.info("CALLBACK: atualizar_lancamento")
            logger.info(f"Índice recebido: {indice}")
            logger.info(f"Tipo do índice: {type(indice)}")
            logger.info(f"Total de lançamentos disponíveis: {len(self.dados_para_incluir)}")
            
            # VALIDAÇÃO 1: Verificar se o índice é válido
            if not isinstance(indice, int):
                logger.error(f"✗ Índice não é inteiro: {indice} (tipo: {type(indice)})")
                return False
            
            if indice < 0 or indice >= len(self.dados_para_incluir):
                logger.error(f"✗ Índice fora do intervalo válido!")
                logger.error(f"  Índice: {indice}")
                logger.error(f"  Intervalo válido: 0 a {len(self.dados_para_incluir)-1}")
                return False
            
            logger.debug("✓ Índice válido")
            
            # VALIDAÇÃO 2: Verificar se há itens no tree
            todos_items = self.tree.get_children()
            logger.debug(f"Total de itens no tree: {len(todos_items)}")
            
            if indice >= len(todos_items):
                logger.error(f"✗ Índice maior que quantidade de itens no tree!")
                logger.error(f"  Índice: {indice}")
                logger.error(f"  Itens no tree: {len(todos_items)}")
                return False
            
            logger.debug("✓ Tree tem itens suficientes")
            
            # ============================================
            # ✅ VALIDAÇÃO CRÍTICA: Buscar tipo_pessoa na base
            # ============================================
            cnpj_cpf_formatado = novos_dados.get('cnpj_cpf', '')
            
            logger.debug(f"CNPJ/CPF recebido: {cnpj_cpf_formatado}")
            
            # Buscar tipo_pessoa na base de fornecedores
            tipo_pessoa = self.obter_tipo_pessoa_fornecedor(cnpj_cpf_formatado)
            
            # ============================================
            # SE NÃO ENCONTRAR = ERRO CRÍTICO
            # ============================================
            if tipo_pessoa is None:
                logger.error("="*60)
                logger.error("❌ ERRO CRÍTICO: FORNECEDOR NÃO CADASTRADO!")
                logger.error(f"CNPJ/CPF: {cnpj_cpf_formatado}")
                logger.error(f"Nome: {novos_dados.get('nome', 'N/A')}")
                logger.error("Este lançamento não pode ser atualizado pois o fornecedor não existe na base!")
                logger.error("="*60)
                
                # Mostrar mensagem ao usuário
                custom_messagebox(
                    "error",
                    "❌ Fornecedor Não Cadastrado",
                    f"ERRO CRÍTICO!\n\n"
                    f"O fornecedor não está cadastrado na base:\n\n"
                    f"📋 CNPJ/CPF: {cnpj_cpf_formatado}\n"
                    f"👤 Nome: {novos_dados.get('nome', 'N/A')}\n\n"
                    f"❌ Este lançamento não pode ser atualizado!\n"
                    f"❌ Cadastre o fornecedor antes de continuar!\n\n"
                    f"💡 Acesse: Menu Principal → Cadastro de Fornecedores"
                )
                
                return False
            
            logger.debug(f"✓ Tipo pessoa obtido da base: {tipo_pessoa}")
            
            # Remover formatação para formatar novamente
            cnpj_cpf_numeros = ''.join(filter(str.isdigit, cnpj_cpf_formatado))
            
            logger.debug(f"Formatando documento...")
            logger.debug(f"  Números: {cnpj_cpf_numeros}")
            logger.debug(f"  Tipo: {tipo_pessoa}")
            
            # Formatar com tipo_pessoa correto
            try:
                novos_dados['cnpj_cpf'] = formatar_documento(cnpj_cpf_numeros, tipo_pessoa)
                logger.debug(f"✓ CNPJ/CPF formatado: {novos_dados['cnpj_cpf']}")
            except Exception as e:
                logger.error(f"✗ Erro ao formatar documento: {str(e)}")
                # Se falhar, manter o valor original formatado
                novos_dados['cnpj_cpf'] = cnpj_cpf_formatado
            
            # Formatar observação
            novos_dados['observacao'] = novos_dados.get('observacao', '').upper()
            
            # ✅ IMPORTANTE: Preservar tipo_pessoa nos dados
            novos_dados['tipo_pessoa'] = tipo_pessoa
            logger.debug(f"✓ tipo_pessoa preservado nos dados: {tipo_pessoa}")
            
            # Obter item do tree
            logger.debug(f"Obtendo item {indice} do tree...")
            try:
                item = todos_items[indice]
                logger.debug(f"✓ Item obtido: {item}")
            except IndexError as e:
                logger.error(f"✗ Erro ao obter item do tree: {str(e)}")
                return False
            
            # Obter valores atuais (para preservar checkbox)
            logger.debug("Obtendo valores atuais do item...")
            try:
                valores_atuais = self.tree.item(item)['values']
                logger.debug(f"✓ Valores atuais obtidos: {len(valores_atuais)} campos")
            except Exception as e:
                logger.error(f"✗ Erro ao obter valores atuais: {str(e)}")
                return False
            
            # Montar novos valores
            logger.debug("Montando novos valores para o tree...")
            valores = (
                valores_atuais[0],  # Preservar checkbox
                novos_dados.get('data', ''),
                novos_dados.get('tp_desp', ''),
                novos_dados.get('cnpj_cpf', ''),
                novos_dados.get('nome', ''),
                novos_dados.get('referencia', ''),
                novos_dados.get('nf', ''),
                novos_dados.get('vr_unit', ''),
                novos_dados.get('dias', '1'),
                novos_dados.get('valor', ''),
                novos_dados.get('dt_vencto', ''),
                novos_dados.get('categoria', ''),
                novos_dados.get('forma_pagamento', ''),
                novos_dados.get('dados_bancarios', ''),
                novos_dados.get('observacao', '')
            )
            
            logger.debug(f"Valores montados: {len(valores)} campos")
            
            # Atualizar dados internos
            logger.debug(f"Atualizando dados_para_incluir no índice {indice}...")
            
            self.dados_para_incluir[indice] = novos_dados.copy()
            
            logger.debug(f"✓ Dados internos atualizados")
            
            # Atualizar tree
            logger.debug("Atualizando item no tree...")
            try:
                self.tree.item(item, values=valores)
                logger.debug("✓ Item do tree atualizado")
            except Exception as e:
                logger.error(f"✗ Erro ao atualizar tree: {str(e)}")
                return False
            
            # Atualizar resumo
            logger.debug("Atualizando resumo...")
            try:
                self.atualizar_resumo()
                logger.debug("✓ Resumo atualizado")
            except Exception as e:
                logger.error(f"✗ Erro ao atualizar resumo: {str(e)}")
            
            # Atualizar sistema principal
            logger.debug("Sincronizando com sistema principal...")
            try:
                self.sistema.dados_para_incluir = self.dados_para_incluir.copy()
                logger.debug("✓ Sistema principal sincronizado")
            except Exception as e:
                logger.error(f"✗ Erro ao sincronizar sistema: {str(e)}")
            
            # Salvar rascunho
            logger.debug("Salvando rascunho...")
            try:
                self.salvar_rascunho_imediatamente()
                logger.debug("✓ Rascunho salvo")
            except Exception as e:
                logger.error(f"✗ Erro ao salvar rascunho: {str(e)}")
            
            logger.info("✓ LANÇAMENTO ATUALIZADO COM SUCESSO!")
            logger.info("="*60)
            return True
            
        except Exception as e:
            logger.error("="*60)
            logger.error("ERRO CRÍTICO EM atualizar_lancamento")
            logger.error(f"Tipo: {type(e).__name__}")
            logger.error(f"Mensagem: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            logger.error("="*60)
            return False

    def salvar_na_planilha(self):
        """Salva os dados diretamente na planilha"""
        if not self.dados_para_incluir:
            self._dialogo_aberto = True
            custom_messagebox("warning", "Aviso", "Não há dados para salvar!")
            self._dialogo_aberto = False
            self.janela.lift()
            return

        try:
            self.sistema.dados_para_incluir = self.dados_para_incluir.copy()
            self._fechando = True
            
            if self.sistema:
                self.sistema.enviar_dados()
                
                try:
                    temp_file = os.path.join(os.path.expanduser("~"), "Desktop", 
                                            "backup_lancamentos.json")
                    if os.path.exists(temp_file):
                        os.remove(temp_file)
                        logger.debug("✅ Rascunho DELETADO após salvamento na planilha")
                except:
                    pass
                
                if self.janela and self.janela.winfo_exists():
                    self.janela.destroy()
            else:
                self._fechando = False
                self._dialogo_aberto = True
                custom_messagebox("error", "Erro", 
                                "Referência ao sistema principal não encontrada")
                self._dialogo_aberto = False
                self.janela.lift()

        except Exception as e:
            self._fechando = False
            self._dialogo_aberto = True
            custom_messagebox("error", "Erro", f"Erro ao salvar dados: {str(e)}")
            self._dialogo_aberto = False
            self.janela.lift()
            logger.debug(f"Erro detalhado ao salvar: {str(e)}")

    def atualizar_resumo(self):
        """Atualiza os totais e resumo"""
        items = self.tree.get_children()
        total_lancamentos = len(items)
        valor_total = 0
        
        for item in items:
            try:
                valor_total += float(self.tree.item(item)['values'][9])
            except (ValueError, TypeError, IndexError):
                pass
        
        self.lbl_total_lancamentos.config(text=f"Total de Lançamentos: {total_lancamentos}")
        self.lbl_valor_total.config(text=f"Valor Total: R$ {valor_total:,.2f}")
        self.atualizar_contador_selecionados()

    def get_dados_atualizados(self):
        """Retorna todos os dados atualizados"""
        return self.dados_para_incluir.copy()

    def carregar_rascunho(self):
        """Carrega dados do arquivo de backup - busca no Drive e no Desktop"""
        try:
            backups_encontrados = []

            # ── BUSCA 1: Google Drive (prioridade, igual ao verificar_dados_nao_salvos) ──
            try:
                pasta_backup = PASTA_CLIENTES / "Backups_Sistema"
                if pasta_backup.exists():
                    agora = datetime.now()
                    limite_tempo = agora - relativedelta(hours=24)

                    for arquivo_backup in pasta_backup.glob("backup_*.json"):
                        try:
                            data_modificacao = datetime.fromtimestamp(arquivo_backup.stat().st_mtime)
                            if data_modificacao >= limite_tempo:
                                with open(arquivo_backup, 'r', encoding='utf-8') as f:
                                    backup_data = json.load(f)

                                if backup_data.get('lancamentos') and len(backup_data['lancamentos']) > 0:
                                    backups_encontrados.append({
                                        'arquivo': arquivo_backup,
                                        'data': backup_data,
                                        'origem': 'Google Drive'
                                    })
                        except Exception as e:
                            logger.debug(f"Erro ao processar backup {arquivo_backup}: {str(e)}")
                            continue
            except Exception as e:
                logger.debug(f"Erro ao buscar backups no Google Drive: {str(e)}")

            # ── BUSCA 2: Desktop – formato novo (específico do cliente) ──
            if not backups_encontrados:
                try:
                    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                    cliente_ref = (
                        self.sistema.cliente_atual
                        if hasattr(self.sistema, 'cliente_atual') and self.sistema.cliente_atual
                        else None
                    )
                    candidatos = []

                    if cliente_ref:
                        candidatos.append(os.path.join(desktop, f"backup_{cliente_ref}.json"))

                    # Formato genérico antigo como último recurso
                    candidatos.append(os.path.join(desktop, "backup_lancamentos.json"))

                    for caminho in candidatos:
                        if os.path.exists(caminho):
                            data_modificacao = datetime.fromtimestamp(os.path.getmtime(caminho))
                            if (datetime.now() - data_modificacao).days < 1:
                                with open(caminho, 'r', encoding='utf-8') as f:
                                    backup_data = json.load(f)
                                if backup_data.get('lancamentos'):
                                    backups_encontrados.append({
                                        'arquivo': caminho,
                                        'data': backup_data,
                                        'origem': 'Desktop Local'
                                    })
                                    break   # Usa o primeiro válido encontrado
                except Exception as e:
                    logger.debug(f"Erro ao buscar backup no Desktop: {str(e)}")

            # ── Nenhum backup encontrado ──
            if not backups_encontrados:
                self._dialogo_aberto = True
                custom_messagebox("info", "📂 Rascunho",
                                "Nenhum rascunho encontrado\n(Google Drive ou Desktop).")
                self._dialogo_aberto = False
                self.janela.lift()
                return

            # ── Usa o backup mais recente ──
            backups_encontrados.sort(
                key=lambda x: datetime.fromisoformat(x['data']['data_sessao']),
                reverse=True
            )
            melhor = backups_encontrados[0]
            backup_data = melhor['data']
            origem = melhor['origem']

            data_backup = datetime.fromisoformat(backup_data['data_sessao'])
            cliente_backup = backup_data.get('cliente', '')
            total = backup_data.get('total_lancamentos', len(backup_data['lancamentos']))

            self._dialogo_aberto = True
            resposta = custom_messagebox(
                "yesno",
                "📂 Carregar Rascunho",
                f"Rascunho encontrado:\n\n"
                f"• Cliente: {cliente_backup}\n"
                f"• Lançamentos: {total}\n"
                f"• Salvo em: {data_backup.strftime('%d/%m/%Y às %H:%M')}\n"
                f"• Origem: {origem}\n\n"
                "Carregar estes dados?\n"
                "(Os dados atuais serão substituídos)"
            )
            self._dialogo_aberto = False

            if resposta:
                # Atualizar sistema principal
                self.sistema.dados_para_incluir = backup_data['lancamentos']
                self.sistema.cliente_atual = cliente_backup

                # Atualizar o próprio visualizador
                self.dados_para_incluir = backup_data['lancamentos'].copy()
                self.atualizar_dados(backup_data['lancamentos'])

                # Sincronizar combobox
                if hasattr(self.sistema, 'cliente_combobox'):
                    self.sistema.cliente_combobox.set(cliente_backup)
                    self.sistema.selecionar_cliente(None)

                # Remover backup após carga bem-sucedida
                try:
                    if origem == 'Google Drive':
                        melhor['arquivo'].unlink()
                    else:
                        os.remove(melhor['arquivo'])
                    logger.debug(f"✅ Backup removido após carga manual: {melhor['arquivo']}")
                except Exception as e:
                    logger.debug(f"⚠️ Erro ao remover backup após carga: {str(e)}")

                self._dialogo_aberto = True
                custom_messagebox("info", "✅ Rascunho Carregado",
                                f"Dados carregados com sucesso!\n"
                                f"{total} lançamentos carregados.\n"
                                f"Origem: {origem}")
                self._dialogo_aberto = False

            self.janela.lift()

        except Exception as e:
            self._dialogo_aberto = True
            custom_messagebox("error", "Erro", f"Erro ao carregar rascunho: {str(e)}")
            self._dialogo_aberto = False
            self.janela.lift()
            import traceback
            traceback.print_exc()

    def popular_tree(self, dados_lancamentos):
        """Popula a TreeView com os dados fornecidos"""
        try:
            self.dados_originais = dados_lancamentos.copy() if dados_lancamentos else []
            
            for item in self.tree.get_children():
                self.tree.delete(item)
            
            if not dados_lancamentos:
                self.atualizar_contador()
                return
            
            valor_total = 0
            for lancamento in dados_lancamentos:
                valores = (
                    '☐',
                    lancamento.get('data', ''),
                    lancamento.get('tp_desp', ''),
                    lancamento.get('cnpj_cpf', ''),
                    lancamento.get('nome', ''),
                    lancamento.get('referencia', ''),
                    lancamento.get('nf', ''),
                    lancamento.get('vr_unit', ''),
                    lancamento.get('dias', '1'),
                    lancamento.get('valor', ''),
                    lancamento.get('dt_vencto', ''),
                    lancamento.get('categoria', ''),
                    lancamento.get('forma_pagamento', ''),
                    lancamento.get('dados_bancarios', ''),
                    lancamento.get('observacao', '')
                )
                
                self.tree.insert('', 'end', values=valores)
                
                try:
                    valor_total += float(str(lancamento.get('valor', 0)).replace(',', '.'))
                except (ValueError, TypeError):
                    pass
            
            self.atualizar_contador()
            
        except Exception as e:
            logger.debug(f"Erro ao popular tree: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def remover_itens_especificos(self, indices_para_remover):
        """Remove itens específicos da TreeView e dos dados"""
        try:
            todos_items = self.tree.get_children()
            
            indices_validos = [idx for idx in indices_para_remover 
                            if 0 <= idx < len(todos_items)]
            
            if not indices_validos:
                return 0
            
            items_removidos = []
            for idx in sorted(indices_validos, reverse=True):
                if idx < len(todos_items):
                    item_id = todos_items[idx]
                    self.tree.delete(item_id)
                    items_removidos.append(idx)
            
            novos_dados = []
            for idx, dados in enumerate(self.dados_para_incluir):
                if idx not in indices_validos:
                    novos_dados.append(dados)
            
            self.dados_para_incluir = novos_dados
            
            if hasattr(self, 'dados_originais'):
                novos_dados_originais = []
                for idx, dados in enumerate(self.dados_originais):
                    if idx not in indices_validos:
                        novos_dados_originais.append(dados)
                self.dados_originais = novos_dados_originais
            
            self.atualizar_contador()
            
            return len(items_removidos)
            
        except Exception as e:
            logger.debug(f"Erro ao remover itens específicos: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return 0

    def atualizar_contador(self):
        """Atualiza o contador de registros e valor total"""
        try:
            qtd_registros = len(self.tree.get_children())
            valor_total = 0
            
            for item in self.tree.get_children():
                try:
                    valores = self.tree.item(item)['values']
                    valor_str = str(valores[9]).replace(',', '.')
                    valor_total += float(valor_str)
                except (ValueError, TypeError, IndexError):
                    continue
            
            if hasattr(self, 'lbl_total_lancamentos'):
                self.lbl_total_lancamentos.config(
                    text=f"Total de Lançamentos: {qtd_registros}"
                )
            
            if hasattr(self, 'lbl_valor_total'):
                self.lbl_valor_total.config(
                    text=f"Valor Total: R$ {valor_total:,.2f}"
                )
            
            if hasattr(self, 'janela') and self.janela:
                self.janela.title(f"Visualização de Lançamentos Pendentes - {qtd_registros} registros")
            
            self.atualizar_contador_selecionados()
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar contador: {str(e)}")

class EditorLancamento:
    def __init__(self, parent, dados, indice, callback_atualizacao):
        self.janela = tk.Toplevel(parent)
        self.janela.title("Editar Lançamento")
        self.janela.geometry("600x700")  # Aumentado para acomodar todos os campos
        
        self._fechando = False
        self.janela.protocol("WM_DELETE_WINDOW", self.on_close)
        self.janela.transient(parent)
        self.janela.grab_set()
        
        self.dados = dados
        self.indice = indice
        self.callback_atualizacao = callback_atualizacao
        
        # Frame principal com scrollbar
        canvas = tk.Canvas(self.janela)
        scrollbar = ttk.Scrollbar(self.janela, orient="vertical", command=canvas.yview)
        frame_scroll = ttk.Frame(canvas)
        
        frame_scroll.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=frame_scroll, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        frame = ttk.Frame(frame_scroll, padding="10")
        frame.pack(fill='both', expand=True)
        
        # Frame para dados do fornecedor (não editáveis)
        frame_fornecedor = ttk.LabelFrame(frame, text="Dados do Fornecedor (somente leitura)")
        frame_fornecedor.pack(fill='x', pady=5)
        
        # CNPJ/CPF
        ttk.Label(frame_fornecedor, text="CNPJ/CPF:").grid(row=0, column=0, sticky='w', padx=5, pady=2)
        self.cnpj_cpf = ttk.Entry(frame_fornecedor, state='readonly', width=30)
        self.cnpj_cpf.grid(row=0, column=1, sticky='ew', padx=5, pady=2)
        
        # Nome
        ttk.Label(frame_fornecedor, text="Nome:").grid(row=1, column=0, sticky='w', padx=5, pady=2)
        self.nome = ttk.Entry(frame_fornecedor, state='readonly', width=30)
        self.nome.grid(row=1, column=1, sticky='ew', padx=5, pady=2)
        
        # Categoria
        ttk.Label(frame_fornecedor, text="Categoria:").grid(row=2, column=0, sticky='w', padx=5, pady=2)
        self.categoria = ttk.Entry(frame_fornecedor, state='readonly', width=30)
        self.categoria.grid(row=2, column=1, sticky='ew', padx=5, pady=2)
        
        # Dados Bancários (editável apenas para este lançamento)
        ttk.Label(frame_fornecedor, text="Dados Bancários:").grid(row=3, column=0, sticky='w', padx=5, pady=2)
        self.dados_bancarios = ttk.Entry(frame_fornecedor, width=30)
        self.dados_bancarios.grid(row=3, column=1, sticky='ew', padx=5, pady=2)
        ttk.Label(frame_fornecedor, text="(altera só este lançamento, não o cadastro)",
                  foreground='gray', font=('TkDefaultFont', 7)).grid(row=4, column=1, sticky='w', padx=5)
        
        frame_fornecedor.columnconfigure(1, weight=1)
        
        # Frame para dados da despesa (EDITÁVEIS)
        frame_despesa = ttk.LabelFrame(frame, text="Dados da Despesa (editáveis)")
        frame_despesa.pack(fill='x', pady=5)
        
        row = 0
        
        # Data de Referência
        ttk.Label(frame_despesa, text="Data do Relatório:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.data_rel = DateEntry(frame_despesa, width=27, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_rel.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Tipo de Despesa
        ttk.Label(frame_despesa, text="Tipo Despesa:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.tp_desp = ttk.Entry(frame_despesa, width=30)
        self.tp_desp.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Referência
        ttk.Label(frame_despesa, text="Referência:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.referencia = ttk.Entry(frame_despesa, width=30)
        self.referencia.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1

        # Etapa da Obra — agora com autocompletar, vinculado à lista real
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        from src.widgets.combobox_autocompletar import ComboboxAutocompletar

        ttk.Label(frame_despesa, text="Etapa da Obra:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        self.etapa_obra = ComboboxAutocompletar(
            frame_despesa,
            values=etapas_obra,
            config_key='etapas_obra',
            config_manager=GerenciadorConfiguracoes,
            width=28,
            state='normal'
        )
        self.etapa_obra.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1

        # Insumo — agora com autocompletar, vinculado à lista real
        ttk.Label(frame_despesa, text="Insumo:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        insumos = GerenciadorConfiguracoes.get_insumos()
        self.insumo = ComboboxAutocompletar(
            frame_despesa,
            values=insumos,
            config_key='insumos',
            config_manager=GerenciadorConfiguracoes,
            width=28,
            state='normal'
        )
        self.insumo.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1

        # NF
        ttk.Label(frame_despesa, text="NF:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.nf = ttk.Entry(frame_despesa, width=30)
        self.nf.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Valor Unitário
        ttk.Label(frame_despesa, text="Valor Unitário:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.vr_unit = ttk.Entry(frame_despesa, width=30)
        self.vr_unit.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Dias
        ttk.Label(frame_despesa, text="Dias:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.dias = ttk.Entry(frame_despesa, width=30)
        self.dias.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Valor Total (calculado automaticamente)
        ttk.Label(frame_despesa, text="Valor Total:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.valor = ttk.Entry(frame_despesa, state='readonly', width=30)
        self.valor.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Data de Vencimento
        ttk.Label(frame_despesa, text="Data Vencimento:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.dt_vencto = DateEntry(frame_despesa, width=27, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.dt_vencto.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Forma de Pagamento
        ttk.Label(frame_despesa, text="Forma de Pagamento:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.forma_pagamento = ttk.Combobox(frame_despesa, values=['PIX', 'TED', 'DINHEIRO'], 
                                            state='readonly', width=27)
        self.forma_pagamento.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        row += 1
        
        # Observação
        ttk.Label(frame_despesa, text="Observação:").grid(row=row, column=0, sticky='w', padx=5, pady=2)
        self.observacao = ttk.Entry(frame_despesa, width=30)
        self.observacao.grid(row=row, column=1, sticky='ew', padx=5, pady=2)
        
        frame_despesa.columnconfigure(1, weight=1)
        
        # Botões
        frame_botoes = ttk.Frame(frame)
        frame_botoes.pack(fill='x', pady=10)
        
        ttk.Button(frame_botoes, text="💾 Salvar", command=self.salvar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="❌ Cancelar", command=self.on_close).pack(side='left', padx=5)
        
        # Preencher dados existentes
        self.preencher_dados()
        
        # Vincular eventos para cálculo automático
        self.vr_unit.bind('<KeyRelease>', self.calcular_valor_total)
        self.dias.bind('<KeyRelease>', self.calcular_valor_total)
        
        # Habilitar scroll com mouse
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def on_close(self):
        """Fecha a janela de forma segura"""
        self._fechando = True
        self.janela.grab_release()
        self.janela.destroy()
        
    def preencher_dados(self):
        """Preenche os campos com os dados atuais - VERSÃO COMPLETA"""
        try:
            logger.debug("Preenchendo dados do editor...")
            
            # Campos readonly do fornecedor
            self.cnpj_cpf.config(state='normal')
            self.cnpj_cpf.delete(0, tk.END)
            self.cnpj_cpf.insert(0, self.dados.get('cnpj_cpf', ''))
            self.cnpj_cpf.config(state='readonly')
            
            self.nome.config(state='normal')
            self.nome.delete(0, tk.END)
            self.nome.insert(0, self.dados.get('nome', ''))
            self.nome.config(state='readonly')
            
            self.categoria.config(state='normal')
            self.categoria.delete(0, tk.END)
            self.categoria.insert(0, self.dados.get('categoria', ''))
            self.categoria.config(state='readonly')
            
            self.dados_bancarios.delete(0, tk.END)
            self.dados_bancarios.insert(0, self.dados.get('dados_bancarios', ''))
            
            # Campos editáveis da despesa
            try:
                data_str = self.dados.get('data', '')
                if data_str:
                    self.data_rel.set_date(datetime.strptime(data_str, '%d/%m/%Y'))
                    logger.debug(f"Data relatório preenchida: {data_str}")
            except Exception as e:
                logger.warning(f"Erro ao preencher data relatório: {e}")
            
            self.tp_desp.insert(0, self.dados.get('tp_desp', ''))
            self.referencia.insert(0, self.dados.get('referencia', ''))
            
            # ✅ CORREÇÃO: Preencher etapa_obra e insumo
            self.etapa_obra.insert(0, self.dados.get('etapa_obra', ''))
            self.insumo.insert(0, self.dados.get('insumo', ''))
            
            self.nf.insert(0, self.dados.get('nf', ''))
            self.vr_unit.insert(0, self.dados.get('vr_unit', ''))
            self.dias.insert(0, str(self.dados.get('dias', '1')))
            
            self.valor.config(state='normal')
            self.valor.delete(0, tk.END)
            self.valor.insert(0, self.dados.get('valor', ''))
            self.valor.config(state='readonly')
            
            try:
                dt_vencto_str = self.dados.get('dt_vencto', '')
                if dt_vencto_str:
                    self.dt_vencto.set_date(datetime.strptime(dt_vencto_str, '%d/%m/%Y'))
                    logger.debug(f"Data vencimento preenchida: {dt_vencto_str}")
            except Exception as e:
                logger.warning(f"Erro ao preencher data vencimento: {e}")
            
            self.forma_pagamento.set(self.dados.get('forma_pagamento', ''))
            self.observacao.insert(0, self.dados.get('observacao', ''))
            
            logger.debug("✓ Dados preenchidos com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao preencher dados: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())

    def atualizar_dados_bancarios(self, event=None):
        """Atualiza os dados bancários baseado no tipo de despesa e forma de pagamento"""
        cnpj_cpf = self.campos_fornecedor['cnpj_cpf'].get().strip()

        if not cnpj_cpf:  # Se não houver fornecedor selecionado
            return
        
        forma_pagamento = self.forma_pagamento_var.get()
        
        try:
            # Usar a função centralizada em utils
            from src.config.utils import buscar_dados_bancarios_fornecedor
            dados_bancarios = buscar_dados_bancarios_fornecedor(cnpj_cpf, forma_pagamento)
        except ImportError:
            # Implementação alternativa se a função não estiver disponível
            fornecedor_completo = self.buscar_fornecedor_completo(cnpj_cpf)
            if not fornecedor_completo:
                return
            
            if forma_pagamento == "DINHEIRO":
                dados_bancarios = "PAGAMENTO EM DINHEIRO"
            elif forma_pagamento == "PIX" and fornecedor_completo['chave_pix']:
                dados_bancarios = f"PIX: {fornecedor_completo['chave_pix']}"
            else:
                # Estrutura para TED
                dados_ted = []
                if fornecedor_completo['banco']: dados_ted.append(str(fornecedor_completo['banco']))
                if fornecedor_completo['op']: dados_ted.append(str(fornecedor_completo['op']))
                if fornecedor_completo['agencia']: dados_ted.append(str(fornecedor_completo['agencia']))
                if fornecedor_completo['conta']: dados_ted.append(str(fornecedor_completo['conta']))
                # SEMPRE adicionar o CNPJ/CPF para TED
                dados_ted.append(str(fornecedor_completo['cnpj_cpf']))
                
                dados_bancarios = ' - '.join(filter(None, dados_ted))

            if dados_bancarios.strip() in ['', ' - ']:
                dados_bancarios = ''

        # Atualizar o campo
        self.campos_fornecedor['dados_bancarios'].config(state='normal')
        self.campos_fornecedor['dados_bancarios'].delete(0, tk.END)
        self.campos_fornecedor['dados_bancarios'].insert(0, dados_bancarios)
        self.campos_fornecedor['dados_bancarios'].config(state='readonly')
        
        
    def calcular_valor_total(self, event=None):
        """Calcula o valor total baseado no valor unitário e dias"""
        try:
            vr_unit = float(self.vr_unit.get().replace(',', '.'))
            dias = float(self.dias.get() or 1)
            valor_total = vr_unit * dias
            
            self.valor.config(state='normal')
            self.valor.delete(0, tk.END)
            self.valor.insert(0, f"{valor_total:.2f}")
            self.valor.config(state='readonly')
            
        except (ValueError, AttributeError):
            self.valor.config(state='normal')
            self.valor.delete(0, tk.END)
            self.valor.config(state='readonly')
            
    def salvar(self):
        """Salva as alterações e fecha a janela - VERSÃO COM LOGS DETALHADOS"""
        try:
            logger.info("="*60)
            logger.info("INICIANDO SALVAMENTO DE EDIÇÃO INDIVIDUAL")
            logger.info(f"Índice do lançamento: {self.indice}")
            
            # Validar campos obrigatórios
            campos_obrigatorios = {
                'tp_desp': self.tp_desp.get(),
                'referencia': self.referencia.get(),
                'vr_unit': self.vr_unit.get()
            }
            
            logger.debug("Validando campos obrigatórios...")
            campos_vazios = [nome for nome, valor in campos_obrigatorios.items() if not valor]
            
            if campos_vazios:
                logger.error(f"✗ Campos obrigatórios vazios: {campos_vazios}")
                custom_messagebox("error", "Erro", 
                                f"Preencha todos os campos obrigatórios:\n\n" +
                                "\n".join(f"• {c}" for c in campos_vazios))
                return
            
            logger.debug("✓ Campos obrigatórios preenchidos")
            
            # Validar datas
            logger.debug("Validando datas...")
            try:
                data_rel_str = self.data_rel.get()
                dt_vencto_str = self.dt_vencto.get()
                
                logger.debug(f"  Data Relatório: {data_rel_str}")
                logger.debug(f"  Data Vencimento: {dt_vencto_str}")
                
                datetime.strptime(data_rel_str, '%d/%m/%Y')
                datetime.strptime(dt_vencto_str, '%d/%m/%Y')
                
                logger.debug("✓ Datas válidas")
                
            except ValueError as ve:
                logger.error(f"✗ Data inválida: {str(ve)}")
                custom_messagebox("error", "Erro", 
                                "Data inválida! Use o formato DD/MM/AAAA")
                return
            
            # Validar dias
            try:
                dias_valor = float(self.dias.get().replace(',', '.') if self.dias.get() else 1)
                if dias_valor <= 0:
                    raise ValueError("Dias deve ser maior que zero")
                logger.debug(f"✓ Dias válido: {dias_valor}")
            except ValueError as ve:
                logger.error(f"✗ Valor de dias inválido: {str(ve)}")
                custom_messagebox("error", "Erro", "Valor de 'Dias' inválido!")
                return
            
            # Montar dados atualizados
            logger.debug("Montando dados atualizados...")
            dados_atualizados = {
                'data': self.data_rel.get(),
                'tp_desp': self.tp_desp.get(),
                'cnpj_cpf': self.dados['cnpj_cpf'],
                'nome': self.dados['nome'],
                'forma_pagamento': self.forma_pagamento.get(),
                'referencia': self.referencia.get(),
                'etapa_obra': self.etapa_obra.get(),
                'insumo': self.insumo.get(),
                'nf': self.nf.get(),
                'vr_unit': self.vr_unit.get(),
                'dias': dias_valor,
                'valor': self.valor.get(),
                'dt_vencto': self.dt_vencto.get(),
                'categoria': self.dados['categoria'],
                'dados_bancarios': self.dados_bancarios.get(),
                'observacao': self.observacao.get().upper()
            }
            
            logger.info("Dados para atualização:")
            for campo, valor in dados_atualizados.items():
                logger.info(f"  {campo}: {valor}")
            
            # Chamar callback de atualização
            logger.debug("Chamando callback de atualização...")
            resultado = self.callback_atualizacao(self.indice, dados_atualizados)
            
            if resultado:
                logger.info("✓ EDIÇÃO SALVA COM SUCESSO!")
                logger.info("="*60)
                custom_messagebox("info", "Sucesso", "Alterações salvas com sucesso!")
                self.on_close()
            else:
                logger.error("✗ Callback retornou False - falha ao salvar")
                logger.error("="*60)
                custom_messagebox("error", "Erro", "Não foi possível salvar as alterações!")
            
        except Exception as e:
            logger.error("="*60)
            logger.error("ERRO CRÍTICO NO SALVAMENTO")
            logger.error(f"Tipo: {type(e).__name__}")
            logger.error(f"Mensagem: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            logger.error("="*60)
            
            custom_messagebox("error", "Erro", 
                            f"Erro ao salvar alterações:\n\n{str(e)}\n\n"
                            f"Verifique os logs para mais detalhes.")


class EditorEmMassa:
    """Editor para alteração em massa de lançamentos marcados"""
    
    def __init__(self, parent, dados_selecionados, indices_selecionados, callback_atualizacao):
        self.janela = tk.Toplevel(parent)
        self.janela.title(f"Edição em Massa - {len(indices_selecionados)} lançamentos")
        self.janela.geometry("500x500")
        
        # Gerenciamento de foco
        self._fechando = False
        self.janela.protocol("WM_DELETE_WINDOW", self.on_close)
        self.janela.transient(parent)
        self.janela.grab_set()
        
        self.dados_selecionados = dados_selecionados
        self.indices_selecionados = indices_selecionados
        self.callback_atualizacao = callback_atualizacao
        
        self._criar_interface()
    
    def _criar_interface(self):
        frame = ttk.Frame(self.janela, padding="10")
        frame.pack(fill='both', expand=True)
        
        info_frame = ttk.LabelFrame(frame, text="Informações")
        info_frame.pack(fill='x', pady=5)
        
        ttk.Label(info_frame, 
                 text=f"Você está editando {len(self.indices_selecionados)} lançamentos simultaneamente.",
                 font=('TkDefaultFont', 9, 'bold')).pack(padx=10, pady=5)
        ttk.Label(info_frame, 
                 text="Marque apenas os campos que deseja alterar.",
                 foreground='blue').pack(padx=10, pady=2)
        
        campos_frame = ttk.LabelFrame(frame, text="Campos para Edição em Massa")
        campos_frame.pack(fill='both', expand=True, pady=10)
        
        self.campos_vars = {}
        self.campos_widgets = {}
        
        # TODOS OS 7 CAMPOS
        self._criar_campo_checkbox(campos_frame, 0, "data_rel", "Data do Relatório:", 
                                   DateEntry, date_pattern='dd/mm/yyyy', locale='pt_BR', width=20)
        
        self._criar_campo_checkbox(campos_frame, 1, "tp_desp", "Tipo de Despesa:", 
                                   ttk.Entry, width=30)
        
        self._criar_campo_checkbox(campos_frame, 2, "referencia", "Referência:", 
                                   ttk.Entry, width=30)
        
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        from src.widgets.combobox_autocompletar import ComboboxAutocompletar
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        self._criar_campo_checkbox(campos_frame, 3, "etapa_obra", "Etapa da Obra:",
                                   ComboboxAutocompletar, values=etapas_obra,
                                   config_key='etapas_obra',
                                   config_manager=GerenciadorConfiguracoes,
                                   width=28)
        
        self._criar_campo_checkbox(campos_frame, 4, "dt_vencto", "Data de Vencimento:", 
                                   DateEntry, date_pattern='dd/mm/yyyy', locale='pt_BR', width=20)
        
        valor_bancario_inicial = (self.dados_selecionados[0].get('dados_bancarios', '') 
                                  if self.dados_selecionados else '')
        self._criar_campo_checkbox(campos_frame, 5, "dados_bancarios", "Dados Bancários:", 
                                   ttk.Entry, width=30, valor_inicial=valor_bancario_inicial)
        
        ttk.Label(campos_frame, 
                 text="⚠️ Altera apenas os lançamentos marcados — não altera o cadastro do fornecedor.",
                 foreground='gray', font=('TkDefaultFont', 7)).grid(row=6, column=0, columnspan=3, 
                                                                     sticky='w', padx=5, pady=(0,5))
        
        # Frame de atalhos
        atalhos_frame = ttk.Frame(campos_frame)
        atalhos_frame.grid(row=7, column=0, columnspan=3, pady=10, sticky='ew')
        
        ttk.Label(atalhos_frame, text="Marcar:").pack(side='left', padx=5)
        ttk.Button(atalhos_frame, text="✓ Todos os Campos", 
                  command=self.marcar_todos).pack(side='left', padx=2)
        ttk.Button(atalhos_frame, text="✗ Nenhum Campo", 
                  command=self.desmarcar_todos).pack(side='left', padx=2)
        
        # Botões de ação
        botoes_frame = ttk.Frame(frame)
        botoes_frame.pack(fill='x', pady=10)
        
        ttk.Button(botoes_frame, text="💾 Aplicar Alterações", 
                  command=self.aplicar_alteracoes).pack(side='left', padx=5)
        ttk.Button(botoes_frame, text="❌ Cancelar", 
                  command=self.on_close).pack(side='left', padx=5)
        
        ttk.Label(botoes_frame, 
                 text="⚠️ As alterações serão aplicadas imediatamente",
                 foreground='red', font=('TkDefaultFont', 8)).pack(side='right', padx=10)
    
    def _criar_campo_checkbox(self, parent, row, nome_campo, label, widget_class, 
                               valor_inicial=None, **widget_kwargs):
        """Cria um campo com checkbox de habilitação, opcionalmente pré-preenchido"""
        var = tk.BooleanVar(value=False)
        self.campos_vars[nome_campo] = var
        
        chk = ttk.Checkbutton(parent, variable=var, 
                             command=lambda: self._toggle_campo(nome_campo))
        chk.grid(row=row, column=0, padx=5, pady=5)
        
        lbl = ttk.Label(parent, text=label, state='disabled')
        lbl.grid(row=row, column=1, sticky='w', padx=5, pady=5)
        
        # Criar o widget
        if widget_class == DateEntry:
            widget = widget_class(parent, **widget_kwargs)
            # ✅ CORREÇÃO: Não usar widget._entry diretamente
        elif widget_class == ttk.Combobox:
            widget = widget_class(parent, **widget_kwargs)
        else:
            widget = widget_class(parent, **widget_kwargs)
        
        widget.grid(row=row, column=2, padx=5, pady=5, sticky='ew')
        
        # Pré-preencher ANTES de desabilitar (Tcl bloqueia insert() em widget disabled)
        if valor_inicial:
            try:
                if isinstance(widget, DateEntry):
                    widget.set_date(datetime.strptime(valor_inicial, '%d/%m/%Y'))
                else:
                    widget.insert(0, valor_inicial)
            except Exception as e:
                logger.debug(f"Não foi possível pré-preencher '{nome_campo}': {e}")
        
        widget.config(state='disabled')
        
        self.campos_widgets[nome_campo] = {'label': lbl, 'widget': widget}
        parent.columnconfigure(2, weight=1)
    
    def _toggle_campo(self, nome_campo):
        """Habilita/desabilita um campo baseado no checkbox"""
        habilitado = self.campos_vars[nome_campo].get()
        estado = 'normal' if habilitado else 'disabled'
        
        self.campos_widgets[nome_campo]['label'].config(state=estado)
        
        widget = self.campos_widgets[nome_campo]['widget']
        
        # Tratamento especial para cada tipo
        if isinstance(widget, DateEntry):
            if habilitado:
                widget.config(state='normal')
                # ✅ CORREÇÃO: Acessar entry interno de forma segura
                try:
                    for child in widget.winfo_children():
                        if isinstance(child, tk.Entry):
                            child.config(state='normal')
                            break
                except:
                    pass
            else:
                widget.config(state='disabled')
        elif isinstance(widget, ComboboxAutocompletar):
            # Precisa ficar 'normal' (não 'readonly'), senão trava a
            # digitação livre e a função de adicionar item novo.
            widget.config(state=estado)
        elif isinstance(widget, ttk.Combobox):
            if habilitado:
                widget.config(state='readonly')
            else:
                widget.config(state='disabled')
        else:
            widget.config(state=estado)
    
    def marcar_todos(self):
        """Marca todos os checkboxes e habilita todos os campos"""
        for nome_campo in self.campos_vars:
            self.campos_vars[nome_campo].set(True)
            self._toggle_campo(nome_campo)
    
    def desmarcar_todos(self):
        """Desmarca todos os checkboxes e desabilita todos os campos"""
        for nome_campo in self.campos_vars:
            self.campos_vars[nome_campo].set(False)
            self._toggle_campo(nome_campo)
    
    def aplicar_alteracoes(self):
        """Aplica as alterações em todos os lançamentos marcados - VERSÃO COM LOGS"""
        try:
            logger.info("="*60)
            logger.info("INICIANDO EDIÇÃO EM MASSA")
            logger.info(f"Quantidade de lançamentos: {len(self.indices_selecionados)}")
            
            try:
                from src.config.dialogs import custom_messagebox
            except ImportError:
                from config.dialogs import custom_messagebox
            
            campos_marcados = [campo for campo, var in self.campos_vars.items() if var.get()]
            
            logger.info(f"Campos marcados para edição: {campos_marcados}")
            
            if not campos_marcados:
                logger.warning("Nenhum campo marcado para edição")
                custom_messagebox("warning", "⚠️ Atenção", 
                                "Você precisa marcar pelo menos um campo para editar!")
                return
            
            qtd = len(self.indices_selecionados)
            
            traducao_campos = {
                'data_rel': 'Data do Relatório',
                'tp_desp': 'Tipo de Despesa',
                'referencia': 'Referência',
                'etapa_obra': 'Etapa da Obra',
                'dt_vencto': 'Data de Vencimento',
                'dados_bancarios': 'Dados Bancários',
                'forma_pagamento': 'Forma de Pagamento',
                'observacao': 'Observação'
            }
            
            campos_texto = "\n• ".join([traducao_campos.get(c, c) for c in campos_marcados])
            
            resposta = custom_messagebox("yesno", 
                "⚠️ Confirmar Edição em Massa",
                f"Você está prestes a alterar {qtd} lançamentos!\n\n"
                f"Campos que serão alterados:\n• {campos_texto}\n\n"
                f"Esta operação não pode ser desfeita.\n\n"
                f"Confirma a alteração?")
            
            if not resposta:
                logger.info("Edição em massa CANCELADA pelo usuário")
                return
            
            # Coletar valores
            logger.debug("Coletando valores dos campos...")
            valores_alteracao = {}
            for campo in campos_marcados:
                widget = self.campos_widgets[campo]['widget']
                
                if isinstance(widget, DateEntry):
                    valores_alteracao[campo] = widget.get()
                    logger.debug(f"  {campo}: {valores_alteracao[campo]} (DateEntry)")
                elif isinstance(widget, (ttk.Entry, ttk.Combobox)):
                    valores_alteracao[campo] = widget.get()
                    logger.debug(f"  {campo}: {valores_alteracao[campo]} (Entry/Combo)")
            
            alteracoes_realizadas = 0
            erros = []
            
            logger.info("Aplicando alterações nos lançamentos...")
            
            for idx, dados_originais in zip(self.indices_selecionados, self.dados_selecionados):
                try:
                    logger.debug(f"Processando lançamento índice {idx}...")
                    
                    dados_atualizados = dados_originais.copy()
                    
                    for campo, valor in valores_alteracao.items():
                        if campo == 'data_rel':
                            dados_atualizados['data'] = valor
                            logger.debug(f"  Atualizando 'data' para: {valor}")
                        else:
                            dados_atualizados[campo] = valor
                            logger.debug(f"  Atualizando '{campo}' para: {valor}")
                    
                    if self.callback_atualizacao(idx, dados_atualizados):
                        alteracoes_realizadas += 1
                        logger.debug(f"  ✓ Lançamento {idx} atualizado")
                    else:
                        erros.append(f"Lançamento {idx+1}")
                        logger.error(f"  ✗ Falha ao atualizar lançamento {idx}")
                        
                except Exception as e:
                    erro_msg = f"Lançamento {idx+1}: {str(e)}"
                    erros.append(erro_msg)
                    logger.error(f"  ✗ Erro: {erro_msg}")
            
            logger.info(f"Edição concluída: {alteracoes_realizadas} sucessos, {len(erros)} erros")
            logger.info("="*60)
            
            if alteracoes_realizadas > 0:
                mensagem = f"✅ {alteracoes_realizadas} lançamentos alterados com sucesso!"
                
                if erros:
                    mensagem += f"\n\n⚠️ {len(erros)} lançamentos com erro:\n" + "\n".join(erros[:5])
                    if len(erros) > 5:
                        mensagem += f"\n... e mais {len(erros)-5} erros"
                
                custom_messagebox("info", "Resultado da Edição em Massa", mensagem)
                self.on_close()
            else:
                custom_messagebox("error", "Erro", 
                                "Nenhuma alteração foi realizada.\n\n" + 
                                "Erros:\n" + "\n".join(erros[:10]))
                
        except Exception as e:
            logger.error("="*60)
            logger.error("ERRO CRÍTICO NA EDIÇÃO EM MASSA")
            logger.error(f"Tipo: {type(e).__name__}")
            logger.error(f"Mensagem: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            logger.error("="*60)
            
            custom_messagebox("error", "Erro", f"Erro ao aplicar alterações: {str(e)}")
    
    def on_close(self):
        """Fecha a janela de forma segura"""
        self._fechando = True
        self.janela.grab_release()
        self.janela.destroy()

class SistemaEntradaDados:

    def atualizar_combos_configuracoes(self):
        """Atualiza os valores das Comboboxes baseados nas configurações"""
        if 'categoria' in self.campos_fornecedor and isinstance(self.campos_fornecedor['categoria'], ttk.Combobox):
            categorias = get_categorias_fornecedor()
            self.campos_fornecedor['categoria']['values'] = categorias
            # Define o primeiro valor como padrão se houver categorias
            if categorias:
                self.campos_fornecedor['categoria'].set(categorias[0])
            
    def __init__(self, parent=None):
        logger.debug("Inicializando SistemaEntradaDados...")
        self._encerrando = False

        if parent:
            self.root = tk.Toplevel(parent)
            self.menu_principal = parent
        else:
            self.root = tk.Tk()
            self.menu_principal = None
            
        configurar_janela(self.root, "Sistema de Entrada de Dados")

        self.root.protocol("WM_DELETE_WINDOW", self.sair_sistema)
        logger.debug("✅ Protocolo de fechamento configurado")

        self.dados_para_incluir = []
        self.data_rel = None
        self.cliente_atual = None
        self.visualizador = None
        self._gestor_parcelas = None  # Inicializa como None
        self.gerenciador_lancamentos = None
        self.gerenciador_agenda = None 
        self.cache_fornecedores = CacheFornecedores()

        # Inicializar a variável de forma de pagamento
        self.forma_pagamento_var = tk.StringVar(value="PIX")
            
        # Frame temporário para criar os entries
        temp_frame = ttk.Frame(self.root)

        # Criação dos campos_fornecedor e campos_despesa
        self.campos_fornecedor = {
            'cnpj_cpf': tk.Entry(temp_frame),
            'nome': tk.Entry(temp_frame),
            'categoria': tk.Entry(temp_frame),
            'dados_bancarios': tk.Entry(temp_frame)
        }

        self.campos_despesa = {
            'tp_desp': tk.Entry(temp_frame),
            'referencia': tk.Entry(temp_frame),
            'nf': tk.Entry(temp_frame),
            'vr_unit': tk.Entry(temp_frame),
            'dias': tk.Entry(temp_frame),
            'valor': tk.Entry(temp_frame),
            'dt_vencto': tk.Entry(temp_frame),
            'observacao': tk.Entry(temp_frame)
        }

        self.importador_medicoes = ImportadorMedicoes(self)  

        self.atualizar_combos_configuracoes()
            
        # Configurar interface
        self.setup_gui()
        # self.configurar_todos_calendarios()

        # Adicionar estas linhas para configurar cada aba explicitamente
        logger.debug("Configurando aba de seleção...")
        self.setup_aba_selecao()
        logger.debug("Configurando aba de fornecedor...")
        self.setup_aba_fornecedor()
        logger.debug("Configurando aba de dados...")
        self.setup_aba_dados()

       # Configurar sistema de backup automático
        logger.debug("Configurando sistema de backup...")
        
        # Verificar dados não salvos após 1 segundo (para interface carregar)
        self.root.after(1000, self.verificar_dados_nao_salvos)
        
        # Configurar proteções
        self.configurar_protecoes()

        # Configurar auto-salvamento
        self.configurar_auto_salvamento()
        
        logger.debug("Sistema de backup configurado ✅")

        # Inicializar sistema de materiais
        self.integrador_materiais = inicializar_sistema_materiais_completo(self)
        
        # Inicializar sistema NFe:
        try:
            from src.nfe.extensao_sistema_hibrido import inicializar_sistema_nfe_estendido
            inicializar_sistema_nfe_estendido(self)
        except Exception as e:
            logger.debug(f"⚠️ Sistema NFe estendido não carregado: {e}")
            # Fallback para sistema original
            try:
                from src.nfe.sistema_hibrido_nfe import inicializar_sistema_nfe_hibrido
                inicializar_sistema_nfe_hibrido(self)
                logger.debug("⚠️ Usando sistema NFe original (sem extensão)")
            except Exception as e2:
                logger.debug(f"⚠️ Sistema NFe não carregado: {e2}")

        if hasattr(self, 'configurar_certificado_rapido'):
            logger.debug("✅ Certificado A1 disponível!")
        else:
            logger.debug("❌ Certificado A1 NÃO disponível")

        # Verificação automática do certificado A1
        try:
            from teste_certificado_automatico import verificar_certificado_a1_automatico
            verificar_certificado_a1_automatico(self)
        except Exception as e:
            logger.debug(f"Erro na verificação do certificado: {e}")

        # Adicionar métodos de interface
        try:
            from teste_certificado_automatico import (
                criar_botao_teste_certificado,
                configurar_certificado_interface,
                testar_certificado_interface,
                consultar_nfe_interface,
                processar_nfe_consultada
            )
            
            self.criar_botao_teste_certificado = criar_botao_teste_certificado.__get__(self)
            self.configurar_certificado_interface = configurar_certificado_interface.__get__(self)
            self.testar_certificado_interface = testar_certificado_interface.__get__(self)
            self.consultar_nfe_interface = consultar_nfe_interface.__get__(self)
            self.processar_nfe_consultada = processar_nfe_consultada.__get__(self)
            
        except Exception as e:
            logger.debug(f"Erro ao adicionar métodos de interface: {e}")
        
        logger.debug("Finalizada inicialização do sistema")

    def setup_gui(self):
        logger.debug("Iniciando setup_gui...")
        
        # Remover notebook existente se houver
        for widget in self.root.winfo_children():
            if isinstance(widget, ttk.Notebook):
                logger.debug("Notebook existente encontrado e será removido")
                widget.destroy()
        
        # Frame principal com abas
        self.notebook = ttk.Notebook(self.root)
        logger.debug("Novo Notebook criado")
        self.notebook.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Criar abas
        self.aba_selecao = ttk.Frame(self.notebook)
        self.aba_fornecedor = ttk.Frame(self.notebook)
        self.aba_dados = ttk.Frame(self.notebook)
        
        logger.debug("Adicionando abas ao Notebook")
        self.notebook.add(self.aba_selecao, text='Seleção de Cliente')
        self.notebook.add(self.aba_fornecedor, text='Fornecedor')
        self.notebook.add(self.aba_dados, text='Entrada de Dados')

        logger.debug("Setup_gui concluído")

    @property
    def gestor_parcelas(self):
        """Getter para gestor_parcelas - cria apenas quando necessário"""
        if self._gestor_parcelas is None:
            logger.debug("Criando nova instância do GestorParcelas")  # Debug
            self._gestor_parcelas = GestorParcelas(self)
        return self._gestor_parcelas

    @gestor_parcelas.setter
    def gestor_parcelas(self, valor):
        """Setter para gestor_parcelas"""
        self._gestor_parcelas = valor        

    def voltar_menu(self):
        """
        Retorna ao menu principal com restauração completa
        """
        try:
            # Verificar dados não salvos
            if self.dados_para_incluir and custom_messagebox("yesno", 
                "Confirmação", 
                "Existem dados não salvos. Deseja salvá-los antes de sair?"):
                self.enviar_dados()
            
            logger.info("Voltando ao menu principal")
            
            menu_ref = self.menu_principal
            
            # ============================================================
            # FECHAR VISUALIZADOR SE ESTIVER ABERTO
            # ============================================================
            if hasattr(self, 'visualizador') and self.visualizador:
                try:
                    if hasattr(self.visualizador, 'janela') and self.visualizador.janela.winfo_exists():
                        self.visualizador._fechando = True
                        self.visualizador.janela.destroy()
                        logger.info("✅ Visualizador fechado")
                except Exception as e:
                    logger.warning(f"⚠️ Erro ao fechar visualizador: {e}")
            
            # ============================================================
            # DESTRUIR JANELA ATUAL COM SEGURANÇA
            # ============================================================
            try:
                # Cancelar quaisquer callbacks pendentes
                for after_id in self.root.tk.call('after', 'info'):
                    try:
                        self.root.after_cancel(after_id)
                    except:
                        pass
                
                # self.root.quit()  # ✅ IMPORTANTE: Sair do mainloop desta janela
                self.root.destroy()
                logger.info("✅ Janela do Sistema de Entrada destruída")
                
            except Exception as e:
                logger.error(f"❌ Erro ao destruir janela: {e}")
            
            # ============================================================
            # RESTAURAR MENU PRINCIPAL
            # ============================================================
            if menu_ref and menu_ref.winfo_exists():
                try:
                    geometria = getattr(menu_ref, '_geometria_original', "900x700+100+50")
                    logger.info(f"📐 Restaurando geometria: {geometria}")
                    
                    # ESTRATÉGIA: Forçar processamento em cada etapa
                    menu_ref.withdraw()  # Garantir que está oculto
                    menu_ref.update_idletasks()
                    
                    # Configurar geometria
                    menu_ref.geometry(geometria)
                    menu_ref.update_idletasks()
                    menu_ref.update()
                    
                    # Pequena pausa para garantir processamento
                    menu_ref.after(50)  # 50ms
                    menu_ref.update()
                    
                    # Mostrar janela
                    menu_ref.deiconify()
                    menu_ref.update_idletasks()
                    menu_ref.update()
                    
                    # Trazer para frente
                    menu_ref.lift()
                    menu_ref.focus_force()
                    menu_ref.update_idletasks()
                    
                    logger.info("✅ Menu principal restaurado com sucesso")
                    
                except Exception as e:
                    logger.error(f"❌ Erro ao restaurar menu: {e}")
                    # Tentar restauração forçada
                    try:
                        menu_ref.deiconify()
                        menu_ref.lift()
                    except:
                        pass
            else:
                logger.warning("⚠️ Referência ao menu principal não existe")
                
        except Exception as e:
            logger.error(f"❌ Erro geral em voltar_menu: {str(e)}")
            import traceback
            traceback.print_exc()

    def sair_sistema(self):
        """Fecha o sistema verificando dados não salvos"""
        try:
            self.finalizar_sistema()
        except Exception as e:
            logger.debug(f"Erro ao finalizar sistema: {str(e)}")
        finally:
            # Forçar saída se necessário
            import sys
            sys.exit()
    
    def setup_aba_selecao(self):
        """Configura a aba de seleção de cliente - VERSÃO FINAL"""
        # Frame principal para organização
        frame_principal = ttk.Frame(self.aba_selecao)
        frame_principal.pack(expand=True, fill='both', padx=20, pady=10)

        # ===== SEÇÃO DE SELEÇÃO DE CLIENTE - MODERNIZADA =====
        frame_selecao = ttk.LabelFrame(
            frame_principal, 
            text="Seleção do Cliente", 
            padding=(15, 10)
        )
        frame_selecao.pack(fill='x', pady=(0, 15))

        # Container para label e área de busca
        frame_busca = ttk.Frame(frame_selecao)
        frame_busca.pack(fill='x', pady=5)

        # Label com instrução mais clara
        ttk.Label(
            frame_busca, 
            text="Digite ou selecione o cliente:", 
            font=('Arial', 11, 'bold')
        ).pack(anchor='w', pady=(0, 5))

        # Frame para combobox e contador
        frame_combo = ttk.Frame(frame_busca)
        frame_combo.pack(fill='x')

        # Combobox com busca melhorada
        self.cliente_combobox = ttk.Combobox(
            frame_combo, 
            font=('Arial', 11),
            state='normal'
        )
        self.cliente_combobox.pack(side='left', fill='x', expand=True, padx=(0, 5))

        # Label contador de resultados
        self.label_contador = ttk.Label(
            frame_combo, 
            text="", 
            font=('Arial', 9),
            foreground='gray'
        )
        self.label_contador.pack(side='left', padx=5)

        # Botão Ver Todos
        self.btn_ver_todos = ttk.Button(
            frame_combo, 
            text="📋 Ver Todos", 
            command=self.mostrar_todos_clientes,
            width=12
        )
        self.btn_ver_todos.pack(side='right', padx=(5, 0))

        # ===== BINDINGS =====
        self.cliente_combobox.bind('<KeyRelease>', self.filtrar_clientes_digitacao)
        self.cliente_combobox.bind('<Button-1>', self.abrir_dropdown_clientes)
        self.cliente_combobox.bind('<<ComboboxSelected>>', self.selecionar_cliente)
        self.cliente_combobox.bind('<Return>', self.selecionar_primeiro_resultado)
        self.cliente_combobox.bind('<Escape>', self.limpar_busca)

        # Dica visual
        frame_dica = ttk.Frame(frame_selecao)
        frame_dica.pack(fill='x', pady=(5, 0))
        
        ttk.Label(
            frame_dica,
            text="💡 Dica: Comece a digitar para buscar. Use ↑↓ para navegar, Enter para selecionar, ESC para limpar.",
            font=('Arial', 9, 'italic'),
            foreground='#666666'
        ).pack(anchor='w')

        # ===== BOTÕES =====
        frame_gerenciar = ttk.Frame(frame_principal)
        frame_gerenciar.pack(pady=10)

        style = ttk.Style()
        style.configure('Big.TButton', font=('Arial', 11, 'bold'), padding=(20, 12))
        style.configure('Action.TButton', font=('Arial', 11, 'bold'), padding=(25, 15))

        frame_botoes = ttk.Frame(frame_gerenciar)
        frame_botoes.pack(pady=5)

        ttk.Button(
            frame_botoes, 
            text="➕ Novo Cliente", 
            command=self.criar_novo_cliente,
            style='Big.TButton'
        ).pack(side='left', padx=8)
                
        ttk.Button(
            frame_botoes,
            text="✏️ Editar Cliente",
            command=self.editar_cliente,
            style='Big.TButton'
        ).pack(side='left', padx=8)

        ttk.Button(
            frame_botoes, 
            text="📄 Gerir Contratos",
            command=self.abrir_gestao_contratos,
            style='Big.TButton'
        ).pack(side='left', padx=8)

        # Botão Continuar
        frame_continuar = ttk.Frame(frame_principal)
        frame_continuar.pack(fill='x', pady=15)

        ttk.Separator(frame_continuar, orient='horizontal').pack(fill='x', pady=(0, 15))

        self.btn_continuar = ttk.Button(
            frame_continuar,
            text="Continuar →",
            command=self.continuar_para_fornecedor,
            state='disabled',
            style='Action.TButton'
        )
        self.btn_continuar.pack(pady=5)

        # Botões de navegação
        frame_navegacao = ttk.Frame(frame_principal)
        frame_navegacao.pack(fill='x', side='bottom', pady=(20, 0))

        ttk.Separator(frame_navegacao, orient='horizontal').pack(fill='x', pady=(0, 10))

        frame_botoes_nav = ttk.Frame(frame_navegacao)
        frame_botoes_nav.pack()

        ttk.Button(
            frame_botoes_nav, 
            text="⬅️ Voltar ao Menu", 
            command=self.voltar_menu,
            style='Big.TButton'
        ).pack(side='left', padx=10)
        
        ttk.Button(
            frame_botoes_nav, 
            text="❌ Sair", 
            command=self.sair_sistema,
            style='Big.TButton'
        ).pack(side='left', padx=10)

       # Inicialização
        self.clientes_completos = []
        self.atualizar_lista_clientes()

        # Pré-selecionar o último cliente usado em outro módulo (ex.: Gestão de Empreiteiros)
        # OBS: adiado com after() porque, neste ponto, outras abas (que criam
        # widgets usados dentro de selecionar_cliente, como cliente_label)
        # ainda não foram montadas — chamar direto aqui dá AttributeError.
        try:
            try:
                from src.estado_compartilhado import estado_sessao
            except ImportError:
                from estado_compartilhado import estado_sessao

            if estado_sessao.ultimo_cliente and estado_sessao.ultimo_cliente in self.clientes_completos:
                self.cliente_combobox.set(estado_sessao.ultimo_cliente)
                self.root.after(100, lambda: self.selecionar_cliente(None))
            else:
                self.cliente_combobox.focus_set()
        except Exception as e:
            logger.error(f"Não foi possível pré-selecionar último cliente: {str(e)}")
            self.cliente_combobox.focus_set()

    def filtrar_clientes_digitacao(self, event=None):
        """Filtra clientes em tempo real - VERSÃO FINAL"""
        try:
            texto_busca = self.cliente_combobox.get().upper().strip()
            
            if not texto_busca:
                self.cliente_combobox['values'] = self.clientes_completos
                if hasattr(self, 'atualizar_contador'):
                    self.atualizar_contador(len(self.clientes_completos))
                return
            
            clientes_filtrados = []
            for cliente in self.clientes_completos:
                try:
                    cliente_str = str(cliente) if cliente is not None else ""
                    if texto_busca in cliente_str.upper():
                        clientes_filtrados.append(cliente)
                except Exception:
                    continue
            
            self.cliente_combobox['values'] = clientes_filtrados
            
            if hasattr(self, 'atualizar_contador'):
                self.atualizar_contador(len(clientes_filtrados))
            
            if clientes_filtrados and len(texto_busca) >= 2:
                try:
                    self.cliente_combobox.event_generate('<Down>')
                except Exception:
                    pass
                    
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.error(f"Erro ao filtrar clientes: {str(e)}")
            try:
                self.cliente_combobox['values'] = self.clientes_completos
                if hasattr(self, 'atualizar_contador'):
                    self.atualizar_contador(len(self.clientes_completos))
            except Exception:
                pass

    def abrir_dropdown_clientes(self, event=None):
        """Abre dropdown automaticamente ao clicar no campo"""
        # Garantir que mostra todos os clientes se não há filtro
        if not self.cliente_combobox.get():
            self.cliente_combobox['values'] = self.clientes_completos
            self.atualizar_contador(len(self.clientes_completos))
        
        # Abrir dropdown
        self.cliente_combobox.event_generate('<Down>')

    def selecionar_primeiro_resultado(self, event=None):
        """Seleciona o primeiro resultado quando Enter é pressionado"""
        valores = self.cliente_combobox['values']
        
        if valores:
            # Definir primeiro valor
            self.cliente_combobox.set(valores[0])
            # Disparar evento de seleção
            self.cliente_combobox.event_generate('<<ComboboxSelected>>')

    def limpar_busca(self, event=None):
        """Limpa o campo de busca e restaura lista completa"""
        self.cliente_combobox.set('')
        self.cliente_combobox['values'] = self.clientes_completos
        self.atualizar_contador(len(self.clientes_completos))
        self.btn_continuar.config(state='disabled')

    def atualizar_contador(self, quantidade):
        """Atualiza contador de resultados"""
        try:
            if not hasattr(self, 'label_contador'):
                return
                
            if not hasattr(self, 'clientes_completos'):
                self.label_contador.config(text=f"({quantidade} clientes)")
                return
                
            if quantidade == len(self.clientes_completos):
                self.label_contador.config(
                    text=f"({quantidade} clientes)",
                    foreground='gray'
                )
            else:
                self.label_contador.config(
                    text=f"({quantidade} de {len(self.clientes_completos)})",
                    foreground='#0066cc'
                )
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.debug(f"Erro ao atualizar contador: {str(e)}")

    def _listar_clientes_reais_para_vinculo(self):
        """
        Le os nomes cadastrados em Clientes.xlsx para popular o combobox
        'Cliente vinculado'. Exclui clientes ja marcados como GESTAO_MO
        (um ficticio nao deveria apontar para outro ficticio). Se a
        coluna TIPO_CLIENTE ainda nao existir no arquivo (primeira vez
        rodando isso), lista todos os clientes normalmente.
        """
        try:
            if not os.path.exists(ARQUIVO_CLIENTES):
                return []

            wb = load_workbook(ARQUIVO_CLIENTES, read_only=True, data_only=True)
            ws = wb['Clientes']

            cabecalho = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            col_tipo = cabecalho.index('TIPO_CLIENTE') + 1 if 'TIPO_CLIENTE' in cabecalho else None

            nomes = []
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                if col_tipo is not None and row[col_tipo - 1] == 'GESTAO_MO':
                    continue
                nomes.append(row[0])

            wb.close()
            return sorted(nomes)

        except Exception as e:
            logger.warning(f"Não foi possível carregar clientes para vínculo: {e}")
            return []

    def criar_novo_cliente(self):
        """Abre janela para cadastro de novo cliente - LAYOUT COMPACTO
        (campos curtos agrupados na mesma linha) + suporte a cliente
        fictício de gestão de mão de obra e caixa controlado"""
        janela_cliente = tk.Toplevel(self.root)
        janela_cliente.title("Novo Cliente")
        janela_cliente.geometry("700x850")
 
        canvas = tk.Canvas(janela_cliente)
        scrollbar = ttk.Scrollbar(janela_cliente, orient="vertical", command=canvas.yview)
        frame = ttk.Frame(canvas, padding="20")
 
        frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
 
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
 
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
 
        # ===== SEÇÃO: IDENTIFICAÇÃO =====
        ttk.Label(frame, text="IDENTIFICAÇÃO", font=('Arial', 12, 'bold')).grid(
            row=0, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        frame_nome = ttk.Frame(frame)
        frame_nome.grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_nome, text="Nome do Cliente:*").pack(side='left')
        nome_entry = ttk.Entry(frame_nome, width=85)
        nome_entry.pack(side='left', padx=(5, 0))
 
        # ===== SEÇÃO: ENDEREÇO =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=2, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="ENDEREÇO", font=('Arial', 12, 'bold')).grid(
            row=3, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        frame_logradouro = ttk.Frame(frame)
        frame_logradouro.grid(row=4, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_logradouro, text="Logradouro:*").pack(side='left')
        logradouro_entry = ttk.Entry(frame_logradouro, width=90)
        logradouro_entry.pack(side='left', padx=(5, 0))
 
        # Número / Complemento / CEP na mesma linha
        frame_end_linha = ttk.Frame(frame)
        frame_end_linha.grid(row=5, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(frame_end_linha, text="Número:*").pack(side='left')
        numero_entry = ttk.Entry(frame_end_linha, width=8)
        numero_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_end_linha, text="Complemento:").pack(side='left')
        complemento_entry = ttk.Entry(frame_end_linha, width=20)
        complemento_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_end_linha, text="CEP:").pack(side='left')
        cep_entry = ttk.Entry(frame_end_linha, width=12)
        cep_entry.bind('<KeyRelease>', formatar_cep_campo)
        cep_entry.pack(side='left', padx=(5, 0))
 
        frame_localidade = ttk.Frame(frame)
        frame_localidade.grid(row=6, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_localidade, text="Localidade (Bairro/Condomínio):*").pack(side='left')
        localidade_entry = ttk.Entry(frame_localidade, width=72)
        localidade_entry.pack(side='left', padx=(5, 0))
 
        # Cidade / Estado na mesma linha
        frame_cidade_estado = ttk.Frame(frame)
        frame_cidade_estado.grid(row=7, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(frame_cidade_estado, text="Cidade:*").pack(side='left')
        cidade_entry = ttk.Entry(frame_cidade_estado, width=30)
        cidade_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_cidade_estado, text="Estado:*").pack(side='left')
        estado_var = tk.StringVar(value="MG")
        estados = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA",
                "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN",
                "RS", "RO", "RR", "SC", "SP", "SE", "TO"]
        estado_combo = ttk.Combobox(frame_cidade_estado, textvariable=estado_var, values=estados, width=6, state='readonly')
        estado_combo.pack(side='left', padx=(5, 0))
 
        # ===== SEÇÃO: DADOS DA OBRA =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=8, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="DADOS DA OBRA", font=('Arial', 12, 'bold')).grid(
            row=9, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        # Data Inicial / Metragem / CNO na mesma linha
        frame_obra_linha = ttk.Frame(frame)
        frame_obra_linha.grid(row=10, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(frame_obra_linha, text="Data Inicial:* (dia 5 ou 20)").pack(side='left')
        data_entry = DateEntry(
            frame_obra_linha,
            width=12,
            date_pattern='yyyy-mm-dd',
            locale='pt_BR'
        )
        data_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_obra_linha, text="Metragem (m²):").pack(side='left')
        metragem_entry = ttk.Entry(frame_obra_linha, width=10)
        metragem_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_obra_linha, text="CNO:").pack(side='left')
        cno_entry = ttk.Entry(frame_obra_linha, width=20)
        cno_entry.bind('<KeyRelease>', formatar_cno_campo)
        cno_entry.pack(side='left', padx=(5, 0))
 
        frame_grupo_linha = ttk.Frame(frame)
        frame_grupo_linha.grid(row=11, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_grupo_linha, text="Grupo:").pack(side='left')
        grupo_var = tk.StringVar(value=" ")
 
        for i in range(1, 5):
            ttk.Radiobutton(
                frame_grupo_linha,
                text=f"Grupo {i}",
                variable=grupo_var,
                value=f"Grupo {i}"
            ).pack(side='left', padx=(10 if i == 1 else 5, 0))
 
        # ===== SEÇÃO: TIPO DE CLIENTE / VÍNCULO =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=12, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="TIPO DE CLIENTE", font=('Arial', 12, 'bold')).grid(
            row=13, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        eh_ficticio_var = tk.BooleanVar(value=False)
 
        def alternar_cliente_vinculado():
            if eh_ficticio_var.get():
                cliente_vinculado_combo.config(state='readonly')
            else:
                cliente_vinculado_var.set('')
                cliente_vinculado_combo.config(state='disabled')
 
        ttk.Checkbutton(
            frame,
            text="Este é um cliente fictício de gestão de mão de obra "
                 "(ex.: RVR - SPRC - CASA JD PETROPOLIS)",
            variable=eh_ficticio_var,
            command=alternar_cliente_vinculado
        ).grid(row=14, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(
            frame,
            text="Cria automaticamente a aba de Controle de Repasse - Mão de Obra "
                 "neste arquivo, para uso no Relatório de Despesas.",
            font=('Arial', 9, 'italic'),
            foreground='gray',
            wraplength=560,
            justify='left'
        ).grid(row=15, column=0, columnspan=2, padx=5, pady=(0, 5), sticky='w')
 
        frame_vinculado = ttk.Frame(frame)
        frame_vinculado.grid(row=16, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_vinculado, text="Cliente vinculado (real):").pack(side='left')
        cliente_vinculado_var = tk.StringVar(value='')
        cliente_vinculado_combo = ttk.Combobox(
            frame_vinculado,
            textvariable=cliente_vinculado_var,
            values=self._listar_clientes_reais_para_vinculo(),
            width=40,
            state='disabled'
        )
        cliente_vinculado_combo.pack(side='left', padx=(5, 0))
 
        tem_caixa_var = tk.BooleanVar(value=False)
 
        ttk.Checkbutton(
            frame,
            text="Este cliente possui caixa de obra controlado pela construtora "
                 "(gera Controle de Saldo - Caixa de Obra)",
            variable=tem_caixa_var
        ).grid(row=17, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(
            frame,
            text="Uso: quando o cliente faz aportes numa conta que a construtora "
                 "movimenta para pagamentos de baixa monta (PAGAMENTOS CAIXA DE OBRA).",
            font=('Arial', 9, 'italic'),
            foreground='gray',
            wraplength=560,
            justify='left'
        ).grid(row=18, column=0, columnspan=2, padx=5, pady=(0, 5), sticky='w')
 
        # ===== SEÇÃO: ADMINISTRAÇÃO =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=19, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="ADMINISTRAÇÃO", font=('Arial', 12, 'bold')).grid(
            row=20, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        frame_taxa = ttk.Frame(frame)
        frame_taxa.grid(row=21, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_taxa, text="Tipo de Taxa de Administração:*").pack(side='left')
        tipo_taxa_var = tk.StringVar(value=" ")
 
        ttk.Radiobutton(frame_taxa, text="Percentual", variable=tipo_taxa_var, value="Percentual").pack(side='left', padx=(10, 5))
        ttk.Radiobutton(frame_taxa, text="Fixo", variable=tipo_taxa_var, value="Fixo").pack(side='left', padx=5)
        ttk.Radiobutton(frame_taxa, text="Sem Taxa", variable=tipo_taxa_var, value="Sem Taxa").pack(side='left', padx=5)
 
        # ===== SEÇÃO: DADOS PESSOAIS =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=22, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="DADOS PESSOAIS DO PROPRIETÁRIO", font=('Arial', 12, 'bold')).grid(
            row=23, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        # CPF / Estado Civil na mesma linha
        # Bloco do proprietário: linha 1 = CPF/CNPJ + Estado Civil;
        # linha 2 = Domicílio (residência PF / sede PJ), usado nos contratos
        frame_bloco_pessoal = ttk.Frame(frame)
        frame_bloco_pessoal.grid(row=24, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        frame_pessoal = ttk.Frame(frame_bloco_pessoal)
        frame_pessoal.pack(side='top', anchor='w')
 
        ttk.Label(frame_pessoal, text="CPF/CNPJ:").pack(side='left')
        cpf_entry = ttk.Entry(frame_pessoal, width=20)
        cpf_entry.bind('<KeyRelease>', formatar_cpf_cnpj_campo)
        cpf_entry.bind('<FocusOut>', formatar_cpf_cnpj_campo)
        cpf_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_pessoal, text="Estado Civil:").pack(side='left')
        estado_civil_var = tk.StringVar(value=" ")
        for ec in ["Casado(a)", "Solteiro(a)", "Divorciado(a)", "Viúvo(a)"]:
            ttk.Radiobutton(frame_pessoal, text=ec, variable=estado_civil_var, value=ec).pack(side='left', padx=5)

        frame_domicilio = ttk.Frame(frame_bloco_pessoal)
        frame_domicilio.pack(side='top', anchor='w', pady=(8, 0))
        ttk.Label(frame_domicilio, text="Domicílio (residência PF / sede PJ):").pack(side='left')
        domicilio_entry = ttk.Entry(frame_domicilio, width=62)
        domicilio_entry.pack(side='left', padx=(5, 0))
        ttk.Label(
            frame_bloco_pessoal,
            text="Endereço que qualifica o contratante nos contratos. Em branco = usa o endereço da obra.",
            font=('Arial', 9, 'italic'),
            foreground='gray'
        ).pack(side='top', anchor='w')
 
        # ===== SEÇÃO: DADOS BANCÁRIOS =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=25, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        ttk.Label(frame, text="DADOS BANCÁRIOS", font=('Arial', 12, 'bold')).grid(
            row=26, column=0, columnspan=2, pady=(0, 5), sticky='w'
        )
        ttk.Label(frame, text="(Para transações entre obras)", font=('Arial', 9, 'italic'), foreground='gray').grid(
            row=27, column=0, columnspan=2, pady=(0, 10), sticky='w'
        )
 
        # Banco / Agência / Conta na mesma linha
        frame_banco_linha1 = ttk.Frame(frame)
        frame_banco_linha1.grid(row=28, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(frame_banco_linha1, text="Banco:").pack(side='left')
        banco_entry = ttk.Entry(frame_banco_linha1, width=22)
        banco_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_banco_linha1, text="Agência:").pack(side='left')
        agencia_entry = ttk.Entry(frame_banco_linha1, width=10)
        agencia_entry.pack(side='left', padx=(5, 20))
 
        ttk.Label(frame_banco_linha1, text="Conta:").pack(side='left')
        conta_entry = ttk.Entry(frame_banco_linha1, width=14)
        conta_entry.pack(side='left', padx=(5, 0))
 
        # Tipo de Conta / PIX na mesma linha
        frame_banco_linha2 = ttk.Frame(frame)
        frame_banco_linha2.grid(row=29, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
        ttk.Label(frame_banco_linha2, text="Tipo:").pack(side='left')
        tipo_conta_var = tk.StringVar(value=" ")
        ttk.Radiobutton(frame_banco_linha2, text="Corrente", variable=tipo_conta_var, value="Corrente").pack(side='left', padx=(5, 5))
        ttk.Radiobutton(frame_banco_linha2, text="Poupança", variable=tipo_conta_var, value="Poupança").pack(side='left', padx=(0, 20))
 
        ttk.Label(frame_banco_linha2, text="PIX:").pack(side='left')
        pix_entry = ttk.Entry(frame_banco_linha2, width=35)
        pix_entry.pack(side='left', padx=(5, 0))
 
        # ===== SEÇÃO: OBSERVAÇÕES =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=30, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        frame_obs = ttk.Frame(frame)
        frame_obs.grid(row=31, column=0, columnspan=2, padx=5, pady=5, sticky='w')
        ttk.Label(frame_obs, text="Observações:").pack(side='left')
        obs_entry = ttk.Entry(frame_obs, width=90)
        obs_entry.pack(side='left', padx=(5, 0))
 
        # ===== NAVEGAÇÃO POR ENTER =====
        campos_entry = [
            nome_entry, logradouro_entry, numero_entry, complemento_entry,
            cep_entry, localidade_entry, cidade_entry, estado_combo,
            data_entry, metragem_entry, cno_entry,
            cpf_entry, domicilio_entry, banco_entry, agencia_entry, conta_entry,
            pix_entry, obs_entry
        ]
 
        def proximo_campo(event, campos, index):
            if index < len(campos) - 1:
                campos[index + 1].focus_set()
                return "break"
            else:
                btn_salvar.focus_set()
                return "break"
 
        for i, campo in enumerate(campos_entry):
            campo.bind('<Return>', lambda e, idx=i: proximo_campo(e, campos_entry, idx))
 
        def validar_data(*args):
            data = data_entry.get_date()
            if data.day not in [5, 20]:
                messagebox.showinfo(
                    "Data Inválida",
                    "A data inicial deve ser dia 5 ou 20 do mês."
                )
                if data.day < 5:
                    data = data.replace(day=5)
                elif data.day < 20:
                    data = data.replace(day=20)
                else:
                    if data.month == 12:
                        data = data.replace(year=data.year + 1, month=1, day=5)
                    else:
                        data = data.replace(month=data.month + 1, day=5)
                data_entry.set_date(data)
 
        data_entry.bind("<<DateEntrySelected>>", validar_data)
 
        # ===== FUNÇÃO SALVAR =====
        def salvar_cliente():
            nome = nome_entry.get().strip().upper()
            logradouro = logradouro_entry.get().strip().upper()
            numero = numero_entry.get().strip().upper()
            complemento = complemento_entry.get().strip().upper()
            localidade = localidade_entry.get().strip().upper()
            cep = cep_entry.get().strip()
            cidade = cidade_entry.get().strip().upper()
            estado = estado_var.get()
 
            if not nome:
                messagebox.showerror("Erro", "Nome é obrigatório!")
                nome_entry.focus_set()
                return
            if not logradouro:
                messagebox.showerror("Erro", "Logradouro é obrigatório!")
                logradouro_entry.focus_set()
                return
            if not numero:
                messagebox.showerror("Erro", "Número é obrigatório!")
                numero_entry.focus_set()
                return
            if not localidade:
                messagebox.showerror("Erro", "Localidade (Bairro/Condomínio) é obrigatória!")
                localidade_entry.focus_set()
                return
            if not cidade:
                messagebox.showerror("Erro", "Cidade é obrigatória!")
                cidade_entry.focus_set()
                return

            # CPF (PF) ou CNPJ (PJ): valida e grava sempre com máscara padrão
            doc_ok, doc_formatado = validar_documento_cliente(cpf_entry.get())
            if not doc_ok:
                cpf_entry.focus_set()
                return
            cpf_entry.delete(0, tk.END)
            cpf_entry.insert(0, doc_formatado)

            # Domicílio: obrigatório na prática para PJ (sede difere da obra)
            domicilio = domicilio_entry.get().strip().upper()
            if doc_formatado and _eh_cnpj(_doc_limpo(doc_formatado)) and not domicilio:
                if not messagebox.askyesno(
                    "Domicílio não informado",
                    "Cliente pessoa jurídica (CNPJ) sem domicílio (sede).\n\n"
                    "Nos contratos, o contratante será qualificado com o endereço "
                    "da obra.\n\nDeseja salvar mesmo assim?"
                ):
                    domicilio_entry.focus_set()
                    return
 
            eh_ficticio = eh_ficticio_var.get()
            cliente_vinculado = cliente_vinculado_var.get().strip() if eh_ficticio else ''
            if eh_ficticio and not cliente_vinculado:
                messagebox.showerror(
                    "Erro",
                    "Selecione o cliente real vinculado a este cliente fictício de "
                    "gestão de mão de obra."
                )
                cliente_vinculado_combo.focus_set()
                return
 
            tem_caixa = tem_caixa_var.get()
 
            partes_endereco = [logradouro, numero]
            if complemento:
                partes_endereco.append(complemento)
 
            endereco = f"{', '.join(partes_endereco)} - {localidade} - {cidade}/{estado}"
 
            try:
                data = datetime.strptime(data_entry.get(), '%Y-%m-%d').date()
                if data.day not in [5, 20]:
                    messagebox.showerror("Erro", "A data inicial deve ser dia 5 ou 20 do mês!")
                    return
            except ValueError:
                messagebox.showerror("Erro", "Data inválida!")
                return
 
            metragem = None
            if metragem_entry.get().strip():
                try:
                    metragem = float(metragem_entry.get().strip().replace(',', '.'))
                except ValueError:
                    messagebox.showerror("Erro", "Metragem inválida! Use formato: 999.99")
                    metragem_entry.focus_set()
                    return
 
            try:
                wb = load_workbook(ARQUIVO_CLIENTES)
                ws = wb['Clientes']
 
                for row in ws.iter_rows(min_row=2, values_only=True):
                    if row[0] and row[0].upper() == nome:
                        messagebox.showerror("Erro", "Cliente já cadastrado!")
                        return
 
                proxima_linha = ws.max_row + 1
 
                ws.cell(row=proxima_linha, column=1, value=nome)
                ws.cell(row=proxima_linha, column=2, value=endereco)
                ws.cell(row=proxima_linha, column=3, value=data)
                ws.cell(row=proxima_linha, column=4, value=obs_entry.get().strip().upper())
                ws.cell(row=proxima_linha, column=5, value=None)  # Data Final
                ws.cell(row=proxima_linha, column=6, value=tipo_taxa_var.get())
                ws.cell(row=proxima_linha, column=7, value=cpf_entry.get().strip())
                ws.cell(row=proxima_linha, column=8, value=cno_entry.get().strip())
                ws.cell(row=proxima_linha, column=9, value=estado_civil_var.get())
                ws.cell(row=proxima_linha, column=10, value=cidade)
                ws.cell(row=proxima_linha, column=11, value=grupo_var.get())
 
                ws.cell(row=proxima_linha, column=12, value=logradouro)
                ws.cell(row=proxima_linha, column=13, value=numero)
                ws.cell(row=proxima_linha, column=14, value=complemento)
                ws.cell(row=proxima_linha, column=15, value=localidade)
                ws.cell(row=proxima_linha, column=16, value=cep)
                ws.cell(row=proxima_linha, column=17, value=estado)
                ws.cell(row=proxima_linha, column=18, value=metragem)
                ws.cell(row=proxima_linha, column=19, value=banco_entry.get().strip().upper())
                ws.cell(row=proxima_linha, column=20, value=agencia_entry.get().strip())
                ws.cell(row=proxima_linha, column=21, value=conta_entry.get().strip())
                ws.cell(row=proxima_linha, column=22, value=tipo_conta_var.get())
                ws.cell(row=proxima_linha, column=23, value=pix_entry.get().strip())
 
                if ws.cell(row=1, column=24).value != 'TIPO_CLIENTE':
                    ws.cell(row=1, column=24, value='TIPO_CLIENTE')
                if ws.cell(row=1, column=25).value != 'CLIENTE_VINCULADO':
                    ws.cell(row=1, column=25, value='CLIENTE_VINCULADO')
                if ws.cell(row=1, column=26).value != 'CAIXA_CONTROLADO':
                    ws.cell(row=1, column=26, value='CAIXA_CONTROLADO')
 
                ws.cell(row=proxima_linha, column=24, value='GESTAO_MO' if eh_ficticio else '')
                ws.cell(row=proxima_linha, column=25, value=cliente_vinculado if eh_ficticio else '')
                ws.cell(row=proxima_linha, column=26, value='SIM' if tem_caixa else '')

                if ws.cell(row=1, column=27).value != 'DOMICILIO':
                    ws.cell(row=1, column=27, value='DOMICILIO')
                ws.cell(row=proxima_linha, column=27, value=domicilio)
 
                salvar_planilha_segura(wb, ARQUIVO_CLIENTES)
 
                if self.criar_arquivo_cliente(nome, endereco, eh_ficticio=eh_ficticio, tem_caixa=tem_caixa):
                    # Captura os valores ANTES de destruir a janela —
                    # os widgets deixam de existir após janela_cliente.destroy()
                    cpf_cliente = cpf_entry.get().strip()
                    pix_cliente = pix_entry.get().strip()
                    banco_cliente = banco_entry.get().strip()
                    agencia_cliente = agencia_entry.get().strip()
                    conta_cliente = conta_entry.get().strip()

                    messagebox.showinfo("Sucesso", "Cliente cadastrado com sucesso!")
                    self.atualizar_lista_clientes()
                    janela_cliente.destroy()

                    # Réplica automática como fornecedor (Categoria DIV, Vínculo CLIENTE)
                    # — apenas para clientes reais, não para o fictício de gestão de MO.
                    if not eh_ficticio:
                        self.replicar_cliente_como_fornecedor(
                            nome=nome,
                            cpf=cpf_cliente,
                            endereco=domicilio or endereco,
                            pix=pix_cliente,
                            banco=banco_cliente,
                            agencia=agencia_cliente,
                            conta=conta_cliente,
                        )
 
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao cadastrar cliente: {str(e)}")
 
        # ===== BOTÕES =====
        ttk.Separator(frame, orient='horizontal').grid(
            row=32, column=0, columnspan=2, sticky='ew', pady=15
        )
 
        frame_botoes = ttk.Frame(frame)
        frame_botoes.grid(row=33, column=0, columnspan=2, pady=10)
 
        btn_salvar = ttk.Button(frame_botoes, text="Salvar", command=salvar_cliente, style='Big.TButton')
        btn_salvar.pack(side='left', padx=5)
 
        ttk.Button(frame_botoes, text="Cancelar", command=janela_cliente.destroy, style='Big.TButton').pack(side='left', padx=5)
 
        nome_entry.focus_set()
 

    def selecionar_cliente(self, event):
        """
        Atualiza seleção de cliente e habilita botão de continuar
        VERSÃO COM PROTEÇÃO contra perda de dados pendentes + FEEDBACK VISUAL MELHORADO
        """
        try:
            # ==========================================
            # PROTEÇÃO: Verificar dados pendentes ANTES de trocar
            # ==========================================
            novo_cliente = self.cliente_combobox.get()
            
            # Se já existe um cliente selecionado E está tentando trocar para outro
            if (hasattr(self, 'cliente_atual') and 
                self.cliente_atual and 
                self.cliente_atual != novo_cliente):
                
                # Verificar se há dados pendentes
                if hasattr(self, 'dados_para_incluir') and self.dados_para_incluir:
                    qtd_pendentes = len(self.dados_para_incluir)
                    
                    # logger = system_logger.get_logger()
                    logger.warning(f"Tentativa de trocar cliente com {qtd_pendentes} lançamentos pendentes")
                    
                    resposta = custom_messagebox(
                        "yesno",
                        "Dados Pendentes - Confirmação Necessária",
                        f"⚠️ ATENÇÃO: Existem {qtd_pendentes} lançamento(s) pendente(s) de envio!\n\n"
                        f"Cliente atual: {self.cliente_atual}\n"
                        f"Novo cliente: {novo_cliente}\n\n"
                        f"Ao trocar de cliente, estes dados serão PERDIDOS e não poderão "
                        f"ser recuperados.\n\n"
                        f"O que deseja fazer?\n\n"
                        f"• SIM = Trocar de cliente e DESCARTAR os {qtd_pendentes} lançamentos pendentes\n"
                        f"• NÃO = Cancelar troca e ENVIAR os lançamentos primeiro"
                    )
                    
                    if not resposta:  # Usuário escolheu NÃO
                        logger.info("Troca de cliente CANCELADA pelo usuário - dados pendentes preservados")
                        
                        # Restaurar seleção anterior no combobox
                        self.cliente_combobox.set(self.cliente_atual)
                        
                        # ===== NOVO: Feedback visual de cancelamento =====
                        if hasattr(self, 'label_contador'):
                            self.label_contador.config(
                                text="⚠️ Troca cancelada - dados preservados",
                                foreground='orange'
                            )
                            # Restaurar após 3 segundos
                            self.root.after(3000, lambda: self.atualizar_contador(len(self.clientes_completos)))
                        
                        # Mensagem informativa
                        custom_messagebox(
                            "info", 
                            "Troca Cancelada", 
                            f"Troca de cliente cancelada.\n\n"
                            f"Os {qtd_pendentes} lançamentos pendentes foram preservados.\n\n"
                            f"Por favor:\n"
                            f"1. Clique em 'Enviar' para salvar os lançamentos\n"
                            f"2. Depois selecione o novo cliente"
                        )
                        
                        return  # IMPORTANTE: Interromper aqui sem trocar cliente
                    
                    # Se chegou aqui, usuário confirmou descarte (SIM)
                    logger.warning(f"Usuário CONFIRMOU descarte de {qtd_pendentes} lançamentos pendentes")
                    
                    # Limpar dados pendentes
                    self.limpar_visualizacao_completa()
                    
                    logger.info(f"Dados pendentes descartados. Trocando de '{self.cliente_atual}' para '{novo_cliente}'")
            
            # ==========================================
            # Continuar com seleção normal do cliente
            # ==========================================
            self.cliente_atual = novo_cliente

            # Lembrar este cliente para outros módulos (ex.: Gestão de Empreiteiros)
            try:
                from src.estado_compartilhado import estado_sessao
            except ImportError:
                from estado_compartilhado import estado_sessao
            estado_sessao.ultimo_cliente = self.cliente_atual
            
            # Atualiza label na aba de dados
            self.cliente_label.config(text=f"Cliente: {self.cliente_atual}")
            
            # Atualiza também o label na aba de fornecedor
            if hasattr(self, 'lbl_cliente_fornecedor'):
                self.lbl_cliente_fornecedor.config(text=f"Cliente: {self.cliente_atual}")
            
            # Habilita o botão continuar
            self.btn_continuar.config(state='normal')
            
            # ===== NOVO: Feedback visual de sucesso =====
            if hasattr(self, 'label_contador'):
                self.label_contador.config(
                    text="✓ Cliente selecionado",
                    foreground='green'
                )
                # Restaurar contador após 2 segundos
                self.root.after(2000, lambda: self.atualizar_contador(len(self.clientes_completos)))
            
            # Log de sucesso
            # logger = system_logger.get_logger()
            logger.info(f"Cliente selecionado com sucesso: {self.cliente_atual}")
            
            # Não muda de aba automaticamente
            
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.error(f"Erro ao selecionar cliente: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao selecionar cliente: {str(e)}")


    def editar_cliente(self):
        """Edita o cliente selecionado - LAYOUT COMPACTO (mesmo padrão
        de criar_novo_cliente) + suporte a cliente fictício de gestão
        de mão de obra e caixa controlado"""
        cliente_selecionado = self.cliente_combobox.get()
 
        if not cliente_selecionado:
            messagebox.showwarning("Aviso", "Selecione um cliente para editar")
            return
 
        try:
            # Carregar dados do cliente
            wb = load_workbook(ARQUIVO_CLIENTES)
            ws = wb['Clientes']
 
            dados_cliente = None
 
            for row in ws.iter_rows(min_row=2, values_only=True):
                if row[0] == cliente_selecionado:
                    dados_cliente = {
                        # Colunas A-K (existentes)
                        'nome': row[0],
                        'endereco': row[1],
                        'data_inicial': row[2],
                        'observacoes': row[3] if row[3] else '',
                        'data_final': row[4] if len(row) > 4 else None,
                        'tipo_taxa': row[5] if len(row) > 5 else 'Percentual',
                        'cpf': row[6] if len(row) > 6 else '',
                        'cno': row[7] if len(row) > 7 else '',
                        'estado_civil': row[8] if len(row) > 8 else '',
                        'cidade': row[9] if len(row) > 9 else '',
                        'grupo': row[10] if len(row) > 10 else '',
                        # Colunas L-W (novas)
                        'logradouro': row[11] if len(row) > 11 and row[11] else '',
                        'numero': row[12] if len(row) > 12 and row[12] else '',
                        'complemento': row[13] if len(row) > 13 and row[13] else '',
                        'localidade': row[14] if len(row) > 14 and row[14] else '',
                        'cep': row[15] if len(row) > 15 and row[15] else '',
                        'estado': row[16] if len(row) > 16 and row[16] else 'MG',
                        'metragem_alvara': row[17] if len(row) > 17 and row[17] else None,
                        'banco': row[18] if len(row) > 18 and row[18] else '',
                        'agencia': row[19] if len(row) > 19 and row[19] else '',
                        'conta': row[20] if len(row) > 20 and row[20] else '',
                        'tipo_conta': row[21] if len(row) > 21 and row[21] else '',
                        'pix': row[22] if len(row) > 22 and row[22] else '',
                        # Colunas X-Z (novas - tipo de cliente / vínculo / caixa)
                        'tipo_cliente': row[23] if len(row) > 23 and row[23] else '',
                        'cliente_vinculado': row[24] if len(row) > 24 and row[24] else '',
                        'caixa_controlado': row[25] if len(row) > 25 and row[25] else '',
                        # Coluna AA (nova - domicílio: residência PF / sede PJ)
                        'domicilio': row[26] if len(row) > 26 and row[26] else '',
                    }
                    break
 
            wb.close()
 
            if not dados_cliente:
                messagebox.showerror("Erro", "Cliente não encontrado!")
                return
 
            # Estado original dos checkboxes de controle - usado para
            # detectar se o usuário está LIGANDO algum deles agora
            # (e então pedir confirmação antes de criar a aba)
            eh_ficticio_inicial = (dados_cliente.get('tipo_cliente') == 'GESTAO_MO')
            tem_caixa_inicial = (dados_cliente.get('caixa_controlado') == 'SIM')
            # CPF/CNPJ que o cliente tinha ao abrir a edição - usado para detectar
            # a INCLUSÃO do documento agora (e então oferecer a réplica como fornecedor)
            doc_inicial = _doc_limpo(dados_cliente.get('cpf'))
 
            # Criar janela de edição
            janela_edicao = tk.Toplevel(self.root)
            janela_edicao.title(f"Editar Cliente - {cliente_selecionado}")
            janela_edicao.geometry("700x850")
 
            canvas = tk.Canvas(janela_edicao)
            scrollbar = ttk.Scrollbar(janela_edicao, orient="vertical", command=canvas.yview)
            frame = ttk.Frame(canvas, padding="20")
 
            frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
 
            canvas.create_window((0, 0), window=frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
 
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
 
            # ===== FUNÇÃO AUXILIAR PARA INSERIR VALORES =====
            def inserir_valor_entry(entry, valor):
                """Insere valor em Entry de forma segura"""
                entry.delete(0, tk.END)
                if valor:
                    entry.insert(0, str(valor))
 
            # ===== SEÇÃO: IDENTIFICAÇÃO =====
            ttk.Label(frame, text="IDENTIFICAÇÃO", font=('Arial', 12, 'bold')).grid(
                row=0, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            frame_nome = ttk.Frame(frame)
            frame_nome.grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_nome, text="Nome do Cliente:*").pack(side='left')
            nome_entry = ttk.Entry(frame_nome, width=85)
            inserir_valor_entry(nome_entry, dados_cliente['nome'])
            nome_entry.pack(side='left', padx=(5, 0))
 
            # ===== SEÇÃO: ENDEREÇO =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=2, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="ENDEREÇO", font=('Arial', 12, 'bold')).grid(
                row=3, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            frame_logradouro = ttk.Frame(frame)
            frame_logradouro.grid(row=4, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_logradouro, text="Logradouro:*").pack(side='left')
            logradouro_entry = ttk.Entry(frame_logradouro, width=90)
            inserir_valor_entry(logradouro_entry, dados_cliente.get('logradouro', ''))
            logradouro_entry.pack(side='left', padx=(5, 0))
 
            # Número / Complemento / CEP na mesma linha
            frame_end_linha = ttk.Frame(frame)
            frame_end_linha.grid(row=5, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(frame_end_linha, text="Número:*").pack(side='left')
            numero_entry = ttk.Entry(frame_end_linha, width=8)
            inserir_valor_entry(numero_entry, dados_cliente.get('numero', ''))
            numero_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_end_linha, text="Complemento:").pack(side='left')
            complemento_entry = ttk.Entry(frame_end_linha, width=20)
            inserir_valor_entry(complemento_entry, dados_cliente.get('complemento', ''))
            complemento_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_end_linha, text="CEP:").pack(side='left')
            cep_entry = ttk.Entry(frame_end_linha, width=12)
            inserir_valor_entry(cep_entry, dados_cliente.get('cep', ''))
            cep_entry.bind('<KeyRelease>', formatar_cep_campo)
            cep_entry.pack(side='left', padx=(5, 0))
 
            frame_localidade = ttk.Frame(frame)
            frame_localidade.grid(row=6, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_localidade, text="Localidade (Bairro/Condomínio):*").pack(side='left')
            localidade_entry = ttk.Entry(frame_localidade, width=72)
            inserir_valor_entry(localidade_entry, dados_cliente.get('localidade', ''))
            localidade_entry.pack(side='left', padx=(5, 0))
 
            # Cidade / Estado na mesma linha
            frame_cidade_estado = ttk.Frame(frame)
            frame_cidade_estado.grid(row=7, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(frame_cidade_estado, text="Cidade:*").pack(side='left')
            cidade_entry = ttk.Entry(frame_cidade_estado, width=30)
            inserir_valor_entry(cidade_entry, dados_cliente.get('cidade', ''))
            cidade_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_cidade_estado, text="Estado:*").pack(side='left')
            estado_var = tk.StringVar(value=dados_cliente.get('estado', 'MG'))
            estados = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA",
                    "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN",
                    "RS", "RO", "RR", "SC", "SP", "SE", "TO"]
            estado_combo = ttk.Combobox(frame_cidade_estado, textvariable=estado_var, values=estados, width=6, state='readonly')
            estado_combo.pack(side='left', padx=(5, 0))
 
            # ===== SEÇÃO: DADOS DA OBRA =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=8, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="DADOS DA OBRA", font=('Arial', 12, 'bold')).grid(
                row=9, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            # Data Inicial / Metragem / CNO na mesma linha
            frame_obra_linha = ttk.Frame(frame)
            frame_obra_linha.grid(row=10, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(frame_obra_linha, text="Data Inicial:*").pack(side='left')
            data_inicial_entry = DateEntry(
                frame_obra_linha,
                width=12,
                date_pattern='yyyy-mm-dd',
                locale='pt_BR'
            )
            if dados_cliente['data_inicial']:
                data_inicial_entry.set_date(dados_cliente['data_inicial'])
            data_inicial_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_obra_linha, text="Metragem (m²):").pack(side='left')
            metragem_entry = ttk.Entry(frame_obra_linha, width=10)
            if dados_cliente.get('metragem_alvara'):
                inserir_valor_entry(metragem_entry, str(dados_cliente['metragem_alvara']))
            metragem_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_obra_linha, text="CNO:").pack(side='left')
            cno_entry = ttk.Entry(frame_obra_linha, width=20)
            inserir_valor_entry(cno_entry, dados_cliente.get('cno', ''))
            cno_entry.bind('<KeyRelease>', formatar_cno_campo)
            cno_entry.pack(side='left', padx=(5, 0))
 
            # Obra finalizada / Data Final na mesma linha (exclusivo da edição)
            frame_data_final = ttk.Frame(frame)
            frame_data_final.grid(row=11, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            tem_data_final = tk.BooleanVar(value=bool(dados_cliente['data_final']))
 
            check_data_final = ttk.Checkbutton(
                frame_data_final,
                text="Obra finalizada - Data Final:",
                variable=tem_data_final
            )
            check_data_final.pack(side='left')
 
            data_final_entry = DateEntry(
                frame_data_final,
                width=12,
                date_pattern='yyyy-mm-dd',
                locale='pt_BR'
            )
            data_final_entry.pack(side='left', padx=(5, 0))
 
            if dados_cliente['data_final']:
                data_final_entry.set_date(dados_cliente['data_final'])
            else:
                data_final_entry.delete(0, tk.END)
                data_final_entry.config(state='disabled')
 
            def toggle_data_final():
                if tem_data_final.get():
                    data_final_entry.config(state='normal')
                    if not data_final_entry.get():
                        data_final_entry.set_date(datetime.now().date())
                else:
                    data_final_entry.delete(0, tk.END)
                    data_final_entry.config(state='disabled')
 
            check_data_final.config(command=toggle_data_final)
 
            frame_grupo_linha = ttk.Frame(frame)
            frame_grupo_linha.grid(row=12, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_grupo_linha, text="Grupo:").pack(side='left')
            grupo_var = tk.StringVar(value=dados_cliente.get('grupo', ''))
            for i in range(1, 5):
                ttk.Radiobutton(
                    frame_grupo_linha,
                    text=f"Grupo {i}",
                    variable=grupo_var,
                    value=f"Grupo {i}"
                ).pack(side='left', padx=(10 if i == 1 else 5, 0))
 
            # ===== SEÇÃO: TIPO DE CLIENTE / VÍNCULO =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=13, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="TIPO DE CLIENTE", font=('Arial', 12, 'bold')).grid(
                row=14, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            eh_ficticio_var = tk.BooleanVar(value=(dados_cliente.get('tipo_cliente') == 'GESTAO_MO'))
 
            def alternar_cliente_vinculado():
                if eh_ficticio_var.get():
                    cliente_vinculado_combo.config(state='readonly')
                else:
                    cliente_vinculado_var.set('')
                    cliente_vinculado_combo.config(state='disabled')
 
            ttk.Checkbutton(
                frame,
                text="Este é um cliente fictício de gestão de mão de obra "
                     "(ex.: RVR - SPRC - CASA JD PETROPOLIS)",
                variable=eh_ficticio_var,
                command=alternar_cliente_vinculado
            ).grid(row=15, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(
                frame,
                text="Cria a aba de Controle de Repasse - Mão de Obra, para uso no Relatório de Despesas.",
                font=('Arial', 9, 'italic'),
                foreground='gray',
                wraplength=560,
                justify='left'
            ).grid(row=16, column=0, columnspan=2, padx=5, pady=(0, 5), sticky='w')
 
            frame_vinculado = ttk.Frame(frame)
            frame_vinculado.grid(row=17, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_vinculado, text="Cliente vinculado (real):").pack(side='left')
            cliente_vinculado_var = tk.StringVar(value=dados_cliente.get('cliente_vinculado', ''))
 
            valores_vinculo = self._listar_clientes_reais_para_vinculo()
            valor_atual_vinculo = dados_cliente.get('cliente_vinculado', '')
            if valor_atual_vinculo and valor_atual_vinculo not in valores_vinculo:
                valores_vinculo = [valor_atual_vinculo] + valores_vinculo
 
            cliente_vinculado_combo = ttk.Combobox(
                frame_vinculado,
                textvariable=cliente_vinculado_var,
                values=valores_vinculo,
                width=40,
                state='readonly' if eh_ficticio_var.get() else 'disabled'
            )
            cliente_vinculado_combo.pack(side='left', padx=(5, 0))
 
            tem_caixa_var = tk.BooleanVar(value=(dados_cliente.get('caixa_controlado') == 'SIM'))
 
            ttk.Checkbutton(
                frame,
                text="Este cliente possui caixa de obra controlado pela construtora "
                     "(gera Controle de Saldo - Caixa de Obra)",
                variable=tem_caixa_var
            ).grid(row=18, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(
                frame,
                text="Uso: quando existe uma conta bancária que o Financeiro movimenta (PAGAMENTOS CAIXA DE OBRA).",
                font=('Arial', 9, 'italic'),
                foreground='gray',
                wraplength=580,
                justify='left'
            ).grid(row=19, column=0, columnspan=2, padx=5, pady=(0, 5), sticky='w')
 
            # ===== SEÇÃO: ADMINISTRAÇÃO =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=20, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="ADMINISTRAÇÃO", font=('Arial', 12, 'bold')).grid(
                row=21, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            frame_taxa = ttk.Frame(frame)
            frame_taxa.grid(row=22, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_taxa, text="Tipo de Taxa:*").pack(side='left')
            tipo_taxa_var = tk.StringVar(value=dados_cliente.get('tipo_taxa', 'Percentual'))
            ttk.Radiobutton(frame_taxa, text="Percentual", variable=tipo_taxa_var, value="Percentual").pack(side='left', padx=(10, 5))
            ttk.Radiobutton(frame_taxa, text="Fixo", variable=tipo_taxa_var, value="Fixo").pack(side='left', padx=5)
            ttk.Radiobutton(frame_taxa, text="Sem Taxa", variable=tipo_taxa_var, value="Sem Taxa").pack(side='left', padx=5)
 
            # ===== SEÇÃO: DADOS PESSOAIS =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=23, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="DADOS PESSOAIS DO PROPRIETÁRIO", font=('Arial', 12, 'bold')).grid(
                row=24, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            # CPF / Estado Civil na mesma linha
            # Bloco do proprietário: linha 1 = CPF/CNPJ + Estado Civil;
            # linha 2 = Domicílio (residência PF / sede PJ), usado nos contratos
            frame_bloco_pessoal = ttk.Frame(frame)
            frame_bloco_pessoal.grid(row=25, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            frame_pessoal = ttk.Frame(frame_bloco_pessoal)
            frame_pessoal.pack(side='top', anchor='w')
 
            ttk.Label(frame_pessoal, text="CPF/CNPJ:").pack(side='left')
            cpf_entry = ttk.Entry(frame_pessoal, width=20)
            inserir_valor_entry(cpf_entry, dados_cliente.get('cpf', ''))
            cpf_entry.bind('<KeyRelease>', formatar_cpf_cnpj_campo)
            cpf_entry.bind('<FocusOut>', formatar_cpf_cnpj_campo)
            cpf_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_pessoal, text="Estado Civil:").pack(side='left')
            estado_civil_var = tk.StringVar(value=dados_cliente.get('estado_civil', ''))
            for ec in ["Casado(a)", "Solteiro(a)", "Divorciado(a)", "Viúvo(a)"]:
                ttk.Radiobutton(frame_pessoal, text=ec, variable=estado_civil_var, value=ec).pack(side='left', padx=5)

            frame_domicilio = ttk.Frame(frame_bloco_pessoal)
            frame_domicilio.pack(side='top', anchor='w', pady=(8, 0))
            ttk.Label(frame_domicilio, text="Domicílio (residência PF / sede PJ):").pack(side='left')
            domicilio_entry = ttk.Entry(frame_domicilio, width=62)
            inserir_valor_entry(domicilio_entry, dados_cliente.get('domicilio', ''))
            domicilio_entry.pack(side='left', padx=(5, 0))
            ttk.Label(
                frame_bloco_pessoal,
                text="Endereço que qualifica o contratante nos contratos. Em branco = usa o endereço da obra.",
                font=('Arial', 9, 'italic'),
                foreground='gray'
            ).pack(side='top', anchor='w')
 
            # ===== SEÇÃO: DADOS BANCÁRIOS =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=26, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            ttk.Label(frame, text="DADOS BANCÁRIOS", font=('Arial', 12, 'bold')).grid(
                row=27, column=0, columnspan=2, pady=(0, 5), sticky='w'
            )
            ttk.Label(frame, text="(Para transações entre obras)", font=('Arial', 9, 'italic'), foreground='gray').grid(
                row=28, column=0, columnspan=2, pady=(0, 10), sticky='w'
            )
 
            # Banco / Agência / Conta na mesma linha
            frame_banco_linha1 = ttk.Frame(frame)
            frame_banco_linha1.grid(row=29, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(frame_banco_linha1, text="Banco:").pack(side='left')
            banco_entry = ttk.Entry(frame_banco_linha1, width=22)
            inserir_valor_entry(banco_entry, dados_cliente.get('banco', ''))
            banco_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_banco_linha1, text="Agência:").pack(side='left')
            agencia_entry = ttk.Entry(frame_banco_linha1, width=10)
            inserir_valor_entry(agencia_entry, dados_cliente.get('agencia', ''))
            agencia_entry.pack(side='left', padx=(5, 20))
 
            ttk.Label(frame_banco_linha1, text="Conta:").pack(side='left')
            conta_entry = ttk.Entry(frame_banco_linha1, width=14)
            inserir_valor_entry(conta_entry, dados_cliente.get('conta', ''))
            conta_entry.pack(side='left', padx=(5, 0))
 
            # Tipo de Conta / PIX na mesma linha
            frame_banco_linha2 = ttk.Frame(frame)
            frame_banco_linha2.grid(row=30, column=0, columnspan=2, padx=5, pady=5, sticky='w')
 
            ttk.Label(frame_banco_linha2, text="Tipo:").pack(side='left')
            tipo_conta_var = tk.StringVar(value=dados_cliente.get('tipo_conta', ''))
            ttk.Radiobutton(frame_banco_linha2, text="Corrente", variable=tipo_conta_var, value="Corrente").pack(side='left', padx=(5, 5))
            ttk.Radiobutton(frame_banco_linha2, text="Poupança", variable=tipo_conta_var, value="Poupança").pack(side='left', padx=(0, 20))
 
            ttk.Label(frame_banco_linha2, text="PIX:").pack(side='left')
            pix_entry = ttk.Entry(frame_banco_linha2, width=35)
            inserir_valor_entry(pix_entry, dados_cliente.get('pix', ''))
            pix_entry.pack(side='left', padx=(5, 0))
 
            # ===== SEÇÃO: OBSERVAÇÕES =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=31, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            frame_obs = ttk.Frame(frame)
            frame_obs.grid(row=32, column=0, columnspan=2, padx=5, pady=5, sticky='w')
            ttk.Label(frame_obs, text="Observações:").pack(side='left')
            obs_entry = ttk.Entry(frame_obs, width=90)
            inserir_valor_entry(obs_entry, dados_cliente.get('observacoes', ''))
            obs_entry.pack(side='left', padx=(5, 0))
 
            # ===== NAVEGAÇÃO POR ENTER =====
            campos_entry = [
                nome_entry, logradouro_entry, numero_entry, complemento_entry,
                cep_entry, localidade_entry, cidade_entry, estado_combo,
                data_inicial_entry, metragem_entry, cno_entry,
                cpf_entry, domicilio_entry, banco_entry, agencia_entry, conta_entry,
                pix_entry, obs_entry
            ]
 
            def proximo_campo(event, campos, index):
                """Avança para próximo campo com Enter"""
                if index < len(campos) - 1:
                    campos[index + 1].focus_set()
                    return "break"
                else:
                    btn_salvar.focus_set()
                    return "break"
 
            for i, campo in enumerate(campos_entry):
                campo.bind('<Return>', lambda e, idx=i: proximo_campo(e, campos_entry, idx))
 
            # ===== FUNÇÃO SALVAR =====
            def salvar_alteracoes():
                try:
                    nome = nome_entry.get().strip().upper()
                    logradouro = logradouro_entry.get().strip().upper()
                    numero = numero_entry.get().strip().upper()
                    complemento = complemento_entry.get().strip().upper()
                    localidade = localidade_entry.get().strip().upper()
                    cep = cep_entry.get().strip()
                    cidade = cidade_entry.get().strip().upper()
                    estado = estado_var.get()
 
                    if not nome:
                        messagebox.showerror("Erro", "Nome é obrigatório!")
                        nome_entry.focus_set()
                        return
                    if not logradouro:
                        messagebox.showerror("Erro", "Logradouro é obrigatório!")
                        logradouro_entry.focus_set()
                        return
                    if not numero:
                        messagebox.showerror("Erro", "Número é obrigatório!")
                        numero_entry.focus_set()
                        return
                    if not localidade:
                        messagebox.showerror("Erro", "Localidade é obrigatória!")
                        localidade_entry.focus_set()
                        return
                    if not cidade:
                        messagebox.showerror("Erro", "Cidade é obrigatória!")
                        cidade_entry.focus_set()
                        return

                    # CPF (PF) ou CNPJ (PJ): valida e grava sempre com máscara padrão
                    doc_ok, doc_formatado = validar_documento_cliente(cpf_entry.get())
                    if not doc_ok:
                        cpf_entry.focus_set()
                        return
                    cpf_entry.delete(0, tk.END)
                    cpf_entry.insert(0, doc_formatado)

                    # Domicílio: obrigatório na prática para PJ (sede difere da obra)
                    domicilio = domicilio_entry.get().strip().upper()
                    if doc_formatado and _eh_cnpj(_doc_limpo(doc_formatado)) and not domicilio:
                        if not messagebox.askyesno(
                            "Domicílio não informado",
                            "Cliente pessoa jurídica (CNPJ) sem domicílio (sede).\n\n"
                            "Nos contratos, o contratante será qualificado com o endereço "
                            "da obra.\n\nDeseja salvar mesmo assim?"
                        ):
                            domicilio_entry.focus_set()
                            return
 
                    eh_ficticio = eh_ficticio_var.get()
                    cliente_vinculado = cliente_vinculado_var.get().strip() if eh_ficticio else ''
                    if eh_ficticio and not cliente_vinculado:
                        messagebox.showerror(
                            "Erro",
                            "Selecione o cliente real vinculado a este cliente fictício de "
                            "gestão de mão de obra."
                        )
                        cliente_vinculado_combo.focus_set()
                        return
 
                    tem_caixa = tem_caixa_var.get()
 
                    # Confirmação extra: só pede se alguma aba de controle
                    # for CRIADA agora (checkbox que estava desmarcado e
                    # foi marcado). Desmarcar não apaga a aba nem pede
                    # confirmação - só controla exibição no relatório
                    # (eh_cliente_gestao_mo / eh_cliente_com_caixa olham a
                    # presença da aba, não esse checkbox).
                    novas_abas = []
                    if eh_ficticio and not eh_ficticio_inicial:
                        novas_abas.append("REPASSES_MO (Controle de Repasse - Mão de Obra)")
                    if tem_caixa and not tem_caixa_inicial:
                        novas_abas.append("REPASSES_CAIXA (Controle de Saldo - Caixa de Obra)")
 
                    if novas_abas:
                        lista_abas = "\n".join(f"  • {a}" for a in novas_abas)
                        confirmado = messagebox.askyesno(
                            "Confirmar criação de controle",
                            f"Esta alteração vai criar a(s) seguinte(s) aba(s) no "
                            f"arquivo do cliente:\n\n{lista_abas}\n\n"
                            f"Isso passa a exibir o(s) painel(is) correspondente(s) "
                            f"no Relatório de Despesas a partir de agora.\n\n"
                            f"Confirma a criação?"
                        )
                        if not confirmado:
                            return
 
                    partes_endereco = [logradouro, numero]
                    if complemento:
                        partes_endereco.append(complemento)
 
                    endereco = f"{', '.join(partes_endereco)} - {localidade} - {cidade}/{estado}"
 
                    metragem = None
                    if metragem_entry.get().strip():
                        try:
                            metragem = float(metragem_entry.get().strip().replace(',', '.'))
                        except ValueError:
                            messagebox.showerror("Erro", "Metragem inválida!")
                            metragem_entry.focus_set()
                            return
 
                    wb = load_workbook(ARQUIVO_CLIENTES)
                    ws = wb['Clientes']
 
                    linhas_para_remover = []
                    for idx, row in enumerate(ws.iter_rows(min_row=2), start=2):
                        if row[0].value == cliente_selecionado:
                            linhas_para_remover.append(idx)
 
                    for linha in reversed(linhas_para_remover):
                        ws.delete_rows(linha)
 
                    proxima_linha = ws.max_row + 1
 
                    ws.cell(row=proxima_linha, column=1, value=nome)
                    ws.cell(row=proxima_linha, column=2, value=endereco)
                    ws.cell(row=proxima_linha, column=3, value=data_inicial_entry.get_date())
                    ws.cell(row=proxima_linha, column=4, value=obs_entry.get().strip().upper())
 
                    if tem_data_final.get():
                        ws.cell(row=proxima_linha, column=5, value=data_final_entry.get_date())
                    else:
                        ws.cell(row=proxima_linha, column=5, value=None)
 
                    ws.cell(row=proxima_linha, column=6, value=tipo_taxa_var.get())
                    ws.cell(row=proxima_linha, column=7, value=cpf_entry.get().strip())
                    ws.cell(row=proxima_linha, column=8, value=cno_entry.get().strip())
                    ws.cell(row=proxima_linha, column=9, value=estado_civil_var.get())
                    ws.cell(row=proxima_linha, column=10, value=cidade)
                    ws.cell(row=proxima_linha, column=11, value=grupo_var.get())
 
                    ws.cell(row=proxima_linha, column=12, value=logradouro)
                    ws.cell(row=proxima_linha, column=13, value=numero)
                    ws.cell(row=proxima_linha, column=14, value=complemento)
                    ws.cell(row=proxima_linha, column=15, value=localidade)
                    ws.cell(row=proxima_linha, column=16, value=cep)
                    ws.cell(row=proxima_linha, column=17, value=estado)
                    ws.cell(row=proxima_linha, column=18, value=metragem)
                    ws.cell(row=proxima_linha, column=19, value=banco_entry.get().strip().upper())
                    ws.cell(row=proxima_linha, column=20, value=agencia_entry.get().strip())
                    ws.cell(row=proxima_linha, column=21, value=conta_entry.get().strip())
                    ws.cell(row=proxima_linha, column=22, value=tipo_conta_var.get())
                    ws.cell(row=proxima_linha, column=23, value=pix_entry.get().strip())
 
                    if ws.cell(row=1, column=24).value != 'TIPO_CLIENTE':
                        ws.cell(row=1, column=24, value='TIPO_CLIENTE')
                    if ws.cell(row=1, column=25).value != 'CLIENTE_VINCULADO':
                        ws.cell(row=1, column=25, value='CLIENTE_VINCULADO')
                    if ws.cell(row=1, column=26).value != 'CAIXA_CONTROLADO':
                        ws.cell(row=1, column=26, value='CAIXA_CONTROLADO')
 
                    ws.cell(row=proxima_linha, column=24, value='GESTAO_MO' if eh_ficticio else '')
                    ws.cell(row=proxima_linha, column=25, value=cliente_vinculado if eh_ficticio else '')
                    ws.cell(row=proxima_linha, column=26, value='SIM' if tem_caixa else '')

                    if ws.cell(row=1, column=27).value != 'DOMICILIO':
                        ws.cell(row=1, column=27, value='DOMICILIO')
                    ws.cell(row=proxima_linha, column=27, value=domicilio)
 
                    salvar_planilha_segura(wb, ARQUIVO_CLIENTES)
 
                    # Renomear arquivo se mudou o nome
                    caminho_antigo = PASTA_CLIENTES / f"{cliente_selecionado}.xlsx"
                    caminho_novo = PASTA_CLIENTES / f"{nome}.xlsx"
                    if nome != cliente_selecionado and os.path.exists(caminho_antigo):
                        os.rename(caminho_antigo, caminho_novo)
 
                    # Garantir abas de controle, se aplicável - IDEMPOTENTE
                    # (só cria se ainda não existir; não duplica, não apaga
                    # dados existentes se a aba já estava lá)
                    if eh_ficticio or tem_caixa:
                        try:
                            if os.path.exists(caminho_novo):
                                wb_cliente = load_workbook(caminho_novo)
                                alterado = False
 
                                if eh_ficticio and 'REPASSES_MO' not in wb_cliente.sheetnames:
                                    ws_r = wb_cliente.create_sheet('REPASSES_MO')
                                    ws_r.append(['ID', 'DATA_REPASSE', 'VALOR', 'REFERENCIA', 'STATUS'])
                                    alterado = True
                                    logger.info(f"Aba REPASSES_MO criada ao editar cliente: {nome}")
 
                                if tem_caixa and 'REPASSES_CAIXA' not in wb_cliente.sheetnames:
                                    ws_c = wb_cliente.create_sheet('REPASSES_CAIXA')
                                    ws_c.append(['ID', 'DATA_REPASSE', 'VALOR', 'REFERENCIA', 'STATUS'])
                                    alterado = True
                                    logger.info(f"Aba REPASSES_CAIXA criada ao editar cliente: {nome}")
 
                                if alterado:
                                    salvar_planilha_segura(wb_cliente, caminho_novo)
                                wb_cliente.close()
                            else:
                                logger.warning(
                                    f"Arquivo do cliente não encontrado em {caminho_novo} - "
                                    f"não foi possível criar as abas de controle."
                                )
                        except Exception as e:
                            logger.warning(f"Não foi possível preparar abas de controle para {nome}: {e}")
                            messagebox.showwarning(
                                "Atenção",
                                f"Cliente atualizado, mas não foi possível preparar as abas "
                                f"de controle automaticamente:\n{e}"
                            )
 
                    # Captura os valores ANTES de destruir a janela -
                    # os widgets deixam de existir após janela_edicao.destroy()
                    doc_final = cpf_entry.get().strip()
                    pix_cliente = pix_entry.get().strip()
                    banco_cliente = banco_entry.get().strip()
                    agencia_cliente = agencia_entry.get().strip()
                    conta_cliente = conta_entry.get().strip()

                    messagebox.showinfo("Sucesso", "Cliente atualizado com sucesso!")
                    self.atualizar_lista_clientes()
                    janela_edicao.destroy()

                    # CPF/CNPJ INCLUÍDO nesta edição (antes estava vazio): abre a
                    # réplica como fornecedor, mesmo fluxo do cadastro de cliente.
                    # Não grava sozinha (o usuário confirma no formulário) e, se já
                    # existir fornecedor com esse documento, apenas avisa.
                    if not doc_inicial and doc_final and not eh_ficticio:
                        self.replicar_cliente_como_fornecedor(
                            nome=nome,
                            cpf=doc_final,
                            endereco=domicilio or endereco,
                            pix=pix_cliente,
                            banco=banco_cliente,
                            agencia=agencia_cliente,
                            conta=conta_cliente,
                        )
 
                except Exception as e:
                    messagebox.showerror("Erro", f"Erro ao salvar: {str(e)}")
 
            # ===== BOTÕES =====
            ttk.Separator(frame, orient='horizontal').grid(
                row=33, column=0, columnspan=2, sticky='ew', pady=15
            )
 
            frame_botoes = ttk.Frame(frame)
            frame_botoes.grid(row=34, column=0, columnspan=2, pady=10)
 
            btn_salvar = ttk.Button(frame_botoes, text="Salvar", command=salvar_alteracoes, style='Big.TButton')
            btn_salvar.pack(side='left', padx=5)
 
            ttk.Button(frame_botoes, text="Cancelar", command=janela_edicao.destroy, style='Big.TButton').pack(side='left', padx=5)
 
            nome_entry.focus_set()
 
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao abrir editor: {str(e)}")

    def atualizar_lista_clientes(self):
        """Atualiza lista de clientes - LÓGICA CORRETA"""
        try:
            if not os.path.exists(ARQUIVO_CLIENTES):
                self.criar_arquivo_clientes()
                return
                
            workbook = load_workbook(ARQUIVO_CLIENTES)
            sheet = workbook['Clientes']
            
            clientes_ativos = []
            
            for row in range(2, sheet.max_row + 1):
                try:
                    nome = sheet.cell(row=row, column=1).value
                    data_final = sheet.cell(row=row, column=5).value  # Coluna E = Data Final
                    
                    if not nome or not isinstance(nome, str):
                        continue
                    
                    nome = nome.strip()
                    if not nome:
                        continue
                    
                    # LÓGICA CORRETA:
                    # Cliente FINALIZADO = tem Data Final preenchida (qualquer valor não-None)
                    # Cliente ATIVO = Data Final vazia (None)
                    is_finalizado = (data_final is not None)
                    
                    if not is_finalizado:
                        clientes_ativos.append(nome)
                        
                except Exception as e:
                    # logger = system_logger.get_logger()
                    logger.warning(f"Erro linha {row}: {str(e)}")
                    continue
            
            workbook.close()
            
            clientes_ativos.sort()
            self.clientes_completos = clientes_ativos
            self.cliente_combobox['values'] = clientes_ativos
            
            if hasattr(self, 'label_contador'):
                self.atualizar_contador(len(clientes_ativos))
            
            if not clientes_ativos and hasattr(self, 'label_contador'):
                self.label_contador.config(
                    text="Nenhum cliente cadastrado",
                    foreground='orange'
                )
                
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao carregar clientes: {str(e)}")
            # logger = system_logger.get_logger()
            logger.error(f"Erro detalhado: {str(e)}")
            if not hasattr(self, 'clientes_completos'):
                self.clientes_completos = []


    def criar_arquivo_clientes(self):
        """Cria arquivo base de clientes se não existir"""
        try:
            logger.debug(f"Tentando criar arquivo de clientes em: {ARQUIVO_CLIENTES}")
            logger.debug(f"Diretório existe? {os.path.exists(os.path.dirname(ARQUIVO_CLIENTES))}")
            
            # Garantir que o diretório existe
            os.makedirs(os.path.dirname(ARQUIVO_CLIENTES), exist_ok=True)
            
            workbook = openpyxl.Workbook()
            sheet = workbook.active
            sheet.title = 'Clientes'
            
            # Adicionar cabeçalhos - agora incluindo Data_Final
            headers = ['Nome', 'Endereco', 'Data_Inicial', 'Observacoes', 'Data_Final']
            for col, header in enumerate(headers, 1):
                sheet.cell(row=1, column=col, value=header)
            
            logger.debug(f"Tentando salvar arquivo em: {ARQUIVO_CLIENTES}")
            salvar_planilha_segura(workbook, ARQUIVO_CLIENTES)
            custom_messagebox("info", "Informação", "Arquivo de clientes criado com sucesso!")
            
        except Exception as e:
            logger.debug(f"Erro detalhado ao criar arquivo de clientes: {str(e)}")
            logger.debug(f"Tipo do erro: {type(e)}")
            custom_messagebox("error", "Erro", f"Erro ao criar arquivo de clientes: {str(e)}")

    def verificar_cpf_fornecedor_existente(self, cpf_numeros):
        """Verifica se já existe um fornecedor cadastrado com o CPF/CNPJ informado
        (comparação apenas por dígitos). Retorna dict com 'cnpj_cpf' e 'nome' se
        encontrado, ou None."""
        if not cpf_numeros:
            return None
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook

            wb = load_workbook(ARQUIVO_FORNECEDORES, read_only=True, data_only=True)
            ws = wb['Fornecedores']
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                # Célula numérica no Excel perde zeros à esquerda (ex.: CNPJ
                # 00.065.389/0001-53 vira 65389000153); por isso converte
                # int/float sem ".0" e compara as duas partes completadas a 14.
                valor_celula = row[0]
                if isinstance(valor_celula, float):
                    valor_celula = int(valor_celula)
                cpf_linha = _doc_limpo(valor_celula)
                if cpf_linha.zfill(14) == _doc_limpo(cpf_numeros).zfill(14):
                    wb.close()
                    return {
                        'cnpj_cpf': cpf_linha,
                        'nome': str(row[3]).strip() if len(row) > 3 and row[3] else ''
                    }
            wb.close()
            return None
        except Exception as e:
            logger.debug(f"Erro ao verificar fornecedor existente: {str(e)}")
            return None
            
    def replicar_cliente_como_fornecedor(self, nome, cpf, endereco,
                                      pix='', banco='', agencia='', conta=''):
        """Abre a janela padrão de 'Novo Fornecedor' já pré-preenchida com os dados
        do cliente recém-cadastrado, para uso quando clientes revendem equipamentos/
        ferramentas/acessórios entre si (Categoria: DIV, Vínculo: CLIENTE).

        Não grava nada sozinha: quem valida e grava é o fluxo normal de
        salvar_fornecedor(), acionado pelo próprio usuário ao clicar em Salvar.
        """
        cpf_numeros = _doc_limpo(cpf)  # dígitos (e letras, se CNPJ alfanumérico)

        if cpf_numeros:
            existente = self.verificar_cpf_fornecedor_existente(cpf_numeros)
            if existente:
                messagebox.showinfo(
                    "Fornecedor já existe",
                    f"O cliente '{nome}' já possui um fornecedor cadastrado com este CPF/CNPJ:\n\n"
                    f"{existente['nome']} ({existente['cnpj_cpf']})\n\n"
                    "Nenhum novo fornecedor será criado."
                )
                return

        # Abre a janela padrão (cria self.janela_fornecedor e self.campos_form)
        self.novo_fornecedor()

        def preencher():
            self.campos_form['cnpj_cpf'].delete(0, tk.END)
            self.campos_form['cnpj_cpf'].insert(0, cpf_numeros)

            self.campos_form['tipo_pessoa'].set('PJ' if len(cpf_numeros) == 14 else 'PF')

            self.campos_form['razao_social'].delete(0, tk.END)
            self.campos_form['razao_social'].insert(0, nome)

            self.campos_form['nome'].delete(0, tk.END)
            self.campos_form['nome'].insert(0, nome)

            self.campos_form['endereco'].delete(0, tk.END)
            self.campos_form['endereco'].insert(0, endereco)

            self.campos_form['categoria'].set('DIV')

            self.campos_form['vinculo'].delete(0, tk.END)
            self.campos_form['vinculo'].insert(0, 'CLIENTE')

            if pix:
                self.campos_form['chave_pix'].delete(0, tk.END)
                self.campos_form['chave_pix'].insert(0, pix)
            elif banco:
                self.campos_form['banco'].set(banco)
                self.campos_form['agencia'].delete(0, tk.END)
                self.campos_form['agencia'].insert(0, agencia)
                self.campos_form['conta'].delete(0, tk.END)
                self.campos_form['conta'].insert(0, conta)

            self.atualizar_resumo_dados_bancarios()

            if not cpf_numeros:
                messagebox.showinfo(
                    "Complete o CPF/CNPJ",
                    f"O cliente '{nome}' não tem CPF/CNPJ cadastrado. "
                    "Informe o CPF (ou CNPJ, se for pessoa jurídica) antes de salvar o fornecedor."
                )
            else:
                self.campos_form['telefone'].focus_set()

        # Aguarda a janela/form terminarem de ser construídos antes de preencher
        self.janela_fornecedor.after(150, preencher)

    def mostrar_todos_clientes(self):
        """Mostra todos os clientes - JANELA CORRIGIDA"""
        try:
            if not os.path.exists(ARQUIVO_CLIENTES):
                custom_messagebox("warning", "Aviso", "Arquivo não encontrado")
                return
                
            workbook = load_workbook(ARQUIVO_CLIENTES)
            sheet = workbook['Clientes']
            
            clientes_ativos = []
            clientes_finalizados = []
            
            for row in range(2, sheet.max_row + 1):
                try:
                    nome = sheet.cell(row=row, column=1).value
                    data_final = sheet.cell(row=row, column=5).value  # Coluna E = Data Final
                    
                    if not nome or not isinstance(nome, str):
                        continue
                    
                    nome = nome.strip()
                    if not nome:
                        continue
                    
                    # LÓGICA CORRETA:
                    # Cliente FINALIZADO = tem Data Final preenchida
                    # Cliente ATIVO = Data Final vazia (None)
                    is_finalizado = (data_final is not None)
                    
                    if is_finalizado:
                        clientes_finalizados.append(nome)
                    else:
                        clientes_ativos.append(nome)
                        
                except Exception as e:
                    #  logger = system_logger.get_logger()
                    logger.warning(f"Erro linha {row}: {str(e)}")
                    continue
            
            workbook.close()
            
            # ===== JANELA COM DIMENSÕES CORRETAS =====
            janela_todos = tk.Toplevel(self.root)
            janela_todos.title("Todos os Clientes")
            janela_todos.geometry("700x600")  # ← AUMENTADO de 600x500
            janela_todos.minsize(600, 500)    # ← TAMANHO MÍNIMO
            janela_todos.transient(self.root)
            janela_todos.grab_set()
            
            # Frame principal com padding adequado
            frame = ttk.Frame(janela_todos, padding="20")  # ← AUMENTADO padding
            frame.pack(fill='both', expand=True)
            
            # Título
            ttk.Label(
                frame, 
                text="Visualização Completa de Clientes",
                font=('Arial', 14, 'bold')  # ← FONTE MAIOR
            ).pack(pady=(0, 20))
            
            # ===== CLIENTES ATIVOS =====
            frame_ativos = ttk.LabelFrame(
                frame, 
                text=f"Clientes Ativos ({len(clientes_ativos)})",
                padding=(10, 10)
            )
            frame_ativos.pack(fill='both', expand=True, pady=(0, 15))
            
            frame_lista_ativos = ttk.Frame(frame_ativos)
            frame_lista_ativos.pack(fill='both', expand=True)
            
            scrollbar_ativos = ttk.Scrollbar(frame_lista_ativos)
            scrollbar_ativos.pack(side='right', fill='y')
            
            lista_ativos = tk.Listbox(
                frame_lista_ativos,
                font=('Arial', 10),
                yscrollcommand=scrollbar_ativos.set,
                height=10  # ← ALTURA FIXA
            )
            lista_ativos.pack(side='left', fill='both', expand=True)
            scrollbar_ativos.config(command=lista_ativos.yview)
            
            for cliente in sorted(clientes_ativos):
                lista_ativos.insert(tk.END, cliente)
            
            # ===== CLIENTES FINALIZADOS =====
            frame_finalizados = ttk.LabelFrame(
                frame,
                text=f"Clientes Finalizados ({len(clientes_finalizados)})",
                padding=(10, 10)
            )
            frame_finalizados.pack(fill='both', expand=True, pady=(0, 15))
            
            frame_lista_fin = ttk.Frame(frame_finalizados)
            frame_lista_fin.pack(fill='both', expand=True)
            
            scrollbar_fin = ttk.Scrollbar(frame_lista_fin)
            scrollbar_fin.pack(side='right', fill='y')
            
            lista_finalizados = tk.Listbox(
                frame_lista_fin,
                font=('Arial', 10),
                foreground='gray',
                yscrollcommand=scrollbar_fin.set,
                height=10  # ← ALTURA FIXA
            )
            lista_finalizados.pack(side='left', fill='both', expand=True)
            scrollbar_fin.config(command=lista_finalizados.yview)
            
            for cliente in sorted(clientes_finalizados):
                lista_finalizados.insert(tk.END, cliente)
            
            # ===== BOTÕES COM LAYOUT CORRETO =====
            frame_botoes = ttk.Frame(frame)
            frame_botoes.pack(fill='x', pady=(15, 0))
            
            # Criar style se não existir
            style = ttk.Style()
            style.configure('Botao.TButton', font=('Arial', 10), padding=(10, 8))
            
            def selecionar_ativo():
                try:
                    selected = lista_ativos.curselection()
                    if not selected:
                        custom_messagebox("warning", "Aviso", "Selecione um cliente ativo")
                        return
                    cliente = lista_ativos.get(selected[0])
                    self.cliente_combobox.set(cliente)
                    self.selecionar_cliente(None)
                    janela_todos.destroy()
                except Exception as e:
                    # logger = system_logger.get_logger()
                    logger.error(f"Erro: {str(e)}")
            
            def selecionar_finalizado():
                try:
                    selected = lista_finalizados.curselection()
                    if not selected:
                        custom_messagebox("warning", "Aviso", "Selecione um cliente finalizado")
                        return
                    cliente = lista_finalizados.get(selected[0])
                    self.cliente_combobox.set(cliente)
                    self.selecionar_cliente(None)
                    janela_todos.destroy()
                except Exception as e:
                    # logger = system_logger.get_logger()
                    logger.error(f"Erro: {str(e)}")
            
            # LAYOUT DE BOTÕES CORRIGIDO - SEM pack(fill='x')
            # Botões alinhados à esquerda com tamanhos fixos
            btn_ativo = ttk.Button(
                frame_botoes,
                text="✓ Selecionar Cliente Ativo",
                command=selecionar_ativo,
                style='Botao.TButton',
                width=25  # ← LARGURA FIXA
            )
            btn_ativo.pack(side='left', padx=(0, 10))
            
            btn_finalizado = ttk.Button(
                frame_botoes,
                text="✓ Selecionar Cliente Finalizado",
                command=selecionar_finalizado,
                style='Botao.TButton',
                width=28  # ← LARGURA FIXA
            )
            btn_finalizado.pack(side='left', padx=(0, 10))
            
            # Botão Fechar à direita com largura fixa
            btn_fechar = ttk.Button(
                frame_botoes,
                text="Fechar",
                command=janela_todos.destroy,
                style='Botao.TButton',
                width=15  # ← LARGURA FIXA
            )
            btn_fechar.pack(side='right')
            
            # Duplo clique
            lista_ativos.bind('<Double-Button-1>', lambda e: selecionar_ativo())
            lista_finalizados.bind('<Double-Button-1>', lambda e: selecionar_finalizado())
            
            # Centralizar janela na tela
            janela_todos.update_idletasks()
            x = (janela_todos.winfo_screenwidth() // 2) - (janela_todos.winfo_width() // 2)
            y = (janela_todos.winfo_screenheight() // 2) - (janela_todos.winfo_height() // 2)
            janela_todos.geometry(f"+{x}+{y}")
                    
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro: {str(e)}")
            # logger = system_logger.get_logger()
            logger.error(f"Erro detalhado: {str(e)}")


    def criar_arquivo_cliente(self, nome_cliente, endereco, eh_ficticio=False, tem_caixa=False):
        """Cria um novo arquivo Excel para o cliente sem depender do MODELO.xlsx

        eh_ficticio=True: cria a aba REPASSES_MO (cliente ficticio de
        gestao de mao de obra).
        tem_caixa=True: cria a aba REPASSES_CAIXA (cliente real com
        caixa de obra controlado pela construtora).
        Os dois sao independentes - um arquivo pode ter as duas abas,
        nenhuma, ou so uma delas.
        """
        try:
            logger.debug(f"\nCriando arquivo para cliente: {nome_cliente}")
            logger.debug(f"PASTA_CLIENTES: {PASTA_CLIENTES}")

            novo_arquivo = PASTA_CLIENTES / f"{nome_cliente}.xlsx"

            if os.path.exists(novo_arquivo):
                raise Exception("Arquivo do cliente já existe!")

            os.makedirs(os.path.dirname(novo_arquivo), exist_ok=True)

            workbook = openpyxl.Workbook()

            # -- Aba Dados --
            ws_dados = workbook.active
            ws_dados.title = 'Dados'

            colunas_dados = [
                'DATA_REL', 'TP_DESP', 'CNPJ_CPF', 'NOME', 'REFERÊNCIA',
                'NF', 'VR_UNIT', 'DIAS', 'VALOR', 'DT_VENCTO',
                'CATEGORIA', 'DADOS_BANCARIOS', 'OBSERVAÇÃO', 'STATUS',
                'ID_LANCAMENTO', 'HISTORICO_ALTERACAO', 'ETAPA_OBRA', 'INSUMO'
            ]
            for col, nome_col in enumerate(colunas_dados, 1):
                cell = ws_dados.cell(row=1, column=col, value=nome_col)
                cell.font = openpyxl.styles.Font(bold=True)

            # -- Aba Contratos_ADM --
            contratos_sheet = workbook.create_sheet("Contratos_ADM")

            blocos = ["CONTRATOS", "", "", "", "", "",
                      "ADMINISTRADORES_CONTRATO", "", "", "", "", "", "",
                      "ADITIVOS", "", "", "",
                      "ADMINISTRADORES_ADITIVO", "", "", "", "", "", "",
                      "PARCELAS", "", "", "", "", "", "", "", "", ""]

            for col, valor in enumerate(blocos, 1):
                contratos_sheet.cell(row=1, column=col, value=valor)

            headers = [
                "Nº Contrato", "Data Início", "Data Fim", "Status", "Observações", "",
                "Nº Contrato", "CNPJ/CPF", "Nome/Razão Social", "Tipo", "Valor/Percentual", "Valor Total", "Nº Parcelas",
                "Nº Contrato", "Nº Aditivo", "Data Início", "Data Fim",
                "Nº Contrato", "Nº Aditivo", "CNPJ/CPF", "Nome/Razão Social", "Tipo", "Valor/Percentual", "Valor Total",
                "Referência", "Número", "CNPJ/CPF", "Nome", "Data Vencimento", "Valor", "Status", "Data Pagamento", "Eventos/Fases", "Percentual %"
            ]

            for col, header in enumerate(headers, 1):
                cell = contratos_sheet.cell(row=2, column=col, value=header)
                cell.font = openpyxl.styles.Font(bold=True)
                cell.alignment = openpyxl.styles.Alignment(horizontal='center')

            for col in range(1, len(headers) + 1):
                contratos_sheet.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 15

            # -- Aba REPASSES_MO (cliente ficticio de gestao de MO) --
            if eh_ficticio:
                ws_repasses_mo = workbook.create_sheet("REPASSES_MO")
                colunas_repasses = ['ID', 'DATA_REPASSE', 'VALOR', 'REFERENCIA', 'STATUS']
                for col, nome_col in enumerate(colunas_repasses, 1):
                    cell = ws_repasses_mo.cell(row=1, column=col, value=nome_col)
                    cell.font = openpyxl.styles.Font(bold=True)
                logger.debug(f"Aba REPASSES_MO incluida para cliente ficticio: {nome_cliente}")

            # -- Aba REPASSES_CAIXA (cliente real com caixa controlado) --
            if tem_caixa:
                ws_repasses_caixa = workbook.create_sheet("REPASSES_CAIXA")
                colunas_repasses = ['ID', 'DATA_REPASSE', 'VALOR', 'REFERENCIA', 'STATUS']
                for col, nome_col in enumerate(colunas_repasses, 1):
                    cell = ws_repasses_caixa.cell(row=1, column=col, value=nome_col)
                    cell.font = openpyxl.styles.Font(bold=True)
                logger.debug(f"Aba REPASSES_CAIXA incluida para cliente com caixa controlado: {nome_cliente}")

            salvar_planilha_segura(workbook, novo_arquivo)
            logger.info(f"Arquivo do cliente criado: {novo_arquivo}")
            return True

        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao criar arquivo do cliente: {str(e)}")
            return False

    
    def abrir_gestao_contratos(self):
        """Abre a gestão de contratos para o cliente atual"""
        if not self.cliente_atual:
            custom_messagebox("warning", "Aviso", "Selecione um cliente primeiro!")
            return
        
        # Ocultar temporariamente a janela principal
        self.root.withdraw()
        
        # Criar e configurar a janela de gestão de contratos diretamente aqui
        # em vez de delegar para outra classe/método
        janela_gestao = tk.Toplevel(self.root)
        janela_gestao.title(f"Gestão de Contratos - {self.cliente_atual}")
        janela_gestao.geometry("800x750")
        
        # Centralizar a janela (sem depender de um método da classe GestaoContratos)
        janela_gestao.update_idletasks()
        width = janela_gestao.winfo_width()
        height = janela_gestao.winfo_height()
        x = (janela_gestao.winfo_screenwidth() // 2) - (width // 2)
        y = (janela_gestao.winfo_screenheight() // 2) - (height // 2)
        janela_gestao.geometry(f'{width}x{height}+{x}+{y}')
        
        # Colocar a janela em primeiro plano
        janela_gestao.attributes('-topmost', True)
        janela_gestao.after(100, lambda: janela_gestao.attributes('-topmost', False))
        
        # Definir comportamento quando a janela for fechada
        def on_close():
            janela_gestao.destroy()
            self.root.deiconify()  # Mostrar a janela principal novamente
            self.root.lift()
            self.root.focus_force()
        
        # Configurar protocolo de fechamento
        janela_gestao.protocol("WM_DELETE_WINDOW", on_close)
        
        # Criar o restante da interface usando o gestor de contratos
        gestor = GestaoContratos(janela_gestao)  # Passamos a janela_gestao como parent
        gestor.cliente_atual = self.cliente_atual
        gestor.arquivo_cliente = PASTA_CLIENTES / f"{self.cliente_atual}.xlsx"
        
        # Criar e preencher a interface dentro da janela_gestao
        gestor.criar_interface_contratos(janela_gestao, on_close)

    def abrir_controle_pagamentos(self):
        """Abre o módulo de controle de pagamentos"""
        try:
            # Importar módulo
            from controle_pagamentos import ControlePagamentos
            
            # Instanciar e abrir janela de controle
            controle = ControlePagamentos(self.root)
        except ImportError as e:
            custom_messagebox("error", "Erro", f"Não foi possível importar o módulo de Controle de Pagamentos: {str(e)}")
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir controle de pagamentos: {str(e)}")

    
    def configurar_protecoes(self):
        """
        Configura proteções contra perda de dados
        Deve ser chamado no __init__ da classe principal
        """
        try:
            # Vincular evento de fechamento da janela
            if hasattr(self, 'janela_principal'):
                self.janela_principal.protocol("WM_DELETE_WINDOW", self.fechar_aplicacao)
            
            # Vincular evento de mudança no combo de clientes
            if hasattr(self, 'combo_cliente'):
                # Remover binding anterior se existir
                self.combo_cliente.unbind('<<ComboboxSelected>>')
                # Adicionar novo binding com proteção
                self.combo_cliente.bind('<<ComboboxSelected>>', self.selecionar_cliente)
            
            # logger = system_logger.get_logger()
            logger.info("Proteções contra perda de dados configuradas")
            
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.error(f"Erro ao configurar proteções: {str(e)}")

    def continuar_para_fornecedor(self):
        """Avança para a aba de fornecedor após confirmar seleção"""
        if self.cliente_atual:
            self.notebook.select(1)  # Vai para aba de fornecedor
        else:
            custom_messagebox("warning",  "Aviso", "Selecione um cliente primeiro!")

    
    def setup_aba_fornecedor(self):
        """Configura a aba de fornecedor com layout elegante e botões de tamanho médio"""
        # Criar estilo para botões médios
        style = ttk.Style()
        style.configure('Medium.TButton', font=('Arial', 11), padding=(10, 6))
        
        # Frame para exibir o cliente selecionado
        frame_cliente = ttk.Frame(self.aba_fornecedor)
        frame_cliente.pack(fill='x', padx=10, pady=5)
        
        # Label para mostrar o cliente selecionado
        self.lbl_cliente_fornecedor = ttk.Label(
            frame_cliente, 
            text="Cliente: Nenhum selecionado", 
            font=('Arial', 12, 'bold'),
            foreground='#0056b3'
        )
        self.lbl_cliente_fornecedor.pack(anchor='w', padx=5)
        
        # Frame de busca com tamanho reduzido
        frame_busca = ttk.LabelFrame(self.aba_fornecedor, text="Busca de Fornecedor")
        frame_busca.pack(fill='x', padx=10, pady=5)

        # Frame interno para organizar os elementos de busca
        busca_interno = ttk.Frame(frame_busca)
        busca_interno.pack(fill='x', padx=5, pady=5)

        # Campo de busca
        ttk.Label(busca_interno, text="Nome:", font=('Arial', 10)).pack(side='left', padx=5)
        self.busca_entry = ttk.Entry(busca_interno, font=('Arial', 10), width=40)
        self.busca_entry.pack(side='left', padx=5)
        self.busca_entry.bind('<Return>', lambda e: self.buscar_fornecedor())

        # Botão de busca
        ttk.Button(busca_interno, 
            text="Buscar", 
            command=self.buscar_fornecedor,
            style='Medium.TButton').pack(side='left', padx=10)

        ttk.Button(busca_interno, 
                text="📋 Lançamentos", 
                command=self.abrir_visualizador_fornecedor,
                style='Medium.TButton').pack(side='left', padx=5)

        # Frame principal para resultados
        frame_resultados = ttk.Frame(self.aba_fornecedor)
        frame_resultados.pack(fill='both', expand=True, padx=10, pady=5)

        # Lista de resultados com scrollbar
        frame_tree = ttk.Frame(frame_resultados)
        frame_tree.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Scrollbar vertical
        scroll_y = ttk.Scrollbar(frame_tree, orient='vertical')
        scroll_y.pack(side='right', fill='y')
        
        # Treeview para resultados
        self.tree_fornecedores = ttk.Treeview(frame_tree, 
                                            columns=('CNPJ/CPF', 'Nome', 'Categoria'),
                                            show='headings',
                                            yscrollcommand=scroll_y.set) 
        
        self.tree_fornecedores.heading('CNPJ/CPF', text='CNPJ/CPF')
        self.tree_fornecedores.heading('Nome', text='Nome')
        self.tree_fornecedores.heading('Categoria', text='Categoria')
        
        # Configurar larguras das colunas
        self.tree_fornecedores.column('CNPJ/CPF', width=150, anchor='w')
        self.tree_fornecedores.column('Nome', width=300)
        self.tree_fornecedores.column('Categoria', width=100)
        
        self.tree_fornecedores.pack(side='left', fill='both', expand=True)
        scroll_y.config(command=self.tree_fornecedores.yview)
        
        # Adicionar evento de duplo clique para selecionar fornecedor
        self.tree_fornecedores.bind('<Double-1>', lambda e: self.selecionar_fornecedor())

        # Frame para botões de ação do fornecedor (dia a dia)
        frame_acoes = ttk.Frame(self.aba_fornecedor)
        frame_acoes.pack(fill='x', padx=10, pady=5)

        ttk.Button(frame_acoes, 
                text="Novo Fornecedor", 
                command=self.novo_fornecedor).pack(side='left', padx=5)
        ttk.Button(frame_acoes, 
                text="Editar Fornecedor", 
                command=self.editar_fornecedor).pack(side='left', padx=5)
        ttk.Button(frame_acoes, 
                text="🗑️ Excluir/Inativar", 
                command=self.gerenciar_exclusao_fornecedor).pack(side='left', padx=5)
        ttk.Button(frame_acoes, 
                text="📋 Ver Inativos", 
                command=self.listar_fornecedores_inativos).pack(side='left', padx=5)
        ttk.Button(frame_acoes, 
                text="Selecionar", 
                command=self.selecionar_fornecedor).pack(side='left', padx=5)

        # Separador para dividir visualmente as seções
        ttk.Separator(self.aba_fornecedor, orient='horizontal').pack(fill='x', padx=10, pady=5)

        # Frame para manutenção/correção de cadastro (nova seção, linha própria)
        frame_manutencao_cadastro = ttk.LabelFrame(self.aba_fornecedor, text="🛠️ Manutenção de Cadastro")
        frame_manutencao_cadastro.pack(fill='x', padx=10, pady=5)

        frame_botoes_manutencao = ttk.Frame(frame_manutencao_cadastro)
        frame_botoes_manutencao.pack(fill='x', padx=5, pady=8)

        ttk.Button(frame_botoes_manutencao,
                text="🗑️ Gerenciar CPFs Criados",
                command=self.gerenciar_cpfs_criados).pack(side='left', padx=5)

        ttk.Button(frame_botoes_manutencao,
                text="🔧 Regularizar Cadastro",
                command=self.abrir_regularizar_fornecedor).pack(side='left', padx=5)

        ttk.Button(frame_botoes_manutencao,
                text="🔗 Mesclar Duplicados",
                command=self.abrir_fundir_fornecedores).pack(side='left', padx=5)

        ttk.Label(frame_botoes_manutencao,
                text="(corrigir CPF/nome errado, unir cadastros duplicados)",
                font=('Arial', 8),
                foreground='gray').pack(side='left', padx=10)
        

        self.adicionar_botao_gerenciar_lancamentos()

        # Separador para dividir visualmente as seções
        ttk.Separator(self.aba_fornecedor, orient='horizontal').pack(fill='x', padx=10, pady=5)

        # Frame para taxas e processamento
        frame_taxas = ttk.LabelFrame(self.aba_fornecedor, text="Funções Administrativas")
        frame_taxas.pack(fill='x', padx=10, pady=5)

        # Container para botões de taxas
        frame_botoes_taxas = ttk.Frame(frame_taxas)
        frame_botoes_taxas.pack(fill='x', padx=5, pady=8)

        ttk.Button(
            frame_botoes_taxas, 
            text="Controle de Pagamentos de Taxa",
            command=self.abrir_controle_pagamentos,
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_taxas, 
            text="Finalização de Quinzena",
            command=self.abrir_finalizacao_quinzena,
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_taxas, 
            text="Correção Monetária",
            command=self.abrir_correcao_monetaria,
        ).pack(side='left', padx=5)

        ttk.Button(
                    frame_botoes_taxas, 
                    text="🔍 Verificar Consistência das Taxas",
                    command=lambda: self.verificar_e_mostrar_consistencia(),
                ).pack(side='left', padx=5)

       
        # Separador para dividir visualmente as seções
        ttk.Separator(self.aba_fornecedor, orient='horizontal').pack(fill='x', padx=10, pady=5)
        
        # Frame para importações
        frame_importacoes = ttk.LabelFrame(self.aba_fornecedor, text="Importação de Dados de Planilhas")
        frame_importacoes.pack(fill='x', padx=10, pady=5)
        
        frame_botoes_import = ttk.Frame(frame_importacoes)
        frame_botoes_import.pack(fill='x', padx=5, pady=8)
        
        # Botões de importação reorganizados
        ttk.Button(
            frame_botoes_import,
            text="🚛 Transporte",
            command=self.importar_transporte_cafe,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_import,
            text="👥 Folha RH",
            command=self.importar_folha_rh,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_import,
            text="📋 Diárias",
            command=self.importar_diarias,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

        # Dentro de setup_aba_fornecedor, no frame_botoes_import que já existe
        # (junto de "Importar Transporte", "Importar Folha RH" etc.)
        # ttk.Button(
        #     frame_botoes_import,
        #     text="📄 Importar Guia (FGTS/DARF)",
        #     command=self.importar_guia_recorrente,
        #     style='Medium.TButton'
        # ).pack(side='left', padx=5)
        
        ttk.Button(
            frame_botoes_import,
            text="📧 E-mail",
            command=self.importar_documentos_email,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_import, 
            text="📊 Medições",  # ← NOVO BOTÃO
            command=self.importar_medicoes,
            style='Medium.TButton'
        ).pack(side='left', padx=5)
        
        ttk.Button(
            frame_botoes_import, 
            text="🔧 Gestão de Locações", 
            command=self.abrir_gestao_locacoes,
            style='Medium.TButton'
        ).pack(side='left', padx=5)
       
        # Separador antes dos botões gerais
        ttk.Separator(self.aba_fornecedor, orient='horizontal').pack(fill='x', padx=10, pady=5)
        
        # Frame de botões gerais na parte inferior (MANTIDO)
        frame_botoes_fornecedor = ttk.Frame(self.aba_fornecedor)
        frame_botoes_fornecedor.pack(fill='x', padx=10, pady=10, side='bottom')

        ttk.Button(frame_botoes_fornecedor, 
           text="📁 Abrir Logs", 
           command=self.abrir_pasta_logs).pack(side='left', padx=5)

        ttk.Button(frame_botoes_fornecedor, 
                text="Voltar ao Menu", 
                command=self.voltar_menu,
                style='Medium.TButton').pack(side='right', padx=5)
        ttk.Button(frame_botoes_fornecedor, 
                text="Sair", 
                command=self.sair_sistema,
                style='Medium.TButton').pack(side='right', padx=5)
        
        # self.adicionar_secao_materiais_fornecedor()

    
    def novo_fornecedor(self):
        """Abre janela para cadastro de novo fornecedor - VERSÃO CORRIGIDA"""
        self.janela_fornecedor = tk.Toplevel(self.root)
        self.janela_fornecedor.title("Novo Fornecedor")
        self.janela_fornecedor.geometry("800x750")
        
        self.janela_fornecedor.transient(self.root)  # Definir como janela filha
        self.janela_fornecedor.grab_set()  # Tornar modal
        self.janela_fornecedor.update_idletasks()  # Garantir que o tamanho seja calculado
        
        # Calcular posição central
        largura = 800
        altura = 750
        pos_x = (self.janela_fornecedor.winfo_screenwidth() // 2) - (largura // 2)
        pos_y = (self.janela_fornecedor.winfo_screenheight() // 2) - (altura // 2)
        
        # Aplicar posição
        self.janela_fornecedor.geometry(f"{largura}x{altura}+{pos_x}+{pos_y}")

        self.janela_fornecedor.lift()  # Trazer para frente
        self.janela_fornecedor.focus_force()  # Forçar foco
        self.janela_fornecedor.attributes('-topmost', True)  # Manter no topo temporariamente

        self.janela_fornecedor.after(500, lambda: self.janela_fornecedor.attributes('-topmost', False))
        
        # Configurar formulário
        self.setup_formulario_fornecedor()

        self.janela_fornecedor.after(100, lambda: self.janela_fornecedor.focus_force())

    def setup_formulario_fornecedor(self, modo_edicao=False):
        """
        Configura o formulário de cadastro/edição de fornecedor com suporte a CPFs criados
        Para novos campos na planilha:
        adicionar a coluna na planilha, adicionar a entrada em COLUNAS, 
        adicionar a entrada no dicionário dados, 
        e adicionar o widget no setup_formulario_fornecedor
        """

        self.modo_edicao_fornecedor = modo_edicao
        
        formulario = ttk.Frame(self.janela_fornecedor)
        formulario.pack(padx=10, pady=5, fill='both', expand=True)

        # Inicializar gerenciador de CPFs se não existir
        if not hasattr(self, 'gerenciador_cpfs'):
            self.gerenciador_cpfs = GerenciadorCPFsCriados()

        # Campos principais
        campos_principais = ttk.LabelFrame(formulario, text="Dados Principais")
        campos_principais.pack(fill='x', pady=5)

        self.campos_form = {}

        # Frame especial para CNPJ/CPF com botões de CPF criado
        frame_cpf_completo = ttk.Frame(campos_principais)
        frame_cpf_completo.grid(row=0, column=0, columnspan=4, sticky='ew', padx=5, pady=5)

        # Label e campo CNPJ/CPF
        tk.Label(frame_cpf_completo, text="CNPJ/CPF:*").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['cnpj_cpf'] = tk.Entry(frame_cpf_completo, width=20)
        self.campos_form['cnpj_cpf'].grid(row=0, column=1, padx=5, pady=2)
        self.campos_form['cnpj_cpf'].bind('<FocusOut>', self.atualizar_tipo_pessoa)
        
        # Tipo de pessoa
        tk.Label(frame_cpf_completo, text="Tipo:*").grid(row=0, column=2, padx=10, pady=2, sticky='w')
        self.campos_form['tipo_pessoa'] = ttk.Combobox(frame_cpf_completo, 
                                                    values=['PF', 'PJ'],
                                                    state='readonly',
                                                    width=5)
        self.campos_form['tipo_pessoa'].grid(row=0, column=3, padx=5, pady=2)

        # Frame para botões de CPF criado
        frame_botoes_cpf = ttk.Frame(frame_cpf_completo)
        frame_botoes_cpf.grid(row=1, column=0, columnspan=4, pady=5, sticky='ew')

        # Botão para usar CPF criado automaticamente
        btn_cpf_auto = ttk.Button(frame_botoes_cpf, 
                                text="🔄 Obter CPF Criado", 
                                command=self.usar_cpf_criado_auto,
                                width=18)
        btn_cpf_auto.pack(side='left', padx=5)

        # Botão para escolher CPF da lista
        btn_cpf_lista = ttk.Button(frame_botoes_cpf, 
                                text="📋 Escolher da Lista", 
                                command=self.mostrar_cpfs_disponiveis,
                                width=18)
        btn_cpf_lista.pack(side='left', padx=5)

        # Label informativo
        lbl_info = tk.Label(frame_botoes_cpf, 
                        text="💡 Use estes botões para prestadores sem CPF próprio",
                        font=('Arial', 8),
                        fg='gray')
        lbl_info.pack(side='left', padx=20)

        # Razão Social e Nome
        tk.Label(campos_principais, text="Razão Social:*").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['razao_social'] = tk.Entry(campos_principais, width=80)
        self.campos_form['razao_social'].grid(row=1, column=1, columnspan=3, padx=5, pady=2, sticky='ew')
        self.campos_form['razao_social'].bind('<FocusOut>', self.copiar_para_nome)

        tk.Label(campos_principais, text="Nome Fantasia:*").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['nome'] = tk.Entry(campos_principais, width=50)
        self.campos_form['nome'].grid(row=2, column=1, columnspan=3, padx=5, pady=2, sticky='ew')

        # Contatos - Frame especial para telefone com botão PIX
        campos_contato = ttk.LabelFrame(formulario, text="Contato")
        campos_contato.pack(fill='x', pady=5)

        # Frame para telefone com botão PIX
        frame_telefone = ttk.Frame(campos_contato)
        frame_telefone.grid(row=0, column=0, columnspan=2, sticky='ew', padx=5, pady=2)

        tk.Label(frame_telefone, text="Telefone:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['telefone'] = tk.Entry(frame_telefone, width=20)
        self.campos_form['telefone'].grid(row=0, column=1, padx=5, pady=2)

        # Botão para usar telefone como PIX
        btn_tel_pix = ttk.Button(frame_telefone, 
                                text="📱 Usar como PIX", 
                                command=self.usar_telefone_como_pix,
                                width=15)
        btn_tel_pix.grid(row=0, column=2, padx=10, pady=2)

        # Email
        tk.Label(campos_contato, text="Email:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['email'] = tk.Entry(campos_contato, width=50)
        self.campos_form['email'].grid(row=1, column=1, padx=5, pady=2, sticky='ew')

        # Responsável (opcional)
        tk.Label(campos_contato, text="Responsável:").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['responsavel'] = tk.Entry(campos_contato, width=50)
        self.campos_form['responsavel'].grid(row=2, column=1, padx=5, pady=2, sticky='ew')

        # ===== NOVA SEÇÃO: RESUMO DOS DADOS BANCÁRIOS =====
        frame_resumo_bancario = ttk.LabelFrame(formulario, text="📋 Resumo dos Dados Bancários")
        frame_resumo_bancario.pack(fill='x', pady=5)

        frame_resumo_interno = ttk.Frame(frame_resumo_bancario)
        frame_resumo_interno.pack(fill='x', padx=10, pady=10)

        tk.Label(frame_resumo_interno, text="Dados Consolidados:", 
                font=('Arial', 9, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='w')
        
        self.campos_form['dados_bancarios_display'] = tk.Entry(frame_resumo_interno, 
                                                            width=60, 
                                                            state='readonly',
                                                            font=('Arial', 9))
        self.campos_form['dados_bancarios_display'].grid(row=0, column=1, padx=5, pady=2, sticky='ew')
        
        # Botão para limpar todos os dados bancários
        btn_limpar_bancarios = ttk.Button(frame_resumo_interno, 
                                        text="🗑️ Limpar Dados Bancários", 
                                        command=self.limpar_todos_dados_bancarios,
                                        width=22)
        btn_limpar_bancarios.grid(row=0, column=2, padx=5, pady=2)

        frame_resumo_interno.columnconfigure(1, weight=1)

        # Dados Bancários
        campos_bancarios = ttk.LabelFrame(formulario, text="Dados Bancários Detalhados")
        campos_bancarios.pack(fill='x', pady=5)

        # Carregar configurações
        try:
            carregar_configuracoes()  
            lista_bancos = get_bancos()
        except Exception as e:
            logger.debug(f"Erro ao carregar bancos: {str(e)}")
            lista_bancos = []

        tk.Label(campos_bancarios, text="Banco:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['banco'] = ttk.Combobox(
            campos_bancarios,
            values=lista_bancos,
            state='readonly'
        )
        self.campos_form['banco'].grid(row=0, column=1, padx=5, pady=2, sticky='ew')
        # Bind para atualizar resumo quando banco mudar
        self.campos_form['banco'].bind('<<ComboboxSelected>>', self.atualizar_resumo_dados_bancarios)

        tk.Label(campos_bancarios, text="Operação:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['op'] = tk.Entry(campos_bancarios)
        self.campos_form['op'].grid(row=1, column=1, padx=5, pady=2, sticky='ew')
        self.campos_form['op'].bind('<KeyRelease>', self.atualizar_resumo_dados_bancarios)

        tk.Label(campos_bancarios, text="Agência:").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['agencia'] = tk.Entry(campos_bancarios)
        self.campos_form['agencia'].grid(row=2, column=1, padx=5, pady=2, sticky='ew')
        self.campos_form['agencia'].bind('<KeyRelease>', self.atualizar_resumo_dados_bancarios)

        tk.Label(campos_bancarios, text="Conta:").grid(row=3, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['conta'] = tk.Entry(campos_bancarios)
        self.campos_form['conta'].grid(row=3, column=1, padx=5, pady=2, sticky='ew')
        self.campos_form['conta'].bind('<KeyRelease>', self.atualizar_resumo_dados_bancarios)

        # PIX
        campos_pix = ttk.LabelFrame(formulario, text="Chave PIX")
        campos_pix.pack(fill='x', pady=5)

        # Tipo de chave PIX
        ttk.Label(campos_pix, text="Tipo de Chave:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.tipo_pix = ttk.Combobox(
            campos_pix, 
            values=['Selecione', 'CNPJ/CPF', 'Telefone', 'Email'],
            state='readonly'
        )
        self.tipo_pix.grid(row=0, column=1, padx=5, pady=2)
        self.tipo_pix.set('Telefone')  # Padrão para prestadores
        self.tipo_pix.bind('<<ComboboxSelected>>', self.atualizar_chave_pix)

        ttk.Label(campos_pix, text="Chave:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['chave_pix'] = ttk.Entry(campos_pix, width=40)
        self.campos_form['chave_pix'].grid(row=1, column=1, padx=5, pady=2, sticky='ew')
        self.campos_form['chave_pix'].bind('<KeyRelease>', self.atualizar_resumo_dados_bancarios)

        # Classificação
        campos_class = ttk.LabelFrame(formulario, text="Classificação")
        campos_class.pack(fill='x', pady=5)

        # Carregar categorias
        try:
            categorias = get_categorias_fornecedor()
        except Exception as e:
            logger.debug(f"Erro ao carregar categorias: {str(e)}")
            categorias = ['ADM', 'DIV', 'LOC', 'MAT', 'MO', 'SERV', 'TP']

        tk.Label(campos_class, text="Categoria:*").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['categoria'] = ttk.Combobox(campos_class, 
                                                    values=categorias,
                                                    state='readonly')
        self.campos_form['categoria'].grid(row=0, column=1, padx=5, pady=2, sticky='ew')

        tk.Label(campos_class, text="Especificação:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['especificacao'] = tk.Entry(campos_class, width=40)
        self.campos_form['especificacao'].grid(row=1, column=1, padx=5, pady=2, sticky='ew')

        tk.Label(campos_class, text="Vínculo:").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['vinculo'] = tk.Entry(campos_class, width=40)
        self.campos_form['vinculo'].grid(row=2, column=1, padx=5, pady=2, sticky='ew')

        tk.Label(campos_class, text="Endereço:").grid(row=3, column=0, padx=5, pady=2, sticky='w')
        self.campos_form['endereco'] = tk.Entry(campos_class, width=100)
        self.campos_form['endereco'].grid(row=3, column=1, padx=5, pady=2, sticky='ew')

        # Botões de ação
        frame_botoes = ttk.Frame(formulario)
        frame_botoes.pack(fill='x', pady=10)

        ttk.Button(frame_botoes, 
                text="Salvar", 
                command=self.salvar_fornecedor).pack(side='left', padx=5)
        ttk.Button(frame_botoes, 
                text="Cancelar", 
                command=self.janela_fornecedor.destroy).pack(side='left', padx=5)

        # Atualizar resumo inicial (caso esteja em modo edição)
        if modo_edicao:
            self.janela_fornecedor.after(100, self.atualizar_resumo_dados_bancarios)

    def editar_fornecedor(self):
        """Abre janela para edição de fornecedor existente"""
        selecionado = self.tree_fornecedores.selection()
        if not selecionado:
            custom_messagebox("warning",  "Aviso", "Selecione um fornecedor para editar")
            return

        # Buscar dados completos do fornecedor
        fornecedor = self.buscar_fornecedor_completo(
            self.tree_fornecedores.item(selecionado)['values'][0]
        )
        if not fornecedor:
            custom_messagebox("error", "Erro", "Fornecedor não encontrado")
            return

        # Criar janela de edição
        self.janela_fornecedor = tk.Toplevel(self.root)
        self.janela_fornecedor.title("Editar Fornecedor")
        self.setup_formulario_fornecedor(modo_edicao=True)

        try:
            # Tipo de pessoa: a coluna B da planilha (PF/PJ) é a fonte da verdade.
            # O tamanho do documento só é usado se a coluna B estiver vazia, e
            # contando apenas letras/dígitos (a máscara não entra na conta).
            cnpj_cpf = str(fornecedor['cnpj_cpf']).strip()
            tipo_pessoa = str(fornecedor.get('tipo_pessoa') or '').strip().upper()
            if tipo_pessoa not in ('PF', 'PJ'):
                tipo_pessoa = 'PJ' if len(''.join(filter(str.isalnum, cnpj_cpf))) > 11 else 'PF'

            # Preencher e configurar campos não editáveis
            # CNPJ/CPF
            self.campos_form['cnpj_cpf'].insert(0, cnpj_cpf.zfill(14 if tipo_pessoa == 'PJ' else 11))
            self.campos_form['cnpj_cpf'].config(state='readonly')
            
            # Tipo Pessoa
            self.campos_form['tipo_pessoa'].set(tipo_pessoa)
            self.campos_form['tipo_pessoa'].config(state='disabled')
            
            # Razão Social
            self.campos_form['razao_social'].insert(0, fornecedor['razao_social'] or '')
            self.campos_form['razao_social'].config(state='readonly')
            
            # Preencher campos editáveis
            self.campos_form['nome'].insert(0, fornecedor['nome'] or '')
            self.campos_form['telefone'].insert(0, fornecedor['telefone'] or '')
            self.campos_form['email'].insert(0, fornecedor['email'] or '')
            self.campos_form['banco'].set(fornecedor['banco'] or '')
            self.campos_form['op'].insert(0, fornecedor['op'] or '')
            self.campos_form['agencia'].insert(0, fornecedor['agencia'] or '')
            self.campos_form['conta'].insert(0, fornecedor['conta'] or '')
            self.campos_form['chave_pix'].insert(0, fornecedor['chave_pix'] or '')
            self.tipo_pix.set(_tipo_chave_pix(fornecedor['chave_pix'],
                                              fornecedor.get('cnpj_cpf'),
                                              fornecedor.get('telefone')))
            
            # Categoria (pode ser combobox)
            if isinstance(self.campos_form['categoria'], ttk.Combobox):
                self.campos_form['categoria'].set(fornecedor['categoria'] or '')
            else:
                self.campos_form['categoria'].insert(0, fornecedor['categoria'] or '')
                
            self.campos_form['especificacao'].insert(0, fornecedor['especificacao'] or '')
            self.campos_form['vinculo'].insert(0, fornecedor['vinculo'] or '')
            self.campos_form['endereco'].insert(0, fornecedor['endereco'] or '')
            self.campos_form['responsavel'].insert(0, fornecedor.get('responsavel') or '')

            # Centralizar a janela
            self.janela_fornecedor.update_idletasks()
            width = self.janela_fornecedor.winfo_width()
            height = self.janela_fornecedor.winfo_height()
            x = (self.janela_fornecedor.winfo_screenwidth() // 2) - (width // 2)
            y = (self.janela_fornecedor.winfo_screenheight() // 2) - (height // 2)
            self.janela_fornecedor.geometry('{}x{}+{}+{}'.format(width, height, x, y))
            
            # Tornar a janela modal
            self.janela_fornecedor.transient(self.root)
            self.janela_fornecedor.grab_set()

        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao carregar dados do fornecedor: {str(e)}")
            self.janela_fornecedor.destroy()

    def gerenciar_exclusao_fornecedor(self):
        """
        Abre janela para excluir ou inativar fornecedor selecionado
        Permite escolher entre exclusão física ou inativação
        """
        try:
            from src.config.utils import custom_messagebox
            from src.config.config import ARQUIVO_FORNECEDORES
            
            # Verificar se há fornecedor selecionado
            selecionado = self.tree_fornecedores.selection()
            if not selecionado:
                custom_messagebox("warning", "Aviso", 
                                "⚠️ Selecione um fornecedor na lista primeiro!")
                return
            
            # Obter dados do fornecedor selecionado
            valores = self.tree_fornecedores.item(selecionado[0])['values']
            tags = self.tree_fornecedores.item(selecionado[0])['tags']
            
            if len(valores) < 3 or valores[1] == 'Nenhum fornecedor encontrado':
                custom_messagebox("warning", "Aviso", "Selecione um fornecedor válido!")
                return
            
            # Extrair dados
            cnpj_tag = tags[0] if tags and len(tags) > 0 else ''
            
            # Remover prefixo "ID:" se existir
            if cnpj_tag.startswith('ID:'):
                cnpj_cpf_normalizado = cnpj_tag[3:]
            else:
                cnpj_cpf_normalizado = str(cnpj_tag)
            
            nome = str(valores[1]).strip()
            categoria = str(valores[2]).strip()
            cnpj_cpf_formatado = str(valores[0]).strip()
            
            # Buscar dados completos
            fornecedor = self.buscar_fornecedor_completo(cnpj_cpf_normalizado)
            
            if not fornecedor:
                custom_messagebox("error", "Erro", 
                                f"Não foi possível carregar dados do fornecedor!\n\n"
                                f"CNPJ/CPF: {cnpj_cpf_formatado}")
                return
            
            # Criar janela de gerenciamento
            janela_exclusao = tk.Toplevel(self.root)
            janela_exclusao.title("Excluir/Inativar Fornecedor")
            janela_exclusao.geometry("600x600")
            janela_exclusao.transient(self.root)
            janela_exclusao.grab_set()
            
            # Centralizar
            janela_exclusao.update_idletasks()
            x = (janela_exclusao.winfo_screenwidth() // 2) - 300
            y = (janela_exclusao.winfo_screenheight() // 2) - 300
            janela_exclusao.geometry(f"600x600+{x}+{y}")
            
            main_frame = ttk.Frame(janela_exclusao, padding="20")
            main_frame.pack(fill='both', expand=True)
            
            # ============================================
            # CABEÇALHO
            # ============================================
            header_frame = ttk.Frame(main_frame)
            header_frame.pack(fill='x', pady=(0, 20))
            
            ttk.Label(header_frame, 
                    text="🗑️ Gerenciar Exclusão/Inativação",
                    font=('Arial', 16, 'bold')).pack()
            
            ttk.Separator(header_frame, orient='horizontal').pack(fill='x', pady=10)
            
            # ============================================
            # DADOS DO FORNECEDOR
            # ============================================
            dados_frame = ttk.LabelFrame(main_frame, text="📋 Dados do Fornecedor")
            dados_frame.pack(fill='x', pady=(0, 20))
            
            info_dados = ttk.Frame(dados_frame, padding="10")
            info_dados.pack(fill='x')
            
            # Nome
            ttk.Label(info_dados, text="Nome:", 
                    font=('Arial', 10, 'bold')).grid(row=0, column=0, sticky='w', pady=5)
            ttk.Label(info_dados, text=nome,
                    font=('Arial', 10)).grid(row=0, column=1, sticky='w', padx=10, pady=5)
            
            # CNPJ/CPF
            ttk.Label(info_dados, text="CNPJ/CPF:", 
                    font=('Arial', 10, 'bold')).grid(row=1, column=0, sticky='w', pady=5)
            ttk.Label(info_dados, text=cnpj_cpf_formatado,
                    font=('Arial', 10)).grid(row=1, column=1, sticky='w', padx=10, pady=5)
            
            # Categoria
            ttk.Label(info_dados, text="Categoria:", 
                    font=('Arial', 10, 'bold')).grid(row=2, column=0, sticky='w', pady=5)
            ttk.Label(info_dados, text=categoria,
                    font=('Arial', 10)).grid(row=2, column=1, sticky='w', padx=10, pady=5)
            
            # ============================================
            # OPÇÕES DE EXCLUSÃO/INATIVAÇÃO
            # ============================================
            opcoes_frame = ttk.LabelFrame(main_frame, text="⚙️ Escolha uma Ação")
            opcoes_frame.pack(fill='both', expand=True, pady=(0, 20))
            
            # Variável para armazenar escolha
            acao_var = tk.StringVar(value="inativar")
            
            # OPÇÃO 1: Inativar (RECOMENDADO)
            opcao1_frame = ttk.Frame(opcoes_frame, padding="15")
            opcao1_frame.pack(fill='x', pady=5)
            
            ttk.Radiobutton(
                opcao1_frame,
                text="🔴 INATIVAR fornecedor (Recomendado)",
                variable=acao_var,
                value="inativar"
            ).pack(anchor='w')
            
            info1 = tk.Text(opcao1_frame, height=3, wrap='word', 
                        bg='#e8f4f8', font=('Arial', 9), state='normal')
            info1.pack(fill='x', padx=20, pady=5)
            info1.insert('1.0', 
                        "• Mantém histórico de lançamentos\n"
                        "• Permite reativação futura\n"
                        "• Não aparece em buscas de fornecedores ativos")
            info1.config(state='disabled')
            
            # OPÇÃO 2: Excluir permanentemente
            opcao2_frame = ttk.Frame(opcoes_frame, padding="15")
            opcao2_frame.pack(fill='x', pady=5)
            
            ttk.Radiobutton(
                opcao2_frame,
                text="⚠️ EXCLUIR fornecedor permanentemente",
                variable=acao_var,
                value="excluir"
            ).pack(anchor='w')
            
            info2 = tk.Text(opcao2_frame, height=3, wrap='word', 
                        bg='#fff3cd', font=('Arial', 9), state='normal')
            info2.pack(fill='x', padx=20, pady=5)
            info2.insert('1.0', 
                        "• Remove PERMANENTEMENTE da base\n"
                        "• Não pode ser desfeito\n"
                        "• Use apenas se certeza absoluta")
            info2.config(state='disabled')
            
            # ============================================
            # BOTÕES DE AÇÃO
            # ============================================
            botoes_frame = ttk.Frame(main_frame)
            botoes_frame.pack(fill='x')
            
            def confirmar_acao():
                acao = acao_var.get()
                
                if acao == "inativar":
                    # Chamar método de inativação
                    sucesso = self.inativar_fornecedor(cnpj_cpf_normalizado, nome)
                    if sucesso:
                        custom_messagebox("info", "Sucesso",
                                        f"✅ Fornecedor inativado com sucesso!\n\n"
                                        f"Nome: {nome}\n"
                                        f"CNPJ/CPF: {cnpj_cpf_formatado}\n\n"
                                        f"O fornecedor não aparecerá mais em buscas,\n"
                                        f"mas pode ser reativado se necessário.")
                        janela_exclusao.destroy()
                        self.buscar_fornecedor()  # Atualizar lista
                
                elif acao == "excluir":
                    # Confirmação adicional para exclusão
                    confirmacao = custom_messagebox("warning", "⚠️ CONFIRMAÇÃO FINAL",
                                                f"ATENÇÃO: Esta ação é IRREVERSÍVEL!\n\n"
                                                f"Deseja REALMENTE EXCLUIR permanentemente?\n\n"
                                                f"Nome: {nome}\n"
                                                f"CNPJ/CPF: {cnpj_cpf_formatado}\n\n"
                                                f"Digite 'EXCLUIR' para confirmar:",
                                                tipo_dialog='input')
                    
                    if confirmacao and confirmacao.upper() == "EXCLUIR":
                        sucesso = self.excluir_fornecedor_permanente(cnpj_cpf_normalizado, nome)
                        if sucesso:
                            custom_messagebox("info", "Excluído",
                                            f"✅ Fornecedor excluído permanentemente!\n\n"
                                            f"Nome: {nome}\n"
                                            f"CNPJ/CPF: {cnpj_cpf_formatado}")
                            janela_exclusao.destroy()
                            self.buscar_fornecedor()  # Atualizar lista
                    else:
                        custom_messagebox("info", "Cancelado", "Exclusão cancelada.")
            
            ttk.Button(botoes_frame, text="✅ Confirmar Ação",
                    command=confirmar_acao).pack(side='left', padx=5)
            
            ttk.Button(botoes_frame, text="❌ Cancelar",
                    command=janela_exclusao.destroy).pack(side='left', padx=5)
            
        except Exception as e:
            custom_messagebox("error", "Erro", 
                            f"Erro ao abrir gerenciador de exclusão:\n{str(e)}")
            import traceback
            logger.error(traceback.format_exc())

    def inativar_fornecedor(self, cnpj_cpf, nome):
        """
        Marca fornecedor como INATIVO na planilha
        
        IMPORTANTE: Este método adiciona/usa uma coluna STATUS (coluna Q)
        Se a coluna não existir, será criada automaticamente
        
        Args:
            cnpj_cpf: CNPJ/CPF do fornecedor (apenas números)
            nome: Nome do fornecedor (para log)
        
        Returns:
            bool: True se inativado com sucesso, False caso contrário
        """
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook
            import logging
            
            logger = logging.getLogger(__name__)
            logging.getLogger('PIL').setLevel(logging.WARNING)
            logging.getLogger('matplotlib').setLevel(logging.WARNING)
            
            wb = load_workbook(ARQUIVO_FORNECEDORES)
            ws = wb['Fornecedores']
            
            # Verificar se coluna STATUS existe (coluna 17 = Q)
            if ws.cell(1, 17).value != 'STATUS':
                # Adicionar cabeçalho STATUS
                ws.cell(1, 17, 'STATUS')
                logger.info("Coluna STATUS criada na planilha")
                
                # Marcar todos os registros existentes como ATIVO
                for row in range(2, ws.max_row + 1):
                    if ws.cell(row, 1).value:  # Se tem CNPJ/CPF
                        ws.cell(row, 17, 'ATIVO')
            
            # Buscar fornecedor e marcar como INATIVO
            cnpj_cpf_busca = ''.join(filter(str.isdigit, str(cnpj_cpf)))
            fornecedor_encontrado = False
            
            for row in range(2, ws.max_row + 1):
                cnpj_cpf_row = ws.cell(row, 1).value
                if not cnpj_cpf_row:
                    continue
                
                cnpj_cpf_row_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf_row)))
                
                if cnpj_cpf_row_numeros == cnpj_cpf_busca:
                    # Marcar como INATIVO
                    ws.cell(row, 17, 'INATIVO')
                    fornecedor_encontrado = True
                    logger.info(f"Fornecedor inativado: {nome} ({cnpj_cpf})")
                    break
            
            if not fornecedor_encontrado:
                wb.close()
                custom_messagebox("error", "Erro", 
                                f"Fornecedor não encontrado na planilha!\n"
                                f"CNPJ/CPF: {cnpj_cpf}")
                return False
            
            # Salvar planilha
            try:
                salvar_planilha_segura(wb, ARQUIVO_FORNECEDORES)
                wb.close()
                return True
            except PermissionError:
                wb.close()
                custom_messagebox("error", "Erro de Permissão",
                                "Arquivo está aberto em outro programa!\n"
                                "Feche o Excel e tente novamente.")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao inativar fornecedor: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            custom_messagebox("error", "Erro", 
                            f"Erro ao inativar fornecedor:\n{str(e)}")
            return False


    def excluir_fornecedor_permanente(self, cnpj_cpf, nome):
        """
        Remove PERMANENTEMENTE fornecedor da planilha
        
        ⚠️ ATENÇÃO: Esta ação é IRREVERSÍVEL!
        
        Args:
            cnpj_cpf: CNPJ/CPF do fornecedor (apenas números)
            nome: Nome do fornecedor (para log)
        
        Returns:
            bool: True se excluído com sucesso, False caso contrário
        """
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook
            import logging
            
            logger = logging.getLogger(__name__)
            
            wb = load_workbook(ARQUIVO_FORNECEDORES)
            ws = wb['Fornecedores']
            
            # Buscar fornecedor
            cnpj_cpf_busca = ''.join(filter(str.isdigit, str(cnpj_cpf)))
            linha_para_excluir = None
            
            for row in range(2, ws.max_row + 1):
                cnpj_cpf_row = ws.cell(row, 1).value
                if not cnpj_cpf_row:
                    continue
                
                cnpj_cpf_row_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf_row)))
                
                if cnpj_cpf_row_numeros == cnpj_cpf_busca:
                    linha_para_excluir = row
                    break
            
            if not linha_para_excluir:
                wb.close()
                custom_messagebox("error", "Erro", 
                                f"Fornecedor não encontrado na planilha!\n"
                                f"CNPJ/CPF: {cnpj_cpf}")
                return False
            
            # Excluir linha
            ws.delete_rows(linha_para_excluir, 1)
            logger.warning(f"Fornecedor EXCLUÍDO PERMANENTEMENTE: {nome} ({cnpj_cpf})")
            
            # Salvar planilha
            try:
                salvar_planilha_segura(wb, ARQUIVO_FORNECEDORES)
                wb.close()
                return True
            except PermissionError:
                wb.close()
                custom_messagebox("error", "Erro de Permissão",
                                "Arquivo está aberto em outro programa!\n"
                                "Feche o Excel e tente novamente.")
                return False
                
        except Exception as e:
            logger.error(f"Erro ao excluir fornecedor: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            custom_messagebox("error", "Erro", 
                            f"Erro ao excluir fornecedor:\n{str(e)}")
            return False
    
    def selecionar_fornecedor(self):
        """Seleciona o fornecedor e preenche seus dados"""
        try:
            logger.info("="*50)
            logger.info("INICIANDO SELEÇÃO DE FORNECEDOR")
            logger.info("="*50)
            
            selecionado = self.tree_fornecedores.selection()
            
            if not selecionado:
                custom_messagebox("warning", "Aviso", "Selecione um fornecedor na lista!")
                return
            
            valores = self.tree_fornecedores.item(selecionado[0])['values']
            tags = self.tree_fornecedores.item(selecionado[0])['tags']
            
            logger.debug(f"DEBUG SELEÇÃO:")
            logger.debug(f"  Tags RAW: {tags}")
            
            if len(valores) < 3 or valores[1] == 'Nenhum fornecedor encontrado':
                custom_messagebox("warning", "Aviso", "Selecione um fornecedor válido!")
                return
            
            # ============================================
            # REMOVER O PREFIXO "ID:" ao recuperar
            # ============================================
            cnpj_tag = tags[0] if tags and len(tags) > 0 else ''
            
            # Remover prefixo "ID:"
            if cnpj_tag.startswith('ID:'):
                cnpj_cpf_normalizado = cnpj_tag[3:]  # Remove "ID:"
            else:
                cnpj_cpf_normalizado = str(cnpj_tag)  # Fallback
            
            tipo_pessoa = tags[1] if tags and len(tags) > 1 else 'PJ'
            
            nome = str(valores[1]).strip()
            categoria = str(valores[2]).strip()
            cnpj_cpf_formatado = str(valores[0]).strip()
            
            logger.info(f"Fornecedor: {nome}")
            logger.debug(f"Tag original: {cnpj_tag}")
            logger.debug(f"CNPJ/CPF normalizado (SEM PREFIXO): {cnpj_cpf_normalizado}")
            logger.debug(f"Tipo pessoa: {tipo_pessoa}")
            logger.debug(f"CNPJ/CPF formatado: {cnpj_cpf_formatado}")
            
            # Buscar dados completos
            fornecedor_completo = self.buscar_fornecedor_completo(cnpj_cpf_normalizado)
            
            if not fornecedor_completo:
                logger.error(f"Fornecedor não encontrado: {cnpj_cpf_normalizado}")
                custom_messagebox("error", "Erro", 
                                f"Não foi possível carregar os dados do fornecedor!\n\n"
                                f"CNPJ/CPF: {cnpj_cpf_formatado}")
                return
            
            logger.info(f"Dados carregados: {fornecedor_completo['nome']}")
            
            if not hasattr(self, 'campos_fornecedor'):
                custom_messagebox("error", "Erro", "Campos de fornecedor não configurados!")
                return
            
            # === PREENCHER CAMPOS ===
            
            # CNPJ/CPF (usar formatado)
            self.campos_fornecedor['cnpj_cpf'].config(state='normal')
            self.campos_fornecedor['cnpj_cpf'].delete(0, tk.END)
            self.campos_fornecedor['cnpj_cpf'].insert(0, cnpj_cpf_formatado)
            self.campos_fornecedor['cnpj_cpf'].config(state='readonly')
            
            # Nome
            self.campos_fornecedor['nome'].config(state='normal')
            self.campos_fornecedor['nome'].delete(0, tk.END)
            self.campos_fornecedor['nome'].insert(0, nome)
            self.campos_fornecedor['nome'].config(state='readonly')
            
            # Categoria
            if isinstance(self.campos_fornecedor['categoria'], ttk.Combobox):
                self.campos_fornecedor['categoria'].set(categoria)
            else:
                self.campos_fornecedor['categoria'].config(state='normal')
                self.campos_fornecedor['categoria'].delete(0, tk.END)
                self.campos_fornecedor['categoria'].insert(0, categoria)
                self.campos_fornecedor['categoria'].config(state='readonly')
            
            # ============================================
            # PREENCHER DADOS BANCÁRIOS
            # ============================================
            dados_bancarios_planilha = fornecedor_completo.get('dados_bancarios', '').strip()
            
            self.campos_fornecedor['dados_bancarios'].config(state='normal')
            self.campos_fornecedor['dados_bancarios'].delete(0, tk.END)
            
            if dados_bancarios_planilha:
                # Se houver dados bancários na planilha, usar
                self.campos_fornecedor['dados_bancarios'].insert(0, dados_bancarios_planilha)
                logger.debug(f"Dados bancários da planilha: {dados_bancarios_planilha}")
            else:
                # Se não houver, montar dinamicamente
                logger.debug("Sem dados bancários na planilha, montando dinamicamente")
                self.atualizar_dados_bancarios()
            
            self.campos_fornecedor['dados_bancarios'].config(state='readonly')
            
            logger.info("Campos preenchidos com sucesso!")
            
            # ============================================
            # PREENCHER REFERÊNCIA COM ESPECIFICAÇÃO (Coluna M)
            # ============================================
            especificacao = fornecedor_completo.get('especificacao', '').strip()
            
            if hasattr(self, 'campos_despesa') and 'referencia' in self.campos_despesa:
                # Limpar campo de referência
                self.campos_despesa['referencia'].delete(0, tk.END)
                
                if especificacao:
                    # Inserir especificação se existir
                    self.campos_despesa['referencia'].insert(0, especificacao)
                    logger.info(f"✓ Referência preenchida: {especificacao}")
                else:
                    logger.debug("Nenhuma especificação cadastrada para este fornecedor")
            else:
                logger.warning("Campo 'referencia' não encontrado em campos_despesa")

            # ============================================
            # AVANÇAR PARA ABA DE DADOS (SEMPRE!)
            # ============================================
            if hasattr(self, 'notebook'):
                num_abas = self.notebook.index('end')
                if num_abas >= 3:
                    self.notebook.select(2)  # Seleciona aba de dados
                    logger.debug("Aba de dados selecionada")
                    
                    # Focar no primeiro campo editável
                    if hasattr(self, 'campos_despesa') and 'tp_desp' in self.campos_despesa:
                        self.campos_despesa['tp_desp'].focus()
                        logger.debug("Foco definido no campo 'tp_desp'")
            
            logger.info("SELEÇÃO CONCLUÍDA COM SUCESSO!")
            logger.info("="*50)
            
        except Exception as e:
            logger.error(f"ERRO em selecionar_fornecedor: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao selecionar fornecedor:\n{str(e)}")
            
    
    def buscar_fornecedor(self):
        """
        Adiciona filtro para não exibir fornecedores INATIVOS
        """
        try:
            from src.config.utils import custom_messagebox
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook
            
            termo = self.busca_entry.get().strip()
            
            # Limpar resultados anteriores
            for item in self.tree_fornecedores.get_children():
                self.tree_fornecedores.delete(item)
            
            if not termo:
                return
            
            wb = load_workbook(ARQUIVO_FORNECEDORES, data_only=True)
            ws = wb['Fornecedores']
            
            resultados_encontrados = 0
            termo_upper = termo.upper()
            resultados = []
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                
                # ============================================
                # FILTRO DE STATUS (NOVO!)
                # ============================================
                # Verificar coluna 17 (STATUS)
                status = str(row[16]).strip().upper() if len(row) > 16 and row[16] else 'ATIVO'
                
                # Pular fornecedores INATIVOS
                if status == 'INATIVO':
                    continue
                # ============================================
                
                cnpj_cpf_valor = row[0]
                tipo_pessoa = str(row[1]).strip().upper()
                nome = str(row[3] or '').strip().upper()
                categoria = str(row[11] or '').strip()
                
                # Extrair números
                cnpj_cpf_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf_valor)))
                
                # Normalizar com zeros
                if tipo_pessoa == 'PF':
                    cnpj_cpf_normalizado = cnpj_cpf_numeros.zfill(11)
                else:  # PJ
                    cnpj_cpf_normalizado = cnpj_cpf_numeros.zfill(14)
                
                # Formatar para exibição
                if tipo_pessoa == 'PF':
                    cnpj_cpf_formatado = f"{cnpj_cpf_normalizado[:3]}.{cnpj_cpf_normalizado[3:6]}.{cnpj_cpf_normalizado[6:9]}-{cnpj_cpf_normalizado[9:11]}"
                else:  # PJ
                    cnpj_cpf_formatado = f"{cnpj_cpf_normalizado[:2]}.{cnpj_cpf_normalizado[2:5]}.{cnpj_cpf_normalizado[5:8]}/{cnpj_cpf_normalizado[8:12]}-{cnpj_cpf_normalizado[12:14]}"
                
                if termo_upper in nome:
                    resultados.append({
                        'values': (cnpj_cpf_formatado, nome, categoria),
                        'tags': (cnpj_cpf_normalizado, tipo_pessoa)
                    })
                    
                    resultados_encontrados += 1
                    
                    if resultados_encontrados >= 100:
                        break
            
            wb.close()
            
            # Ordenar resultados
            if resultados:
                resultados.sort(key=lambda x: x['values'][1])
            
            # Inserir resultados
            for resultado in resultados:
                cnpj_tag = f"ID:{resultado['tags'][0]}"
                tipo_tag = resultado['tags'][1]
                
                self.tree_fornecedores.insert('', 'end', 
                    values=resultado['values'],
                    tags=(cnpj_tag, tipo_tag)
                )
            
            if resultados_encontrados == 0:
                self.tree_fornecedores.insert('', 'end', values=(
                    '', 'Nenhum fornecedor encontrado', ''
                ))
                
        except Exception as e:
            logger.error(f"Erro na busca: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro na busca: {str(e)}")


    def listar_fornecedores_inativos(self):
        """
        Abre janela para visualizar e gerenciar fornecedores INATIVOS
        VERSÃO CORRIGIDA - USA TIPO_PESSOA DA COLUNA B
        """
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook
            import logging
            
            logger = logging.getLogger(__name__)
            logger.info("="*60)
            logger.info("ABRINDO JANELA DE FORNECEDORES INATIVOS")
            logger.info("="*60)
            
            # Criar janela
            janela_inativos = tk.Toplevel(self.root)
            janela_inativos.title("Fornecedores Inativos")
            janela_inativos.geometry("900x600")
            janela_inativos.transient(self.root)
            janela_inativos.grab_set()
            
            # Centralizar
            janela_inativos.update_idletasks()
            x = (janela_inativos.winfo_screenwidth() // 2) - 450
            y = (janela_inativos.winfo_screenheight() // 2) - 300
            janela_inativos.geometry(f"900x600+{x}+{y}")
            
            main_frame = ttk.Frame(janela_inativos, padding="15")
            main_frame.pack(fill='both', expand=True)
            
            # Cabeçalho
            ttk.Label(main_frame, text="📋 Fornecedores Inativos",
                    font=('Arial', 16, 'bold')).pack(pady=(0, 15))
            
            # Frame para lista
            lista_frame = ttk.Frame(main_frame)
            lista_frame.pack(fill='both', expand=True, pady=(0, 15))
            
            # Treeview
            tree_inativos = ttk.Treeview(lista_frame,
                                        columns=('CNPJ/CPF', 'Nome', 'Categoria'),
                                        show='headings',
                                        height=20)
            
            tree_inativos.heading('CNPJ/CPF', text='CNPJ/CPF')
            tree_inativos.heading('Nome', text='Nome')
            tree_inativos.heading('Categoria', text='Categoria')
            
            tree_inativos.column('CNPJ/CPF', width=150, anchor='center')
            tree_inativos.column('Nome', width=400)
            tree_inativos.column('Categoria', width=100, anchor='center')
            
            # Scrollbar
            scroll_y = ttk.Scrollbar(lista_frame, orient='vertical', command=tree_inativos.yview)
            tree_inativos.configure(yscrollcommand=scroll_y.set)
            
            tree_inativos.pack(side='left', fill='both', expand=True)
            scroll_y.pack(side='right', fill='y')
            
            # Carregar fornecedores inativos
            logger.info("Carregando fornecedores inativos da planilha...")
            
            wb = load_workbook(ARQUIVO_FORNECEDORES, data_only=True)
            ws = wb['Fornecedores']
            
            total_inativos = 0
            
            for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
                if not row or not row[0]:
                    continue
                
                # Verificar STATUS (coluna 17 = índice 16)
                status = str(row[16]).strip().upper() if len(row) > 16 and row[16] else 'ATIVO'
                
                logger.debug(f"Linha {row_num}: {row[3]} - STATUS: {status}")
                
                if status == 'INATIVO':
                    # ✅ OBTER TIPO_PESSOA DA COLUNA B (índice 1)
                    tipo_pessoa = str(row[1]).strip().upper() if row[1] else 'PJ'
                    
                    # Extrair CNPJ/CPF
                    cnpj_cpf_valor = row[0]
                    cnpj_cpf_limpo = ''.join(filter(str.isdigit, str(cnpj_cpf_valor)))
                    
                    # ✅ NORMALIZAR BASEADO NO TIPO_PESSOA
                    if tipo_pessoa == 'PF':
                        cnpj_cpf_normalizado = cnpj_cpf_limpo.zfill(11)  # CPF: 11 dígitos
                        # Formatar CPF
                        cnpj_cpf_formatado = f"{cnpj_cpf_normalizado[:3]}.{cnpj_cpf_normalizado[3:6]}.{cnpj_cpf_normalizado[6:9]}-{cnpj_cpf_normalizado[9:11]}"
                    else:  # PJ
                        cnpj_cpf_normalizado = cnpj_cpf_limpo.zfill(14)  # CNPJ: 14 dígitos
                        # Formatar CNPJ
                        cnpj_cpf_formatado = f"{cnpj_cpf_normalizado[:2]}.{cnpj_cpf_normalizado[2:5]}.{cnpj_cpf_normalizado[5:8]}/{cnpj_cpf_normalizado[8:12]}-{cnpj_cpf_normalizado[12:14]}"
                    
                    nome = str(row[3] or '').strip()
                    categoria = str(row[11] or '').strip()
                    
                    # ✅ ARMAZENAR CNPJ/CPF NORMALIZADO E TIPO_PESSOA NAS TAGS
                    tree_inativos.insert('', 'end',
                                    values=(cnpj_cpf_formatado, nome, categoria),
                                    tags=(cnpj_cpf_normalizado, tipo_pessoa))  # ← CNPJ + TIPO
                    
                    total_inativos += 1
                    
                    logger.debug(f"  ✓ Adicionado: {nome}")
                    logger.debug(f"    Tipo: {tipo_pessoa}")
                    logger.debug(f"    CNPJ/CPF normalizado: {cnpj_cpf_normalizado}")
            
            wb.close()
            
            logger.info(f"Total de fornecedores inativos encontrados: {total_inativos}")
            
            # Botões
            botoes_frame = ttk.Frame(main_frame)
            botoes_frame.pack(fill='x')
            
            ttk.Label(botoes_frame, text=f"Total: {total_inativos} fornecedor(es) inativo(s)",
                    font=('Arial', 10, 'bold')).pack(side='left', padx=10)
            
            def reativar_selecionado():
                """Reativa o fornecedor selecionado"""
                try:
                    from src.config.utils import custom_messagebox
                    
                    logger.info("="*60)
                    logger.info("INICIANDO REATIVAÇÃO DE FORNECEDOR")
                    logger.info("="*60)
                    
                    selecionado = tree_inativos.selection()
                    
                    if not selecionado:
                        logger.warning("Nenhum fornecedor selecionado")
                        custom_messagebox("warning", "Aviso", "⚠️ Selecione um fornecedor!")
                        return
                    
                    # Obter dados do item selecionado
                    valores = tree_inativos.item(selecionado[0])['values']
                    tags = tree_inativos.item(selecionado[0])['tags']
                    
                    logger.debug(f"Valores: {valores}")
                    logger.debug(f"Tags: {tags}")
                    
                    if not valores or len(valores) < 2:
                        logger.error("Dados inválidos do fornecedor selecionado")
                        custom_messagebox("error", "Erro", "❌ Dados inválidos!")
                        return
                    
                    cnpj_cpf_formatado = valores[0]
                    nome = valores[1]
                    
                    # ✅ OBTER CNPJ/CPF E TIPO_PESSOA DAS TAGS
                    if tags and len(tags) >= 2:
                        cnpj_cpf = tags[0]  # CNPJ normalizado
                        tipo_pessoa = tags[1]  # PF ou PJ
                    else:
                        logger.error("Tags inválidas")
                        custom_messagebox("error", "Erro", "❌ Dados inválidos!")
                        return
                    
                    logger.info(f"Reativando fornecedor:")
                    logger.info(f"  Nome: {nome}")
                    logger.info(f"  Tipo: {tipo_pessoa}")
                    logger.info(f"  CNPJ/CPF formatado: {cnpj_cpf_formatado}")
                    logger.info(f"  CNPJ/CPF normalizado: {cnpj_cpf}")
                    
                    # ✅ CHAMAR MÉTODO COM TIPO_PESSOA
                    sucesso = self.reativar_fornecedor(cnpj_cpf, tipo_pessoa, nome)
                    
                    if sucesso:
                        logger.info("✅ Fornecedor reativado com sucesso!")
                        
                        # Remover da lista
                        tree_inativos.delete(selecionado[0])
                        
                        # Atualizar contador
                        total_restante = len(tree_inativos.get_children())
                        botoes_frame.winfo_children()[0].config(
                            text=f"Total: {total_restante} fornecedor(es) inativo(s)"
                        )
                        
                        custom_messagebox("info", "Sucesso",
                                        f"✅ Fornecedor reativado com sucesso!\n\n"
                                        f"Nome: {nome}\n"
                                        f"CNPJ/CPF: {cnpj_cpf_formatado}\n\n"
                                        f"O fornecedor voltará a aparecer nas buscas.")
                    else:
                        logger.error("❌ Falha ao reativar fornecedor")
                        custom_messagebox("error", "Erro",
                                        f"❌ Não foi possível reativar o fornecedor.\n\n"
                                        f"Verifique os logs para mais detalhes.")
                    
                    logger.info("="*60)
                    
                except Exception as e:
                    logger.error(f"ERRO em reativar_selecionado: {str(e)}")
                    import traceback
                    logger.error(traceback.format_exc())
                    custom_messagebox("error", "Erro", 
                                    f"❌ Erro ao reativar fornecedor:\n{str(e)}")
            
            ttk.Button(botoes_frame, text="✅ Reativar Selecionado",
                    command=reativar_selecionado).pack(side='right', padx=5)
            
            ttk.Button(botoes_frame, text="Fechar",
                    command=janela_inativos.destroy).pack(side='right', padx=5)
            
            logger.info("Janela de fornecedores inativos aberta com sucesso")
            
        except Exception as e:
            logger.error(f"ERRO ao abrir janela de inativos: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            from src.config.utils import custom_messagebox
            custom_messagebox("error", "Erro", f"Erro ao listar inativos:\n{str(e)}")


    def reativar_fornecedor(self, cnpj_cpf, tipo_pessoa, nome):
        """
        Reativa um fornecedor que estava INATIVO
        VERSÃO CORRIGIDA - USA TIPO_PESSOA PARA NORMALIZAR
        
        Args:
            cnpj_cpf: CNPJ/CPF do fornecedor (normalizado com zeros)
            tipo_pessoa: 'PF' ou 'PJ' (da coluna B)
            nome: Nome do fornecedor (para log)
        
        Returns:
            bool: True se reativado com sucesso, False caso contrário
        """
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook
            import logging
            
            logger = logging.getLogger(__name__)
            
            logger.info("="*60)
            logger.info("MÉTODO: reativar_fornecedor()")
            logger.info("="*60)
            logger.info(f"CNPJ/CPF recebido: '{cnpj_cpf}' (type: {type(cnpj_cpf).__name__})")
            logger.info(f"Tipo Pessoa: '{tipo_pessoa}'")
            logger.info(f"Nome: '{nome}'")
            
            # ✅ GARANTIR QUE CNPJ/CPF ESTÁ NORMALIZADO
            cnpj_cpf_limpo = ''.join(filter(str.isdigit, str(cnpj_cpf)))
            
            if tipo_pessoa == 'PF':
                cnpj_cpf_normalizado = cnpj_cpf_limpo.zfill(11)  # CPF: 11 dígitos
            else:  # PJ
                cnpj_cpf_normalizado = cnpj_cpf_limpo.zfill(14)  # CNPJ: 14 dígitos
            
            logger.info(f"CNPJ/CPF normalizado: '{cnpj_cpf_normalizado}' (len={len(cnpj_cpf_normalizado)})")
            
            # Abrir planilha
            logger.debug(f"Abrindo planilha: {ARQUIVO_FORNECEDORES}")
            wb = load_workbook(ARQUIVO_FORNECEDORES)
            ws = wb['Fornecedores']
            
            logger.debug(f"Planilha aberta. Total de linhas: {ws.max_row}")
            
            # Buscar fornecedor e marcar como ATIVO
            fornecedor_encontrado = False
            linha_encontrada = None
            
            for row_num in range(2, ws.max_row + 1):
                cnpj_cpf_row = ws.cell(row_num, 1).value  # Coluna A
                tipo_pessoa_row = ws.cell(row_num, 2).value  # Coluna B
                
                if not cnpj_cpf_row:
                    continue
                
                # ✅ OBTER TIPO_PESSOA DA PLANILHA
                tipo_pessoa_row_upper = str(tipo_pessoa_row).strip().upper() if tipo_pessoa_row else 'PJ'
                
                # ✅ NORMALIZAR CNPJ/CPF DA PLANILHA BASEADO NO TIPO
                cnpj_cpf_row_limpo = ''.join(filter(str.isdigit, str(cnpj_cpf_row)))
                
                if tipo_pessoa_row_upper == 'PF':
                    cnpj_cpf_row_normalizado = cnpj_cpf_row_limpo.zfill(11)
                else:
                    cnpj_cpf_row_normalizado = cnpj_cpf_row_limpo.zfill(14)
                
                # Log para debug (primeiras linhas ou quando encontrar)
                if row_num <= 3 or cnpj_cpf_row_normalizado == cnpj_cpf_normalizado:
                    logger.debug(f"Linha {row_num}:")
                    logger.debug(f"  CNPJ planilha original: '{cnpj_cpf_row}'")
                    logger.debug(f"  Tipo planilha: '{tipo_pessoa_row_upper}'")
                    logger.debug(f"  CNPJ planilha normalizado: '{cnpj_cpf_row_normalizado}'")
                    logger.debug(f"  CNPJ busca normalizado: '{cnpj_cpf_normalizado}'")
                    logger.debug(f"  Match? {cnpj_cpf_row_normalizado == cnpj_cpf_normalizado}")
                
                # ✅ COMPARAR VALORES NORMALIZADOS
                if cnpj_cpf_row_normalizado == cnpj_cpf_normalizado:
                    # ✅ FORNECEDOR ENCONTRADO!
                    logger.info(f"✅ FORNECEDOR ENCONTRADO NA LINHA {row_num}!")
                    
                    status_anterior = ws.cell(row_num, 17).value
                    logger.info(f"  STATUS anterior: '{status_anterior}'")
                    
                    # Marcar como ATIVO
                    ws.cell(row_num, 17, 'ATIVO')
                    logger.info(f"  STATUS novo: 'ATIVO'")
                    
                    fornecedor_encontrado = True
                    linha_encontrada = row_num
                    break
            
            if not fornecedor_encontrado:
                logger.warning(f"❌ Fornecedor NÃO ENCONTRADO!")
                logger.warning(f"  Buscou por CNPJ/CPF: '{cnpj_cpf_normalizado}' (tipo: {tipo_pessoa})")
                logger.warning(f"  Total de linhas verificadas: {ws.max_row - 1}")
                wb.close()
                return False
            
            # Salvar planilha
            logger.info("Salvando planilha...")
            
            try:
                salvar_planilha_segura(wb, ARQUIVO_FORNECEDORES)
                logger.info("✅ Planilha salva com sucesso!")
                
            except PermissionError:
                logger.error("❌ ERRO: Arquivo está aberto em outro programa!")
                wb.close()
                from src.config.utils import custom_messagebox
                custom_messagebox("error", "Erro de Permissão",
                                "❌ Arquivo está aberto no Excel!\n\n"
                                "Feche o arquivo e tente novamente.")
                return False
            
            wb.close()
            
            logger.info(f"✅ Fornecedor '{nome}' reativado com sucesso!")
            logger.info(f"   Linha: {linha_encontrada}")
            logger.info(f"   Tipo: {tipo_pessoa}")
            logger.info(f"   STATUS: INATIVO → ATIVO")
            logger.info("="*60)
            
            return True
            
        except Exception as e:
            logger.error(f"❌ ERRO CRÍTICO em reativar_fornecedor: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            
            try:
                wb.close()
            except:
                pass
            
            return False
    
    def buscar_fornecedores_por_nome_parcial(self, nome_parcial):
        """
        Busca otimizada por nome parcial usando cache
        VERSÃO FINAL OTIMIZADA
        """
        try:
            if not nome_parcial or len(nome_parcial) < 3:
                return []
            
            # Carregar fornecedores do cache
            fornecedores = self.cache_fornecedores.carregar_cache_se_necessario(ARQUIVO_FORNECEDORES)
            
            if not fornecedores:
                logger.debug("DEBUG: Cache vazio, fazendo busca direta")
                return self.buscar_fornecedores_por_nome_parcial_direto(nome_parcial)
            
            nome_busca = nome_parcial.strip().upper()
            fornecedores_encontrados = []
            
            logger.debug(f"DEBUG: Buscando '{nome_busca}' em {len(fornecedores)} fornecedores do cache")
            
            for fornecedor in fornecedores:
                nome = fornecedor['nome']
                
                if nome_busca in nome:
                    # Calcular relevância (posição no nome)
                    posicao = nome.find(nome_busca)
                    relevancia = 1000 - posicao
                    
                    fornecedor_resultado = fornecedor.copy()
                    fornecedor_resultado['relevancia'] = relevancia
                    
                    fornecedores_encontrados.append(fornecedor_resultado)
                    
                    # Limitar resultados para performance
                    if len(fornecedores_encontrados) >= 15:
                        break
            
            # Ordenar por relevância
            fornecedores_encontrados.sort(key=lambda x: (-x['relevancia'], x['nome']))
            
            logger.debug(f"DEBUG: {len(fornecedores_encontrados)} fornecedores encontrados no cache")
            
            return fornecedores_encontrados
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro na busca por cache: {str(e)}")
            # Fallback para busca direta
            return self.buscar_fornecedores_por_nome_parcial_direto(nome_parcial)

    def buscar_fornecedor_completo(self, cnpj_cpf):
        """
        Busca fornecedor completo (todos os campos) por CNPJ/CPF.
        Aceita tanto o valor formatado (com pontuação) quanto só números.
        """
        try:
            cnpj_cpf_busca_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf).strip()))
    
            fornecedores = self.cache_fornecedores.carregar_cache_se_necessario(ARQUIVO_FORNECEDORES)
    
            for fornecedor in fornecedores:
                if fornecedor['cnpj_cpf_numeros'] == cnpj_cpf_busca_numeros:
                    # Devolve uma cópia sem o campo auxiliar interno do cache,
                    # mantendo exatamente o mesmo formato que o código antigo
                    # devolvia (mesmas chaves, para não quebrar quem já consome
                    # este retorno).
                    resultado = fornecedor.copy()
                    resultado.pop('cnpj_cpf_numeros', None)
                    return resultado
    
            logger.warning(f"✗ Fornecedor não encontrado: '{cnpj_cpf}' (números: '{cnpj_cpf_busca_numeros}')")
            return None
    
        except Exception as e:
            logger.error(f"Erro em buscar_fornecedor_completo: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return None

    def buscar_fornecedor_por_cnpj(self, cnpj_cpf):
        """Busca e seleciona fornecedor pelo CNPJ/CPF"""
        try:
            fornecedor = self.buscar_fornecedor_completo(cnpj_cpf)
            if fornecedor:
                # Preencher dados do fornecedor encontrado
                self.campos_fornecedor['nome'].delete(0, tk.END)
                self.campos_fornecedor['nome'].insert(0, fornecedor['nome'])
                
                if fornecedor.get('categoria'):
                    self.campos_fornecedor['categoria'].delete(0, tk.END)
                    self.campos_fornecedor['categoria'].insert(0, fornecedor['categoria'])
                
                # Preencher dados bancários baseado na forma de pagamento padrão
                if fornecedor.get('chave_pix'):
                    dados_bancarios = f"PIX: {fornecedor['chave_pix']}"
                else:
                    # Construir dados para TED
                    partes_dados = []
                    if fornecedor.get('banco'): partes_dados.append(fornecedor['banco'])
                    if fornecedor.get('op'): partes_dados.append(fornecedor['op'])
                    if fornecedor.get('agencia'): partes_dados.append(fornecedor['agencia'])
                    if fornecedor.get('conta'): partes_dados.append(fornecedor['conta'])
                    partes_dados.append(fornecedor['cnpj_cpf'])
                    dados_bancarios = ' - '.join(partes_dados)
                
                self.campos_despesa['dados_bancarios'].delete(0, tk.END)
                self.campos_despesa['dados_bancarios'].insert(0, dados_bancarios)
                
                logger.debug(f"DEBUG: Fornecedor encontrado e dados preenchidos: {fornecedor['nome']}")
                return True
            else:
                logger.debug(f"DEBUG: Fornecedor não encontrado para CNPJ/CPF: {cnpj_cpf}")
                return False
                
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao buscar fornecedor por CNPJ: {str(e)}")
            return False

    def buscar_fornecedor_por_nome_agenda(self, nome_fornecedor):
        """Busca fornecedor pelo nome para uso na agenda (via cache)"""
        try:
            if not nome_fornecedor or not nome_fornecedor.strip():
                return None
    
            nome_busca = nome_fornecedor.strip().upper()
    
            fornecedores = self.cache_fornecedores.carregar_cache_se_necessario(ARQUIVO_FORNECEDORES)
    
            fornecedor_encontrado = None
            melhor_match = 0
    
            for f in fornecedores:
                nome = f['nome']  # já vem em upper do cache
    
                if nome_busca in nome:
                    match_quality = len(nome_busca) / len(nome) if nome else 0
    
                    if nome_busca == nome or match_quality > melhor_match:
                        melhor_match = match_quality
                        fornecedor_encontrado = {
                            'cnpj_cpf': f['cnpj_cpf'],
                            'nome': nome,
                            'categoria': f['categoria'],
                            'telefone': f['telefone'],
                            'email': f['email'],
                            'banco': f['banco'],
                            'op': f['op'],
                            'agencia': f['agencia'],
                            'conta': f['conta'],
                            'chave_pix': f['chave_pix'],
                            'dados_bancarios': f['dados_bancarios'],
                        }
    
                        if nome_busca == nome:
                            break
    
            if fornecedor_encontrado:
                logger.debug(f"DEBUG: Fornecedor encontrado: {fornecedor_encontrado['nome']} - {fornecedor_encontrado['cnpj_cpf']}")
            else:
                logger.debug(f"DEBUG: Nenhum fornecedor encontrado para: {nome_fornecedor}")
    
            return fornecedor_encontrado
    
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao buscar fornecedor por nome: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return None
    
    def buscar_fornecedor_por_cnpj_agenda(self, cnpj_cpf):
        """Busca fornecedor pelo CNPJ/CPF para uso na agenda (via cache)"""
        try:
            if not cnpj_cpf or not cnpj_cpf.strip():
                return None
    
            cnpj_limpo = ''.join(filter(str.isdigit, cnpj_cpf))
    
            fornecedores = self.cache_fornecedores.carregar_cache_se_necessario(ARQUIVO_FORNECEDORES)
    
            for f in fornecedores:
                if f['cnpj_cpf_numeros'] == cnpj_limpo:
                    fornecedor = {
                        'cnpj_cpf': f['cnpj_cpf'],
                        'nome': f['nome'],
                        'categoria': f['categoria'],
                        'telefone': f['telefone'],
                        'email': f['email'],
                        'banco': f['banco'],
                        'op': f['op'],
                        'agencia': f['agencia'],
                        'conta': f['conta'],
                        'chave_pix': f['chave_pix'],
                        'dados_bancarios': f['dados_bancarios'],
                    }
                    logger.debug(f"DEBUG: Fornecedor encontrado por CNPJ: {fornecedor['nome']}")
                    return fornecedor
    
            logger.debug(f"DEBUG: Nenhum fornecedor encontrado para CNPJ: {cnpj_cpf}")
            return None
    
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao buscar fornecedor por CNPJ: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return None

    def buscar_dados_bancarios(self, cnpj_cpf):
        try:
            cnpj_busca_numeros = ''.join(filter(str.isdigit, str(cnpj_cpf)))  # ALTERADO: normaliza antes de comparar
    
            fornecedores = self.cache_fornecedores.carregar_cache_se_necessario(ARQUIVO_FORNECEDORES)
    
            for f in fornecedores:
                if f['cnpj_cpf_numeros'] == cnpj_busca_numeros:
                    logger.debug(f"CNPJ/CPF encontrado: {cnpj_cpf}")
                    return f['dados_bancarios'] or ""
    
            return ""
        except Exception as e:
            logger.debug(f"Erro ao buscar dados bancários: {e}")
            return ""

    def obter_dados_bancarios_fornecedor(self, cnpj_cpf, forma_pagamento_preferida="PIX"):
        """Obtém dados bancários formatados do fornecedor"""
        logger.debug(f"DEBUG ===== obter_dados_bancarios_fornecedor =====")
        logger.debug(f"DEBUG: cnpj_cpf recebido: '{cnpj_cpf}'")
        logger.debug(f"DEBUG: forma_pagamento: '{forma_pagamento_preferida}'")
        
        try:
            fornecedor = self.buscar_fornecedor_por_cnpj_agenda(cnpj_cpf)
            
            logger.debug(f"DEBUG: Fornecedor retornado: {fornecedor}")
            
            if not fornecedor:
                logger.debug(f"DEBUG: Fornecedor não encontrado - retornando vazio")
                return ""
            
            # PRIORIDADE 1: Usar coluna DADOS BANCÁRIOS se já estiver preenchida
            dados_bancarios_coluna = fornecedor.get('dados_bancarios', '').strip()
            if dados_bancarios_coluna:
                logger.debug(f"DEBUG: Usando dados da coluna DADOS BANCÁRIOS: '{dados_bancarios_coluna}'")
                return dados_bancarios_coluna
            
            # PRIORIDADE 2: Construir dados baseado na forma de pagamento PIX
            if forma_pagamento_preferida == "PIX":
                chave_pix = fornecedor.get('chave_pix', '').strip()
                if chave_pix:
                    resultado = f"PIX: {chave_pix}"
                    logger.debug(f"DEBUG: Construindo dados PIX: '{resultado}'")
                    return resultado
                else:
                    logger.debug(f"DEBUG: Chave PIX não cadastrada - retornando vazio")
                    return ""
            
            # PRIORIDADE 3: Construir dados para TED (apenas se houver dados completos)
            partes_dados = []
            
            if fornecedor.get('banco'): 
                partes_dados.append(fornecedor['banco'])
            if fornecedor.get('op'): 
                partes_dados.append(fornecedor['op'])
            if fornecedor.get('agencia'): 
                partes_dados.append(fornecedor['agencia'])
            if fornecedor.get('conta'): 
                partes_dados.append(fornecedor['conta'])
            
            # Só adicionar CNPJ/CPF se houver pelo menos um dado bancário
            if partes_dados:
                partes_dados.append(fornecedor['cnpj_cpf'])
                resultado = ' - '.join(partes_dados)
                logger.debug(f"DEBUG: Construindo dados TED: '{resultado}'")
                return resultado
            else:
                # Se não houver nenhum dado bancário, retornar vazio
                logger.debug(f"DEBUG: Nenhum dado bancário cadastrado - retornando vazio")
                return ""
            
        except Exception as e:
            logger.debug(f"DEBUG: ERRO em obter_dados_bancarios_fornecedor: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return ""
    
    def atualizar_resumo_dados_bancarios(self, event=None):
        """Atualiza o campo de resumo dos dados bancários em tempo real"""
        try:
            # Obter chave PIX
            chave_pix = self.campos_form['chave_pix'].get().strip()
            
            if chave_pix:
                # FORMA 1: Pagamento via PIX
                dados_consolidados = f"PIX: {chave_pix}"
            else:
                # Verificar se tem dados bancários para TED
                banco = self.campos_form['banco'].get().strip()
                op = self.campos_form['op'].get().strip()
                agencia = self.campos_form['agencia'].get().strip()
                conta = self.campos_form['conta'].get().strip()
                cnpj_cpf = self.campos_form['cnpj_cpf'].get().strip()
                
                # FORMA 2: Pagamento via TED (precisa de todos os dados)
                if banco and agencia and conta and cnpj_cpf:
                    partes = [banco]
                    if op:
                        partes.append(f"Op: {op}")
                    partes.append(f"Ag: {agencia}")
                    partes.append(f"Conta: {conta}")
                    partes.append(f"CNPJ/CPF: {cnpj_cpf}")
                    
                    dados_consolidados = " | ".join(partes)
                # FORMA 3: Pagamento em DINHEIRO (não precisa de dados bancários)
                else:
                    dados_consolidados = "NENHUM DADO BANCÁRIO CADASTRADO"
            
            # Atualizar campo display
            self.campos_form['dados_bancarios_display'].config(state='normal')
            self.campos_form['dados_bancarios_display'].delete(0, tk.END)
            self.campos_form['dados_bancarios_display'].insert(0, dados_consolidados)
            self.campos_form['dados_bancarios_display'].config(state='readonly')
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar resumo bancário: {str(e)}")

    def limpar_todos_dados_bancarios(self):
        """Limpa todos os campos de dados bancários de uma vez, evitando inconsistências"""
        resposta = messagebox.askyesno(
            "Confirmação",
            "⚠️ Deseja realmente limpar TODOS os dados bancários?\n\n"
            "Isso incluirá:\n"
            "• Banco\n"
            "• Operação\n"
            "• Agência\n"
            "• Conta\n"
            "• Chave PIX\n\n"
            "Esta ação não pode ser desfeita!",
            icon='warning'
        )
        
        if resposta:
            # Limpar todos os campos bancários
            self.campos_form['banco'].set('')
            self.campos_form['op'].delete(0, tk.END)
            self.campos_form['agencia'].delete(0, tk.END)
            self.campos_form['conta'].delete(0, tk.END)
            self.campos_form['chave_pix'].delete(0, tk.END)
            self.tipo_pix.set('Selecione')
            
            # Atualizar resumo
            self.atualizar_resumo_dados_bancarios()
            
            custom_messagebox("info", "Dados Limpos", 
                            "✅ Todos os dados bancários foram removidos!")

    def usar_cpf_criado_auto(self):
        """Busca e usa automaticamente o próximo CPF criado disponível - VERSÃO MELHORADA"""
        try:
            if not hasattr(self, 'gerenciador_cpfs'):
                self.gerenciador_cpfs = GerenciadorCPFsCriados()
            
            logger.debug("Iniciando busca por CPF disponível...")
            cpf_disponivel, linha = self.gerenciador_cpfs.obter_proximo_cpf_disponivel()
            
            if cpf_disponivel:
                logger.debug(f"CPF obtido: {cpf_disponivel}")
                
                # TESTE: Validar o CPF antes de usar
                if not self.gerenciador_cpfs.validar_cpf_gerado(cpf_disponivel):
                    custom_messagebox("error", "Erro", 
                                    f"❌ CPF gerado é inválido: {cpf_disponivel}\n\n"
                                    f"Verifique o algoritmo de geração")
                    return
                
                # Formatar CPF
                cpf_formatado = f"{cpf_disponivel[:3]}.{cpf_disponivel[3:6]}.{cpf_disponivel[6:9]}-{cpf_disponivel[9:]}"
                logger.debug(f"CPF formatado: {cpf_formatado}")
                
                # TESTE: Validar CPF formatado com a função do sistema
                try:
                    if not validar_documento(cpf_formatado, 'PF'):
                        logger.debug(f"AVISO: Sistema não reconheceu CPF como válido: {cpf_formatado}")
                        # Mesmo assim, continuar - pode ser problema na função validar_documento
                except Exception as e:
                    logger.debug(f"Erro na validação do sistema: {str(e)}")
                
                # Preencher campo CNPJ/CPF
                self.campos_form['cnpj_cpf'].delete(0, tk.END)
                self.campos_form['cnpj_cpf'].insert(0, cpf_formatado)
                
                # Definir como PF
                self.campos_form['tipo_pessoa'].set('PF')
                
                # Configurar PIX automaticamente
                self.tipo_pix.set('CNPJ/CPF')
                self.campos_form['chave_pix'].delete(0, tk.END)
                self.campos_form['chave_pix'].insert(0, cpf_formatado)
                
                # Focar no campo nome para continuar o cadastro
                self.campos_form['razao_social'].focus()
                
                custom_messagebox("info", "CPF Obtido", 
                                f"✅ CPF criado obtido com sucesso!\n\n"
                                f"📋 CPF: {cpf_formatado}\n"
                                f"🔑 Configurado como chave PIX\n"
                                f"🔍 Validação: CPF matematicamente correto\n\n"
                                f"➡️ Continue preenchendo os dados do prestador")
            else:
                custom_messagebox("error", "Erro", 
                                "❌ Não foi possível obter um CPF criado.\n\n"
                                "Possíveis causas:\n"
                                "• Arquivo Base_Fornecedores.xlsx não encontrado\n"
                                "• Erro na geração de CPFs válidos\n"
                                "• Problema de permissão no arquivo")
                
        except Exception as e:
            logger.debug(f"Erro detalhado: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"❌ Erro ao obter CPF criado:\n{str(e)}")

    def mostrar_cpfs_disponiveis(self):
        """Mostra lista de CPFs disponíveis para seleção manual"""
        try:
            if not hasattr(self, 'gerenciador_cpfs'):
                self.gerenciador_cpfs = GerenciadorCPFsCriados()
                
            cpfs_disponiveis = self.gerenciador_cpfs.listar_cpfs_disponiveis()
            
            if not cpfs_disponiveis:
                custom_messagebox("info", "CPFs Disponíveis", 
                                "❌ Nenhum CPF disponível no momento.\n\n"
                                "Use o botão 'Obter CPF Criado' para gerar novos CPFs automaticamente.")
                return
            
            # Criar janela de seleção
            janela_cpfs = tk.Toplevel(self.janela_fornecedor)
            janela_cpfs.title("📋 CPFs Criados - Escolher da Lista")
            janela_cpfs.geometry("450x600")
            janela_cpfs.transient(self.janela_fornecedor)
            janela_cpfs.grab_set()
            
            # Centralizar janela
            janela_cpfs.update_idletasks()
            x = (janela_cpfs.winfo_screenwidth() // 2) - (225)
            y = (janela_cpfs.winfo_screenheight() // 2) - (300)
            janela_cpfs.geometry(f"450x600+{x}+{y}")
            
            frame = ttk.Frame(janela_cpfs, padding="15")
            frame.pack(fill='both', expand=True)
            
            # Cabeçalho
            header_frame = ttk.Frame(frame)
            header_frame.pack(fill='x', pady=(0, 15))
            
            ttk.Label(header_frame, text="📋 CPFs Criados Disponíveis", 
                    font=('Arial', 14, 'bold')).pack()
            ttk.Label(header_frame, text=f"Total disponível: {len(cpfs_disponiveis)}", 
                    font=('Arial', 10)).pack()
            
            # Lista de CPFs
            lista_frame = ttk.LabelFrame(frame, text="Selecione um CPF:")
            lista_frame.pack(fill='both', expand=True, pady=(0, 15))
            
            # Frame interno para Treeview e scrollbar
            tree_frame = ttk.Frame(lista_frame)
            tree_frame.pack(fill='both', expand=True, padx=10, pady=10)
            
            # Treeview para CPFs
            tree_cpfs = ttk.Treeview(tree_frame, columns=('CPF', 'Status'), show='headings', height=15)
            tree_cpfs.heading('CPF', text='CPF Disponível')
            tree_cpfs.heading('Status', text='Status')
            tree_cpfs.column('CPF', width=200, anchor='center')
            tree_cpfs.column('Status', width=100, anchor='center')
            
            # Scrollbar
            scroll_cpfs = ttk.Scrollbar(tree_frame, orient='vertical', command=tree_cpfs.yview)
            tree_cpfs.configure(yscrollcommand=scroll_cpfs.set)
            
            tree_cpfs.pack(side='left', fill='both', expand=True)
            scroll_cpfs.pack(side='right', fill='y')
            
            # Preencher lista
            for i, cpf in enumerate(cpfs_disponiveis, 1):
                cpf_formatado = f"{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}"
                tree_cpfs.insert('', 'end', values=(cpf_formatado, '✅ Disponível'), tags=(cpf,))
            
            def selecionar_cpf():
                selecionado = tree_cpfs.selection()
                if not selecionado:
                    custom_messagebox("warning", "Aviso", "⚠️ Selecione um CPF da lista")
                    return
                
                # Obter CPF selecionado (não formatado)
                cpf_selecionado = tree_cpfs.item(selecionado[0])['tags'][0]
                cpf_formatado = tree_cpfs.item(selecionado[0])['values'][0]
                
                # Preencher no formulário principal
                self.campos_form['cnpj_cpf'].delete(0, tk.END)
                self.campos_form['cnpj_cpf'].insert(0, cpf_formatado)
                
                # Configurar tipo como PF
                self.campos_form['tipo_pessoa'].set('PF')
                
                # Configurar PIX
                self.tipo_pix.set('CNPJ/CPF')
                self.campos_form['chave_pix'].delete(0, tk.END)
                self.campos_form['chave_pix'].insert(0, cpf_formatado)
                
                # Fechar janela
                janela_cpfs.destroy()
                
                # Focar no campo nome
                self.campos_form['razao_social'].focus()
                
                custom_messagebox("info", "CPF Selecionado", 
                                f"✅ CPF selecionado com sucesso!\n\n"
                                f"📋 {cpf_formatado}\n\n"
                                f"➡️ Continue preenchendo os dados")
            
            # Botões
            frame_botoes = ttk.Frame(frame)
            frame_botoes.pack(fill='x')
            
            ttk.Button(frame_botoes, text="✅ Selecionar", 
                    command=selecionar_cpf).pack(side='left', padx=5)
            ttk.Button(frame_botoes, text="❌ Cancelar", 
                    command=janela_cpfs.destroy).pack(side='left', padx=5)
            
            # Info adicional
            info_label = tk.Label(frame_botoes, 
                                text="💡 Dica: Dê duplo clique no CPF para selecioná-lo rapidamente",
                                font=('Arial', 8), fg='gray')
            info_label.pack(side='right', padx=10)
            
            # Double-click para selecionar rapidamente
            tree_cpfs.bind('<Double-1>', lambda e: selecionar_cpf())
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"❌ Erro ao mostrar CPFs:\n{str(e)}")

    def usar_telefone_como_pix(self):
        """Usa o telefone digitado como chave PIX"""
        telefone = self.campos_form['telefone'].get().strip()
        
        if not telefone:
            custom_messagebox("warning", "Aviso", "⚠️ Digite o telefone primeiro!")
            self.campos_form['telefone'].focus()
            return
        
        # Limpar telefone (remover caracteres especiais)
        telefone_limpo = ''.join(filter(str.isdigit, telefone))
        
        # Verificar se tem pelo menos 10 dígitos
        if len(telefone_limpo) < 10:
            custom_messagebox("warning", "Aviso", "⚠️ Telefone deve ter pelo menos 10 dígitos!")
            self.campos_form['telefone'].focus()
            return
        
        # Formatar telefone para PIX
        if len(telefone_limpo) == 10:
            # Fixo: (XX) XXXX-XXXX
            tel_formatado = f"({telefone_limpo[:2]}) {telefone_limpo[2:6]}-{telefone_limpo[6:]}"
        elif len(telefone_limpo) == 11:
            # Celular: (XX) 9XXXX-XXXX
            tel_formatado = f"({telefone_limpo[:2]}) {telefone_limpo[2:7]}-{telefone_limpo[7:]}"
        else:
            # Manter como estava se tiver mais de 11 dígitos
            tel_formatado = telefone_limpo
        
        # Atualizar campo telefone com formatação
        self.campos_form['telefone'].delete(0, tk.END)
        self.campos_form['telefone'].insert(0, tel_formatado)
        
        # Definir tipo PIX como Telefone
        self.tipo_pix.set('Telefone')
        
        # Preencher chave PIX
        self.campos_form['chave_pix'].delete(0, tk.END)
        self.campos_form['chave_pix'].insert(0, tel_formatado)
        
        custom_messagebox("info", "PIX Configurado", 
                        f"✅ Telefone configurado como chave PIX!\n\n"
                        f"📱 {tel_formatado}\n\n"
                        f"➡️ Continue preenchendo os outros dados")

    def atualizar_chave_pix(self, event=None):
        """Atualiza o campo de chave PIX baseado no tipo selecionado"""
        tipo_selecionado = self.tipo_pix.get()
        self.campos_form['chave_pix'].delete(0, tk.END)
        
        if tipo_selecionado == 'CNPJ/CPF':
            self.campos_form['chave_pix'].insert(0, self.campos_form['cnpj_cpf'].get())
        elif tipo_selecionado == 'Telefone':
            self.campos_form['chave_pix'].insert(0, self.campos_form['telefone'].get())
        elif tipo_selecionado == 'Email':
            self.campos_form['chave_pix'].insert(0, self.campos_form['email'].get())
        
        # Atualizar resumo após alterar PIX
        self.atualizar_resumo_dados_bancarios()

    def atualizar_tipo_pessoa(self, event=None):
        """Determina automaticamente o tipo de pessoa baseado no CNPJ/CPF"""
        cnpj_cpf = self.campos_form['cnpj_cpf'].get().strip()
        # Remove caracteres não numéricos
        cnpj_cpf = ''.join(filter(str.isdigit, cnpj_cpf))
        
        if len(cnpj_cpf) <= 11:
            self.campos_form['tipo_pessoa'].set('PF')
        else:
            self.campos_form['tipo_pessoa'].set('PJ')

    def copiar_para_nome(self, event=None):
        """Copia a razão social para o nome se este estiver vazio"""
        razao_social = self.campos_form['razao_social'].get().strip()
        nome_atual = self.campos_form['nome'].get().strip()
        
        if razao_social and not nome_atual:
            self.campos_form['nome'].insert(0, razao_social)
 
    def validar_cnpj_cpf_numeros(self, numeros):
        """Valida CNPJ/CPF usando apenas os números"""
        if len(numeros) == 11:
            # Validar CPF
            return validar_documento(
                f"{numeros[:3]}.{numeros[3:6]}.{numeros[6:9]}-{numeros[9:]}", 'PF')
        elif len(numeros) == 14:
            # Validar CNPJ
            return validar_documento(
                f"{numeros[:2]}.{numeros[2:5]}.{numeros[5:8]}/{numeros[8:12]}-{numeros[12:]}", 'PJ')
        return False

    def salvar_fornecedor(self):
        """Salva ou atualiza fornecedor — lê o formulário, valida e grava na planilha.

        Novo cadastro (janela "Novo Fornecedor") NUNCA sobrescreve linha
        existente, ativa ou inativa, com o mesmo documento: recusa e explica.
        Só a janela "Editar Fornecedor" atualiza uma linha existente.
        """

        # ── 1. VALIDAÇÃO ──────────────────────────────────────────────
        campos_obrigatorios = ['tipo_pessoa', 'cnpj_cpf', 'razao_social', 'nome', 'categoria']
        for campo in campos_obrigatorios:
            if not self.campos_form[campo].get().strip():
                custom_messagebox("error", "Erro", f"❌ O campo {campo} é obrigatório!")
                return

        modo_edicao = getattr(self, 'modo_edicao_fornecedor', False)
        tipo_pessoa = self.campos_form['tipo_pessoa'].get().strip().upper()
        if tipo_pessoa not in ('PF', 'PJ'):
            custom_messagebox("error", "Erro", "❌ Selecione o tipo de pessoa (PF ou PJ).")
            return

        # O tipo DECLARADO manda: completa zeros à esquerda conforme PF (11)
        # ou PJ (14). Um CNPJ como 00.065.389/0001-53 digitado sem os zeros
        # vira 00065389000153, em vez de ser lido como CPF de 11 dígitos.
        cnpj_cpf_digitado = ''.join(filter(str.isdigit, self.campos_form['cnpj_cpf'].get()))
        tamanho = 11 if tipo_pessoa == 'PF' else 14
        if len(cnpj_cpf_digitado) > tamanho:
            custom_messagebox("error", "Erro",
                            f"❌ O documento tem {len(cnpj_cpf_digitado)} dígitos, mas o tipo é "
                            f"{tipo_pessoa} ({'CPF' if tipo_pessoa == 'PF' else 'CNPJ'}, até "
                            f"{tamanho}). Se é um {'CNPJ' if tipo_pessoa == 'PF' else 'CPF'}, "
                            f"mude o tipo para {'PJ' if tipo_pessoa == 'PF' else 'PF'}.")
            return
        cnpj_cpf_numeros = cnpj_cpf_digitado.zfill(tamanho)

        if not validar_documento(cnpj_cpf_numeros, tipo_pessoa):
            custom_messagebox("error", "Erro",
                            f"❌ {'CPF' if tipo_pessoa == 'PF' else 'CNPJ'} inválido!")
            return

        # ── 2. MONTAR DADOS BANCÁRIOS ──────────────────────────────────
        chave_pix = self.campos_form['chave_pix'].get().strip()
        if chave_pix:
            dados_bancarios = f"PIX: {chave_pix}"
        else:
            partes = [self.campos_form[c].get().strip()
                    for c in ('banco', 'op', 'agencia', 'conta')
                    if self.campos_form[c].get().strip()]
            dados_bancarios = ' - '.join(partes)

        # ── 3. DICIONÁRIO ÚNICO DE CAMPOS ─────────────────────────────
        #   Para adicionar um novo campo no futuro:
        #   a) inclua a entrada aqui
        #   b) adicione a coluna na planilha
        #   Só isso — nenhum outro lugar precisa ser alterado.
        dados = {
            'cnpj_cpf':      cnpj_cpf_numeros,
            'tipo_pessoa':   tipo_pessoa,
            'razao_social':  self.campos_form['razao_social'].get().upper(),
            'nome':          self.campos_form['nome'].get().upper(),
            'telefone':      self.campos_form['telefone'].get(),
            'email':         self.campos_form['email'].get(),
            'banco':         self.campos_form['banco'].get(),
            'op':            self.campos_form['op'].get(),
            'agencia':       self.campos_form['agencia'].get(),
            'conta':         self.campos_form['conta'].get(),
            'chave_pix':     chave_pix,
            'categoria':     self.campos_form['categoria'].get().upper(),
            'especificacao': self.campos_form['especificacao'].get().upper(),
            'vinculo':       self.campos_form['vinculo'].get().upper(),
            'dados_bancarios': dados_bancarios,
            'endereco':      self.campos_form['endereco'].get().upper(),
            'responsavel':   self.campos_form['responsavel'].get().upper(),
        }

        # ── 4. VERIFICAR CPF CRIADO (lógica preservada) ────────────────
        eh_cpf_criado = False
        if tipo_pessoa == 'PF':
            try:
                if not hasattr(self, 'gerenciador_cpfs'):
                    self.gerenciador_cpfs = GerenciadorCPFsCriados()
                if cnpj_cpf_numeros in self.gerenciador_cpfs.listar_cpfs_disponiveis():
                    eh_cpf_criado = True
            except Exception as e:
                logger.debug(f"Erro ao verificar CPF criado: {str(e)}")

        # ── 5. GRAVAR NA PLANILHA ──────────────────────────────────────
        try:
            from src.config.config import ARQUIVO_FORNECEDORES
            from openpyxl import load_workbook

            # Mapeamento colunas: (índice_zero_based → chave_do_dicionário)
            # Para adicionar coluna nova: acrescente a entrada aqui e no dicionário acima.
            COLUNAS = [
                'cnpj_cpf', 'tipo_pessoa', 'razao_social', 'nome',
                'telefone', 'email', 'banco', 'op', 'agencia', 'conta',
                'chave_pix', 'categoria', 'especificacao', 'vinculo',
                'dados_bancarios', 'endereco', 'status', 'responsavel',
            ]

            def _doc_normalizado(doc, tipo):
                digitos = ''.join(filter(str.isdigit, str(doc or '')))
                return digitos.zfill(11 if str(tipo).strip().upper() == 'PF' else 14)

            wb = load_workbook(ARQUIVO_FORNECEDORES)
            ws = wb['Fornecedores']

            # Garantir cabeçalho da coluna STATUS
            if ws.cell(1, 17).value != 'STATUS':
                ws.cell(1, 17, 'STATUS')

            # Ler todos os registros existentes
            fornecedores = []
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row or not row[0]:
                    continue
                row_pad = list(row) + [None] * (len(COLUNAS) - len(row))
                reg = {col: (str(row_pad[i]).strip() if row_pad[i] else '')
                    for i, col in enumerate(COLUNAS)}
                reg['status'] = reg['status'].upper() if reg['status'] else 'ATIVO'
                if reg['cnpj_cpf'] and reg['nome']:
                    fornecedores.append(reg)

            # Localizar linha com o mesmo documento (comparação normalizada
            # pelo tipo de cada lado, para zeros à esquerda não atrapalharem)
            indice_existente = None
            for i, reg in enumerate(fornecedores):
                if _doc_normalizado(reg['cnpj_cpf'], reg['tipo_pessoa']) == cnpj_cpf_numeros:
                    indice_existente = i
                    break

            if indice_existente is not None and not modo_edicao:
                # NOVO cadastro com documento que já existe: recusar.
                wb.close()
                existente = fornecedores[indice_existente]
                if existente['status'] == 'INATIVO':
                    dica = ("Ele está INATIVO. Para voltar a usá-lo, reative-o em "
                            "'📋 Ver Inativos'.")
                else:
                    dica = "Para alterar os dados dele, use 'Editar Fornecedor'."
                if eh_cpf_criado:
                    dica += ("\n\nEste CPF criado está marcado como DISPONÍVEL, mas já está em "
                             "uso. Escolha outro em '📋 Escolher da Lista' e, na aba CPF do "
                             "Base_Fornecedores.xlsx, mude o status deste CPF para USADO.")
                custom_messagebox("error", "Documento já cadastrado",
                                f"❌ Já existe um fornecedor com este documento:\n\n"
                                f"{existente['nome']} ({existente['status']})\n\n"
                                f"Nada foi gravado. {dica}")
                return

            if indice_existente is not None:
                dados['status'] = fornecedores[indice_existente].get('status', 'ATIVO')  # preserva status
                fornecedores[indice_existente] = dados.copy()
            else:
                dados['status'] = 'ATIVO'
                fornecedores.append(dados.copy())

            # Reescrever planilha ordenada
            fornecedores.sort(key=lambda x: x.get('nome', '').upper())
            max_row = ws.max_row
            if max_row > 1:
                ws.delete_rows(2, max_row - 1)

            for i, reg in enumerate(fornecedores, start=2):
                for j, col in enumerate(COLUNAS, start=1):
                    ws.cell(row=i, column=j, value=reg.get(col, ''))

            salvar_planilha_segura(wb, ARQUIVO_FORNECEDORES)
            wb.close()

        except PermissionError:
            custom_messagebox("error", "Erro de Permissão",
                            "Arquivo aberto em outro programa! Feche o Excel e tente novamente.")
            return
        except Exception as e:
            logger.error(f"Erro ao salvar fornecedor: {str(e)}")
            custom_messagebox("error", "Erro", f"❌ Erro ao salvar:\n{str(e)}")
            return

        # ── 6. PÓS-SALVAMENTO ─────────────────────────────────────────
        if eh_cpf_criado:
            try:
                sucesso = self.gerenciador_cpfs.marcar_cpf_como_usado(
                    cnpj_cpf_numeros, dados['nome'])
                msg = ("✅ Fornecedor salvo!\n\n🔄 CPF criado marcado como usado."
                    if sucesso else
                    "✅ Fornecedor salvo!\n\n⚠️ Não foi possível marcar o CPF como usado.")
            except Exception as e:
                msg = "✅ Fornecedor salvo!"
        else:
            msg = "✅ Fornecedor salvo com sucesso!"

        custom_messagebox("info", "Sucesso", msg)
        self.janela_fornecedor.destroy()
        self.buscar_fornecedor()

    def preencher_dados_fornecedor(self, dados):
        """Preenche os campos do fornecedor na aba de entrada"""
        self.campos_fornecedor['cnpj_cpf'].delete(0, tk.END)
        self.campos_fornecedor['cnpj_cpf'].insert(0, dados[0])
        
        self.campos_fornecedor['nome'].delete(0, tk.END)
        self.campos_fornecedor['nome'].insert(0, dados[1])
        
        self.campos_fornecedor['categoria'].delete(0, tk.END)
        self.campos_fornecedor['categoria'].insert(0, dados[2])


    def gerenciar_cpfs_criados(self):
        """Abre interface para gerenciar fornecedores com CPFs criados - NOVA FUNCIONALIDADE"""
        try:
            # Verificar se o arquivo de fornecedores existe
            if not os.path.exists(ARQUIVO_FORNECEDORES):
                custom_messagebox("error", "Erro", "Arquivo de fornecedores não encontrado!")
                return
            
            # Criar janela de gerenciamento
            janela_gerencia = tk.Toplevel(self.root)
            janela_gerencia.title("Gerenciar Fornecedores com CPF Criado")
            janela_gerencia.geometry("900x700")
            janela_gerencia.transient(self.root)
            janela_gerencia.grab_set()
            
            # Centralizar janela
            janela_gerencia.update_idletasks()
            x = (janela_gerencia.winfo_screenwidth() // 2) - (450)
            y = (janela_gerencia.winfo_screenheight() // 2) - (350)
            janela_gerencia.geometry(f"900x800+{x}+{y}")
            
            main_frame = ttk.Frame(janela_gerencia, padding="15")
            main_frame.pack(fill='both', expand=True)
            
            # Cabeçalho
            header_frame = ttk.Frame(main_frame)
            header_frame.pack(fill='x', pady=(0, 15))
            
            ttk.Label(header_frame, text="Gerenciar Fornecedores com CPF Criado", 
                    font=('Arial', 16, 'bold')).pack()
            ttk.Label(header_frame, text="Exclua registros temporários quando obtiver os dados reais", 
                    font=('Arial', 10), foreground='gray').pack()
            
            # Frame de controles
            controls_frame = ttk.Frame(main_frame)
            controls_frame.pack(fill='x', pady=(0, 10))
            
            # Botão para atualizar lista
            ttk.Button(controls_frame, text="Atualizar Lista", 
                    command=lambda: self.carregar_fornecedores_cpf_criado(tree_fornecedores)).pack(side='left', padx=5)
            
            # Botão para excluir selecionados
            ttk.Button(controls_frame, text="Excluir Selecionados", 
                    command=lambda: self.excluir_fornecedores_selecionados(tree_fornecedores)).pack(side='left', padx=5)
            
            # Label para contagem
            self.lbl_contagem = ttk.Label(controls_frame, text="", font=('Arial', 10))
            self.lbl_contagem.pack(side='right', padx=10)
            
            # Frame para lista de fornecedores
            lista_frame = ttk.LabelFrame(main_frame, text="Fornecedores com CPF Criado:")
            lista_frame.pack(fill='both', expand=True, pady=(0, 10))
            
            # Frame interno para Treeview e scrollbars
            tree_frame = ttk.Frame(lista_frame)
            tree_frame.pack(fill='both', expand=True, padx=10, pady=10)
            
            # Treeview para fornecedores
            tree_fornecedores = ttk.Treeview(tree_frame, 
                                            columns=('CPF', 'Nome', 'Categoria', 'Especificacao', 'Status'), 
                                            show='headings', 
                                            height=20,
                                            selectmode='extended')  # Permite seleção múltipla
            
            # Configurar colunas
            tree_fornecedores.heading('CPF', text='CPF Criado')
            tree_fornecedores.heading('Nome', text='Nome/Razão Social')
            tree_fornecedores.heading('Categoria', text='Categoria')
            tree_fornecedores.heading('Especificacao', text='Especificação')
            tree_fornecedores.heading('Status', text='Status')
            
            tree_fornecedores.column('CPF', width=150, anchor='center')
            tree_fornecedores.column('Nome', width=250)
            tree_fornecedores.column('Categoria', width=100, anchor='center')
            tree_fornecedores.column('Especificacao', width=150)
            tree_fornecedores.column('Status', width=120, anchor='center')
            
            # Scrollbars
            scroll_y = ttk.Scrollbar(tree_frame, orient='vertical', command=tree_fornecedores.yview)
            scroll_x = ttk.Scrollbar(tree_frame, orient='horizontal', command=tree_fornecedores.xview)
            tree_fornecedores.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
            
            tree_fornecedores.pack(side='left', fill='both', expand=True)
            scroll_y.pack(side='right', fill='y')
            scroll_x.pack(side='bottom', fill='x')
            
            # Frame de informações e ações
            info_frame = ttk.LabelFrame(main_frame, text="Informações:")
            info_frame.pack(fill='x', pady=(0, 15))
            
            info_text = tk.Text(info_frame, height=4, wrap='word', bg='#f0f0f0', 
                            font=('Arial', 9), state='normal')
            info_text.pack(fill='x', padx=10, pady=10)
            
            info_text.insert('1.0', 
                "• Selecione um ou múltiplos fornecedores para exclusão (Ctrl+Click para múltipla seleção)\n"
                "• CPFs criados são identificados automaticamente pela base de CPFs gerados\n"
                "• A exclusão é permanente - certifique-se antes de confirmar\n"
                "• Após excluir, o CPF volta a ficar disponível para reutilização")
            info_text.config(state='disabled')
            
            # Botões de ação
            buttons_frame = ttk.Frame(main_frame)
            buttons_frame.pack(fill='x')
            
            ttk.Button(buttons_frame, text="Fechar", 
                    command=janela_gerencia.destroy).pack(side='right', padx=5)
            
            ttk.Button(buttons_frame, text="Exportar Lista", 
                    command=lambda: self.exportar_lista_cpf_criado(tree_fornecedores)).pack(side='left', padx=5)
            
            # Carregar dados iniciais
            self.carregar_fornecedores_cpf_criado(tree_fornecedores)
            
            # Armazenar referência da tree para uso em outras funções
            self.tree_gerencia_cpf = tree_fornecedores
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir gerenciador: {str(e)}")

    def carregar_fornecedores_cpf_criado(self, tree_widget):
        """Carrega fornecedores que usam CPFs criados da aba CPF"""
        try:
            # Limpar tree
            for item in tree_widget.get_children():
                tree_widget.delete(item)
            
            # Inicializar gerenciador de CPFs se não existir
            if not hasattr(self, 'gerenciador_cpfs'):
                self.gerenciador_cpfs = GerenciadorCPFsCriados()
            
            # Obter lista de CPFs criados da aba CPF
            cpfs_criados_total = self.gerenciador_cpfs.listar_todos_cpfs_criados()
            
            if not cpfs_criados_total:
                self.lbl_contagem.config(text="Nenhum CPF criado encontrado na aba CPF")
                tree_widget.insert('', 'end', values=(
                    '', 'Nenhum CPF criado encontrado na aba CPF', '', '', ''
                ))
                return
            
            # Carregar fornecedores da aba Fornecedores
            wb = load_workbook(ARQUIVO_FORNECEDORES, data_only=True)
            ws = wb['Fornecedores']
            
            fornecedores_encontrados = []
            cpfs_usados = self.gerenciador_cpfs.listar_cpfs_usados()
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row[0]:  # Pular linhas vazias
                    continue
                
                cnpj_cpf_row = str(row[0]).strip()
                # Remover formatação para comparação
                cnpj_cpf_numeros = ''.join(filter(str.isdigit, cnpj_cpf_row))
                
                # Verificar se é um CPF criado
                if cnpj_cpf_numeros in cpfs_criados_total:
                    nome = str(row[3] or '').strip()  # Coluna D = Nome
                    categoria = str(row[11] or '').strip()  # Coluna L = Categoria
                    especificacao = str(row[12] or '').strip()  # Coluna M = Especificação
                    
                    # Verificar status na aba CPF
                    status = "Em Uso" if cnpj_cpf_numeros in cpfs_usados else "Disponível"
                    
                    # Obter detalhes do CPF da aba CPF
                    detalhes = self.gerenciador_cpfs.obter_detalhes_cpf_usado(cnpj_cpf_numeros)
                    if detalhes:
                        if detalhes['status'].upper() == 'USADO':
                            status = f"Em Uso ({detalhes['data_uso']})"
                        elif detalhes['status'].upper() == 'DISPONIVEL':
                            status = "Cadastrado (não deveria existir)"
                        elif detalhes['status'].upper() == 'INVALIDO':
                            status = "CPF Inválido"
                    
                    # Formatar CPF para exibição
                    cpf_formatado = f"{cnpj_cpf_numeros[:3]}.{cnpj_cpf_numeros[3:6]}.{cnpj_cpf_numeros[6:9]}-{cnpj_cpf_numeros[9:]}"
                    
                    # Inserir na tree
                    item_id = tree_widget.insert('', 'end', values=(
                        cpf_formatado,
                        nome,
                        categoria,
                        especificacao,
                        status
                    ), tags=(cnpj_cpf_numeros,))  # Armazenar CPF sem formatação nas tags
                    
                    fornecedores_encontrados.append({
                        'cpf': cnpj_cpf_numeros,
                        'nome': nome,
                        'categoria': categoria,
                        'especificacao': especificacao,
                        'status': status
                    })
            
            wb.close()
            
            # Atualizar contador
            total = len(fornecedores_encontrados)
            em_uso = len([f for f in fornecedores_encontrados if 'Em Uso' in f['status']])
            inconsistentes = len([f for f in fornecedores_encontrados if 'não deveria existir' in f['status']])
            
            contador_texto = f"Total: {total} | Em uso: {em_uso}"
            if inconsistentes > 0:
                contador_texto += f" | Inconsistentes: {inconsistentes}"
            
            self.lbl_contagem.config(text=contador_texto)
            
            if total == 0:
                # Inserir mensagem informativa
                tree_widget.insert('', 'end', values=(
                    '', 'Nenhum fornecedor com CPF criado encontrado', '', '', ''
                ))
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao carregar fornecedores: {str(e)}")
            logger.debug(f"Erro detalhado: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def excluir_fornecedores_selecionados(self, tree_widget):
        """Exclui os fornecedores selecionados da base"""
        try:
            selecionados = tree_widget.selection()
            
            if not selecionados:
                custom_messagebox("warning", "Aviso", "Selecione pelo menos um fornecedor para excluir!")
                return
            
            # Coletar dados dos selecionados
            fornecedores_para_excluir = []
            for item in selecionados:
                values = tree_widget.item(item)['values']
                if values[1] == 'Nenhum fornecedor com CPF criado encontrado':
                    continue
                
                cpf_sem_formatacao = tree_widget.item(item)['tags'][0]
                fornecedores_para_excluir.append({
                    'cpf': cpf_sem_formatacao,
                    'cpf_formatado': values[0],
                    'nome': values[1],
                    'categoria': values[2],
                    'especificacao': values[3],
                    'status': values[4]
                })
            
            if not fornecedores_para_excluir:
                custom_messagebox("warning", "Aviso", "Nenhum fornecedor válido selecionado!")
                return
            
            # Confirmar exclusão
            total = len(fornecedores_para_excluir)
            lista_nomes = '\n'.join([f"• {f['cpf_formatado']} - {f['nome']}" for f in fornecedores_para_excluir[:5]])
            if total > 5:
                lista_nomes += f"\n... e mais {total - 5} fornecedores"
            
            resposta = custom_messagebox("question", "Confirmar Exclusão", 
                                    f"Deseja realmente excluir {total} fornecedor(es)?\n\n"
                                    f"{lista_nomes}\n\n"
                                    f"ATENÇÃO: Esta ação é permanente e não pode ser desfeita!")
            
            if resposta != 'yes':
                return
            
            # Executar exclusão
            sucesso, falhas = self.executar_exclusao_fornecedores(fornecedores_para_excluir)
            
            # Mostrar resultado
            if falhas:
                mensagem = f"Exclusão concluída com problemas:\n\n"
                mensagem += f"✓ Excluídos com sucesso: {sucesso}\n"
                mensagem += f"✗ Falhas: {len(falhas)}\n\n"
                mensagem += "Fornecedores com falha:\n"
                for falha in falhas[:3]:
                    mensagem += f"• {falha['nome']} - {falha['erro']}\n"
                if len(falhas) > 3:
                    mensagem += f"... e mais {len(falhas) - 3} falhas"
                
                custom_messagebox("warning", "Exclusão com Problemas", mensagem)
            else:
                custom_messagebox("info", "Sucesso", 
                                f"✓ {sucesso} fornecedor(es) excluído(s) com sucesso!\n\n"
                                f"Os CPFs voltaram a ficar disponíveis para reutilização.")
            
            # Recarregar lista
            self.carregar_fornecedores_cpf_criado(tree_widget)
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro durante exclusão: {str(e)}")

    def executar_exclusao_fornecedores(self, fornecedores_para_excluir):
        """Executa a exclusão dos fornecedores da base e atualiza CPFs criados"""
        sucesso = 0
        falhas = []
        
        try:
            # Carregar planilha de fornecedores
            wb = load_workbook(ARQUIVO_FORNECEDORES)
            ws = wb['Fornecedores']
            
            # Coletar todas as linhas que NÃO devem ser excluídas
            linhas_manter = []
            cpfs_excluir = [f['cpf'] for f in fornecedores_para_excluir]
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row[0]:  # Linha vazia
                    continue
                
                cnpj_cpf_row = str(row[0]).strip()
                cnpj_cpf_numeros = ''.join(filter(str.isdigit, cnpj_cpf_row))
                
                # Se não está na lista de exclusão, manter
                if cnpj_cpf_numeros not in cpfs_excluir:
                    linhas_manter.append(row)
            
            # Limpar planilha (manter apenas cabeçalho)
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.value = None
            
            # Reescrever apenas as linhas que devem ser mantidas
            for i, row_data in enumerate(linhas_manter, start=2):
                for j, value in enumerate(row_data, start=1):
                    if j <= 15:  # Limitar às colunas existentes
                        ws.cell(row=i, column=j, value=value)
            
            # Salvar alterações na base de fornecedores
            salvar_planilha_segura(wb, ARQUIVO_FORNECEDORES)
            
            # Marcar CPFs como disponíveis novamente
            if not hasattr(self, 'gerenciador_cpfs'):
                self.gerenciador_cpfs = GerenciadorCPFsCriados()
            
            for fornecedor in fornecedores_para_excluir:
                try:
                    # Tentar marcar CPF como disponível novamente
                    self.gerenciador_cpfs.marcar_cpf_como_disponivel(fornecedor['cpf'])
                    sucesso += 1
                except Exception as e:
                    falhas.append({
                        'nome': fornecedor['nome'],
                        'cpf': fornecedor['cpf'],
                        'erro': str(e)
                    })
            
        except Exception as e:
            # Se der erro geral, considerar falha para todos
            for fornecedor in fornecedores_para_excluir:
                falhas.append({
                    'nome': fornecedor['nome'],
                    'cpf': fornecedor['cpf'],
                    'erro': f"Erro geral: {str(e)}"
                })
        
        return sucesso, falhas

    def exportar_lista_cpf_criado(self, tree_widget):
        """Exporta a lista de fornecedores com CPF criado para Excel"""
        try:
            from tkinter import filedialog
            import pandas as pd
            from datetime import datetime
            
            # Verificar se há dados
            if not tree_widget.get_children():
                custom_messagebox("warning", "Aviso", "Não há dados para exportar!")
                return
            
            # Coletar dados da tree
            dados = []
            for item in tree_widget.get_children():
                values = tree_widget.item(item)['values']
                if values[1] != 'Nenhum fornecedor com CPF criado encontrado':
                    dados.append({
                        'CPF_Criado': values[0],
                        'Nome_Razao_Social': values[1],
                        'Categoria': values[2],
                        'Especificacao': values[3],
                        'Status': values[4]
                    })
            
            if not dados:
                custom_messagebox("warning", "Aviso", "Não há dados válidos para exportar!")
                return
            
            # Escolher local para salvar
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            arquivo = filedialog.asksaveasfilename(
                title="Salvar lista de fornecedores com CPF criado",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialvalue=f"fornecedores_cpf_criado_{timestamp}.xlsx"
            )
            
            if not arquivo:
                return
            
            # Criar DataFrame e salvar
            df = pd.DataFrame(dados)
            
            with pd.ExcelWriter(arquivo, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Fornecedores_CPF_Criado', index=False)
                
                # Ajustar largura das colunas
                worksheet = writer.sheets['Fornecedores_CPF_Criado']
                for column in worksheet.columns:
                    max_length = 0
                    column_letter = column[0].column_letter
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = min(max_length + 2, 50)
                    worksheet.column_dimensions[column_letter].width = adjusted_width
            
            custom_messagebox("info", "Sucesso", 
                            f"Lista exportada com sucesso!\n\n"
                            f"Arquivo: {arquivo}\n"
                            f"Total de registros: {len(dados)}")
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao exportar: {str(e)}")

    def abrir_regularizar_fornecedor(self):
        from src.fornecedores import regularizar_fornecedor
        from src.config import ARQUIVO_FORNECEDORES, PASTA_CLIENTES
        from datetime import datetime
        import os

        selecionado = self.tree_fornecedores.selection()
        if not selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um fornecedor primeiro!")
            return

        tags = self.tree_fornecedores.item(selecionado[0])['tags']
        doc_antigo = tags[0].replace('ID:', '')
        fornecedor = self.buscar_fornecedor_completo(doc_antigo)
        if not fornecedor:
            custom_messagebox("error", "Erro", "Não foi possível carregar os dados atuais do fornecedor.")
            return

        # Tipo de pessoa atual: coluna B da base (fonte da verdade). Se o
        # cache não trouxer, usa a tag gravada por buscar_fornecedor(), que
        # também vem da coluna B. Nunca pela contagem de dígitos.
        tipo_atual = str(fornecedor.get('tipo_pessoa') or '').strip().upper()
        if tipo_atual not in ('PF', 'PJ'):
            tipo_atual = str(tags[1]).strip().upper() if len(tags) > 1 else ''
        if tipo_atual not in ('PF', 'PJ'):
            tipo_atual = ''

        janela = tk.Toplevel(self.root)
        janela.title("🔧 Regularizar Cadastro de Fornecedor")
        largura, altura = 650, 540
        janela.geometry(f"{largura}x{altura}")
        janela.transient(self.root)
        janela.grab_set()
        janela.update_idletasks()
        pos_x = (janela.winfo_screenwidth() // 2) - (largura // 2)
        pos_y = (janela.winfo_screenheight() // 2) - (altura // 2)
        janela.geometry(f"{largura}x{altura}+{pos_x}+{pos_y}")
        janela.lift()
        janela.focus_force()
        janela.attributes('-topmost', True)
        janela.after(500, lambda: janela.attributes('-topmost', False))

        main = ttk.Frame(janela, padding=15)
        main.pack(fill='both', expand=True)

        ttk.Label(main, text="🔧 Regularizar Cadastro", font=('Arial', 16, 'bold')).pack(pady=(0, 5))
        ttk.Label(main,
                text="Use para corrigir dado ERRADO (digitação, nome incompleto) ou para trocar\n"
                    "um CPF criado pelo documento real (CPF ou CNPJ).\n"
                    "Para unir dois cadastros que são a mesma pessoa/empresa, use 'Mesclar Duplicados'.",
                font=('Arial', 9), foreground='gray', justify='left').pack(pady=(0, 15))

        campos_frame = ttk.LabelFrame(main, text="Dados atuais → corrigidos")
        campos_frame.pack(fill='x', pady=(0, 10))
        campos = ttk.Frame(campos_frame, padding=10)
        campos.pack(fill='x')

        ttk.Label(campos, text="CNPJ/CPF atual:").grid(row=0, column=0, sticky='w', pady=4)
        ttk.Label(campos, text=fornecedor['cnpj_cpf'], font=('Arial', 9, 'bold')).grid(row=0, column=1, sticky='w', padx=5)
        ttk.Label(campos, text="CNPJ/CPF correto:").grid(row=1, column=0, sticky='w', pady=4)
        entry_doc = ttk.Entry(campos, width=25)
        entry_doc.insert(0, fornecedor['cnpj_cpf'])
        entry_doc.grid(row=1, column=1, sticky='w', padx=5)

        ttk.Label(campos, text="Tipo de pessoa atual:").grid(row=2, column=0, sticky='w', pady=4)
        ttk.Label(campos, text=tipo_atual or '(não preenchido na base)',
                  font=('Arial', 9, 'bold')).grid(row=2, column=1, sticky='w', padx=5)
        ttk.Label(campos, text="Tipo de pessoa correto:").grid(row=3, column=0, sticky='w', pady=4)
        combo_tipo = ttk.Combobox(campos, values=['PF', 'PJ'], state='readonly', width=5)
        if tipo_atual:
            combo_tipo.set(tipo_atual)
        combo_tipo.grid(row=3, column=1, sticky='w', padx=5)
        ttk.Label(campos, text="PF = CPF  |  PJ = CNPJ", font=('Arial', 8),
                  foreground='gray').grid(row=3, column=1, sticky='w', padx=(60, 0))

        ttk.Label(campos, text="Nome atual:").grid(row=4, column=0, sticky='w', pady=4)
        ttk.Label(campos, text=fornecedor['nome'], font=('Arial', 9, 'bold')).grid(row=4, column=1, sticky='w', padx=5)
        ttk.Label(campos, text="Nome correto:").grid(row=5, column=0, sticky='w', pady=4)
        entry_nome = ttk.Entry(campos, width=50)
        entry_nome.insert(0, fornecedor['nome'])
        entry_nome.grid(row=5, column=1, sticky='w', padx=5)

        ttk.Label(campos, text="Razão social atual:").grid(row=6, column=0, sticky='w', pady=4)
        ttk.Label(campos, text=fornecedor['razao_social'], font=('Arial', 9, 'bold')).grid(row=6, column=1, sticky='w', padx=5)
        ttk.Label(campos, text="Razão social correta:").grid(row=7, column=0, sticky='w', pady=4)
        entry_razao = ttk.Entry(campos, width=50)
        entry_razao.insert(0, fornecedor['razao_social'])
        entry_razao.grid(row=7, column=1, sticky='w', padx=5)

        ttk.Label(main, text="💡 Deixe igual ao que já está se não precisar corrigir aquele campo.\n"
                             "💡 Trocou CPF por CNPJ (ou o contrário)? Mude também o Tipo de pessoa.",
                font=('Arial', 8), foreground='gray', justify='left').pack(anchor='w')

        label_progresso = ttk.Label(main, text="", font=('Arial', 8), foreground='#0056b3')
        label_progresso.pack(anchor='w', pady=(5, 0))

        def progresso(i, total, nome_arquivo):
            label_progresso.config(text=f"Verificando {i}/{total}: {nome_arquivo}...")
            janela.update_idletasks()

        NADA = (None, None, None, None)

        def _ler_campos():
            """Retorna (doc_novo, nome_novo, razao_novo, tipo_novo); cada um é
            None quando não mudou. NADA quando nada mudou ou há erro."""
            doc_digitado = entry_doc.get().strip()
            nome_novo = entry_nome.get().strip()
            razao_novo = entry_razao.get().strip()
            tipo_escolhido = combo_tipo.get().strip().upper()

            if tipo_escolhido not in ('PF', 'PJ'):
                custom_messagebox("warning", "Aviso", "Selecione o tipo de pessoa correto (PF ou PJ).")
                return NADA

            # Compara só os dígitos, sem zeros à esquerda, para que digitar o
            # mesmo documento com ou sem máscara/zeros não conte como mudança.
            dig_novo = ''.join(filter(str.isdigit, doc_digitado))
            dig_antigo = ''.join(filter(str.isdigit, doc_antigo))
            doc_novo = doc_digitado if dig_novo.lstrip('0') != dig_antigo.lstrip('0') else None
            nome_novo = nome_novo if nome_novo.upper() != str(fornecedor['nome'] or '').upper() else None
            razao_novo = razao_novo if razao_novo.upper() != str(fornecedor['razao_social'] or '').upper() else None
            tipo_novo = tipo_escolhido if tipo_escolhido != tipo_atual else None

            if not (doc_novo or nome_novo or razao_novo or tipo_novo):
                custom_messagebox("warning", "Aviso", "Nenhum campo foi alterado.")
                return NADA
            return doc_novo, nome_novo, razao_novo, tipo_novo

        def _chamar(dry_run, **extra):
            return regularizar_fornecedor(
                base_path=ARQUIVO_FORNECEDORES, pasta_clientes=PASTA_CLIENTES,
                doc_antigo=doc_antigo, doc_novo=doc_novo_g[0], nome_novo=doc_novo_g[1],
                razao_novo=doc_novo_g[2], tipo_pessoa_novo=doc_novo_g[3],
                dry_run=dry_run, callback_progresso=progresso, **extra,
            )

        doc_novo_g = list(NADA)  # valores lidos na última ação (usado por _chamar)

        def pre_visualizar():
            valores = _ler_campos()
            if valores == NADA:
                return
            doc_novo_g[:] = valores
            label_progresso.config(text="Iniciando pré-visualização...")
            janela.update_idletasks()
            preview = _chamar(dry_run=True)
            label_progresso.config(text="")
            custom_messagebox(
                "error" if preview.erro else "info",
                "Erro" if preview.erro else "Pré-visualização (nada foi gravado)",
                preview.erro or preview.resumo()
            )

        def confirmar_e_aplicar():
            valores = _ler_campos()
            if valores == NADA:
                return
            doc_novo_g[:] = valores

            label_progresso.config(text="Verificando o que seria alterado...")
            janela.update_idletasks()
            preview = _chamar(dry_run=True)
            label_progresso.config(text="")
            if preview.erro:
                custom_messagebox("error", "Erro", preview.erro)
                return
            if not preview.alteracoes:
                custom_messagebox("info", "Nada a fazer", "Nenhuma alteração seria feita.")
                return

            arquivos_afetados = sorted(set(a.arquivo for a in preview.alteracoes))
            resposta = custom_messagebox(
                "question", "Confirmar Regularização",
                f"{len(preview.alteracoes)} célula(s) serão alteradas em "
                f"{len(arquivos_afetados)} arquivo(s):\n\n"
                + "\n".join(f"  • {a}" for a in arquivos_afetados[:8])
                + (f"\n  ... e mais {len(arquivos_afetados) - 8}" if len(arquivos_afetados) > 8 else "")
                + (("\n\nATENÇÃO:\n" + "\n".join(f"  ⚠ {av}" for av in preview.avisos))
                   if preview.avisos else "")
                + "\n\nConfirma?"
            )
            if not resposta:
                return

            nome_base = os.path.basename(ARQUIVO_FORNECEDORES)
            arquivos_cliente_afetados = [
                os.path.join(PASTA_CLIENTES, a) for a in arquivos_afetados if a != nome_base
            ]

            pasta_logs = os.path.join(os.path.dirname(ARQUIVO_FORNECEDORES), 'logs_regularizacao')
            os.makedirs(pasta_logs, exist_ok=True)
            carimbo = datetime.now().strftime('%Y%m%d_%H%M%S')
            log_debug = os.path.join(pasta_logs, f"debug_{doc_antigo}_{carimbo}.log")

            label_progresso.config(text="Aplicando alterações...")
            janela.update_idletasks()
            resultado = _chamar(dry_run=False, arquivo_log_debug=log_debug,
                                arquivos_cliente=arquivos_cliente_afetados)

            resultado.salvar_log(os.path.join(pasta_logs, f"regularizacao_{doc_antigo}_{carimbo}.json"))

            pendente = bool(resultado.arquivos_com_falha or resultado.erro)
            custom_messagebox(
                "warning" if pendente else "info",
                "Concluído com pendências" if pendente else "Regularização concluída",
                resultado.resumo()
            )
            janela.destroy()
            self.buscar_fornecedor()

        frame_botoes = ttk.Frame(main)
        frame_botoes.pack(fill='x', pady=(15, 0))
        ttk.Button(frame_botoes, text="👁️ Pré-visualizar (não grava)",
                command=pre_visualizar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="✅ Confirmar e Aplicar",
                command=confirmar_e_aplicar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="❌ Cancelar",
                command=janela.destroy).pack(side='right', padx=5)
        
    def abrir_fundir_fornecedores(self):
        """
        Abre janela para mesclar dois (ou mais) cadastros de fornecedores que
        representam a mesma pessoa/empresa (ex.: CPF criado + CPF real depois
        obtido). Mostra os candidatos detectados automaticamente e também
        permite informar o par manualmente.
        """
        from src.fornecedores import fundir_fornecedores, detectar_possiveis_duplicatas
        from src.config import ARQUIVO_FORNECEDORES, PASTA_CLIENTES
        from datetime import datetime
        import os

        janela = tk.Toplevel(self.root)
        janela.title("🔗 Mesclar Fornecedores Duplicados")
        janela.geometry("900x650")
        janela.transient(self.root)
        janela.grab_set()

        main = ttk.Frame(janela, padding=15)
        main.pack(fill='both', expand=True)

        ttk.Label(main, text="🔗 Mesclar Cadastros Duplicados",
                font=('Arial', 16, 'bold')).pack(pady=(0, 5))
        ttk.Label(main, text="Selecione um candidato detectado automaticamente, ou informe o par manualmente abaixo.",
                font=('Arial', 9), foreground='gray').pack(pady=(0, 15))

        # ---- Candidatos automáticos ----
        frame_cand = ttk.LabelFrame(main, text="Candidatos detectados (score >= 0.75)")
        frame_cand.pack(fill='both', expand=True, pady=(0, 15))

        tree = ttk.Treeview(frame_cand, columns=('score', 'prov', 'doc_prov', 'cand', 'doc_cand'),
                            show='headings', height=10)
        tree.heading('score', text='Score')
        tree.heading('prov', text='Nome (CPF criado)')
        tree.heading('doc_prov', text='Doc. provisório')
        tree.heading('cand', text='Nome (candidato)')
        tree.heading('doc_cand', text='Doc. candidato')
        for col, w in [('score', 60), ('prov', 220), ('doc_prov', 130), ('cand', 220), ('doc_cand', 130)]:
            tree.column(col, width=w, anchor='w')
        tree.pack(fill='both', expand=True, padx=10, pady=10)

        try:
            candidatos, orfaos = detectar_possiveis_duplicatas(ARQUIVO_FORNECEDORES, limiar=0.75)
        except Exception as e:
            candidatos, orfaos = [], []
            custom_messagebox("warning", "Aviso", f"Não foi possível rodar a detecção automática:\n{e}")

        # Ao preencher a lista de candidatos:
        mapa_candidatos = {}  # iid da linha -> (doc_provisorio, doc_candidato), só em memória Python
        for c in candidatos:
            iid = tree.insert('', 'end', values=(
                f"{c['score']:.2f}", c['nome_provisorio'], c['doc_provisorio'],
                c['nome_candidato'], c['doc_candidato']
            ))
            mapa_candidatos[iid] = (c['doc_provisorio'], c['doc_candidato'])

        if orfaos:
            ttk.Label(frame_cand,
                    text=f"⚠️ {len(orfaos)} CPF(s) criado(s) 'USADO' sem cadastro correspondente "
                        f"(não são duplicata — provavelmente precisam ser liberados à parte).",
                    font=('Arial', 8), foreground='#a06000').pack(anchor='w', padx=10, pady=(0, 5))

        def preencher_do_candidato():
            sel = tree.selection()
            if not sel:
                custom_messagebox("warning", "Aviso", "Selecione um candidato na lista acima primeiro.")
                return
            doc_prov, doc_cand = mapa_candidatos[sel[0]]   # <- direto do dicionário Python, nunca do Tcl
            entry_vencedor.delete(0, tk.END)
            entry_vencedor.insert(0, doc_cand)
            entry_perdedores.delete(0, tk.END)
            entry_perdedores.insert(0, doc_prov)

        ttk.Button(frame_cand, text="⬇️ Usar candidato selecionado nos campos abaixo",
                command=preencher_do_candidato).pack(pady=(0, 10))

        # ---- Campos manuais ----
        frame_manual = ttk.LabelFrame(main, text="Documentos para mesclar")
        frame_manual.pack(fill='x', pady=(0, 15))
        campos = ttk.Frame(frame_manual, padding=10)
        campos.pack(fill='x')

        ttk.Label(campos, text="CPF/CNPJ VENCEDOR (fica ativo):").grid(row=0, column=0, sticky='w', pady=4)
        entry_vencedor = ttk.Entry(campos, width=25)
        entry_vencedor.grid(row=0, column=1, sticky='w', padx=5)

        ttk.Label(campos, text="CPF/CNPJ PERDEDOR(ES) (vírgula p/ mais de um):").grid(row=1, column=0, sticky='w', pady=4)
        entry_perdedores = ttk.Entry(campos, width=40)
        entry_perdedores.grid(row=1, column=1, sticky='w', padx=5)

       
        # ---- Ações ----
        frame_botoes = ttk.Frame(main)
        frame_botoes.pack(fill='x')

        def _ler_docs():
            doc_vencedor = entry_vencedor.get().strip()
            docs_perdedores = [d.strip() for d in entry_perdedores.get().split(',') if d.strip()]
            if not doc_vencedor or not docs_perdedores:
                custom_messagebox("warning", "Aviso", "Informe o vencedor e ao menos um perdedor.")
                return None, None
            return doc_vencedor, docs_perdedores

        def pre_visualizar():
            doc_vencedor, docs_perdedores = _ler_docs()
            if not doc_vencedor:
                return
            resultado = fundir_fornecedores(
                base_path=ARQUIVO_FORNECEDORES, pasta_clientes=PASTA_CLIENTES,
                doc_vencedor=doc_vencedor, docs_perdedores=docs_perdedores,
                dry_run=True,
            )
            custom_messagebox(
                "error" if resultado.erro else "info",
                "Erro" if resultado.erro else "Pré-visualização (nada foi gravado)",
                resultado.erro or resultado.resumo()
            )
    
        def confirmar_e_aplicar():
            doc_vencedor, docs_perdedores = _ler_docs()
            if not doc_vencedor:
                return
    
            preview = fundir_fornecedores(
                base_path=ARQUIVO_FORNECEDORES, pasta_clientes=PASTA_CLIENTES,
                doc_vencedor=doc_vencedor, docs_perdedores=docs_perdedores,
                dry_run=True,
            )
            if preview.erro:
                custom_messagebox("error", "Erro", preview.erro)
                return
            if not preview.alteracoes:
                custom_messagebox("info", "Nada a fazer", "Nenhuma alteração seria feita.")
                return
    
            arquivos_afetados = sorted(set(a.arquivo for a in preview.alteracoes))
            resposta = custom_messagebox(
                "question", "⚠️ Confirmar Fusão de Cadastros",
                f"{len(docs_perdedores)} cadastro(s) perdedor(es) serão mesclados no vencedor "
                f"{doc_vencedor}.\n\n"
                f"{len(preview.alteracoes)} célula(s) alteradas em {len(arquivos_afetados)} arquivo(s):\n"
                + "\n".join(f"  • {a}" for a in arquivos_afetados[:8])
                + (f"\n  ... e mais {len(arquivos_afetados) - 8}" if len(arquivos_afetados) > 8 else "")
                + "\n\nOs perdedores ficarão INATIVOS (não excluídos)."
                + "\n\nEsta ação não é desfeita automaticamente. Confirma?"
            )
            if not resposta:
                return
    
            resultado = fundir_fornecedores(
                base_path=ARQUIVO_FORNECEDORES, pasta_clientes=PASTA_CLIENTES,
                doc_vencedor=doc_vencedor, docs_perdedores=docs_perdedores,
                dry_run=False,
            )
    
            pasta_logs = os.path.join(os.path.dirname(ARQUIVO_FORNECEDORES), 'logs_regularizacao')
            os.makedirs(pasta_logs, exist_ok=True)
            resultado.salvar_log(os.path.join(
                pasta_logs, f"fusao_{doc_vencedor}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            ))
    
            custom_messagebox(
                "warning" if resultado.arquivos_com_falha else "info",
                "Concluído com pendências" if resultado.arquivos_com_falha else "Fusão concluída",
                resultado.resumo()
            )
            janela.destroy()
            self.buscar_fornecedor()

        ttk.Button(frame_botoes, text="👁️ Pré-visualizar (não grava)",
                command=pre_visualizar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="✅ Confirmar e Aplicar",
                command=confirmar_e_aplicar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="❌ Cancelar",
                command=janela.destroy).pack(side='right', padx=5)

    def abrir_visualizador_fornecedor(self):
        """Abre o visualizador de lançamentos para o fornecedor selecionado"""
        selecionado = self.tree_fornecedores.selection()
        if not selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um fornecedor primeiro!")
            return
        
        valores = self.tree_fornecedores.item(selecionado[0])['values']
        tags = self.tree_fornecedores.item(selecionado[0])['tags']
        
        cnpj_cpf = valores[0]
        nome = valores[1]
        
        # Tentar pegar das tags
        tipo_pessoa = tags[1] if tags and len(tags) > 1 else None
        
        # Se não encontrou, buscar da planilha
        if not tipo_pessoa or tipo_pessoa not in ['PF', 'PJ']:
            fornecedor = self.buscar_fornecedor_completo(cnpj_cpf)
            tipo_pessoa = fornecedor.get('tipo_pessoa', 'PJ') if fornecedor else 'PJ'
        
        if not self.cliente_atual:
            custom_messagebox("error", "Erro", "Selecione um cliente primeiro!")
            return
        
        visualizador = VisualizadorLancamentosFornecedor(self.root, self)
        visualizador.abrir_visualizador(cnpj_cpf, nome, tipo_pessoa)

    def validar_tipo_despesa(self, P):
        """
        Valida entrada do tipo de despesa
        Args:
            P: valor proposto após a modificação
        """
        if P == "": return True  # Permite campo vazio
        if not P.isdigit(): return False  # Permite apenas dígitos
        return 1 <= int(P) <= 6  # Permite apenas valores entre 1 e 6

    def setup_aba_dados(self):
        """Configura a aba de entrada de dados com layout aprimorado e ordem de campos otimizada"""
        # Verificar se o estilo Medium.TButton já existe
        style = ttk.Style()
        if not style.lookup('Medium.TButton', 'font'):
            style.configure('Medium.TButton', font=('Arial', 11), padding=(10, 6))

        # Frame para cabeçalho com informações do cliente
        frame_cabecalho = ttk.Frame(self.aba_dados)
        frame_cabecalho.pack(fill='x', padx=10, pady=5)
        
        # Label do cliente destacado
        self.cliente_label = ttk.Label(frame_cabecalho, 
                                    text="Cliente: Nenhum selecionado", 
                                    font=('Arial', 12, 'bold'),
                                    foreground='#0056b3')
        self.cliente_label.pack(side='left', padx=5)
        
        # Frame para data de referência
        frame_data = ttk.LabelFrame(self.aba_dados, text="Data de Referência")
        frame_data.pack(fill='x', padx=10, pady=8)
        
        # Container interno para organização da data
        frame_data_interno = ttk.Frame(frame_data)
        frame_data_interno.pack(fill='x', padx=5, pady=5)
        
        ttk.Label(frame_data_interno, text="Data do Relatório:", font=('Arial', 10)).pack(side='left', padx=5)
        
        
        self.data_rel_entry = DateEntry(
            frame_data_interno,
            format='dd/mm/yyyy',
            locale='pt_BR',
            background='darkblue',
            foreground='white',
            borderwidth=2,
            font=('Arial', 10),
        )
        self.data_rel_entry.pack(side='left', padx=5, pady=5)
        
        # Definir data de referência inicial
        data_rel_inicial = self.calcular_data_rel()
        self.data_rel_entry.set_date(data_rel_inicial)
        
        def validar_entrada_data(event=None):
            data = self.data_rel_entry.get()
            if not validar_data(data):
                custom_messagebox("error", "Erro", "Data inválida! Use o formato dd/mm/aaaa")
                self.data_rel_entry.delete(0, tk.END)
                self.data_rel_entry.insert(0, self.calcular_data_rel().strftime('%d/%m/%Y'))
                logger.warning(f"validar_entrada_data: string rejeitada = '{data}' | hoje = {datetime.now()}")
                return False
            return True
        
        self.data_rel_entry.bind('<FocusOut>', validar_entrada_data)  # Valida quando perde o foco
        
        # Frame para dados do fornecedor
        frame_fornecedor = ttk.LabelFrame(self.aba_dados, text="Dados do Fornecedor")
        frame_fornecedor.pack(fill='x', padx=10, pady=8)
        
        # Adicione esta linha para tornar frame_fornecedor um atributo da classe
        self.frame_fornecedor = frame_fornecedor
        
        # Grid para organizar os campos de fornecedor de forma mais equilibrada
        self.campos_fornecedor = {}
        
        # CNPJ/CPF (row=0)
        ttk.Label(frame_fornecedor, text='CNPJ/CPF:', font=('Arial', 10)).grid(
            row=0, column=0, padx=5, pady=5, sticky='e')
        entry = ttk.Entry(frame_fornecedor, width=40, font=('Arial', 10), state='readonly')
        entry.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        self.campos_fornecedor['cnpj_cpf'] = entry
        
        # Nome (row=1)
        ttk.Label(frame_fornecedor, text='Nome:', font=('Arial', 10)).grid(
            row=1, column=0, padx=5, pady=5, sticky='e')
        entry = ttk.Entry(frame_fornecedor, width=40, font=('Arial', 10), state='readonly')
        entry.grid(row=1, column=1, padx=5, pady=5, sticky='ew')
        self.campos_fornecedor['nome'] = entry
        
        # Categoria (row=2) - CORRIGIDO: Combobox editável com valores das configurações
        ttk.Label(frame_fornecedor, text='Categoria:', font=('Arial', 10)).grid(
            row=2, column=0, padx=5, pady=5, sticky='e')
        
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        categorias = GerenciadorConfiguracoes.get_categorias_fornecedor()
        
        categoria_combo = ttk.Combobox(
            frame_fornecedor, 
            values=categorias,
            font=('Arial', 10), 
            width=38,
            state='normal'  # Editável
        )
        categoria_combo.grid(row=2, column=1, padx=5, pady=5, sticky='ew')
        self.campos_fornecedor['categoria'] = categoria_combo
        
        # Frame para forma de pagamento (row=3)
        frame_pagamento = ttk.Frame(frame_fornecedor)
        frame_pagamento.grid(row=3, column=0, columnspan=2, pady=5, sticky='ew')
        
        ttk.Label(frame_pagamento, text="Forma de Pagamento:", font=('Arial', 10)).pack(side='left', padx=5)
        self.forma_pagamento_combo = ttk.Combobox(
            frame_pagamento,
            textvariable=self.forma_pagamento_var,
            values=["PIX", "TED", "DINHEIRO"],
            state="readonly",
            width=10,
            font=('Arial', 10)
        )
        self.forma_pagamento_combo.pack(side='left', padx=5)
        # self.forma_pagamento_combo.set("PIX")
        self.forma_pagamento_combo.bind('<<ComboboxSelected>>', self.atualizar_dados_bancarios)
        
        # Dados Bancários (row=4)
        ttk.Label(frame_fornecedor, text="Dados Bancários:", font=('Arial', 10)).grid(
            row=4, column=0, padx=5, pady=5, sticky='e')
        entry = ttk.Entry(frame_fornecedor, width=40, state='readonly', font=('Arial', 10))
        entry.grid(row=4, column=1, padx=5, pady=5, sticky='ew')
        self.campos_fornecedor['dados_bancarios'] = entry
        
        # Configure expandability of columns
        frame_fornecedor.columnconfigure(1, weight=1)
        
        # Frame para botões de parcelamento
        frame_parcelamento = ttk.Frame(self.aba_dados)
        frame_parcelamento.pack(fill='x', padx=10, pady=5)
        
        # Inicializar o gestor de parcelas com a janela root
        self.gestor_parcelas = GestorParcelas(self)
        
        ttk.Button(
            frame_parcelamento,
            text="Parcelar Despesa",
            command=self.abrir_parcelamento,
            style='Medium.TButton'
        ).pack(side='left', padx=5)
        
        # Frame para dados da despesa com layout em grid otimizado
        frame_despesa = ttk.LabelFrame(self.aba_dados, text="Dados da Despesa")
        frame_despesa.pack(fill='both', expand=True, padx=10, pady=8)
        
        # Adicionar as opções de referência para tipo 1
        self.opcoes_referencia_tipo1 = [
            'DIÁRIA', 'SALÁRIO', 'TRANSPORTE', 
            'FÉRIAS', '13º SALÁRIO', 'RESCISÃO', 'CAFÉ'
        ]
        
        self.campos_despesa = {}
        
        # Criar grid layout de 4x4 para os campos da despesa
        # Coluna 0 e 1: Labels e campos da esquerda
        # Coluna 2 e 3: Labels e campos da direita
        
        # ===== LADO ESQUERDO (valores numéricos) =====

        # Tipo Despesa (row=0)
        ttk.Label(frame_despesa, text="Tipo Despesa (1-6):", font=('Arial', 10)).grid(
            row=0, column=0, padx=5, pady=5, sticky='e')
        vcmd = (frame_despesa.register(self.validar_tipo_despesa), '%P')
        self.campos_despesa['tp_desp'] = ttk.Entry(
            frame_despesa, validate='key', validatecommand=vcmd, font=('Arial', 10), width=10)
        self.campos_despesa['tp_desp'].grid(row=0, column=1, padx=(5, 20), pady=5, sticky='w')
        
        # Valor Unitário (row=1)
        ttk.Label(frame_despesa, text="Valor Unitário:", font=('Arial', 10)).grid(
            row=1, column=0, padx=5, pady=5, sticky='e')
        self.campos_despesa['vr_unit'] = ttk.Entry(frame_despesa, font=('Arial', 10), width=15)
        self.campos_despesa['vr_unit'].grid(row=1, column=1, padx=(5, 20), pady=5, sticky='w')
        
        # Dias (row=2)
        ttk.Label(frame_despesa, text="Dias:", font=('Arial', 10)).grid(
            row=2, column=0, padx=5, pady=5, sticky='e')
        self.campos_despesa['dias'] = ttk.Entry(frame_despesa, font=('Arial', 10), width=8)
        self.campos_despesa['dias'].grid(row=2, column=1, padx=(5, 20), pady=5, sticky='w')
        
        # Valor Total (row=3)
        ttk.Label(frame_despesa, text="Valor Total:", font=('Arial', 10)).grid(
            row=3, column=0, padx=5, pady=5, sticky='e')
        self.campos_despesa['valor'] = ttk.Entry(
            frame_despesa, state='readonly', font=('Arial', 10), width=15)
        self.campos_despesa['valor'].grid(row=3, column=1, padx=(5, 20), pady=5, sticky='w')
        
        # Data Vencimento (row=4) - MOVIDO PARA A ESQUERDA
        ttk.Label(frame_despesa, text="Data Vencimento:", font=('Arial', 10)).grid(
            row=4, column=0, padx=5, pady=5, sticky='e')
        self.campos_despesa['dt_vencto'] = DateEntry(
            frame_despesa,
            format='dd/mm/yyyy',
            locale='pt_BR',
            background='darkblue',
            foreground='white',
            borderwidth=2,
            font=('Arial', 10),
            width=15
        )
        self.campos_despesa['dt_vencto'].grid(row=4, column=1, padx=(5, 20), pady=5, sticky='w')
        self.campos_despesa['dt_vencto'].delete(0, tk.END)  # Inicializa vazio
        
        # ===== LADO DIREITO (texto) =====
        
        # Referência (row=0)
        ttk.Label(frame_despesa, text="Referência:", font=('Arial', 10)).grid(
            row=0, column=2, padx=5, pady=5, sticky='e')
        self.campos_despesa['referencia'] = ttk.Combobox(
            frame_despesa, font=('Arial', 10), width=40)
        self.campos_despesa['referencia']['values'] = self.opcoes_referencia_tipo1
        self.campos_despesa['referencia'].grid(row=0, column=3, padx=5, pady=5, sticky='ew')
        self.campos_despesa['referencia'].bind(
            '<<ComboboxSelected>>', lambda e: self.calcular_valor_total())
        
        # Etapa da Obra (row=1)
        ttk.Label(frame_despesa, text="Etapa da Obra:", font=('Arial', 10)).grid(
            row=1, column=2, padx=5, pady=5, sticky='e')
        
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        
        self.campos_despesa['etapa_obra'] = ComboboxAutocompletar(
            frame_despesa, 
            values=etapas_obra,
            config_key='etapas_obra',
            config_manager=GerenciadorConfiguracoes,
            font=('Arial', 10), 
            width=40, 
            state='normal'  # Mudado de 'readonly' para 'normal'
        )
        self.campos_despesa['etapa_obra'].grid(row=1, column=3, padx=5, pady=5, sticky='ew')

        # Insumo (row=2)
        ttk.Label(frame_despesa, text="Insumo:", font=('Arial', 10)).grid(
            row=2, column=2, padx=5, pady=5, sticky='e')
        
        # Obter lista de insumos das configurações
        insumos = GerenciadorConfiguracoes.get_insumos()
        
        self.campos_despesa['insumo'] = ComboboxAutocompletar(
            frame_despesa, 
            values=insumos,
            config_key='insumos',
            config_manager=GerenciadorConfiguracoes,
            font=('Arial', 10), 
            width=40, 
            state='normal'  # Mudado de 'readonly' para 'normal'
        )
        self.campos_despesa['insumo'].grid(row=2, column=3, padx=5, pady=5, sticky='ew')

        # NF + Checkbox para materiais (row=3)
        ttk.Label(frame_despesa, text="NF:", font=('Arial', 10)).grid(
            row=3, column=2, padx=5, pady=5, sticky='e')

        # Frame para NF e checkbox de materiais
        frame_nf = ttk.Frame(frame_despesa)
        frame_nf.grid(row=3, column=3, padx=5, pady=5, sticky='ew')

        self.campos_despesa['nf'] = ttk.Entry(frame_nf, font=('Arial', 10), width=15)
        self.campos_despesa['nf'].pack(side='left')

        # Checkbox para indicar se há materiais vinculados
        self.tem_materiais_var = tk.BooleanVar()
        self.checkbox_materiais = ttk.Checkbutton(
            frame_nf,
            text="Tem materiais",
            variable=self.tem_materiais_var,
            command=self.handle_checkbox_change
        )
        self.checkbox_materiais.pack(side='left', padx=(10, 0))
                
        # Observação (row=4)
        ttk.Label(frame_despesa, text="Observação:", font=('Arial', 10)).grid(
            row=4, column=2, padx=5, pady=5, sticky='e')
        self.campos_despesa['observacao'] = ttk.Entry(frame_despesa, font=('Arial', 10), width=40)
        self.campos_despesa['observacao'].grid(row=4, column=3, padx=5, pady=5, sticky='ew')

        # Configurar peso da coluna para expandir apenas os campos de referência e observação
        frame_despesa.columnconfigure(3, weight=1)  # Apenas a coluna 3 (campos expansíveis) cresce
        
        # Inserir valor padrão para dias
        self.campos_despesa['dias'].insert(0, "1")
        
        # Bindings
        self.campos_despesa['vr_unit'].bind('<KeyRelease>', self.calcular_valor_total)
        self.campos_despesa['dias'].bind('<KeyRelease>', self.calcular_valor_total)
        self.campos_despesa['tp_desp'].bind('<KeyRelease>', self.verificar_tipo_despesa)
        
        # Configurar a ordem de tab para seguir o fluxo de trabalho natural
        self.campos_despesa['tp_desp'].bind('<Return>', lambda e: self.campos_despesa['referencia'].focus())
        self.campos_despesa['referencia'].bind('<Return>', lambda e: self.campos_despesa['vr_unit'].focus())
        self.campos_despesa['vr_unit'].bind('<Return>', lambda e: self.campos_despesa['dias'].focus())
        self.campos_despesa['dias'].bind('<Return>', lambda e: self.campos_despesa['etapa_obra'].focus())
        self.campos_despesa['etapa_obra'].bind('<Return>', lambda e: self.campos_despesa['insumo'].focus(), add='+')
        self.campos_despesa['insumo'].bind('<Return>', lambda e: self.campos_despesa['nf'].focus(), add='+')
        self.campos_despesa['nf'].bind('<Return>', lambda e: self.campos_despesa['dt_vencto'].focus())
        self.campos_despesa['dt_vencto'].bind('<Return>', lambda e: self.campos_despesa['observacao'].focus())
        
        # Frame para botões de ação
        frame_botoes = ttk.Frame(self.aba_dados)
        frame_botoes.pack(fill='x', padx=10, pady=10, side='bottom')
        
        # Organizar botões com Adicionar em destaque à direita
        ttk.Button(frame_botoes, text="Cancelar", 
                command=self.cancelar_entrada,
                style='Medium.TButton').pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Visualizar Lançamentos", 
                command=self.visualizar_lancamentos,
                style='Medium.TButton').pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Enviar", 
                command=self.enviar_dados,
                style='Medium.TButton').pack(side='left', padx=5)
        
        # Botão Adicionar em destaque (lado direito)
        adicionar_btn = ttk.Button(frame_botoes, text="Adicionar", 
                                command=self.adicionar_dados,
                                style='Medium.TButton')
        adicionar_btn.pack(side='right', padx=5)
        
        # Configurar um estilo especial para o botão Adicionar (opcional)
        style = ttk.Style()
        style.configure('Destaque.TButton', 
                    background='#0056b3',  # Esta propriedade pode não ter efeito em todos os temas
                    font=('Arial', 11, 'bold'))
        adicionar_btn.configure(style='Destaque.TButton')

        # ADICIONAR NO FINAL DO MÉTODO:
        logger.debug("DEBUG: setup_aba_dados executado completamente!")
        logger.debug(f"DEBUG: tem_materiais_var criado: {hasattr(self, 'tem_materiais_var')}")
        logger.debug(f"DEBUG: checkbox_materiais criado: {hasattr(self, 'checkbox_materiais')}")
        
        if hasattr(self, 'checkbox_materiais'):
            try:
                comando = self.checkbox_materiais.cget('command')
                logger.debug(f"DEBUG: Comando do checkbox: {comando}")
            except Exception as e:
                logger.debug(f"DEBUG: Erro ao verificar comando: {e}")

    def calcular_data_rel(self):
        """
        Calcula a data de referência seguindo a regra dos dias 5 e 20
        """
        hoje = datetime.now()
        if 6 <= hoje.day <= 20:
            data_rel = hoje.replace(day=20)
        else:
            if hoje.day > 20:
                data_rel = (hoje + relativedelta(months=1)).replace(day=5)
            else:
                data_rel = hoje.replace(day=5)
        return data_rel

    def visualizar_lancamentos(self):
        """Abre a janela de visualização de lançamentos pendentes"""
        
        # ============================================================
        # FORÇA SINCRONIZAÇÃO ANTES DE ABRIR
        # ============================================================
        self.root.update_idletasks()
        
        # ============================================================
        # LOG DETALHADO - DIAGNÓSTICO
        # ============================================================
        qtd_dados = len(self.dados_para_incluir) if hasattr(self, 'dados_para_incluir') else 0
        logger.info("=" * 60)
        logger.info("📊 ABRINDO VISUALIZADOR DE LANÇAMENTOS")
        logger.info("=" * 60)
        logger.info(f"Cliente atual: {self.cliente_atual if hasattr(self, 'cliente_atual') else 'NÃO DEFINIDO'}")
        logger.info(f"Dados disponíveis: {qtd_dados} lançamento(s)")
        
        if qtd_dados > 0:
            logger.info("📋 Últimos 3 lançamentos:")
            for i, lancamento in enumerate(self.dados_para_incluir[-3:], 1):
                logger.info(f"  {i}. {lancamento.get('nome', 'N/A')} - {lancamento.get('referencia', 'N/A')} - R$ {lancamento.get('valor', '0.00')}")
        else:
            logger.warning("⚠️ NENHUM LANÇAMENTO PENDENTE!")
        
        # ============================================================
        # VERIFICAR SE JÁ EXISTE VISUALIZADOR ABERTO
        # ============================================================
        if hasattr(self, 'visualizador') and self.visualizador and hasattr(self.visualizador, 'janela') and self.visualizador.janela.winfo_exists():
            logger.info("🔄 Visualizador já existe - Atualizando dados e trazendo para frente")
            
            # ATUALIZAR OS DADOS NO VISUALIZADOR EXISTENTE
            self.visualizador.dados_para_incluir = self.dados_para_incluir.copy()
            self.visualizador.atualizar_dados(self.dados_para_incluir)
            
            # Trazer para frente
            self.visualizador.janela.lift()
            self.visualizador.janela.focus_force()
            
            logger.info(f"✅ Visualizador atualizado com {len(self.visualizador.dados_para_incluir)} lançamento(s)")
            logger.info("=" * 60)
            return
        
        # ============================================================
        # CRIAR NOVA INSTÂNCIA DO VISUALIZADOR
        # ============================================================
        logger.info("🆕 Criando novo visualizador")
        
        # FORÇA MAIS UMA SINCRONIZAÇÃO ANTES DE CRIAR
        self.root.update_idletasks()
        
        self.visualizador = VisualizadorLancamentos(self)
        
        # Configurar callback para quando a janela for fechada
        self.visualizador.janela.protocol("WM_DELETE_WINDOW", self.on_visualizador_close)
        
        # ============================================================
        # ATUALIZAR DADOS NO VISUALIZADOR
        # ============================================================
        self.visualizador.dados_para_incluir = self.dados_para_incluir.copy()
        self.visualizador.atualizar_dados(self.dados_para_incluir)
        
        logger.info(f"✅ Visualizador criado com {len(self.visualizador.dados_para_incluir)} lançamento(s)")
        
        # ============================================================
        # VALIDAÇÃO CRÍTICA - GARANTIR SINCRONIZAÇÃO
        # ============================================================
        if len(self.visualizador.dados_para_incluir) != qtd_dados:
            logger.error("❌ ERRO DE SINCRONIZAÇÃO!")
            logger.error(f"   Esperado: {qtd_dados} lançamentos")
            logger.error(f"   Recebido: {len(self.visualizador.dados_para_incluir)} lançamentos")
            logger.error("   Tentando recuperar...")
            
            # FORÇAR CÓPIA NOVAMENTE
            self.visualizador.dados_para_incluir = self.dados_para_incluir.copy()
            self.visualizador.atualizar_dados(self.dados_para_incluir)
            
            logger.info(f"🔄 Após recuperação: {len(self.visualizador.dados_para_incluir)} lançamentos")
        
        # Garantir que a janela fique na frente
        self.visualizador.janela.lift()
        self.visualizador.janela.focus_force()
        
        logger.info("✅ VISUALIZADOR ABERTO COM SUCESSO")
        logger.info("=" * 60)

    def on_visualizador_close(self):
        """Manipula o fechamento da janela do visualizador"""
        # Atualizar dados_para_incluir com os dados mais recentes do visualizador
        if self.visualizador:
            self.dados_para_incluir = self.visualizador.get_dados_atualizados()
            self.visualizador.janela.destroy()
            self.visualizador = None

    def adicionar_botao_gerenciar_lancamentos(self):
        """Adiciona botão para gerenciar lançamentos na aba de fornecedor"""
        frame_gerenciamento = ttk.LabelFrame(self.aba_fornecedor, text="Gerenciamento de Dados")
        frame_gerenciamento.pack(fill='x', padx=10, pady=5)
        
        frame_botoes_ger = ttk.Frame(frame_gerenciamento)
        frame_botoes_ger.pack(fill='x', padx=5, pady=8)
        
        ttk.Button(
            frame_botoes_ger, 
            text="📅 Agenda",
            command=self.abrir_agenda,
            style='Medium.TButton'
        ).pack(side='left', padx=5)
        
        ttk.Button(
            frame_botoes_ger, 
            text="Gerenciar Lançamentos",
            command=self.abrir_gerenciador_lancamentos,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

        ttk.Button(
            frame_botoes_ger, 
            text="📋 Visualizar Lançamentos",
            command=self.visualizar_lancamentos,
            style='Medium.TButton'
        ).pack(side='left', padx=5)

    def abrir_gerenciador_lancamentos(self):
        """Abre o gerenciador de lançamentos"""
        if not hasattr(self, 'gerenciador_lancamentos') or self.gerenciador_lancamentos is None:
            self.gerenciador_lancamentos = GerenciadorLancamentos(self)
        self.gerenciador_lancamentos.abrir_gerenciador()

    def abrir_parcelamento(self):
        """Abre a janela de parcelamento e processa os dados após o fechamento"""
        logger.debug("\nIniciando processo de parcelamento...")
        
        # Verificar se há fornecedor selecionado
        cnpj_cpf = self.campos_fornecedor['cnpj_cpf'].get()
        if not cnpj_cpf:
            logger.debug("Erro: Fornecedor não selecionado")
            custom_messagebox("error", "Erro", "Selecione um fornecedor antes de criar parcelas!")
            return

        logger.debug("\nCapturando dados do fornecedor...")
        dados_fornecedor = {
            'cnpj_cpf': cnpj_cpf,
            'nome': self.campos_fornecedor['nome'].get(),
            'categoria': self.campos_fornecedor['categoria'].get(),
            'dados_bancarios': self.campos_fornecedor['dados_bancarios'].get()
        }
        logger.debug(f"Dados capturados: {dados_fornecedor}")
        
        # Validar se todos os campos do fornecedor estão preenchidos
        if not all(dados_fornecedor.values()):
            logger.debug("Erro: Dados do fornecedor incompletos")
            custom_messagebox("error", "Erro", "Dados do fornecedor incompletos!")
            return

        logger.debug("Abrindo janela de parcelamento...")
        self.gestor_parcelas.abrir_janela_parcelas()
        self.root.wait_window(self.gestor_parcelas.janela_parcelas)

        if hasattr(self.gestor_parcelas, 'parcelas') and self.gestor_parcelas.parcelas:
            logger.debug(f"Processando {len(self.gestor_parcelas.parcelas)} parcelas...")
            
            success = True
            for i, parcela in enumerate(self.gestor_parcelas.parcelas, 1):
                try:
                    logger.debug(f"\nProcessando parcela {i}")
                    
                    # Restaurar dados do fornecedor
                    for campo, valor in dados_fornecedor.items():
                        entry = self.campos_fornecedor[campo]
                        entry.config(state='normal')
                        entry.delete(0, tk.END)
                        entry.insert(0, valor)
                        if campo != 'categoria':
                            entry.config(state='readonly')
                    
                    # Preencher dados da parcela
                    self.data_rel_entry.set_date(datetime.strptime(parcela['data_rel'], '%d/%m/%Y'))
                    
                    self.campos_despesa['tp_desp'].delete(0, tk.END)
                    self.campos_despesa['tp_desp'].insert(0, self.gestor_parcelas.tipo_despesa_valor)
                    self.campos_despesa['nf'].delete(0, tk.END)
                    self.campos_despesa['nf'].insert(0, parcela['nf'])
                    
                    if isinstance(self.campos_despesa['referencia'], ttk.Combobox):
                        self.campos_despesa['referencia'].set(parcela['referencia'])
                    else:
                        self.campos_despesa['referencia'].delete(0, tk.END)
                        self.campos_despesa['referencia'].insert(0, parcela['referencia'])
                    
                    self.campos_despesa['vr_unit'].delete(0, tk.END)
                    self.campos_despesa['vr_unit'].insert(0, f"{parcela['valor']:.2f}")
                    
                    self.campos_despesa['dias'].delete(0, tk.END)
                    self.campos_despesa['dias'].insert(0, '1')
                    
                    self.campos_despesa['valor'].config(state='normal')
                    self.campos_despesa['valor'].delete(0, tk.END)
                    self.campos_despesa['valor'].insert(0, f"{parcela['valor']:.2f}")
                    self.campos_despesa['valor'].config(state='readonly')
                    
                    self.campos_despesa['dt_vencto'].set_date(
                        datetime.strptime(parcela['dt_vencto'], '%d/%m/%Y')
                    )
                    
                    self.campos_despesa['etapa_obra'].delete(0, tk.END)
                    self.campos_despesa['etapa_obra'].insert(0, parcela.get('etapa_obra', ''))

                    self.campos_despesa['insumo'].delete(0, tk.END)
                    self.campos_despesa['insumo'].insert(0, parcela.get('insumo', ''))

                    # Adicionar à lista de dados
                    if not self.adicionar_dados(eh_parcelamento=True):
                        logger.debug(f"Falha ao adicionar parcela {i}")
                        success = False
                        break
                    
                    logger.debug(f"Parcela {i} processada com sucesso")
                    
                except Exception as e:
                    success = False
                    logger.debug(f"Erro ao processar parcela {i}: {str(e)}")
                    custom_messagebox("error", "Erro", f"Erro ao processar parcela {i}: {str(e)}")
                    break
            
            if success:
                custom_messagebox("info", "Sucesso", 
                                  f"Todas as {len(self.gestor_parcelas.parcelas)} parcelas foram processadas!")
                # Calcular a data de referência padrão
                hoje = datetime.now()
                if 6 <= hoje.day <= 20:
                    data_rel = hoje.replace(day=20)
                else:
                    if hoje.day > 20:
                        data_rel = (hoje + relativedelta(months=1)).replace(day=5)
                    else:
                        data_rel = hoje.replace(day=5)
                
                # Restaurar a data de referência padrão
                self.data_rel_entry.set_date(data_rel)
                
                self.limpar_campos_despesa()
                self.notebook.select(1)  # Volta para aba fornecedor
            else:
                custom_messagebox("error", "Erro", "Houve um erro no processamento das parcelas.")
        else:
            logger.debug("Nenhuma parcela para processar")

    def atualizar_campo_referencia(self, event=None):
        """Atualiza o campo de referência baseado no tipo de despesa"""
        tp_desp = self.campos_despesa['tp_desp'].get().strip()
    
        try:
            if tp_desp == '1':
                # Redefine as opções e configura como readonly
                self.campos_despesa['referencia']['values'] = self.opcoes_referencia_tipo1
                self.campos_despesa['referencia'].config(state='readonly')
                # Seleciona o primeiro item como padrão
                if self.opcoes_referencia_tipo1:
                    self.campos_despesa['referencia'].set(self.opcoes_referencia_tipo1[0])
            else:
                # Para outros tipos, limpa a seleção e permite digitação
                self.campos_despesa['referencia'].set('')
                self.campos_despesa['referencia']['values'] = []
                self.campos_despesa['referencia'].config(state='normal')
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar campo referência: {str(e)}")

    def atualizar_dados_bancarios(self, event=None):
        """Atualiza os dados bancários baseado no tipo de despesa"""
        tp_desp = self.campos_despesa['tp_desp'].get().strip()
        cnpj_cpf = self.campos_fornecedor['cnpj_cpf'].get().strip()

        if not cnpj_cpf:  # Se não houver fornecedor selecionado
            return
        
        fornecedor_completo = self.buscar_fornecedor_completo(cnpj_cpf)
        if not fornecedor_completo:
            return
        
        logger.debug(f"DEBUG atualizar_dados_bancarios:")
        logger.debug(f"  forma_pagamento: '{self.forma_pagamento_var.get()}'")
        logger.debug(f"  chave_pix: '{fornecedor_completo.get('chave_pix', 'KEY NOT FOUND')}'")
        logger.debug(f"  dados_bancarios: '{fornecedor_completo.get('dados_bancarios', 'KEY NOT FOUND')}'")

        self.campos_fornecedor['dados_bancarios'].config(state='normal')
        self.campos_fornecedor['dados_bancarios'].delete(0, tk.END)
        
        # PRIORIDADE: verificar forma de pagamento PRIMEIRO
        forma_pagamento = self.forma_pagamento_var.get()
        
        if forma_pagamento == "DINHEIRO":
            # Para DINHEIRO, deixar o campo vazio
            dados_bancarios = ""
        else:
            # Para PIX ou TED, verificar se há dados na planilha
            dados_bancarios_planilha = fornecedor_completo.get('dados_bancarios', '').strip()
            
            if dados_bancarios_planilha:
                # Coluna O já tem os dados - usar diretamente!
                dados_bancarios = dados_bancarios_planilha
            else:
                # Construir dados bancários baseado na forma de pagamento
                if forma_pagamento == "PIX" and fornecedor_completo.get('chave_pix'):
                    dados_bancarios = f"PIX: {fornecedor_completo['chave_pix']}"
                else:
                    # Estrutura para TED
                    dados_ted = []
                    if fornecedor_completo.get('banco'): dados_ted.append(str(fornecedor_completo['banco']))
                    if fornecedor_completo.get('op'): dados_ted.append(str(fornecedor_completo['op']))
                    if fornecedor_completo.get('agencia'): dados_ted.append(str(fornecedor_completo['agencia']))
                    if fornecedor_completo.get('conta'): dados_ted.append(str(fornecedor_completo['conta']))
                    # SEMPRE adicionar o CNPJ/CPF para TED
                    dados_ted.append(str(fornecedor_completo['cnpj_cpf']))
                    
                    dados_bancarios = ' - '.join(filter(None, dados_ted))

                if dados_bancarios.strip() in ['', ' - ']:
                    dados_bancarios = ''
            
        self.campos_fornecedor['dados_bancarios'].insert(0, dados_bancarios)
        self.campos_fornecedor['dados_bancarios'].config(state='readonly')
 
    def cancelar_entrada(self):
        """Cancela a entrada de dados atual e retorna à aba fornecedor"""
        if any(self.campos_despesa[campo].get() for campo in ['tp_desp', 'referencia', 'vr_unit']):
            if custom_messagebox("yesno", "Confirmação", "Deseja descartar os dados atuais?"):
                self.limpar_campos_despesa()
                self.notebook.select(1)  # Volta para aba fornecedor
        else:
            self.notebook.select(1)  # Volta para aba fornecedor
    
    def abrir_gestao_locacoes(self):
        """Abre o módulo de gestão de locações"""
        if not self.cliente_atual:
            custom_messagebox("warning", "Aviso", "Selecione um cliente primeiro!")
            return
        
        try:
            gerenciador = GerenciadorLocacoes(self)
            gerenciador.abrir_gestao_locacoes()
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir gestão de locações: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def abrir_agenda(self):
        """Abre o gerenciador de agenda"""
        try:
            if not self.cliente_atual:
                custom_messagebox("error", "Erro", "Selecione um cliente primeiro!")
                return
            
            # Importar e instanciar o gerenciador de agenda apenas quando necessário
            if not hasattr(self, 'gerenciador_agenda') or self.gerenciador_agenda is None:
                self.gerenciador_agenda = GerenciadorAgenda(self)
            
            self.gerenciador_agenda.abrir_agenda()
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir agenda: {str(e)}")
            logger.debug(f"DEBUG: Erro ao abrir agenda: {str(e)}")

    def salvar_confirmacao_direta(self, dados_lancamento):
        """✅ VERSÃO OTIMIZADA - Única abertura de arquivo"""
        try:
            # Validação rápida
            campos_obrigatorios = ['nome', 'cnpj_cpf', 'valor', 'data_rel', 'dt_vencto']
            
            for campo in campos_obrigatorios:
                if not dados_lancamento.get(campo):
                    custom_messagebox("error", "Erro", f"{campo} obrigatório!")
                    return False
            
            try:
                valor_float = float(dados_lancamento['valor'])
                if valor_float <= 0:
                    custom_messagebox("error", "Erro", "Valor deve ser maior que zero!")
                    return False
            except (ValueError, TypeError):
                custom_messagebox("error", "Erro", "Valor inválido!")
                return False
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.cliente_atual}.xlsx"
            
            from openpyxl import load_workbook
            from datetime import datetime
            
            # ✅ ÚNICA abertura de arquivo
            wb = load_workbook(arquivo_cliente)
            ws = wb["Dados"]
            
            # ✅ Verificação de duplicidade OTIMIZADA (últimas 50 linhas apenas)
            max_row = ws.max_row
            inicio_busca = max(2, max_row - 50)  # Era 100, agora 50
            
            duplicata_encontrada = False
            
            for row in ws.iter_rows(min_row=inicio_busca, max_row=max_row, values_only=True):
                try:
                    if (row[3] and str(row[3]).upper() == dados_lancamento['nome'].upper() and
                        row[4] and str(row[4]).upper() == dados_lancamento['referencia'].upper() and
                        row[8] and abs(float(row[8]) - valor_float) < 0.01):
                        
                        duplicata_encontrada = True
                        break
                except:
                    continue
            
            if duplicata_encontrada:
                wb.close()
                resposta = custom_messagebox(
                    "yesno",
                    "⚠️ Duplicata",
                    "Já existe lançamento similar.\n\nProsseguir mesmo assim?"
                )
                
                if not resposta:
                    return False
                
                # Reabrir arquivo (usuário confirmou)
                wb = load_workbook(arquivo_cliente)
                ws = wb["Dados"]
            
            # ✅ Inserção otimizada
            proxima_linha = ws.max_row + 1
            
            # Preparar data_rel
            data_rel_obj = dados_lancamento['data_rel']
            if isinstance(data_rel_obj, str):
                data_rel_obj = datetime.strptime(data_rel_obj, '%d/%m/%Y')
            
            # ✅ Inserir valores diretamente (sem múltiplas chamadas .cell())
            ws.append([
                data_rel_obj,  # A - DATA_REL
                int(dados_lancamento.get('tp_desp', 3)),  # B - TP_DESP
                dados_lancamento['cnpj_cpf'],  # C - CNPJ_CPF
                dados_lancamento['nome'].upper(),  # D - NOME
                dados_lancamento['referencia'].upper(),  # E - REFERÊNCIA
                dados_lancamento.get('nf', '').upper(),  # F - NF
                dados_lancamento.get('vr_unit', valor_float),  # G - VR_UNIT
                dados_lancamento.get('dias', 1),  # H - DIAS
                valor_float,  # I - VALOR
                dados_lancamento['dt_vencto'],  # J - DT_VENCTO
                dados_lancamento.get('categoria', 'MO'),  # K - CATEGORIA
                dados_lancamento.get('dados_bancarios', ''),  # L - DADOS_BANCARIOS
                dados_lancamento.get('observacao', '').upper(),  # M - OBSERVAÇÃO
                'ATIVO',  # N - STATUS
                self.obter_proximo_id_sequencial(ws),  # O - ID_LANCAMENTO
                '',  # P - (vazio)
                dados_lancamento.get('etapa_obra', ''),  # Q - ETAPA_OBRA
                dados_lancamento.get('insumo', '')  # R - INSUMO
            ])
            
            # ✅ Aplicar formatações na última linha
            ultima_linha = ws.max_row
            ws[f'A{ultima_linha}'].number_format = 'DD/MM/YYYY'
            ws[f'B{ultima_linha}'].number_format = '0'
            ws[f'G{ultima_linha}'].number_format = '#,##0.00'
            ws[f'H{ultima_linha}'].number_format = '0.0'
            ws[f'I{ultima_linha}'].number_format = '#,##0.00'
            ws[f'J{ultima_linha}'].number_format = 'DD/MM/YYYY'
            
            novo_id = ws[f'O{ultima_linha}'].value
            
            logger.info(f"✅ Lançamento ID {novo_id} inserido na linha {ultima_linha}")
            
            # ✅ Salvar e fechar (1x apenas)
            try:
                salvar_planilha_segura(wb, arquivo_cliente)
                logger.info("✅ Arquivo salvo")
            except PermissionError:
                wb.close()
                custom_messagebox("error", "Erro", 
                    f"Planilha '{self.cliente_atual}.xlsx' está aberta.\n\nFeche-a e tente novamente.")
                return False
            finally:
                wb.close()
            
            return {
                'sucesso': True,
                'id_lancamento': novo_id,
                'linha': ultima_linha
            }
            
        except Exception as e:
            logger.error(f"❌ Erro: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao salvar: {str(e)}")
            return False
    
    def calcular_valor_total(self, event=None):
        """Calcula o valor total baseado no tipo de despesa"""
        try:
            # Pegar valor unitário
            vr_unit_str = self.campos_despesa['vr_unit'].get().strip()
            if not vr_unit_str:
                self.campos_despesa['valor'].config(state='normal')
                self.campos_despesa['valor'].delete(0, tk.END)
                self.campos_despesa['valor'].config(state='readonly')
                return
                
            vr_unit = float(vr_unit_str.replace(',', '.'))
            
            # Pegar tipo de despesa
            tp_desp = self.campos_despesa['tp_desp'].get()
            
            # Calcular com base no tipo
            if tp_desp == '1':  # Tipo que usa dias
                dias_str = self.campos_despesa['dias'].get().strip()
                dias = float(dias_str.replace(',', '.')) if dias_str else 1
                valor_total = vr_unit * dias
            else:
                valor_total = vr_unit
                
            # Atualizar campo de valor
            self.campos_despesa['valor'].config(state='normal')
            self.campos_despesa['valor'].delete(0, tk.END)
            self.campos_despesa['valor'].insert(0, f"{valor_total:.2f}")
            self.campos_despesa['valor'].config(state='readonly')
            
        except ValueError:
            # Em caso de erro, limpa o campo valor
            self.campos_despesa['valor'].config(state='normal')
            self.campos_despesa['valor'].delete(0, tk.END)
            self.campos_despesa['valor'].config(state='readonly')

    def verificar_tipo_despesa(self, event=None):
        """Verifica o tipo de despesa e ajusta campos conforme necessário"""
        tp_desp = self.campos_despesa['tp_desp'].get().strip()
        
        # Salvar a referência atual antes de qualquer modificação
        referencia_atual = ""
        if isinstance(self.campos_despesa['referencia'], ttk.Combobox):
            referencia_atual = self.campos_despesa['referencia'].get()
        else:
            referencia_atual = self.campos_despesa['referencia'].get() 

        if not tp_desp.isdigit():
            self.campos_despesa['tp_desp'].delete(0, tk.END)
            return

        tp_desp_num = int(tp_desp)
        if not (1 <= tp_desp_num <= 6):
            self.campos_despesa['tp_desp'].delete(0, tk.END)
            return
            
        # Configura o campo dias
        if tp_desp == '1':
            self.campos_despesa['dias'].config(state='normal')
        else:
            self.campos_despesa['dias'].config(state='disabled')
            self.campos_despesa['dias'].delete(0, tk.END)
            self.campos_despesa['dias'].insert(0, '1')

        # Configura o campo nf
        if tp_desp != '1':
            self.campos_despesa['nf'].config(state='normal')
        else:
            self.campos_despesa['nf'].config(state='disabled')
            self.campos_despesa['nf'].delete(0, tk.END)
            
        # Atualiza o campo referência
        self.atualizar_campo_referencia(event)
        
        # NOVO: Restaurar o valor da referência se for uma especificação personalizada
        # e não uma das opções padrão do tipo 1
        if tp_desp != '1' and referencia_atual and referencia_atual not in self.opcoes_referencia_tipo1:
            if isinstance(self.campos_despesa['referencia'], ttk.Combobox):
                self.campos_despesa['referencia'].delete(0, tk.END)
                self.campos_despesa['referencia'].insert(0, referencia_atual)
            else:
                self.campos_despesa['referencia'].delete(0, tk.END)
                self.campos_despesa['referencia'].insert(0, referencia_atual)

        # Move para o campo referência
        self.campos_despesa['referencia'].focus()
        
    def adicionar_dados(self, eh_parcelamento=False):
        """Adiciona dados à lista temporária e retorna à aba fornecedor"""
        # logger = system_logger.get_logger()
        logger.info(f"Iniciando adição de dados - Cliente: {self.cliente_atual}")

        if not self.validar_campos():
            logger.warning(f"Falha na validação dos campos")
            return False
        
        try:
            # Coleta do primeiro conjunto de dados
            vr_unit_str = self.campos_despesa['vr_unit'].get().strip()
            if not vr_unit_str:
                custom_messagebox("error", "Erro", "Valor unitário é obrigatório!")
                return False
            vr_unit = float(vr_unit_str.replace(',', '.'))
        
            valor_str = self.campos_despesa['valor'].get().strip()
            if not valor_str:
                custom_messagebox("error", "Erro", "Valor total não foi calculado!")
                return False
            valor = float(valor_str.replace(',', '.'))

            # Coletar dados do lançamento
            dados = {
                'data': self.data_rel_entry.get(),
                'cnpj_cpf': self.campos_fornecedor['cnpj_cpf'].get(),
                'nome': self.campos_fornecedor['nome'].get(),
                'categoria': self.campos_fornecedor['categoria'].get().upper(),
                'tp_desp': self.campos_despesa['tp_desp'].get(),
                'referencia': self.campos_despesa['referencia'].get().upper(),
                'etapa_obra': self.campos_despesa['etapa_obra'].get(),
                'insumo': self.campos_despesa['insumo'].get(), 
                'nf': self.campos_despesa['nf'].get().upper(),
                'vr_unit': f"{vr_unit:.2f}",
                'dias': float(self.campos_despesa['dias'].get().replace(',', '.')) if self.campos_despesa['dias'].get() else 1,
                'valor': f"{valor:.2f}",
                'dt_vencto': self.campos_despesa['dt_vencto'].get(),
                'dados_bancarios': self.campos_fornecedor['dados_bancarios'].get(),
                'observacao': self.campos_despesa['observacao'].get().upper(),
                'forma_pagamento': self.forma_pagamento_var.get()
            }
            self.dados_para_incluir.append(dados)

            # FORÇA O PROCESSAMENTO IMEDIATO DOS EVENTOS PENDENTES
            self.root.update_idletasks()
            
            logger.info(f"✅ Dados adicionados - Total: {len(self.dados_para_incluir)}")

            # Verificar se é um lançamento de TRANSPORTE e criar lançamento automático de CAFÉ
            if dados['tp_desp'] == '1' and dados['referencia'] == 'TRANSPORTE':
                try:
                    # Buscar valor do café nas configurações
                    from src.configuracoes_sistema import GerenciadorConfiguracoes
                    config = GerenciadorConfiguracoes.carregar_configuracoes()
                    
                    if config and 'cafe' in config and 'valor_atual' in config['cafe']:
                        vr_unit_cafe = float(config['cafe']['valor_atual'])
                    else:
                        vr_unit_cafe = 4.0  # Valor padrão caso não encontre configuração
                        
                    dias_cafe = int(dados['dias'])
                    valor_cafe = vr_unit_cafe * dias_cafe
                    
                    # Criar dados do lançamento do CAFÉ
                    dados_cafe = dados.copy()
                    dados_cafe.update({
                        'referencia': 'CAFÉ',
                        'vr_unit': f"{vr_unit_cafe:.2f}",
                        'valor': f"{valor_cafe:.2f}"
                    })
                    self.dados_para_incluir.append(dados_cafe)
                    custom_messagebox("info", "Informação", 
                        f"Lançamento de CAFÉ adicionado automaticamente com valor de R$ {vr_unit_cafe:.2f} por dia!")
                except Exception as e:
                    custom_messagebox("warning", "Aviso", 
                        f"Erro ao processar lançamento automático do café: {str(e)}\n"
                        "O lançamento principal foi salvo, mas o café não foi gerado.")

            # Só limpa os campos e mostra mensagem se não for parcelamento
            if not eh_parcelamento:
                self.limpar_campos_despesa()
                
                # Limpar campos do fornecedor
                for campo, entry in self.campos_fornecedor.items():
                    entry.config(state='normal')
                    entry.delete(0, tk.END)
                    if campo != 'categoria':
                        entry.config(state='readonly')
                
                # Desmarcar checkbox de materiais
                self.tem_materiais_var.set(False)

                self.root.update_idletasks()
                
                custom_messagebox("info", "Sucesso", "Dados adicionados com sucesso!")
                
                # Voltar para a aba fornecedor
                self.notebook.select(1)
                self.tree_fornecedores.selection_remove(self.tree_fornecedores.selection())
                self.busca_entry.delete(0, tk.END)
            
            logger.info(f"Dados adicionados com sucesso - Cliente: {self.cliente_atual}, Total: {len(self.dados_para_incluir)}")
            return True
            
        except ValueError as e:
            logger.error(f"Erro ao processar valores: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao processar valores: {str(e)}")
            return False

    def handle_checkbox_change(self):
        """
        Versão modificada que inclui sugestão de importar NFe quando materiais são marcados
        """
        logger.debug(f"DEBUG: handle_checkbox_change chamado. tem_materiais_var: {self.tem_materiais_var.get()}")
        
        if self.tem_materiais_var.get():
            # Checkbox foi marcado
            logger.debug("DEBUG: Checkbox marcado - materiais vinculados")
            
            # Perguntar se usuário quer importar NFe
            resposta = messagebox.askyesno(
                "Importar NFe", 
                "🏗️ MATERIAIS VINCULADOS!\n\n"
                "Esta despesa possui materiais associados.\n\n"
                "💡 Dica: Você pode importar os materiais diretamente de uma NFe "
                "para o controle de obra, incluindo:\n"
                "• Descrições detalhadas\n"
                "• Quantidades e valores\n"
                "• Dados do fornecedor\n"
                "• Classificação automática\n\n"
                "Deseja importar materiais de uma NFe agora?"
            )
            
            if resposta:
                self.abrir_importacao_nfe_completa()
        else:
            # Checkbox foi desmarcado
            logger.debug("DEBUG: Checkbox desmarcado - sem materiais")

    def abrir_importacao_nfe_completa(self):
        """
        Método para abrir importação NFe completa
        """
        try:
            # Verificar se cliente está selecionado
            if not self.cliente_atual:
                messagebox.showerror("Erro", "Selecione um cliente antes de importar NFe!")
                return
            
            # Abrir seletor de arquivo XML
            from tkinter import filedialog
            arquivo_xml = filedialog.askopenfilename(
                title="Selecionar XML da NFe",
                filetypes=[
                    ("Arquivos XML", "*.xml"),
                    ("Todos os arquivos", "*.*")
                ]
            )
            
            if arquivo_xml:
                # Processar XML usando o sistema híbrido existente
                if hasattr(self, 'processador_nfe'):
                    try:
                        dados_nfe = self.processador_nfe.processar_xml_nfe(arquivo_xml)
                        
                        if dados_nfe:
                            # Abrir integrador completo
                            from src.nfe.integrador_nfe_sistema import IntegradorNFeFinanceiroMateriais
                            integrador = IntegradorNFeFinanceiroMateriais(self)
                            integrador.criar_interface_integracao_nfe(dados_nfe)
                        else:
                            messagebox.showerror("Erro", "Erro ao processar XML da NFe!")
                            
                    except Exception as e:
                        messagebox.showerror("Erro", f"Erro ao processar XML:\n{str(e)}")
                else:
                    messagebox.showerror("Erro", "Sistema NFe não inicializado!")
                    
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao importar NFe:\n{str(e)}")

    def validar_campos(self):
        """Valida os campos antes de adicionar/enviar dados"""
        # Validar data
        data_rel_str = self.data_rel_entry.get()
        if not data_rel_str:
            custom_messagebox("error", "Erro", "Data de referência é obrigatória!")
            return False

        # ✅ NOVO: garantir dia 5 ou 20 usando a validação já existente em utils.py
        try:
            from src.config.utils import validar_data_quinzena
            data_rel_obj = datetime.strptime(data_rel_str, '%d/%m/%Y')
            data_ajustada, msg = validar_data_quinzena(data_rel_obj)

            if msg:  # a data não era dia 5 nem 20
                resposta = custom_messagebox(
                    "yesno", "Data de Referência Divergente",
                    f"A Data do Relatório está em {data_rel_str}, mas o esperado "
                    f"é dia 5 ou 20.\n\n{msg}\n\nDeseja aplicar a correção?"
                )
                if not resposta:
                    return False  # usuário cancelou — bloqueia o Adicionar/Enviar

                self.data_rel_entry.set_date(data_ajustada)
                logger.warning(
                    f"validar_campos: DATA_REL corrigida automaticamente de "
                    f"{data_rel_str} para {data_ajustada.strftime('%d/%m/%Y')}"
                )
        except ValueError:
            custom_messagebox("error", "Erro", "Data de referência inválida! Use dd/mm/aaaa")
            return False

        # Validar fornecedor
        if not self.campos_fornecedor['cnpj_cpf'].get():
            custom_messagebox("error", "Erro", "Selecione um fornecedor!")
            return False


        # Validar tipo de despesa
        tp_desp = self.campos_despesa['tp_desp'].get().strip()
        if not tp_desp or not tp_desp.isdigit() or not (1 <= int(tp_desp) <= 7):
            custom_messagebox("error", "Erro", "Tipo de despesa deve ser um número entre 1 e 7!")
            return False

        # Validar valor unitário
        vr_unit = self.campos_despesa['vr_unit'].get().strip()
        if not vr_unit:
            custom_messagebox("error", "Erro", "Valor unitário é obrigatório!")
            return False
        try:
            float(vr_unit.replace(',', '.'))
        except ValueError:
            custom_messagebox("error", "Erro", "Valor unitário inválido!")
            return False

        # Validar dias para tipo de despesa 1
        if tp_desp == '1':
            dias = self.campos_despesa['dias'].get().strip()
            if not dias:
                custom_messagebox("error", "Erro", "Quantidade de dias é obrigatória para tipo 1!")
                return False
            try:
                dias_float = float(dias.replace(',', '.'))
                if dias_float <= 0:
                    custom_messagebox("error", "Erro", "Quantidade de dias deve ser maior que zero!")
                    return False
            except ValueError:
                custom_messagebox("error", "Erro", "Quantidade de dias inválida!")
                return False

        # Validar referência
        if not self.campos_despesa['referencia'].get().strip():
            custom_messagebox("error", "Erro", "Referência é obrigatória!")
            return False

        # Validar data de vencimento
        if not self.campos_despesa['dt_vencto'].get():
            custom_messagebox("error", "Erro", "Data de vencimento é obrigatória!")
            return False

        return True

    def importar_folha_rh(self):
        """Inicia o processo de importação de dados da folha de RH"""
        # Verificar se um cliente está selecionado
        if not self.cliente_atual:
            if custom_messagebox("yesno", 
                "Importação RH",
                "Nenhum cliente está selecionado. A importação será feita baseada nos dados da planilha RH.\n\n"
                "Deseja continuar?"
            ):
                importador = ImportadorRH(self)
                importador.importar_dados()
        else:
            importador = ImportadorRH(self)
            importador.importar_dados()

    def importar_transporte_cafe(self):
        """Chama a importação de transporte através do ImportadorRH"""
        try:
            importador = ImportadorRH(self)
            importador.importar_transporte_cafe()
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir importador de transporte: {str(e)}")

    def importar_diarias(self):
        """Chama a importação de diárias através do ImportadorRH"""
        try:
            importador = ImportadorRH(self)
            importador.importar_diarias()
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir importador de diárias: {str(e)}")

    def importar_documentos_email(self):
        """Importa NF-e/NFS-e/boletos lidos do Gmail (triagem em Documentos_Recebidos.xlsx)"""
        try:
            from src.email_fiscal.importar_para_sistema import abrir_importacao_email
        except ImportError:
            from email_fiscal.importar_para_sistema import abrir_importacao_email
        abrir_importacao_email(self)
        
    def importar_medicoes(self):
        """
        Importa medições de contratos a partir de relatório Excel.
        
        Este método:
        1. Valida cliente selecionado
        2. Chama o ImportadorMedicoes
        3. Trata erros
        """
        try:
            # Verificar se importador está disponível
            if self.importador_medicoes is None:
                custom_messagebox(
                    "error",
                    "Erro", 
                    "❌ Sistema de importação de medições não está disponível.\n\n"
                    "Verifique:\n"
                    "• Permissões de acesso aos arquivos\n"
                    "• Se todos os arquivos necessários estão presentes\n\n"
                    "Consulte o log para mais detalhes."
                )
                return
            
            # Prosseguir com a importação
            self.importador_medicoes.importar_medicoes()
            
        except Exception as e:
            custom_messagebox("error", 
                "Erro", 
                f"Erro ao importar medições:\n\n{str(e)}"
            )
            logger.error(f"Erro na importação de medições: {str(e)}")

    def limpar_campos_despesa(self):
        """Limpa todos os campos da despesa"""
        campos_para_limpar = ['tp_desp', 'referencia', 'etapa_obra', 'insumo', 'nf', 'vr_unit', 
                            'dias', 'valor', 'observacao']
        
        for campo in campos_para_limpar:
            if campo in self.campos_despesa:
                widget = self.campos_despesa[campo]
                
                # Tratamento especial para campo 'valor' (Entry readonly)
                if campo == 'valor':
                    widget.config(state='normal')
                    widget.delete(0, tk.END)
                    widget.config(state='readonly')
                
                # Tratamento para Combobox readonly (etapa_obra, insumo)
                elif isinstance(widget, ttk.Combobox):
                    widget.set('')
                
                # Tratamento para Entry normais
                elif hasattr(widget, 'delete'):
                    widget.delete(0, tk.END)
        
        # Reinicializar valor padrão para dias
        if 'dias' in self.campos_despesa:
            self.campos_despesa['dias'].insert(0, "1")
        
        # Limpar data de vencimento
        if 'dt_vencto' in self.campos_despesa:
            self.campos_despesa['dt_vencto'].delete(0, tk.END)

        # Restaurar forma de pagamento para PIX (padrão)
        self.forma_pagamento_var.set("PIX")
        self.atualizar_dados_bancarios()

    def verificar_duplicidade_antes_salvar(self, sheet, dados):
        """
        Verifica se um lançamento similar já existe na planilha usando critérios inteligentes
        VERSÃO CORRIGIDA - Menos restritiva para evitar falsos positivos
        """
        try:
            logger.info("🔍 EXECUTANDO VERIFICAÇÃO DE DUPLICIDADE!")
            logger.debug(f"🔍 Dados recebidos: {dados}")
            
            # Normalizar dados para comparação
            nome_novo = str(dados['nome']).strip().upper()
            referencia_nova = str(dados['referencia']).strip().upper()
            nf_nova = str(dados.get('nf', '')).strip().upper()
            dt_vencto_nova = str(dados['dt_vencto']).strip()
            cnpj_novo = str(dados.get('cnpj_cpf', '')).strip()
            
            try:
                valor_novo = float(str(dados['valor']).replace(',', '.'))
            except (ValueError, TypeError):
                logger.error(f"Erro ao converter valor: {dados['valor']}")
                return False
            
            logger.info(f"=== VERIFICANDO DUPLICIDADE ===")
            logger.info(f"Dados: {nome_novo} | {referencia_nova} | NF: {nf_nova} | R$ {valor_novo:.2f} | {dt_vencto_nova}")
            
            for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                if not row[0]:
                    continue

                # Verificar status - pular se excluído
                status = row[13] if len(row) > 13 else 'ATIVO'
                if status == 'EXCLUIDO':
                    continue
                    
                # Normalizar dados da planilha
                nome_planilha = str(row[3] or '').strip().upper()
                referencia_planilha = str(row[4] or '').strip().upper()
                nf_planilha = str(row[5] or '').strip().upper()
                cnpj_planilha = str(row[2] or '').strip()
                
                # Data de vencimento
                dt_vencto_planilha = ""
                if row[9]:
                    if isinstance(row[9], datetime):
                        dt_vencto_planilha = row[9].strftime('%d/%m/%Y')
                    else:
                        dt_vencto_planilha = str(row[9]).strip()
                
                # Valor
                try:
                    valor_planilha = float(str(row[8] or 0).replace(',', '.'))
                    diferenca_valor = abs(valor_planilha - valor_novo)
                except (ValueError, TypeError):
                    continue
                
                # =============================================================
                # CRITÉRIO 1: DUPLICATA POR NF
                # Âncora: NF (normalizada) + nome + vencimento.
                # Valor e Referência avaliados por proximidade.
                # =============================================================
                if (nf_nova and nf_planilha and
                    nf_nova == nf_planilha and
                    nome_planilha == nome_novo and
                    dt_vencto_planilha == dt_vencto_nova):

                    valor_identico = diferenca_valor < 0.01
                    referencia_identica = (referencia_planilha == referencia_nova)
                    similaridade_ref = self._calcular_similaridade_simples(referencia_nova, referencia_planilha)

                    if valor_identico and referencia_identica:
                        logger.warning(f"🚨 DUPLICATA EXATA (NF)! Linha: {row_num}")
                        return True
                    if valor_identico and similaridade_ref >= 0.85:
                        logger.warning(f"🚨 DUPLICATA POR NF (referência similar, {similaridade_ref:.2f})! Linha: {row_num}")
                        return True
                    if not valor_identico:
                        logger.warning(f"🚨 POSSÍVEL DUPLICATA (NF/nome/vencimento OK, VALOR diverge)! Linha: {row_num} "
                                        f"| R$ {valor_planilha:.2f} vs R$ {valor_novo:.2f}")
                        return True

                # =============================================================
                # CRITÉRIO 2: MESMO FORNECEDOR + VENCIMENTO
                # Cobre lançamentos sem NF confiável (vazio ou placeholder
                # normalizado) — MO, medições, encargos, fretes, PIX sem NF.
                # =============================================================
                if (nome_planilha == nome_novo and
                    dt_vencto_planilha == dt_vencto_nova):

                    valor_identico = diferenca_valor < 0.01
                    referencia_identica = (referencia_planilha == referencia_nova)
                    similaridade_ref = self._calcular_similaridade_simples(referencia_nova, referencia_planilha)
                    referencia_proxima = referencia_identica or similaridade_ref >= 0.85

                    if nf_nova and nf_planilha and nf_nova != nf_planilha:
                        logger.debug(f"   ✅ NFs reais e diferentes - NÃO é duplicata (Critério 2)")
                    elif valor_identico and referencia_proxima:
                        logger.warning(f"🚨 DUPLICATA (Critério 2 - fornecedor/vencimento)! Linha: {row_num}")
                        return True
                    elif not valor_identico and referencia_proxima:
                        logger.warning(f"🚨 POSSÍVEL DUPLICATA (Critério 2 - referência bate, valor diverge)! Linha: {row_num}")
                        return True

                # =============================================================
                # CRITÉRIO 3: MESMO DOCUMENTO, VENCIMENTO DIVERGENTE
                # NF + nome + referência + valor idênticos, vencimento diferente
                # — cobre erro de digitação na data (caso real já encontrado).
                # =============================================================
                if (nf_nova and nf_planilha and
                    nf_nova == nf_planilha and
                    nome_planilha == nome_novo and
                    referencia_planilha == referencia_nova and
                    diferenca_valor < 0.01 and
                    dt_vencto_planilha != dt_vencto_nova):

                    logger.warning(f"🚨 POSSÍVEL DUPLICATA (Critério 3 - NF/nome/referência/valor OK, VENCIMENTO diverge)! "
                                    f"Linha: {row_num} | {dt_vencto_planilha} vs {dt_vencto_nova}")
                    return True
            
            logger.info(f"✅ Nenhuma duplicata para: {nome_novo} - {referencia_nova}")
            return False
            
        except Exception as e:
            logger.error(f"❌ ERRO na verificação: {str(e)}")
            logger.error(traceback.format_exc())
            return False

    def _calcular_similaridade_simples(self, texto1, texto2):
        """Similaridade por sequência de caracteres (Ratcliff/Obershelp)."""
        if not texto1 or not texto2:
            return 0.0
        t1 = ' '.join(texto1.lower().split())
        t2 = ' '.join(texto2.lower().split())
        return SequenceMatcher(None, t1, t2).ratio()


    # Correção para o método enviar_dados() - SistemaEntradaDados.py

    def enviar_dados(self):
        """
        Versão OTIMIZADA com gestão inteligente de duplicatas
        - Remove automaticamente duplicatas da visualização
        - Mantém apenas registros únicos pendentes
        - Protege contra envios para cliente errado
        """
       
        logger.info(f"Iniciando envio de dados - Cliente: {self.cliente_atual}, Registros: {len(self.dados_para_incluir) if self.dados_para_incluir else 0}")
        
        # Desabilitar botão para evitar múltiplos cliques
        btn_enviar = None
        for aba in [self.aba_dados, self.aba_fornecedor]:
            for child in aba.winfo_children():
                if isinstance(child, ttk.Frame):
                    for widget in child.winfo_children():
                        if isinstance(widget, ttk.Button) and widget['text'] == "Enviar":
                            btn_enviar = widget
                            break
        
        if btn_enviar:
            btn_enviar.config(state='disabled')
        
        datas_recalculadas = []
        
        try:
            # ==========================================
            # VALIDAÇÃO 1: Cliente selecionado
            # ==========================================
            if not self.cliente_atual:
                custom_messagebox("error", "Erro", "Selecione um cliente!")
                return
            
            # ==========================================
            # VALIDAÇÃO 2: Verificar NF com materiais
            # ==========================================
            nf_numero = self.campos_despesa['nf'].get().strip()
            tem_materiais_marcado = self.tem_materiais_var.get()
            
            if nf_numero and tem_materiais_marcado:
                if not self.verificar_nf_ja_processada(nf_numero):
                    resposta = custom_messagebox(
                        "yesno",
                        "NFe Detectada",
                        f"NOTA FISCAL DETECTADA!\n\n"
                        f"NF: {nf_numero}\n"
                        f"Materiais marcados como vinculados\n\n"
                        f"SUGESTÃO: Para melhor controle, importe os materiais "
                        f"diretamente do XML da NFe. Isso permitirá:\n\n"
                        f"• Controle detalhado de cada item\n"
                        f"• Valores unitários e totais precisos\n"
                        f"• Classificação automática por categoria\n"
                        f"• Controle de localização na obra\n"
                        f"• Preenchimento automático dos dados\n\n"
                        f"Deseja importar esta NFe agora?\n"
                        f"(Clique 'Não' para continuar com o lançamento manual)"
                    )
                    
                    if resposta:
                        if self.localizar_e_processar_nfe(nf_numero):
                            return
            
            # ==========================================
            # OBTER DADOS PARA PROCESSAR
            # ==========================================
            dados_para_processar = []
            if hasattr(self, 'visualizador') and self.visualizador and self.visualizador.tree.winfo_exists():
                logger.info("Obtendo dados do visualizador")
                dados_para_processar = self.visualizador.get_dados_atualizados()
            elif self.dados_para_incluir:
                logger.info("Usando dados_para_incluir existentes")
                dados_para_processar = self.dados_para_incluir.copy()
                    
            if not dados_para_processar:
                custom_messagebox("warning", "Aviso", "Não há dados para enviar!")
                return

            logger.info(f"Total de registros a processar: {len(dados_para_processar)}")

            # ==========================================
            # GARANTIR CAMPOS OBRIGATÓRIOS
            # ==========================================
            for lancamento in dados_para_processar:
                if 'etapa_obra' not in lancamento:
                    lancamento['etapa_obra'] = ''
                if 'insumo' not in lancamento:
                    lancamento['insumo'] = ''

            # ==========================================
            # CAPTURAR DATAS AFETADAS
            # ==========================================
            datas_afetadas = set()
            for lancamento in dados_para_processar:
                try:
                    data_rel = datetime.strptime(lancamento['data'], '%d/%m/%Y').date()
                    datas_afetadas.add(data_rel)
                except:
                    continue
            
            logger.info(f"Datas que serão afetadas pela inserção: {[d.strftime('%d/%m/%Y') for d in datas_afetadas]}")

            # ==========================================
            # ADICIONAR IDENTIFICADORES ÚNICOS
            # ==========================================
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            for i, lancamento in enumerate(dados_para_processar):
                lancamento['id'] = f"{timestamp}-{i}"

            arquivo_cliente = PASTA_CLIENTES / f"{self.cliente_atual}.xlsx"
            logger.info(f"Salvando em: {arquivo_cliente}")
            
            # ==========================================
            # VERIFICAÇÃO DE DUPLICATAS
            # ==========================================
            try:
                self.verificar_e_corrigir_ids_antes_insercao(arquivo_cliente)
                
                workbook = load_workbook(arquivo_cliente)
                sheet = workbook["Dados"]

                self.verificar_e_adicionar_cabecalho_etapa_obra(sheet)
                self.verificar_e_adicionar_cabecalho_insumo(sheet)
                
                # Separar lançamentos válidos e duplicados
                lancamentos_duplicados = []
                lancamentos_validos = []
                
                for i, dados in enumerate(dados_para_processar, 1):  # ← ADICIONAR ÍNDICE
                    logger.info(f"📋 Processando lançamento {i}/{len(dados_para_processar)}: {dados['nome']} - {dados['referencia']}")
                    
                    if self.verificar_duplicidade_antes_salvar(sheet, dados):
                        lancamentos_duplicados.append(dados)
                        logger.warning(f"   ❌ Marcado como DUPLICATA")
                    else:
                        lancamentos_validos.append(dados)
                        logger.info(f"   ✅ Marcado como VÁLIDO")
                
                logger.info(f"\n📊 RESUMO DA VERIFICAÇÃO:")
                logger.info(f"   ✅ Lançamentos válidos: {len(lancamentos_validos)}")
                logger.info(f"   ❌ Possíveis duplicatas: {len(lancamentos_duplicados)}")

                # ==========================================
                # TRATAMENTO INTELIGENTE DE DUPLICATAS
                # ==========================================
                if lancamentos_duplicados:
                    logger.warning(f"Detectados {len(lancamentos_duplicados)} possíveis lançamentos duplicados")
                    
                    # Construir mensagem detalhada
                    msg_duplicados = f"DUPLICATAS DETECTADAS!\n\n"
                    msg_duplicados += f"Foram encontrados {len(lancamentos_duplicados)} possíveis lançamentos duplicados:\n\n"
                    
                    for i, dados in enumerate(lancamentos_duplicados[:5], 1):
                        msg_duplicados += f"{i}. {dados['nome']}\n"
                        msg_duplicados += f"   {dados['referencia']}\n"
                        msg_duplicados += f"   R$ {dados['valor']}\n"
                        msg_duplicados += f"   Vencimento: {dados['dt_vencto']}\n"
                        if dados.get('nf'):
                            msg_duplicados += f"   NF: {dados['nf']}\n"
                        msg_duplicados += "\n"
                    
                    if len(lancamentos_duplicados) > 5:
                        msg_duplicados += f"... e mais {len(lancamentos_duplicados) - 5} duplicatas.\n\n"
                    
                    msg_duplicados += f"Resumo:\n"
                    msg_duplicados += f"• Lançamentos únicos: {len(lancamentos_validos)}\n"
                    msg_duplicados += f"• Possíveis duplicatas: {len(lancamentos_duplicados)}\n\n"
                    
                    # NOVA OPÇÃO: Se todos são duplicatas
                    if len(lancamentos_validos) == 0:
                        msg_duplicados += "TODOS os lançamentos são duplicatas!\n\n"
                        msg_duplicados += "O que deseja fazer?\n\n"
                        msg_duplicados += "• SIM = Cancelar operação e limpar visualização\n"
                        msg_duplicados += "• NÃO = Manter na visualização para revisar"
                        
                        resposta = custom_messagebox("yesno", "Todas Duplicatas", msg_duplicados)
                        
                        workbook.close()
                        
                        if resposta:  # SIM = Limpar tudo
                            logger.info("Usuário optou por limpar todos os lançamentos duplicados")
                            self.limpar_visualizacao_completa()
                            custom_messagebox("info", "Limpeza Concluída", 
                                            "Todos os lançamentos duplicados foram removidos da visualização.\n\n"
                                            "Nenhum dado foi salvo na planilha.")
                        else:  # NÃO = Manter para revisão
                            logger.info("Usuário optou por manter lançamentos para revisão")
                            custom_messagebox("info", "Mantido para Revisão", 
                                            "Os lançamentos foram mantidos na visualização para que você possa:\n\n"
                                            "• Revisar individualmente cada um\n"
                                            "• Remover duplicatas manualmente\n"
                                            "• Editar se necessário\n\n"
                                            "Nenhum dado foi salvo na planilha.")
                        return
                    
                    # Se há MIX de únicos e duplicados
                    msg_duplicados += "Deseja continuar salvando APENAS os lançamentos únicos?\n\n"
                    msg_duplicados += "• SIM = Salvar únicos e remover duplicatas da visualização\n"
                    msg_duplicados += "• NÃO = Cancelar e manter todos para revisar"
                    
                    resposta = custom_messagebox("yesno", "Duplicatas Detectadas", msg_duplicados)
                    
                    if not resposta:  # Usuário cancelou
                        logger.info("Operação cancelada pelo usuário devido a duplicatas")
                        workbook.close()
                        custom_messagebox("info", "Operação Cancelada", 
                                        "Operação cancelada. Os lançamentos permanecem na visualização para revisão.\n\n"
                                        "Você pode:\n"
                                        "• Remover as duplicatas manualmente\n"
                                        "• Editar os registros\n"
                                        "• Tentar enviar novamente")
                        return
                    
                    # Usuário confirmou: salvar únicos e limpar duplicatas
                    dados_para_processar = lancamentos_validos
                    logger.info(f"Usuário optou por continuar. Processando {len(dados_para_processar)} lançamentos únicos")
                    
                    # IMPORTANTE: Já marcar para limpeza posterior
                    self._duplicatas_para_remover = lancamentos_duplicados

                # ==========================================
                # REMOVER TABELAS EXISTENTES
                # ==========================================
                if sheet.tables:
                    table_name = list(sheet.tables.keys())[0]
                    sheet.tables.pop(table_name)
                    
                # ==========================================
                # PROCESSAR REGISTROS VÁLIDOS
                # ==========================================
                registros_salvos = 0
                for dados in dados_para_processar:
                    try:
                        proxima_linha = sheet.max_row + 1
                        
                        # Data de referência
                        data_rel = datetime.strptime(dados['data'], '%d/%m/%Y')
                        data_cell = sheet.cell(row=proxima_linha, column=1, value=data_rel)
                        data_cell.number_format = 'DD/MM/YYYY'

                        # Tipo de despesa
                        tp_desp_cell = sheet.cell(row=proxima_linha, column=2, value=int(dados['tp_desp']))
                        tp_desp_cell.number_format = '0'

                        # Dados gerais
                        sheet.cell(row=proxima_linha, column=3, value=dados['cnpj_cpf'])
                        sheet.cell(row=proxima_linha, column=4, value=dados['nome'])
                        sheet.cell(row=proxima_linha, column=5, value=dados['referencia'])
                        sheet.cell(row=proxima_linha, column=6, value=dados['nf'])

                        # Valores numéricos
                        vr_unit = float(dados['vr_unit'].replace(',', '.'))
                        vr_unit_cell = sheet.cell(row=proxima_linha, column=7, value=vr_unit)
                        aplicar_formatacao_celula(vr_unit_cell)

                        # Gravar dias como float para aceitar valores decimais (ex: 9,5 dias)
                        dias_valor = dados.get('dias', 1)
                        if isinstance(dias_valor, str):
                            dias_valor = float(dias_valor.replace(',', '.'))
                        dias_cell = sheet.cell(row=proxima_linha, column=8, value=float(dias_valor))
                        dias_cell.number_format = '0.0'

                        valor = float(dados['valor'].replace(',', '.'))
                        valor_cell = sheet.cell(row=proxima_linha, column=9, value=valor)
                        aplicar_formatacao_celula(valor_cell)

                        dt_vencto = datetime.strptime(dados['dt_vencto'], '%d/%m/%Y')
                        dt_vencto_cell = sheet.cell(row=proxima_linha, column=10, value=dt_vencto)
                        dt_vencto_cell.number_format = 'DD/MM/YYYY'

                        sheet.cell(row=proxima_linha, column=11, value=dados['categoria'])
                        sheet.cell(row=proxima_linha, column=12, value=dados['dados_bancarios'])
                        sheet.cell(row=proxima_linha, column=13, value=dados['observacao'])
                        
                        # ID sequencial
                        novo_id = self.obter_proximo_id_sequencial(sheet)
                        sheet.cell(row=proxima_linha, column=14, value='ATIVO')
                        sheet.cell(row=proxima_linha, column=15, value=novo_id)

                        # Campos adicionais
                        sheet.cell(row=proxima_linha, column=17, value=dados.get('etapa_obra', ''))
                        sheet.cell(row=proxima_linha, column=18, value=dados.get('insumo', ''))

                        logger.info(f"Lançamento inserido com ID {novo_id} na linha {proxima_linha}")
                        
                        registros_salvos += 1
                        
                    except Exception as e:
                        logger.error(f"Erro ao processar registro {dados.get('nome', 'DESCONHECIDO')}: {str(e)}")
                        continue

                # ==========================================
                # SALVAR ARQUIVO E RECALCULAR
                # ==========================================
                try:
                    salvar_planilha_segura(workbook, arquivo_cliente)
                    
                    if registros_salvos > 0:
                        logger.info(f"Iniciando verificação de recálculo para {len(datas_afetadas)} datas")
                        
                        import time
                        time.sleep(0.5)
                        
                    # ==========================================
                    # MENSAGEM DE SUCESSO E LIMPEZA
                    # ==========================================
                    if lancamentos_duplicados:
                        mensagem_sucesso = f"Dados salvos com sucesso!\n\n"
                        mensagem_sucesso += f"Resumo da operação:\n"
                        mensagem_sucesso += f"• Lançamentos salvos: {registros_salvos}\n"
                        mensagem_sucesso += f"• Duplicatas ignoradas: {len(lancamentos_duplicados)}\n\n"
                        if datas_recalculadas:
                            mensagem_sucesso += f"Taxas recalculadas para: {', '.join(datas_recalculadas)}\n\n"
                        mensagem_sucesso += f"As duplicatas foram automaticamente removidas da visualização."
                        custom_messagebox("info", "Sucesso com Filtro", mensagem_sucesso)
                        
                        # LIMPAR DUPLICATAS DA VISUALIZAÇÃO
                        self.remover_duplicatas_da_visualizacao(lancamentos_duplicados)
                    else:
                        mensagem_sucesso = f"Dados salvos com sucesso! {registros_salvos} lançamentos processados."
                        if datas_recalculadas:
                            mensagem_sucesso += f"\n\nTaxas recalculadas para: {', '.join(datas_recalculadas)}"
                        custom_messagebox("info", "Sucesso", mensagem_sucesso)
                    
                    self.limpar_backup()

                    # ==========================================
                    # LIMPAR APENAS OS DADOS SALVOS
                    # ==========================================
                    if registros_salvos > 0:
                        self.limpar_dados_salvos(dados_para_processar)
                    
                except PermissionError:
                    logger.error("Permissão negada ao salvar arquivo - provável arquivo aberto")
                    custom_messagebox("error", 
                        "Erro", 
                        f"Não foi possível salvar! A planilha '{self.cliente_atual}.xlsx' está aberta.\n\n"
                        "Por favor:\n"
                        "1. Feche a planilha\n"
                        "2. Clique em OK\n"
                        "3. Tente enviar novamente"
                    )
                except Exception as e:
                    logger.error(f"Erro ao salvar arquivo: {str(e)}")
                    custom_messagebox("error", "Erro", f"Erro ao salvar arquivo: {str(e)}")
                            
            except Exception as e:
                logger.error(f"Erro ao processar dados: {str(e)}", exc_info=True)
                custom_messagebox("error", "Erro", f"Erro ao processar dados: {str(e)}")
                
        except Exception as e:
            logger.error(f"Erro geral no método enviar_dados: {str(e)}", exc_info=True)
            custom_messagebox("error", "Erro", f"Erro ao enviar dados: {str(e)}")
            
        finally:
            # Reabilitar botão
            if btn_enviar:
                btn_enviar.config(state='normal')
            
            if hasattr(self, '_is_saving'):
                self._is_saving = False

    def abrir_pasta_logs(self):
        """Abre a pasta de logs no explorador"""
        import subprocess
        import platform
        
        log_dir = os.path.join(os.path.expanduser('~'), 'Desktop', 'logs_sistema')
        
        if platform.system() == 'Windows':
            subprocess.Popen(f'explorer "{log_dir}"')
        elif platform.system() == 'Darwin':  # macOS
            subprocess.Popen(['open', log_dir])
        else:  # Linux
            subprocess.Popen(['xdg-open', log_dir])
  
    # ==========================================
    # MÉTODOS AUXILIARES PARA GESTÃO DE DUPLICATAS
    # ==========================================

    def limpar_visualizacao_completa(self):
        """
        Limpa completamente a visualização de lançamentos pendentes
        Usado quando usuário confirma descarte ao trocar cliente
        """
        try:
            # logger = system_logger.get_logger()
            logger.info("Limpando visualização completa de lançamentos pendentes")
            
            # Limpar lista principal
            if hasattr(self, 'dados_para_incluir'):
                qtd_antes = len(self.dados_para_incluir)
                self.dados_para_incluir.clear()
                logger.info(f"Lista dados_para_incluir limpa ({qtd_antes} registros removidos)")
            
            # Fechar e destruir visualizador se existir
            if hasattr(self, 'visualizador') and self.visualizador:
                if hasattr(self.visualizador, 'janela') and self.visualizador.janela:
                    try:
                        self.visualizador.janela.destroy()
                        logger.info("Janela do visualizador destruída")
                    except Exception as e:
                        logger.warning(f"Erro ao destruir janela do visualizador: {str(e)}")
                self.visualizador = None
                logger.info("Referência ao visualizador removida")
            
            logger.info("Visualização limpa com sucesso")
            
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.error(f"Erro ao limpar visualização completa: {str(e)}")

    def remover_duplicatas_da_visualizacao(self, lancamentos_duplicados):
        """
        Remove APENAS os lançamentos duplicados da visualização
        Mantém os lançamentos únicos que não foram salvos
        """
        try:
            # logger = system_logger.get_logger()
            logger.info(f"Removendo {len(lancamentos_duplicados)} duplicatas da visualização")
            
            # Criar set de IDs das duplicatas para busca rápida
            ids_duplicatas = set()
            for dup in lancamentos_duplicados:
                # Criar chave única baseada nos campos principais
                chave = f"{dup['nome']}|{dup['referencia']}|{dup['valor']}|{dup['dt_vencto']}"
                ids_duplicatas.add(chave)
            
            # Filtrar dados_para_incluir removendo duplicatas
            dados_filtrados = []
            for dados in self.dados_para_incluir:
                chave = f"{dados['nome']}|{dados['referencia']}|{dados['valor']}|{dados['dt_vencto']}"
                if chave not in ids_duplicatas:
                    dados_filtrados.append(dados)
            
            self.dados_para_incluir = dados_filtrados
            
            # Atualizar visualizador se existir
            if hasattr(self, 'visualizador') and self.visualizador:
                if hasattr(self.visualizador, 'tree') and self.visualizador.tree.winfo_exists():
                    # Limpar tree
                    for item in self.visualizador.tree.get_children():
                        self.visualizador.tree.delete(item)
                    
                    # Repopular apenas com dados filtrados
                    if dados_filtrados:
                        self.visualizador.popular_tree(dados_filtrados)
                        logger.info(f"Visualizador atualizado com {len(dados_filtrados)} registros únicos")
                    else:
                        # Se não sobrou nada, fechar visualizador
                        self.visualizador.janela.destroy()
                        self.visualizador = None
                        logger.info("Visualizador fechado - nenhum registro único restante")
            
            logger.info("Duplicatas removidas com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao remover duplicatas da visualização: {str(e)}")

    def limpar_dados_salvos(self, dados_salvos):
        """
        Remove da visualização APENAS os dados que foram efetivamente salvos
        Mantém dados que ainda não foram processados
        """
        try:
            # logger = system_logger.get_logger()
            logger.info(f"Limpando {len(dados_salvos)} registros salvos da visualização")
            
            # Criar set de IDs dos dados salvos
            ids_salvos = set()
            for dados in dados_salvos:
                if 'id' in dados:
                    ids_salvos.add(dados['id'])
            
            # Filtrar dados_para_incluir
            dados_restantes = [d for d in self.dados_para_incluir if d.get('id') not in ids_salvos]
            
            self.dados_para_incluir = dados_restantes
            
            # Atualizar ou fechar visualizador
            if hasattr(self, 'visualizador') and self.visualizador:
                if dados_restantes:
                    # Ainda há dados - atualizar visualização
                    if hasattr(self.visualizador, 'tree') and self.visualizador.tree.winfo_exists():
                        for item in self.visualizador.tree.get_children():
                            self.visualizador.tree.delete(item)
                        self.visualizador.popular_tree(dados_restantes)
                        logger.info(f"Visualizador atualizado com {len(dados_restantes)} registros pendentes")
                else:
                    # Não há mais dados - fechar visualizador
                    self.visualizador.janela.destroy()
                    self.visualizador = None
                    logger.info("Visualizador fechado - todos os registros foram processados")
            
            logger.info("Dados salvos removidos com sucesso da visualização")
            
        except Exception as e:
            logger.error(f"Erro ao limpar dados salvos: {str(e)}")

    def verificar_e_adicionar_cabecalho_etapa_obra(self, sheet):
        """
        Verifica se o cabeçalho da coluna Etapa da Obra existe e adiciona se necessário
        """
        try:
            # Verificar se existe cabeçalho na linha 1, coluna 17
            cabecalho_atual = sheet.cell(row=1, column=17).value
            
            if cabecalho_atual is None or cabecalho_atual == "":
                # Adicionar cabeçalho para Etapa da Obra
                sheet.cell(row=1, column=17, value="ETAPA_OBRA")
                logger.info("Cabeçalho 'ETAPA_OBRA' adicionado na coluna Q (17)")
                
            return True
            
        except Exception as e:
            logger.error(f"Erro ao verificar/adicionar cabeçalho de etapa da obra: {str(e)}")
            return False

    def verificar_e_adicionar_cabecalho_insumo(self, sheet):
        """
        Verifica se o cabeçalho da coluna Insumo existe e adiciona se necessário
        """
        try:
            # Verificar se existe cabeçalho na linha 1, coluna 18
            cabecalho_atual = sheet.cell(row=1, column=18).value
            
            if cabecalho_atual is None or cabecalho_atual == "":
                # Adicionar cabeçalho para Insumo
                sheet.cell(row=1, column=18, value="INSUMO")
                logger.info("Cabeçalho 'INSUMO' adicionado na coluna R (18)")
                
            return True
            
        except Exception as e:
            logger.error(f"Erro ao verificar/adicionar cabeçalho de insumo: {str(e)}")
            return False
        
    def verificar_e_corrigir_ids_antes_insercao(self, arquivo_cliente):
        """
        Verifica e corrige IDs duplicados ANTES de inserir novos lançamentos
        """
        try:
            # logger = system_logger.get_logger()
            logger.info("Verificando integridade dos IDs antes da inserção")
            
            wb = load_workbook(arquivo_cliente)
            ws = wb['Dados']
            
            # Verificar se coluna ID_LANCAMENTO existe
            if ws.cell(row=1, column=15).value != 'ID_LANCAMENTO':
                ws.cell(row=1, column=15, value='ID_LANCAMENTO')
                logger.info("Coluna ID_LANCAMENTO criada")
            
            # Coletar todos os IDs existentes
            ids_existentes = {}
            linhas_com_id_invalido = []
            
            for row in range(2, ws.max_row + 1):
                id_atual = ws.cell(row=row, column=15).value
                
                if id_atual is None or id_atual == '':
                    linhas_com_id_invalido.append(row)
                else:
                    try:
                        id_int = int(float(id_atual))
                        if id_int in ids_existentes:
                            # ID duplicado encontrado
                            logger.warning(f"ID duplicado {id_int} nas linhas {ids_existentes[id_int]} e {row}")
                            linhas_com_id_invalido.append(row)
                        else:
                            ids_existentes[id_int] = row
                    except (ValueError, TypeError):
                        logger.warning(f"ID inválido na linha {row}: {id_atual}")
                        linhas_com_id_invalido.append(row)
            
            # Se há IDs inválidos, corrigir
            if linhas_com_id_invalido:
                logger.info(f"Corrigindo {len(linhas_com_id_invalido)} IDs inválidos/duplicados")
                
                # Encontrar próximo ID disponível
                proximo_id = max(ids_existentes.keys()) + 1 if ids_existentes else 1
                
                for linha in linhas_com_id_invalido:
                    ws.cell(row=linha, column=15, value=proximo_id)
                    logger.info(f"ID {proximo_id} atribuído à linha {linha}")
                    proximo_id += 1
                
                # Salvar correções
                salvar_planilha_segura(wb, arquivo_cliente)
                logger.info("Correções de ID salvas com sucesso")
            
            wb.close()
            
        except Exception as e:
            logger.error(f"Erro ao verificar IDs: {str(e)}")

    # ===== MÉTODO AUXILIAR NOVO: Obter próximo ID sequencial =====
    def obter_proximo_id_sequencial(self, worksheet):
        """
        Obtém o próximo ID sequencial disponível
        """
        try:
            max_id = 0
            
            # Percorrer coluna 15 (ID_LANCAMENTO) para encontrar o maior ID
            for row in range(2, worksheet.max_row + 1):
                id_valor = worksheet.cell(row=row, column=15).value
                if id_valor is not None:
                    try:
                        id_int = int(float(id_valor))
                        if id_int > max_id:
                            max_id = id_int
                    except (ValueError, TypeError):
                        continue
            
            return max_id + 1
            
        except Exception as e:
            logger.debug(f"Erro ao obter próximo ID: {str(e)}")
            # Fallback: usar número da linha como ID
            return worksheet.max_row

    # ========== MÉTODOS AUXILIARES NECESSÁRIOS NFe==========
    def verificar_nf_ja_processada(self, numero_nf):
        """
        Verifica se uma NF já foi processada via integrador
        """
        try:
            # Verificar no sistema de materiais se há materiais desta NF
            if hasattr(self, 'gerenciador_materiais'):
                df_materiais = self.gerenciador_materiais.carregar_materiais_cliente(self.cliente_atual)
                if not df_materiais.empty and 'Numero_NF' in df_materiais.columns:
                    nfs_existentes = df_materiais['Numero_NF'].dropna().astype(str).str.strip()
                    return numero_nf in nfs_existentes.values
            return False
        except Exception as e:
            logger.debug(f"Erro ao verificar NF processada: {e}")
            return False

    def localizar_e_processar_nfe(self, numero_nf):
        """
        Tenta localizar e processar NFe por número
        """
        try:
            from tkinter import filedialog
            
            # Solicitar localização do XML
            custom_messagebox(
                "info",
                "Localizar XML", 
                f"📁 LOCALIZAR XML DA NFe\n\n"
                f"📋 NF: {numero_nf}\n\n"
                f"Na próxima janela, selecione o arquivo XML "
                f"correspondente a esta nota fiscal."
            )
            
            arquivo_xml = filedialog.askopenfilename(
                title=f"Selecionar XML da NFe {numero_nf}",
                filetypes=[
                    ("Arquivos XML", "*.xml"),
                    ("Todos os arquivos", "*.*")
                ]
            )
            
            if arquivo_xml:
                # Verificar se o XML corresponde à NF informada
                if hasattr(self, 'processador_nfe'):
                    dados_nfe = self.processador_nfe.processar_xml_nfe(arquivo_xml)
                    
                    if dados_nfe and dados_nfe.get('numero_nf') == numero_nf:
                        # XML correto, abrir integrador
                        from src.nfe.integrador_nfe_sistema import IntegradorNFeFinanceiroMateriais
                        integrador = IntegradorNFeFinanceiroMateriais(self)
                        integrador.criar_interface_integracao_nfe(dados_nfe)
                        return True
                    else:
                        nf_encontrada = dados_nfe.get('numero_nf', 'não identificada') if dados_nfe else 'erro ao ler arquivo'
                        custom_messagebox(
                            "error",
                            "Arquivo Incorreto", 
                            f"❌ ARQUIVO INCORRETO!\n\n"
                            f"O XML selecionado não corresponde à NF {numero_nf}.\n\n"
                            f"📋 NF esperada: {numero_nf}\n"
                            f"📄 NF do arquivo: {nf_encontrada}\n\n"
                            f"Selecione o arquivo XML correto ou continue "
                            f"com o lançamento manual."
                        )
                else:
                    custom_messagebox(
                        "error",
                        "Sistema NFe", 
                        "❌ Sistema NFe não inicializado!\n\n"
                        "O processador de NFe não está disponível. "
                        "Continue com o lançamento manual."
                    )
            
            return False
            
        except Exception as e:
            # logger = system_logger.get_logger()
            logger.error(f"Erro ao processar NFe: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao processar NFe:\n{str(e)}")
            return False


    # ========== MÉTODOS AUXILIARES IMPORTAÇÃO GDF E DARF ==========

    # def _localizar_compromisso_agenda(self, dados):
    #     if not self.gerenciador_agenda or not self.gerenciador_agenda.dados_agenda:
    #         return 'agenda_nao_carregada'

    #     # Proteção contra dados_agenda desatualizado de outro cliente
    #     if self.gerenciador_agenda.dados_agenda:
    #         item_amostra = self.gerenciador_agenda.dados_agenda[0]
    #         cliente_do_carregamento = item_amostra.get('cliente')
    #         if cliente_do_carregamento and cliente_do_carregamento != self.cliente_atual:
    #             return 'agenda_de_outro_cliente'

    #     nome_esperado = NOME_FORNECEDOR_POR_TIPO.get(dados['tipo'])
    #     if not nome_esperado:
    #         return None

    #     competencia_pdf = (
    #         competencia_para_mm_aaaa(dados.get('competencia', ''), 'FGTS')
    #         if dados['tipo'] == 'FGTS'
    #         else competencia_para_mm_aaaa(dados.get('periodo_apuracao', ''), 'DARF')
    #     )
    #     if not competencia_pdf:
    #         return None

    #     for item in self.gerenciador_agenda.dados_agenda:
    #         if item.get('origem') != 'CONFIGURACAO' or item.get('status') != 'PENDENTE':
    #             continue
    #         if item.get('fornecedor', '').strip().upper() != nome_esperado.upper():
    #             continue

    #         tipo_ref = item.get('tipo_referencia_mes', 'anterior')
    #         competencia_item = self.gerenciador_agenda.calcular_mes_referencia_compromisso(
    #             item['data_rel'], tipo_ref
    #         )
    #         if competencia_item == competencia_pdf:
    #             return item

    #     return None

    # def importar_guia_recorrente(self):
    #     if not self.cliente_atual:
    #         custom_messagebox("error", "Erro", "Selecione um cliente antes de importar uma guia!")
    #         return

    #     caminho = filedialog.askopenfilename(title="Selecione o PDF da guia", filetypes=[("PDF", "*.pdf")])
    #     if not caminho:
    #         return

    #     try:
    #         dados = extrair_dados_guia(caminho)
    #     except GuiaNaoReconhecida as e:
    #         custom_messagebox("error", "Erro", str(e))
    #         return

    #     if dados['campos_faltando']:
    #         custom_messagebox("warning", "Atenção",
    #             f"Não extraído automaticamente: {', '.join(dados['campos_faltando'])}.")

    #     item_agenda = self._localizar_compromisso_agenda(dados)

    #     if item_agenda == 'agenda_nao_carregada':
    #         custom_messagebox("info", "Abra a Agenda primeiro",
    #             f"Para importar uma guia de {self.cliente_atual}, abra a Agenda ao menos uma vez "
    #             "nesta sessão (ela carrega os compromissos pendentes usados na comparação).")
    #         return

    #     if item_agenda == 'agenda_de_outro_cliente':
    #         custom_messagebox("info", "Agenda desatualizada",
    #             f"A Agenda carregada não é a de {self.cliente_atual}. "
    #             "Abra a Agenda deste cliente antes de importar a guia.")
    #         return

    #     if not item_agenda:
    #         custom_messagebox("warning", "Compromisso não encontrado",
    #             f"Guia lida (Valor: R$ {dados['valor']:.2f}), mas nenhum compromisso "
    #             f"'{NOME_FORNECEDOR_POR_TIPO.get(dados['tipo'])}' pendente com a competência "
    #             "correspondente foi localizado na Agenda.")
    #         return

    #     valores_item_sintetico = (
    #         '',
    #         item_agenda['vencimento'].strftime('%d/%m/%Y'),
    #         item_agenda['status'],
    #         item_agenda['fornecedor'],
    #         item_agenda['referencia'],
    #         f"R$ {dados['valor']:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'),
    #         item_agenda['tipo'],
    #         item_agenda['observacao'],
    #         item_agenda['id_origem'],
    #     )

    #     self.gerenciador_agenda.abrir_confirmacao_lancamento(
    #         valores_item_sintetico, dados_pre_extraidos=dados
    #     )

    # ===== FUNÇÕES UTILITÁRIAS PARA VERIFICAÇÃO E RECÁLCULO =====
    def abrir_finalizacao_quinzena(self):
        """Abre a finalização de quinzena"""
        try:
            from src.finalizacao_quinzena import FinalizacaoQuinzena
            app = FinalizacaoQuinzena(self.root)
            self.root.withdraw()  # Esconde menu principal
            app.run()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao abrir finalização: {str(e)}")


    def verificar_consistencia_taxas(self, data_referencia=None):
        """
        Método para verificar consistência das taxas de administração
        """
        if not self.cliente_atual:
            return "Nenhum cliente selecionado"
        
        try:
            arquivo_cliente = PASTA_CLIENTES / f"{self.cliente_atual}.xlsx"
            
            if not os.path.exists(arquivo_cliente):
                return "Arquivo do cliente não encontrado"
            
            df = pd.read_excel(arquivo_cliente, sheet_name='Dados', converters=CONVERSORES_DADOS)
            df = df.fillna("")
            
            # Se não especificou data, usar todas as datas com taxas
            if data_referencia is None:
                df['DATA_REL'] = pd.to_datetime(df['DATA_REL'], errors='coerce')
                datas_com_taxas = set()
                
                # Identificar datas que têm taxas
                for _, row in df.iterrows():
                    tp_desp = row.get('TP_DESP', 0)
                    if tp_desp == 7:  # Tipo específico para taxas de administração
                        if pd.notna(row['DATA_REL']):
                            datas_com_taxas.add(row['DATA_REL'].date())
                
                if not datas_com_taxas:
                    return "Nenhuma taxa de administração encontrada"
                
                # Verificar cada data
                relatorio = []
                relatorio.append(f"Cliente: {self.cliente_atual}")
                relatorio.append(f"Total de datas com taxas: {len(datas_com_taxas)}")
                relatorio.append("-" * 50)
                
                try:
                    gestor_taxas = GestorTaxasAdministracao(self)
                    for data in sorted(datas_com_taxas):
                        try:
                            precisa, motivo = gestor_taxas.verificar_necessidade_recalculo(data)
                            status = "❌ INCONSISTENTE" if precisa else "✅ OK"
                            relatorio.append(f"{data.strftime('%d/%m/%Y')}: {status} - {motivo}")
                        except Exception as e:
                            relatorio.append(f"{data.strftime('%d/%m/%Y')}: ⚠️ ERRO - {str(e)}")
                except Exception as e:
                    # Se não conseguir usar o gestor, fazer verificação básica
                    for data in sorted(datas_com_taxas):
                        relatorio.append(f"{data.strftime('%d/%m/%Y')}: ℹ️ DETECTADA - Possui taxa de administração")
                    relatorio.append("")
                    relatorio.append(f"⚠️ Erro no gestor de taxas: {str(e)}")
                    relatorio.append("Verificação básica realizada.")
                
                return "\n".join(relatorio)
            
            else:
                # Verificar data específica
                try:
                    gestor_taxas = GestorTaxasAdministracao(self)
                    precisa, motivo = gestor_taxas.verificar_necessidade_recalculo(data_referencia)
                    return f"Data {data_referencia}: {'❌ INCONSISTENTE' if precisa else '✅ OK'} - {motivo}"
                except Exception as e:
                    return f"Data {data_referencia}: ⚠️ ERRO - {str(e)}"
                
        except Exception as e:
            return f"Erro na verificação: {str(e)}"
        
    def verificar_e_mostrar_consistencia(self):
        """
        Verifica e mostra consistência das taxas em interface gráfica
        """
        if not self.cliente_atual:
            custom_messagebox("warning", "Aviso", "Selecione um cliente primeiro!")
            return
        
        try:
            logger.debug("DEBUG: Iniciando verificação de consistência das taxas...")
            logger.debug(f"DEBUG: Cliente atual: {self.cliente_atual}")
            
            # Agora chama o método da própria classe
            relatorio = self.verificar_consistencia_taxas()
            logger.debug(f"DEBUG: Relatório gerado com sucesso")
            
            # Criar janela para mostrar o relatório
            janela = tk.Toplevel(self.root)
            janela.title(f"Verificação de Taxas - {self.cliente_atual}")
            janela.geometry("700x500")
            janela.grab_set()  # Modal
            
            # Centralizar janela
            janela.transient(self.root)
            
            frame = ttk.Frame(janela, padding="15")
            frame.pack(fill='both', expand=True)
            
            ttk.Label(frame, text="📊 Verificação de Consistência das Taxas", 
                    font=('Arial', 14, 'bold')).pack(pady=(0, 15))
            
            # Área de texto com scroll
            text_frame = ttk.Frame(frame)
            text_frame.pack(fill='both', expand=True)
            
            text_widget = tk.Text(text_frame, wrap=tk.WORD, font=('Consolas', 10))
            scrollbar = ttk.Scrollbar(text_frame, orient='vertical', command=text_widget.yview)
            text_widget.configure(yscrollcommand=scrollbar.set)
            
            text_widget.pack(side='left', fill='both', expand=True)
            scrollbar.pack(side='right', fill='y')
            
            text_widget.insert(tk.END, relatorio)
            text_widget.config(state='disabled')
            
            # Botões
            botoes_frame = ttk.Frame(frame)
            botoes_frame.pack(fill='x', pady=(15, 0))
            
            ttk.Button(botoes_frame, text="Fechar", 
                    command=janela.destroy).pack(side='right')
                        
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro na verificação: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro na verificação: {str(e)}")
  
    def configurar_auto_salvamento(self):
        """Configura o auto-salvamento automático - MÉTODO NECESSÁRIO"""
        def executar_auto_salvamento():
            try:
                self.auto_salvar_dados()
                # Reagendar para 2 minutos (120000ms)
                self.root.after(120000, executar_auto_salvamento)
            except Exception as e:
                logger.debug(f"❌ Erro no auto-salvamento automático: {str(e)}")
                # Reagendar mesmo em caso de erro
                self.root.after(120000, executar_auto_salvamento)
        
        # Iniciar o timer após 2 minutos
        self.root.after(120000, executar_auto_salvamento)
        logger.debug("🔄 Auto-salvamento configurado (a cada 2 minutos)")

    def auto_salvar_dados(self):
        """Salva automaticamente os dados - VERSÃO CORRIGIDA COM NOMES ESPECÍFICOS"""
        try:
            if self.dados_para_incluir and self.cliente_atual:  # CORREÇÃO: Verificar se há cliente
                # Preparar dados do backup
                backup_data = {
                    'cliente': self.cliente_atual,
                    'data_sessao': datetime.now().isoformat(),
                    'lancamentos': self.dados_para_incluir,
                    'total_lancamentos': len(self.dados_para_incluir),
                    'estacao': os.environ.get('COMPUTERNAME', 'Desconhecido'),
                    'usuario': os.environ.get('USERNAME', 'Desconhecido'),
                    'versao_backup': '2.1'  # Nova versão com correções
                }
                
                backup_salvo = False
                
                # PRIORIDADE 1: Google Drive (já estava correto)
                try:
                    pasta_backup = PASTA_CLIENTES / "Backups_Sistema"
                    os.makedirs(pasta_backup, exist_ok=True)
                    
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    nome_arquivo = f"backup_{self.cliente_atual}_{timestamp}.json"
                    arquivo_backup = pasta_backup / nome_arquivo
                    
                    with open(arquivo_backup, 'w', encoding='utf-8') as f:
                        json.dump(backup_data, f, ensure_ascii=False, indent=2)
                    
                    logger.debug(f"✅ Backup salvo no Google Drive: {arquivo_backup}")
                    backup_salvo = True
                    
                    self.limpar_backups_antigos(pasta_backup, self.cliente_atual)
                    
                except Exception as e:
                    logger.debug(f"⚠️ Erro ao salvar backup no Google Drive: {str(e)}")
                
                # FALLBACK 1: Desktop local - CORREÇÃO: Nome específico do cliente
                if not backup_salvo:
                    try:
                        desktop_local = os.path.join(os.path.expanduser("~"), "Desktop")
                        if os.path.exists(desktop_local) and os.access(desktop_local, os.W_OK):
                            # CORREÇÃO: Usar nome específico do cliente
                            arquivo_local = os.path.join(desktop_local, f"backup_{self.cliente_atual}.json")
                            
                            with open(arquivo_local, 'w', encoding='utf-8') as f:
                                json.dump(backup_data, f, ensure_ascii=False, indent=2)
                            
                            logger.debug(f"✅ Backup salvo no Desktop: {arquivo_local}")
                            backup_salvo = True
                            
                    except Exception as e:
                        logger.debug(f"⚠️ Erro ao salvar backup no Desktop: {str(e)}")
                
                # FALLBACK 2: Pasta temporária - CORREÇÃO: Nome específico do cliente
                if not backup_salvo:
                    try:
                        import tempfile
                        # CORREÇÃO: Usar nome específico do cliente na pasta temp
                        arquivo_temp = os.path.join(tempfile.gettempdir(), f"backup_{self.cliente_atual}.json")
                        
                        with open(arquivo_temp, 'w', encoding='utf-8') as f:
                            json.dump(backup_data, f, ensure_ascii=False, indent=2)
                        
                        logger.debug(f"✅ Backup salvo na pasta temporária: {arquivo_temp}")
                        backup_salvo = True
                        
                    except Exception as e:
                        logger.debug(f"⚠️ Erro ao salvar backup na pasta temp: {str(e)}")
                
                if backup_salvo:
                    logger.debug(f"🔄 Auto-salvamento realizado para {self.cliente_atual}: {len(self.dados_para_incluir)} itens")
                else:
                    logger.debug("❌ ERRO: Não foi possível salvar backup em nenhum local!")
            else:
                if not self.cliente_atual:
                    logger.debug("⚠️ Auto-salvamento cancelado: Nenhum cliente selecionado")
                if not self.dados_para_incluir:
                    logger.debug("ℹ️ Auto-salvamento cancelado: Nenhum dado para salvar")
                    
        except Exception as e:
            logger.debug(f"❌ Erro geral no auto-salvamento: {str(e)}")

    def limpar_backups_antigos(self, pasta_backup, cliente):
        """Remove backups antigos mantendo apenas os últimos 5"""
        try:
            # Buscar todos os backups do cliente
            pattern = f"backup_{cliente}_*.json"
            backups = list(pasta_backup.glob(pattern))
            
            # Ordenar por data de modificação (mais recente primeiro)
            backups.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            
            # Remover backups excedentes (manter apenas os 5 mais recentes)
            for backup_antigo in backups[5:]:
                try:
                    backup_antigo.unlink()
                    logger.debug(f"🗑️ Backup antigo removido: {backup_antigo.name}")
                except Exception as e:
                    logger.debug(f"⚠️ Erro ao remover backup antigo {backup_antigo}: {str(e)}")
                    
        except Exception as e:
            logger.debug(f"⚠️ Erro ao limpar backups antigos: {str(e)}")

    def verificar_dados_nao_salvos(self):
        """Verifica se existem dados não salvos - VERSÃO CORRIGIDA COM VALIDAÇÃO"""
        if self._encerrando:
            logger.debug("⏹️ Verificação cancelada: sistema encerrando")
            return
        
        try:
            backups_encontrados = []
            
            # BUSCA 1: Google Drive (prioridade)
            try:
                pasta_backup = PASTA_CLIENTES / "Backups_Sistema"
                if pasta_backup.exists():
                    agora = datetime.now()
                    limite_tempo = agora - relativedelta(hours=24)
                    
                    for arquivo_backup in pasta_backup.glob("backup_*.json"):
                        try:
                            # Verificar se é recente
                            data_modificacao = datetime.fromtimestamp(arquivo_backup.stat().st_mtime)
                            if data_modificacao >= limite_tempo:
                                
                                with open(arquivo_backup, 'r', encoding='utf-8') as f:
                                    backup_data = json.load(f)
                                
                                # CORREÇÃO: Verificar se tem dados válidos E se é do cliente atual
                                if (backup_data.get('lancamentos') and 
                                    len(backup_data['lancamentos']) > 0):
                                    
                                    backup_info = {
                                        'arquivo': arquivo_backup,
                                        'data': backup_data,
                                        'origem': 'Google Drive'
                                    }
                                    backups_encontrados.append(backup_info)
                                    
                        except Exception as e:
                            logger.debug(f"Erro ao processar backup {arquivo_backup}: {str(e)}")
                            continue
            except Exception as e:
                logger.debug(f"Erro ao buscar backups no Google Drive: {str(e)}")
            
            # BUSCA 2: Desktop local (fallback) - CORRIGIR NOME DO ARQUIVO
            if not backups_encontrados:
                try:
                    # CORREÇÃO: Usar nome específico do cliente se disponível
                    if self.cliente_atual:
                        temp_file = os.path.join(os.path.expanduser("~"), "Desktop", f"backup_{self.cliente_atual}.json")
                    else:
                        temp_file = os.path.join(os.path.expanduser("~"), "Desktop", "backup_lancamentos.json")
                    
                    if os.path.exists(temp_file):
                        data_modificacao = datetime.fromtimestamp(os.path.getmtime(temp_file))
                        if (datetime.now() - data_modificacao).days < 1:
                            
                            with open(temp_file, 'r', encoding='utf-8') as f:
                                backup_data = json.load(f)
                            
                            if backup_data.get('lancamentos'):
                                backup_info = {
                                    'arquivo': temp_file,
                                    'data': backup_data,
                                    'origem': 'Desktop Local'
                                }
                                backups_encontrados.append(backup_info)
                                
                except Exception as e:
                    logger.debug(f"Erro ao buscar backup no Desktop: {str(e)}")
            
            # Processar backups encontrados COM VALIDAÇÃO DE CLIENTE
            if backups_encontrados:
                # Ordenar por data (mais recente primeiro)
                backups_encontrados.sort(
                    key=lambda x: datetime.fromisoformat(x['data']['data_sessao']), 
                    reverse=True
                )
                
                backup_mais_recente = backups_encontrados[0]
                backup_data = backup_mais_recente['data']
                cliente_backup = backup_data.get('cliente', '')
                
                # CORREÇÃO PRINCIPAL: Validar se o cliente do backup é compatível
                if self.cliente_atual and cliente_backup and self.cliente_atual != cliente_backup:
                    # Cliente do backup é diferente do atual - perguntar ao usuário
                    resposta_cliente = custom_messagebox(
                        "yesno",
                        "⚠️ Cliente Diferente Detectado",
                        f"ATENÇÃO: Foi encontrado um backup com dados de outro cliente!\n\n"
                        f"Cliente atual selecionado: {self.cliente_atual}\n"
                        f"Cliente do backup: {cliente_backup}\n\n"
                        f"Lançamentos no backup: {len(backup_data['lancamentos'])}\n"
                        f"Data do backup: {datetime.fromisoformat(backup_data['data_sessao']).strftime('%d/%m/%Y às %H:%M:%S')}\n\n"
                        f"IMPORTANTE: Se você carregar este backup, o sistema mudará\n"
                        f"automaticamente para o cliente '{cliente_backup}'.\n\n"
                        f"Deseja continuar e mudar para o cliente do backup?"
                    )
                    
                    if not resposta_cliente:
                        # Usuário recusou - perguntar se quer remover o backup
                        if custom_messagebox("yesno", "Remover Backup", 
                                            f"Deseja remover este backup de '{cliente_backup}' "
                                            f"para não ser perguntado novamente?"):
                            try:
                                if backup_mais_recente['origem'] == 'Google Drive':
                                    backup_mais_recente['arquivo'].unlink()
                                else:
                                    os.remove(backup_mais_recente['arquivo'])
                                logger.debug(f"🗑️ Backup de cliente diferente removido")
                            except Exception as e:
                                logger.debug(f"⚠️ Erro ao remover backup: {str(e)}")
                        return False
                
                # Se chegou até aqui, pode continuar com a recuperação
                data_backup = datetime.fromisoformat(backup_data['data_sessao'])
                origem = backup_mais_recente['origem']
                estacao = backup_data.get('estacao', 'Desconhecida')
                usuario = backup_data.get('usuario', 'Desconhecido')
                total_lancamentos = backup_data.get('total_lancamentos', len(backup_data['lancamentos']))
                
                # Mensagem de confirmação melhorada
                mensagem_recuperacao = (
                    f"🔄 RECUPERAÇÃO DE DADOS DISPONÍVEL\n\n"
                    f"📋 Cliente: {cliente_backup}\n"
                    f"📊 Lançamentos: {total_lancamentos}\n"
                    f"📅 Data/Hora: {data_backup.strftime('%d/%m/%Y às %H:%M:%S')}\n"
                    f"💾 Origem: {origem}\n"
                    f"🖥️ Estação: {estacao}\n"
                    f"👤 Usuário: {usuario}\n\n"
                )
                
                # CORREÇÃO: Aviso claro sobre mudança de cliente
                if self.cliente_atual != cliente_backup:
                    mensagem_recuperacao += (
                        f"⚠️ ATENÇÃO: O sistema mudará do cliente '{self.cliente_atual}' "
                        f"para '{cliente_backup}'\n\n"
                    )
                
                mensagem_recuperacao += "Deseja recuperar estes dados?"
                
                if custom_messagebox("yesno", "Recuperação de Dados", mensagem_recuperacao):
                    
                    # Recuperar dados
                    self.dados_para_incluir = backup_data['lancamentos']
                    
                    # CORREÇÃO: Log da mudança de cliente
                    if self.cliente_atual != cliente_backup:
                        logger.debug(f"🔄 Cliente alterado: {self.cliente_atual} → {cliente_backup}")
                    
                    self.cliente_atual = cliente_backup
                    
                    # Atualizar interface
                    if self.cliente_atual:
                        self.cliente_combobox.set(self.cliente_atual)
                        self.selecionar_cliente(None)
                    
                    # Mostrar visualizador
                    self.visualizar_lancamentos()
                    
                    # Remover backup após recuperação bem-sucedida
                    try:
                        if origem == 'Google Drive':
                            backup_mais_recente['arquivo'].unlink()
                            logger.debug(f"✅ Backup removido após recuperação: {backup_mais_recente['arquivo']}")
                        else:
                            os.remove(backup_mais_recente['arquivo'])
                            logger.debug(f"✅ Backup removido após recuperação: {backup_mais_recente['arquivo']}")
                    except Exception as e:
                        logger.debug(f"⚠️ Erro ao remover backup: {str(e)}")
                    
                    custom_messagebox("info", "Recuperação Realizada", 
                                    f"✅ Dados recuperados com sucesso!\n\n"
                                    f"📊 {total_lancamentos} lançamentos carregados\n"
                                    f"📋 Cliente: {cliente_backup}\n"
                                    f"💾 Origem: {origem}")
                    
                    return True
                else:
                    # Usuário recusou recuperação - perguntar se quer remover backup
                    if custom_messagebox("yesno", "Remover Backup", 
                                        "Deseja remover este backup para não ser perguntado novamente?"):
                        try:
                            if origem == 'Google Drive':
                                backup_mais_recente['arquivo'].unlink()
                            else:
                                os.remove(backup_mais_recente['arquivo'])
                            logger.debug(f"🗑️ Backup removido por solicitação do usuário")
                        except Exception as e:
                            logger.debug(f"⚠️ Erro ao remover backup: {str(e)}")
            
            return False
            
        except Exception as e:
            logger.debug(f"❌ Erro na verificação de recuperação: {str(e)}")
            return False

    def limpar_backup(self):
        """Remove arquivos de backup - VERSÃO CORRIGIDA PARA TODOS OS FORMATOS"""
        try:
            backups_removidos = 0
            
            # LIMPAR 1: Google Drive (já estava correto)
            try:
                pasta_backup = PASTA_CLIENTES / "Backups_Sistema"
                if pasta_backup.exists() and self.cliente_atual:
                    pattern = f"backup_{self.cliente_atual}_*.json"
                    for backup_file in pasta_backup.glob(pattern):
                        try:
                            backup_file.unlink()
                            backups_removidos += 1
                            logger.debug(f"🗑️ Backup removido do Google Drive: {backup_file.name}")
                        except Exception as e:
                            logger.debug(f"⚠️ Erro ao remover backup {backup_file}: {str(e)}")
            except Exception as e:
                logger.debug(f"⚠️ Erro ao limpar backups do Google Drive: {str(e)}")
            
            # LIMPAR 2: Desktop local - CORREÇÃO: Buscar ambos os formatos
            try:
                desktop_local = os.path.expanduser("~") + "/Desktop"
                
                # Formato antigo (genérico)
                arquivo_antigo = os.path.join(desktop_local, "backup_lancamentos.json")
                if os.path.exists(arquivo_antigo):
                    os.remove(arquivo_antigo)
                    backups_removidos += 1
                    logger.debug("🗑️ Backup genérico removido do Desktop")
                
                # Formato novo (específico do cliente)
                if self.cliente_atual:
                    arquivo_novo = os.path.join(desktop_local, f"backup_{self.cliente_atual}.json")
                    if os.path.exists(arquivo_novo):
                        os.remove(arquivo_novo)
                        backups_removidos += 1
                        logger.debug(f"🗑️ Backup de {self.cliente_atual} removido do Desktop")
                        
            except Exception as e:
                logger.debug(f"⚠️ Erro ao remover backup do Desktop: {str(e)}")
            
            # LIMPAR 3: Pasta temporária - CORREÇÃO: Buscar ambos os formatos
            try:
                import tempfile
                temp_dir = tempfile.gettempdir()
                
                # Formato antigo (genérico)
                arquivo_antigo = os.path.join(temp_dir, "backup_lancamentos.json")
                if os.path.exists(arquivo_antigo):
                    os.remove(arquivo_antigo)
                    backups_removidos += 1
                    logger.debug("🗑️ Backup genérico removido da pasta temp")
                
                # Formato novo (específico do cliente)
                if self.cliente_atual:
                    arquivo_novo = os.path.join(temp_dir, f"backup_{self.cliente_atual}.json")
                    if os.path.exists(arquivo_novo):
                        os.remove(arquivo_novo)
                        backups_removidos += 1
                        logger.debug(f"🗑️ Backup de {self.cliente_atual} removido da pasta temp")
                        
            except Exception as e:
                logger.debug(f"⚠️ Erro ao remover backup da pasta temp: {str(e)}")
            
            if backups_removidos > 0:
                logger.debug(f"✅ Total de backups limpos: {backups_removidos}")
            else:
                logger.debug("ℹ️ Nenhum backup encontrado para limpeza")
                
        except Exception as e:
            logger.debug(f"❌ Erro ao limpar backup: {str(e)}")

    # MÉTODO ADICIONAL: Visualizar backups disponíveis (para debug/administração)
    def abrir_correcao_monetaria(self):
        """Abre o gerenciador de correção monetária"""
        try:
            from src.correcao_monetaria import InterfaceIndicesCorrecao
            interface = InterfaceIndicesCorrecao(self.root)
        except ImportError as e:
            custom_messagebox("error", "Erro", f"Erro ao importar módulo de correção: {str(e)}")
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir correção monetária: {str(e)}")

    def finalizar_sistema(self):
        """Finaliza o sistema de forma segura"""
        try:
            # Salvar dados pendentes se necessário
            if hasattr(self, 'dados_para_incluir') and self.dados_para_incluir:
                if hasattr(self, 'custom_messagebox'):
                    if self.custom_messagebox("yesno", "Confirmação", 
                        "Existem dados não salvos. Deseja salvá-los antes de sair?"):
                        self.enviar_dados()
            
            # Limpar backup temporário
            if hasattr(self, 'limpar_backup'):
                self.limpar_backup()
            
            # Fechar janelas filhas primeiro
            if hasattr(self, 'visualizador') and self.visualizador:
                try:
                    self.visualizador.janela.destroy()
                except:
                    pass
            
            # Fechar janela principal
            if hasattr(self, 'root') and self.root:
                try:
                    self.root.quit()  # Usar quit() ao invés de destroy()
                    self.root.destroy()
                except:
                    pass
                    
        except Exception as e:
            logger.debug(f"Aviso durante finalização: {str(e)}")

class ImportadorRH:
    def __init__(self, sistema_principal):
        self.sistema = sistema_principal
        self.pasta_rh = Path(BASE_PATH) / "Planilhas_RH"
        
        # Criar pasta se não existir
        os.makedirs(self.pasta_rh, exist_ok=True)
        
        # Mapeamento de cabeçalhos (original -> sistema)
        self.mapeamento_cabecalhos = {
            'Empresa': 'Cliente',
            'Data Pagto':'Data_Pagamento',
            'Nome Empregado': 'Nome_Empregado',
            'Valor Líquido': 'Valor_Líquido',
            'Tipo Folha': 'Tipo_Folha',
            'Forma Pagto': 'Forma_Pagamento',
            'Nome Banco': 'Nome_Banco',
            'Agência': 'Agencia',
            'N° Conta': 'Numero_Conta',
            'Dig. Conta': 'Digito_Conta',
            'Conta': 'Numero_Conta',
            'Dígito': 'Digito_Conta'
        }
        
        # Mapeamento para referências
        self.mapeamento_referencias = {
            '13º SALÁRIO': '13º SALÁRIO',
            'ADIANTAMENTO 13º SALÁRIO': '13º SALÁRIO',
            'ADIANTAMENTO': 'SALÁRIO',
            'MENSAL': 'SALÁRIO',
            'FÉRIAS': 'FÉRIAS',
            'RESCISÃO NORMAL': 'RESCISÃO',
            'RESCISÃO': 'RESCISÃO',
            '13 SALÁRIO': '13º SALÁRIO',
            '13': '13º SALÁRIO',
            'FERIAS': 'FÉRIAS'
        }

    def solicitar_etapa_obra(self):
        """
        Abre um diálogo modal para o usuário selecionar a Etapa da Obra
        que será aplicada a todos os lançamentos importados.
        
        Returns:
            str: A etapa selecionada ou None se o usuário cancelar
        """
        import tkinter as tk
        from tkinter import ttk
        
        # Criar janela de diálogo modal
        dialogo = tk.Toplevel()
        dialogo.title("Etapa da Obra - Importação de dados de RH")
        dialogo.geometry("550x220")
        
        # Tornar a janela modal
        if hasattr(self.sistema, 'root'):
            dialogo.transient(self.sistema.root)
        dialogo.grab_set()
        
        # Centralizar janela na tela
        dialogo.update_idletasks()
        largura = dialogo.winfo_width()
        altura = dialogo.winfo_height()
        x = (dialogo.winfo_screenwidth() // 2) - (largura // 2)
        y = (dialogo.winfo_screenheight() // 2) - (altura // 2)
        dialogo.geometry(f"{largura}x{altura}+{x}+{y}")
        
        # Variável para armazenar a etapa selecionada
        etapa_selecionada = {'valor': None}
        
        # Frame principal com padding
        frame = ttk.Frame(dialogo, padding="25")
        frame.pack(fill='both', expand=True)
        
        # Título explicativo
        ttk.Label(
            frame, 
            text="📋 Selecione a Etapa da Obra",
            font=('Arial', 12, 'bold')
        ).pack(pady=(0, 5))
        
        ttk.Label(
            frame, 
            text="Esta etapa será aplicada a TODOS os lançamentos importados:",
            font=('Arial', 9)
        ).pack(pady=(0, 20))
        
        # Frame para o combobox
        frame_combo = ttk.Frame(frame)
        frame_combo.pack(fill='x', pady=(0, 25))
        
        ttk.Label(
            frame_combo, 
            text="Etapa:",
            font=('Arial', 10)
        ).pack(side='left', padx=(0, 10))
        
        # Carregar etapas disponíveis
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        
        # Criar Combobox
        combo_etapa = ttk.Combobox(
            frame_combo,
            values=etapas_obra,
            font=('Arial', 10),
            width=45,
            state='normal'
        )
        combo_etapa.pack(side='left', fill='x', expand=True)
        combo_etapa.focus_set()
        
        # ===== FUNCIONALIDADE DE AUTOCOMPLETAR =====
        def autocompletar(event):
            """Filtra e completa as opções baseado no que o usuário digitou"""
            # Ignorar teclas especiais
            if event.keysym in ['BackSpace', 'Delete', 'Left', 'Right', 'Up', 'Down', 
                            'Home', 'End', 'Return', 'Tab', 'Escape']:
                return
            
            digitado = combo_etapa.get().upper()
            
            if digitado == '':
                combo_etapa['values'] = etapas_obra
                return
            
            # Filtrar etapas que começam com o texto digitado
            etapas_filtradas = [
                etapa for etapa in etapas_obra 
                if etapa.upper().startswith(digitado)
            ]
            
            if etapas_filtradas:
                # Atualizar valores
                combo_etapa['values'] = etapas_filtradas
                
                # Completar com a primeira opção
                primeira_opcao = etapas_filtradas[0]
                combo_etapa.set(primeira_opcao)
                
                # Selecionar apenas a parte que foi autocompletada
                combo_etapa.icursor(len(digitado))
                combo_etapa.selection_range(len(digitado), tk.END)
            else:
                # Se não houver match no início, buscar em qualquer parte
                etapas_filtradas = [
                    etapa for etapa in etapas_obra 
                    if digitado in etapa.upper()
                ]
                combo_etapa['values'] = etapas_filtradas if etapas_filtradas else etapas_obra
        
        def restaurar_lista(event):
            """Restaura a lista completa quando clicar no dropdown"""
            combo_etapa['values'] = etapas_obra
        
        # Bind dos eventos
        combo_etapa.bind('<KeyRelease>', autocompletar)
        combo_etapa.bind('<Button-1>', restaurar_lista)
        # ===== FIM DO AUTOCOMPLETAR =====
        
        # Frame para os botões
        frame_botoes = ttk.Frame(frame)
        frame_botoes.pack()
        
        def confirmar():
            """Valida e confirma a seleção"""
            etapa = combo_etapa.get().strip()
            
            if not etapa:
                custom_messagebox("warning", "Atenção", 
                    "Por favor, selecione ou digite uma etapa da obra.")
                combo_etapa.focus_set()
                return
            
            etapa_selecionada['valor'] = etapa
            dialogo.destroy()
        
        def cancelar():
            """Cancela a operação"""
            etapa_selecionada['valor'] = None
            dialogo.destroy()
        
        # Botões de ação
        ttk.Button(
            frame_botoes, 
            text="✓ Confirmar", 
            command=confirmar,
            width=15
        ).pack(side='left', padx=5)
        
        ttk.Button(
            frame_botoes, 
            text="✗ Cancelar", 
            command=cancelar,
            width=15
        ).pack(side='left', padx=5)
        
        # Atalhos de teclado
        combo_etapa.bind('<Return>', lambda e: confirmar())
        dialogo.bind('<Escape>', lambda e: cancelar())
        
        # Impedir fechamento pela barra de título sem passar por cancelar
        dialogo.protocol("WM_DELETE_WINDOW", cancelar)
        
        # Aguardar o fechamento da janela
        dialogo.wait_window()
        
        return etapa_selecionada['valor']
            
    def selecionar_arquivo(self):
        """Permite ao usuário selecionar um arquivo Excel de RH para importar"""
        arquivo = filedialog.askopenfilename(
            title="Selecione a planilha de RH",
            filetypes=[
                ("Todos os formatos suportados", "*.xlsx *.xls *.csv *.txt *.xlsm *.xlsb"),
                ("Arquivos Excel", "*.xlsx *.xls *.xlsm *.xlsb"),
                ("Arquivos CSV", "*.csv *.txt")
            ],
            initialdir=str(self.pasta_rh)
        )
        
        if not arquivo:
            return None
        
        # Verificar se é formato antigo do Excel (.xls)
        extensao = os.path.splitext(arquivo)[1].lower()
        if extensao == '.xls':
            # Tentar converter automaticamente
            arquivo_convertido = self.converter_xls_para_xlsx(arquivo)
            if arquivo_convertido:
                arquivo = arquivo_convertido
            else:
                # Se a conversão falhou e o usuário cancelou, retornar None
                return None
        
        # Copiar arquivo para a pasta_rh se estiver em outro local
        nome_arquivo = os.path.basename(arquivo)
        destino = self.pasta_rh / nome_arquivo
        
        if Path(arquivo) != destino:
            try:
                import shutil
                shutil.copy2(arquivo, destino)
                logger.debug(f"Arquivo copiado para {destino}")
            except Exception as e:
                logger.debug(f"Erro ao copiar arquivo: {str(e)}")
                # Continuar usando o arquivo original
                return arquivo
            
        return destino

    def converter_xls_para_xlsx(self, arquivo_origem):
        """
        Converte um arquivo XLS (Excel 97-2003) para XLSX (Excel moderno)
        Returns:
            str: Caminho do arquivo XLSX convertido ou None se falhar
        """
        logger.debug(f"Tentando converter arquivo {arquivo_origem} para formato XLSX")
        
        # Verificar se é um arquivo XLS
        extensao = os.path.splitext(arquivo_origem)[1].lower()
        if extensao != '.xls':
            logger.debug("Arquivo não é XLS, não precisa converter")
            return arquivo_origem
        
        # Criar nome para arquivo convertido
        nome_base = os.path.splitext(os.path.basename(arquivo_origem))[0]
        arquivo_destino = self.pasta_rh / f"{nome_base}_convertido.xlsx"
        
        # Método 1: Tentar usar Excel via COM (Windows)
        try:
            logger.debug("Tentando converter usando Excel via COM...")
            import win32com.client
            excel = win32com.client.Dispatch("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            
            wb = excel.Workbooks.Open(str(arquivo_origem))
            wb.SaveAs(str(arquivo_destino), FileFormat=51)  # 51 = xlOpenXMLWorkbook (*.xlsx)
            wb.Close()
            excel.Quit()
            
            logger.debug(f"Arquivo convertido com sucesso para {arquivo_destino}")
            return arquivo_destino
        except Exception as e:
            logger.debug(f"Erro ao converter usando Excel COM: {str(e)}")
        
        # Método 2: Tentar usar pandas para ler e salvar
        try:
            logger.debug("Tentando converter usando pandas...")
            df = pd.read_excel(arquivo_origem, engine='xlrd')
            df.to_excel(arquivo_destino, index=False)
            logger.debug(f"Arquivo convertido com sucesso para {arquivo_destino} usando pandas")
            return arquivo_destino
        except Exception as e:
            logger.debug(f"Erro ao converter usando pandas: {str(e)}")
        
        # Método 3: Tentar usar xlrd + openpyxl
        try:
            logger.debug("Tentando converter usando xlrd + openpyxl...")
            import xlrd
            from openpyxl import Workbook
            
            # Abrir arquivo XLS
            xls_wb = xlrd.open_workbook(arquivo_origem)
            xls_sheet = xls_wb.sheet_by_index(0)
            
            # Criar novo arquivo XLSX
            xlsx_wb = Workbook()
            xlsx_sheet = xlsx_wb.active
            
            # Copiar dados
            for row_idx in range(xls_sheet.nrows):
                for col_idx in range(xls_sheet.ncols):
                    cell_value = xls_sheet.cell_value(row_idx, col_idx)
                    xlsx_sheet.cell(row=row_idx+1, column=col_idx+1, value=cell_value)
            
            # Salvar arquivo XLSX
            xlsx_wb.save(arquivo_destino)
            logger.debug(f"Arquivo convertido com sucesso para {arquivo_destino} usando xlrd + openpyxl")
            return arquivo_destino
        except Exception as e:
            logger.debug(f"Erro ao converter usando xlrd + openpyxl: {str(e)}")
        
        # Se todas as tentativas falharem, mostrar mensagem e perguntar ao usuário
        resposta = custom_messagebox("yesno", 
            "Formato Antigo do Excel", 
            "O arquivo selecionado está no formato antigo do Excel (97-2003) e não foi possível convertê-lo automaticamente.\n\n"
            "Sugestão: Abra o arquivo no Excel e salve-o como 'Pasta de Trabalho do Excel' (.xlsx).\n\n"
            "Deseja tentar abrir o arquivo original mesmo assim?"
        )
        
        if resposta:
            return arquivo_origem
        else:
            return None

    def tentar_converter_para_csv(self, arquivo):
        """Tenta converter o arquivo para CSV usando ferramentas externas"""
        try:
            # Perguntar ao usuário se deseja tentar converter
            if not custom_messagebox("yesno", 
                "Problema de Formato", 
                "O arquivo está em um formato difícil de ler. Deseja tentar convertê-lo para CSV?\n\n"
                "Isso pode ajudar a importar arquivos com problemas de compatibilidade."
            ):
                return None
                
            # Criar um nome para o arquivo CSV de saída
            base_nome = os.path.splitext(arquivo)[0]
            csv_arquivo = f"{base_nome}_convertido.csv"
            
            # Verificar se o Excel está instalado no sistema e usar para conversão
            try:
                import win32com.client
                excel = win32com.client.Dispatch("Excel.Application")
                excel.Visible = False
                
                wb = excel.Workbooks.Open(arquivo)
                # Salvar como CSV
                wb.SaveAs(csv_arquivo, FileFormat=6)  # 6 = CSV
                wb.Close()
                excel.Quit()
                
                custom_messagebox("info", 
                    "Conversão Realizada", 
                    f"Arquivo convertido para CSV: {csv_arquivo}\n\nTentando importar novamente."
                )
                return csv_arquivo
            except Exception as e:
                logger.debug(f"Erro ao usar Excel para conversão: {str(e)}")
                
                # Se o Excel falhar, tentar com pandas
                try:
                    # Tentar ler com xlrd, que pode funcionar para versões mais antigas
                    with open(arquivo, 'rb') as file:
                        data = file.read(8)  # Lê os primeiros 8 bytes para verificar a assinatura
                    
                    # Verificar se os primeiros bytes são consistentes com XLS
                    if data[:2] == b'\xd0\xcf':  # Possível assinatura de arquivo XLS
                        import xlrd
                        wb = xlrd.open_workbook(arquivo, formatting_info=False)
                        sheet = wb.sheet_by_index(0)
                        
                        # Extrair dados
                        dados = []
                        for row_idx in range(sheet.nrows):
                            row_data = []
                            for col_idx in range(sheet.ncols):
                                cell_value = sheet.cell_value(row_idx, col_idx)
                                row_data.append(cell_value)
                            dados.append(row_data)
                        
                        # Criar DataFrame e salvar como CSV
                        df = pd.DataFrame(dados)
                        df.to_csv(csv_arquivo, index=False, header=False)
                        return csv_arquivo
                except Exception as xlrd_error:
                    logger.debug(f"Erro ao converter manualmente: {str(xlrd_error)}")
                
                custom_messagebox("error", 
                    "Erro na Conversão", 
                    "Não foi possível converter o arquivo para CSV. Tente exportar o arquivo como CSV diretamente do Excel."
                )
                return None
        except Exception as e:
            logger.debug(f"Erro geral na conversão: {str(e)}")
            return None
    
    def montar_dados_bancarios(self, row):
        """Monta os dados bancários com base na forma de pagamento"""
        forma_pagto = self.obter_valor_coluna(row, 'Forma Pagto')
        
        # Se for dinheiro, deixar em branco
        if forma_pagto and str(forma_pagto).upper() == "DINHEIRO":
            return ''
            
        # Se for PIX, usar a chave PIX se estiver disponível
        if forma_pagto and str(forma_pagto).upper() == "PIX":
            chave_pix = self.obter_valor_coluna(row, 'Tipo Conta/Chave PIX')
            if chave_pix and not pd.isna(chave_pix):
                # Tratar a chave PIX para remover prefixos desnecessários
                chave_pix_str = str(chave_pix).strip()
                
                # Verificar se contém ":" e tratar os diferentes formatos
                if ":" in chave_pix_str:
                    # Remove prefixos comuns mantendo apenas o que vem depois do ":"
                    prefixos = ["CPF:", "Celular:", "E-mail:", "Email:"]
                    
                    for prefixo in prefixos:
                        if chave_pix_str.upper().startswith(prefixo.upper()):
                            # Extrair apenas o que vem depois do ":"
                            chave_pix_str = chave_pix_str[len(prefixo):].strip()
                            break
                    
                    # Se ainda houver outros formatos com ":" não listados acima
                    if ":" in chave_pix_str and not any(prefixo.upper() in chave_pix_str.upper() for prefixo in prefixos):
                        chave_pix_str = chave_pix_str.split(":", 1)[1].strip()
                
                return f"PIX: {chave_pix_str}"
        
        # Para Crédito CC ou outros casos, montar os dados bancários
        nome_banco = self.obter_valor_coluna(row, 'Nome Banco', '')
        # Substituir CAIXA ECONÔMICA FEDERAL por CAIXA
        nome_banco_normalizado = self.normalizar_texto(str(nome_banco))
        if nome_banco and "CAIXA ECONOMICA FEDERAL" in nome_banco_normalizado:
            nome_banco = "CAIXA"
            
        # Obter e formatar agência com zeros à esquerda
        agencia_raw = self.obter_valor_coluna(row, 'Agência', '')
        
        # Limpar o valor da agência para remover possíveis decimais
        if agencia_raw:
            try:
                # Remover possíveis casas decimais e converter para inteiro
                agencia_clean = str(agencia_raw).split('.')[0]
                # Formatar com zeros à esquerda para garantir 4 dígitos
                agencia = agencia_clean.zfill(4)
            except:
                # Em caso de erro, manter o valor original
                agencia = str(agencia_raw)
        else:
            agencia = ''
        
        # Tentar diferentes nomes para o número da conta
        numero_conta_raw = self.obter_valor_coluna(row, 'N° Conta', '')
        if not numero_conta_raw:
            numero_conta_raw = self.obter_valor_coluna(row, 'Conta', '')
        
        # CORREÇÃO: Limpar número da conta (remover .0 se vier como float)
        if numero_conta_raw:
            try:
                # Remover possíveis casas decimais
                numero_conta = str(numero_conta_raw).split('.')[0]
            except:
                numero_conta = str(numero_conta_raw)
        else:
            numero_conta = ''
        
        # Tentar diferentes nomes para o dígito da conta
        digito_conta_raw = self.obter_valor_coluna(row, 'Dig. Conta', '')
        if not digito_conta_raw:
            digito_conta_raw = self.obter_valor_coluna(row, 'Dígito', '')
        
        # CORREÇÃO: Limpar dígito da conta (remover .0 se vier como float)
        if digito_conta_raw and not pd.isna(digito_conta_raw):
            try:
                # Remover possíveis casas decimais
                digito_conta = str(digito_conta_raw).split('.')[0]
            except:
                digito_conta = str(digito_conta_raw)
        else:
            digito_conta = ''
            
        # Formatar conta com dígito
        conta = f"{numero_conta}"
        if digito_conta:  # Já verificamos se não é vazio
            conta = f"{numero_conta}-{digito_conta}"
            
        # Obter CPF para incluir nos dados bancários
        cpf = self.obter_valor_coluna(row, 'CPF', '')
        
        # Formatar o CPF se não estiver formatado
        cpf_limpo = ''.join(filter(str.isdigit, str(cpf)))
        if len(cpf_limpo) == 11:
            cpf_formatado = f"{cpf_limpo[:3]}.{cpf_limpo[3:6]}.{cpf_limpo[6:9]}-{cpf_limpo[9:]}"
        else:
            cpf_formatado = cpf
        
        # Montar dados bancários
        partes = [nome_banco, agencia, conta, cpf_formatado]
        partes_filtradas = [str(p) for p in partes if p and not pd.isna(p) and str(p).strip()]
        
        if partes_filtradas:
            return ' - '.join(partes_filtradas)
        else:
            return 'DADOS BANCÁRIOS NÃO CADASTRADOS'
    
    def obter_valor_coluna(self, row, coluna_original, default=''):
        """Tenta obter o valor de uma coluna com tratamento de erro"""
        try:
            # Verificar se a coluna original existe
            if coluna_original in row:
                valor = row[coluna_original]
                if pd.isna(valor):
                    return default
                return valor
            
            # Verificar se o nome mapeado existe
            coluna_mapeada = self.mapeamento_cabecalhos.get(coluna_original)
            if coluna_mapeada and coluna_mapeada in row:
                valor = row[coluna_mapeada]
                if pd.isna(valor):
                    return default
                return valor
            
            # Verificar se alguma variação do nome da coluna existe (case insensitive)
            for col in row.index:
                if coluna_original.lower() == col.lower():
                    valor = row[col]
                    if pd.isna(valor):
                        return default
                    return valor
                    
            return default
        except:
            return default
    
    def obter_referencia(self, row):
        """Obtém a referência com base no tipo de folha"""
        tipo_folha = self.obter_valor_coluna(row, 'Tipo Folha', 'MENSAL')
        
        # Padronizar o valor (remover acentos, converter para maiúsculo)
        tipo_folha = self.normalizar_texto(tipo_folha)
        
        # Se o tipo_folha estiver no mapeamento, usá-lo
        for key, value in self.mapeamento_referencias.items():
            if self.normalizar_texto(key) == tipo_folha:
                return value
        
        # Caso contrário, usar SALÁRIO como padrão
        return 'SALÁRIO'
    
    def normalizar_texto(self, texto):
        """Normaliza um texto para facilitar comparações"""
        import unicodedata
        import re
        
        # Converter para string
        texto = str(texto).strip().upper()
        
        # Remover acentos
        texto = unicodedata.normalize('NFKD', texto)
        texto = ''.join([c for c in texto if not unicodedata.combining(c)])
        
        # Remover caracteres especiais
        texto = re.sub(r'[^\w\s]', '', texto)
        
        return texto
    
    def importar_dados(self):
        """Importa dados da planilha de RH apenas para o cliente atualmente selecionado"""
        # Verificar se há um cliente selecionado
        if not self.sistema.cliente_atual:
            custom_messagebox("error", 
                "Erro", 
                "Nenhum cliente selecionado. Por favor, selecione um cliente antes de importar dados."
            )
            return
            
        cliente_alvo = self.sistema.cliente_atual.upper()
        
        arquivo = self.selecionar_arquivo()
        if not arquivo:
            return

        dtypes_para_forcar = {
            'CPF': str,
            'N° Conta': str,
            'Dig. Conta': str,
            'Conta': str,
            'Dígito': str
        }
        
        # Tentar ler o arquivo
        try:
            # Verificar extensão do arquivo
            extensao = os.path.splitext(arquivo)[1].lower()
            
            # Tentar diferentes métodos de importação baseados na extensão e no conteúdo
            df = None
            erro_leitura = None
            
            # Se for CSV, tentar abrir diretamente
            if extensao in ['.csv', '.txt']:
                # Tentar diferentes delimitadores e encodings
                delimitadores = [',', ';', '\t']
                encodings = ['utf-8', 'latin-1', 'cp1252']
                
                for encoding in encodings:
                    for delim in delimitadores:
                        try:
                            logger.debug(f"Tentando abrir CSV com delimitador: {delim}, encoding: {encoding}")
                            df = pd.read_csv(
                                arquivo,
                                dtype=dtypes_para_forcar,  # CORREÇÃO: Adicionar dtype
                                delimiter=delim,
                                encoding=encoding
                            )
                            logger.debug(f"Sucesso ao abrir CSV com delimitador: {delim}, encoding: {encoding}")
                            break
                        except Exception as e:
                            logger.debug(f"Erro ao abrir CSV com delimitador {delim}, encoding {encoding}: {str(e)}")
                    
                    if df is not None:
                        break
            
            # Se não for CSV ou não conseguiu abrir, tentar como Excel
            if df is None and extensao in ['.xlsx', '.xls', '.xlsm', '.xlsb']:
                engines = ['openpyxl', 'xlrd']
                
                for engine in engines:
                    try:
                        logger.debug(f"Tentando abrir com engine: {engine}")
                        df = pd.read_excel(
                            arquivo,
                            dtype=dtypes_para_forcar,  # CORREÇÃO: Adicionar dtype
                            engine=engine
                        )
                        logger.debug(f"Sucesso ao abrir com engine: {engine}")
                        break
                    except Exception as e:
                        logger.debug(f"Erro ao abrir com engine {engine}: {str(e)}")
                        erro_leitura = str(e)
            
            # Se ainda não conseguiu abrir, tentar converter para CSV
            if df is None:
                csv_arquivo = self.tentar_converter_para_csv(arquivo)
                if csv_arquivo:
                    # Tentar ler o CSV convertido
                    delimitadores = [',', ';', '\t']
                    for delim in delimitadores:
                        try:
                            logger.debug(f"Tentando abrir o CSV convertido com delimitador: {delim}")
                            df = pd.read_csv(
                                csv_arquivo,
                                dtype={'CPF': str},
                                delimiter=delim,
                                encoding='utf-8'
                            )
                            logger.debug(f"Sucesso ao abrir o CSV convertido")
                            break
                        except Exception as e:
                            logger.debug(f"Erro ao abrir o CSV convertido com delimitador {delim}: {str(e)}")
                            
                    # Se ainda não funcionou, tentar com encoding latin-1
                    if df is None:
                        for delim in delimitadores:
                            try:
                                df = pd.read_csv(
                                    csv_arquivo,
                                    dtype={'CPF': str},
                                    delimiter=delim,
                                    encoding='latin-1'
                                )
                                logger.debug(f"Sucesso ao abrir o CSV convertido com encoding latin-1")
                                break
                            except Exception as e:
                                logger.debug(f"Erro ao abrir o CSV convertido com encoding latin-1: {str(e)}")
            if extensao == '.xls' and df is None:
                custom_messagebox("info", 
                    "Sugestão", 
                    "Parece que você está tentando importar um arquivo no formato Excel 97-2003 (.xls).\n\n"
                    "Este formato pode causar problemas de compatibilidade. Sugerimos abrir o arquivo no Excel e "
                    "salvá-lo como 'Pasta de Trabalho do Excel' (.xlsx) antes de importar."
                )

            # Se ainda não conseguiu abrir o arquivo, oferecer opção para selecionar outro
            if df is None:
                if custom_messagebox("yesno", 
                    "Erro de Formato", 
                    "Não foi possível abrir o arquivo. Tente salvar o arquivo como CSV no Excel e importar novamente.\n\nDeseja selecionar outro arquivo?"
                ):
                    return self.importar_dados()  # Reiniciar o processo
                else:
                    return  # Cancelar importação
            
            # Mostrar informações sobre as colunas disponíveis
            logger.debug(f"Colunas disponíveis na planilha: {df.columns.tolist()}")
            
            # Pedir ao usuário que confirme o mapeamento de colunas se necessário
            if not any(col in df.columns for col in ['Empresa', 'Cliente']):
                # Nenhuma coluna de cliente encontrada, perguntar ao usuário
                custom_messagebox("info", 
                    "Configuração Manual",
                    "Não foi possível identificar automaticamente a coluna que contém o nome do cliente.\n"
                    "Na próxima tela, selecione a coluna que contém o nome do cliente/empresa."
                )
                
                # Solicitar ao usuário que escolha a coluna para o cliente
                from tkinter import simpledialog
                coluna_cliente = simpledialog.askstring(
                    "Selecionar Coluna", 
                    f"Selecione a coluna que contém o nome do cliente entre as opções:\n\n{', '.join(df.columns.tolist())}"
                )
                
                if coluna_cliente and coluna_cliente in df.columns:
                    # Adicionar ao mapeamento temporariamente
                    self.mapeamento_cabecalhos['Empresa'] = coluna_cliente
                else:
                    custom_messagebox("info",  
                        "Coluna não encontrada",
                        "Coluna selecionada não encontrada ou inválida. Continuando com as colunas padrão."
                    )
            
            registros_processados = 0
            erros = []
            registros_lote = []
            
            # Processar linha por linha, mantendo o cliente atual
            cliente_atual = None
            cliente_encontrado = False
            
            # Determinar o número total de linhas para exibir progresso
            total_linhas = len(df)
            linhas_processadas = 0
            
            for idx, row in df.iterrows():
                linhas_processadas += 1
                
                if linhas_processadas % 10 == 0:
                    logger.debug(f"Processando linha {linhas_processadas}/{total_linhas} ({linhas_processadas/total_linhas*100:.1f}%)")
                
                # Verificar se esta linha tem um valor na coluna Empresa/Cliente (possível nome de cliente)
                empresa = self.obter_valor_coluna(row, 'Empresa')
                
                if empresa and not pd.isna(empresa):
                    # Corrigir possíveis espaços extras e converter para maiúsculas
                    empresa_limpa = str(empresa).strip().upper()
                    
                    # Ignorar linhas vazias ou com 'EMPRESA' (cabeçalho)
                    if empresa_limpa and empresa_limpa != 'EMPRESA':
                        cliente_atual = empresa_limpa
                        
                        # Verificar se é o cliente que estamos procurando
                        # Fazer comparação mais flexível, usando apenas parte do nome se necessário
                        if cliente_atual == cliente_alvo:
                            cliente_encontrado = True
                            logger.debug(f"Cliente alvo encontrado (match exato): {cliente_atual}")
                        elif cliente_atual in cliente_alvo or cliente_alvo in cliente_atual:
                            cliente_encontrado = True
                            logger.debug(f"Cliente alvo encontrado (match parcial): {cliente_atual} ≈ {cliente_alvo}")
                        else:
                            cliente_encontrado = False
                            logger.debug(f"Cliente diferente encontrado: {cliente_atual}, ignorando")
                
                # Se não for o cliente alvo, pular esta linha
                if not cliente_encontrado:
                    continue
                    
                # Obter os valores necessários
                nome = self.obter_valor_coluna(row, 'Nome Empregado', '').strip().upper()
                cpf = self.obter_valor_coluna(row, 'CPF', '').strip()
                valor_liquido = self.obter_valor_coluna(row, 'Valor Líquido')
                dt_pagto = self.obter_valor_coluna(row, 'Data Pagto')
                
                # Verificar se parece ser uma linha de cabeçalho
                if "NOME EMPREGADO" in nome or "FUNCIONARIO" in nome or "FUNCIONÁRIO" in nome:
                    logger.debug(f"Ignorando provável linha de cabeçalho: {nome}")
                    continue
                # Tentar outras colunas comuns para nome se não encontrar
                if not nome:
                    nome = self.obter_valor_coluna(row, 'Nome', '').strip().upper()
                    if not nome:
                        nome = self.obter_valor_coluna(row, 'Funcionário', '').strip().upper()
                
                # Tentar outras colunas comuns para valor líquido se não encontrar
                if pd.isna(valor_liquido):
                    valor_liquido = self.obter_valor_coluna(row, 'Líquido')
                    if pd.isna(valor_liquido):
                        valor_liquido = self.obter_valor_coluna(row, 'Valor')
                
                # Verificar se esta linha representa um funcionário (tem nome, CPF e valor)
                if not nome or not cpf or pd.isna(valor_liquido):
                    # Se falta apenas o CPF, mas tem nome e valor, gerar um aviso
                    if nome and not pd.isna(valor_liquido) and not cpf:
                        erros.append(f"Funcionário {nome} sem CPF definido")
                    continue
                    
               # Verificar se o valor é numérico
                try:
                    valor = float(str(valor_liquido).replace(',', '.'))
                except (ValueError, TypeError):
                    erros.append(f"Valor inválido para {nome}: {valor_liquido}")
                    continue
                
                # Definir data do relatório atual
                data_rel = self.sistema.data_rel_entry.get()
                if not data_rel:
                    hoje = datetime.now()
                    if 6 <= hoje.day <= 20:
                        data_rel = hoje.replace(day=20).strftime('%d/%m/%Y')
                    else:
                        if hoje.day > 20:
                            proximo_mes = (hoje.replace(day=1) + relativedelta(months=1))
                            data_rel = proximo_mes.replace(day=5).strftime('%d/%m/%Y')
                        else:
                            data_rel = hoje.replace(day=5).strftime('%d/%m/%Y')
                
                # Calcular data de vencimento
                dt_vencto = dt_pagto.strftime('%d/%m/%Y')
                
                # Obter referência com base no tipo de folha
                referencia = self.obter_referencia(row)
                
                # Montar dados bancários
                dados_bancarios = self.montar_dados_bancarios(row)
                # Agora verificamos explicitamente se está vazio
                if dados_bancarios == '':
                    dados_bancarios = ''  # Manter vazio quando for pagamento em dinheiro
                elif not dados_bancarios:
                    dados_bancarios = 'DADOS BANCÁRIOS NÃO CADASTRADOS'
                
                # Determinar forma de pagamento
                forma_pagto = self.obter_valor_coluna(row, 'Forma Pagto', 'PIX')
                forma_pagamento = 'PIX' if forma_pagto.upper() == 'PIX' else 'TED'
                
                # Formatar o CPF
                cpf_numerico = ''.join(filter(str.isdigit, str(cpf)))
                if len(cpf_numerico) == 11:
                    cpf_formatado = f"{cpf_numerico[:3]}.{cpf_numerico[3:6]}.{cpf_numerico[6:9]}-{cpf_numerico[9:]}"
                else:
                    cpf_formatado = cpf
                
                # Criar registro
                registro = {
                    'data': data_rel,
                    'cnpj_cpf': cpf_formatado,
                    'nome': nome,
                    'categoria': 'MO',
                    'tp_desp': '1',
                    'referencia': referencia,
                    'etapa_obra': '',  
                    'insumo': '',
                    'nf': '',
                    'nf': '',
                    'vr_unit': f"{valor:.2f}",
                    'dias': 1,
                    'valor': f"{valor:.2f}",
                    'dt_vencto': dt_vencto,
                    'dados_bancarios': dados_bancarios,
                    'observacao': f"IMPORTADO RH - {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
                    'forma_pagamento': forma_pagamento
                }
                
                # Adicionar à lista para incluir
                self.sistema.dados_para_incluir.append(registro)
                registros_processados += 1
            
            from src.fornecedores.conciliar_importacao import classificar_colaboradores
            from src.fornecedores.triagem_importacao_rh import TriagemImportacaoRH

            candidatos = [{'cpf': r['cnpj_cpf'], 'nome': r['nome'], 'dados_bancarios': r['dados_bancarios']}
                        for r in registros_lote]
            ok, pendencias = classificar_colaboradores(candidatos, self.sistema, origem="Folha RH")
            if pendencias:
                resultado = TriagemImportacaoRH(self.sistema.root, self.sistema, pendencias).executar()
                if resultado['cancelado']:
                    custom_messagebox("info", "Importação Cancelada", "Nenhum dado foi salvo.")
                    return
                fora = set(resultado['cpfs_excluidos'])
                registros_lote = [r for r in registros_lote
                                if ''.join(filter(str.isdigit, r['cnpj_cpf'])) not in fora]
                registros_processados = len(registros_lote)

            self.sistema.dados_para_incluir.extend(registros_lote)

            # Relatório final
            if registros_processados > 0:
                # Solicitar etapa da obra antes de finalizar
                etapa_obra = self.solicitar_etapa_obra()
                
                if etapa_obra is None:
                    # Usuário cancelou - remover todos os registros adicionados
                    self.sistema.dados_para_incluir = [
                        r for r in self.sistema.dados_para_incluir 
                        if r.get('observacao', '').find('IMPORTADO RH') == -1
                    ]
                    custom_messagebox("info", "Importação Cancelada", 
                        "A importação foi cancelada. Nenhum dado foi salvo.")
                    return
                
                # Aplicar etapa_obra a todos os registros importados
                for registro in self.sistema.dados_para_incluir:
                    if 'IMPORTADO RH' in registro.get('observacao', ''):
                        registro['etapa_obra'] = etapa_obra
                
                mensagem = (
                    f"Importação concluída!\n\n"
                    f"Registros processados: {registros_processados} para {cliente_alvo}\n"
                    f"Etapa da Obra: {etapa_obra}\n"
                )
                
                if erros:
                    mensagem += f"\nAdvertências ({len(erros)}):\n"
                    for erro in erros[:5]:  # Limitar a 5 para não sobrecarregar
                        mensagem += f"- {erro}\n"
                    if len(erros) > 5:
                        mensagem += f"- ...e mais {len(erros) - 5} advertências\n"
                
                custom_messagebox("info", "Resultado da Importação", mensagem)
                
                # Perguntar se deseja visualizar
                if custom_messagebox("yesno", 
                    "Importação RH", 
                    "Deseja visualizar os lançamentos antes de salvar?"
                ):
                    self.sistema.visualizar_lancamentos()
            else:
                custom_messagebox("warning",  
                    "Aviso",
                    f"Nenhum registro foi processado para o cliente {cliente_alvo}. Verifique se este cliente está presente na planilha."
                )
                
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao importar dados: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def importar_transporte_cafe(self):
        """
        Importa dados específicos de transporte e gera café automaticamente
        Estrutura esperada da planilha:
        - Coluna B: NOME
        - Coluna C: CPF  
        - Coluna D: DIAS
        - Coluna E: VALOR TRANSPORTE
        """
        # Verificar se há um cliente selecionado
        if not self.sistema.cliente_atual:
            custom_messagebox("error", 
                "Erro", 
                "Nenhum cliente selecionado. Por favor, selecione um cliente antes de importar dados de transporte."
            )
            return
            
        cliente_alvo = self.sistema.cliente_atual.upper()
        
        # Selecionar arquivo específico de transporte
        arquivo = filedialog.askopenfilename(
            title="Selecione a planilha de TRANSPORTE",
            filetypes=[
                ("Arquivos Excel", "*.xlsx *.xls *.xlsm *.xlsb"),
                ("Arquivos CSV", "*.csv *.txt"),
                ("Todos os formatos suportados", "*.xlsx *.xls *.csv *.txt *.xlsm *.xlsb")
            ],
            initialdir=str(self.pasta_rh)
        )
        
        if not arquivo:
            return

        try:
            # Tentar ler o arquivo
            df = None
            extensao = os.path.splitext(arquivo)[1].lower()
            
            if extensao in ['.csv', '.txt']:
                # Para CSV, tentar diferentes delimitadores
                for delim in [',', ';', '\t']:
                    try:
                        df = pd.read_csv(arquivo, dtype={'CPF': str}, delimiter=delim, encoding='utf-8')
                        break
                    except:
                        try:
                            df = pd.read_csv(arquivo, dtype={'CPF': str}, delimiter=delim, encoding='latin-1')
                            break
                        except:
                            continue
            else:
                # Para Excel
                df = pd.read_excel(arquivo, dtype={'CPF': str})
            
            if df is None:
                custom_messagebox("error", "Erro", "Não foi possível ler o arquivo. Verifique o formato.")
                return
            
            logger.debug(f"Arquivo lido com sucesso. Colunas disponíveis: {df.columns.tolist()}")
            logger.debug(f"Primeiras linhas:\n{df.head()}")
            
            # Processar dados de transporte
            registros_processados = self.processar_dados_transporte(df, cliente_alvo)
            
            if registros_processados > 0:
                # Solicitar etapa da obra antes de finalizar
                etapa_obra = self.solicitar_etapa_obra()
                
                if etapa_obra is None:
                    # Usuário cancelou - remover todos os registros adicionados
                    self.sistema.dados_para_incluir = [
                        r for r in self.sistema.dados_para_incluir 
                        if (r.get('observacao', '').find('IMPORTADO TRANSPORTE') == -1 and
                            r.get('observacao', '').find('IMPORTADO CAFÉ') == -1)
                    ]
                    custom_messagebox("info", "Importação Cancelada", 
                        "A importação foi cancelada. Nenhum dado foi salvo.")
                    return
                
                # Aplicar etapa_obra a todos os registros de transporte e café
                for registro in self.sistema.dados_para_incluir:
                    obs = registro.get('observacao', '')
                    if 'IMPORTADO TRANSPORTE' in obs or 'IMPORTADO CAFÉ' in obs:
                        registro['etapa_obra'] = etapa_obra
                
                # Calcular totais
                total_transporte = len([r for r in self.sistema.dados_para_incluir 
                                     if r.get('referencia') == 'TRANSPORTE'])
                total_cafe = len([r for r in self.sistema.dados_para_incluir 
                                if r.get('referencia') == 'CAFÉ'])
                
                mensagem = (
                    f"🚛 Importação de TRANSPORTE concluída!\n\n"
                    f"📊 Resultados:\n"
                    f"• Lançamentos de TRANSPORTE: {total_transporte}\n"
                    f"• Lançamentos de CAFÉ (automático): {total_cafe}\n"
                    f"• Total de registros: {total_transporte + total_cafe}\n\n"
                    f"👤 Cliente: {cliente_alvo}\n"
                    f"🏗️ Etapa: {etapa_obra}"
                )
                
                custom_messagebox("info", "Sucesso na Importação", mensagem)
                
                # Perguntar se deseja visualizar
                if custom_messagebox("yesno", 
                    "Visualizar Lançamentos", 
                    "Deseja visualizar os lançamentos antes de salvar?"
                ):
                    self.sistema.visualizar_lancamentos()

            else:
                custom_messagebox("warning", 
                    "Nenhum Registro", 
                    f"Nenhum registro de transporte foi processado.\n\n"
                    f"Verifique se:\n"
                    f"• As colunas estão corretas (B=NOME, C=CPF, D=DIAS, E=VALOR)\n"
                    f"• Os dados não estão vazios\n"
                    f"• O formato do arquivo está correto"
                )
                    
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao importar dados de transporte: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def processar_dados_transporte(self, df, cliente_alvo):
        """
        Processa os dados da planilha de transporte
        Retorna o número de registros processados
        """
        registros_processados = 0
        erros = []
        registros_lote = []
        
        logger.debug(f"Iniciando processamento de {len(df)} linhas para transporte...")
        
        # Calcular data de referência baseada na regra do sistema
        data_rel = self.calcular_data_referencia_transporte()
        logger.debug(f"Data de referência calculada: {data_rel}")
        
        # Processar linha por linha
        for idx, row in df.iterrows():
            try:
                # Extrair dados das colunas específicas
                nome = self.extrair_valor_coluna_transporte(row, 'B', 1)  # Coluna B (índice 1)
                cpf = self.extrair_valor_coluna_transporte(row, 'C', 2)   # Coluna C (índice 2)
                dias = self.extrair_valor_coluna_transporte(row, 'D', 3)  # Coluna D (índice 3)
                valor_transporte = self.extrair_valor_coluna_transporte(row, 'E', 4)  # Coluna E (índice 4)
                
                logger.debug(f"Linha {idx}: Nome={nome}, CPF={cpf}, Dias={dias}, Valor={valor_transporte}")
                
                # Validar dados obrigatórios
                if not nome or not cpf or not dias or not valor_transporte:
                    if nome:  # Se tem nome mas falta outros dados
                        erros.append(f"Linha {idx+1}: {nome} - dados incompletos")
                    continue
                
                # Limpar e validar nome
                nome_limpo = str(nome).strip().upper()
                if not nome_limpo or nome_limpo in ['NOME', 'FUNCIONARIO', 'FUNCIONÁRIO']:
                    continue  # Pular cabeçalhos
                
                # Limpar e validar CPF
                cpf_numeros = ''.join(filter(str.isdigit, str(cpf)))
                if len(cpf_numeros) != 11:
                    erros.append(f"Linha {idx+1}: {nome_limpo} - CPF inválido: {cpf}")
                    continue
                
                # Formatar CPF
                cpf_formatado = f"{cpf_numeros[:3]}.{cpf_numeros[3:6]}.{cpf_numeros[6:9]}-{cpf_numeros[9:]}"
                
                # Validar dias
                try:
                    dias_int = int(float(str(dias).replace(',', '.')))
                    if dias_int <= 0:
                        erros.append(f"Linha {idx+1}: {nome_limpo} - Dias inválido: {dias}")
                        continue
                except (ValueError, TypeError):
                    erros.append(f"Linha {idx+1}: {nome_limpo} - Dias não numérico: {dias}")
                    continue
                
                # Validar valor do transporte (valor unitário)
                try:
                    vr_unit_float = float(str(valor_transporte).replace(',', '.'))
                    if vr_unit_float <= 0:
                        erros.append(f"Linha {idx+1}: {nome_limpo} - Valor unitário inválido: {valor_transporte}")
                        continue
                except (ValueError, TypeError):
                    erros.append(f"Linha {idx+1}: {nome_limpo} - Valor unitário não numérico: {valor_transporte}")
                    continue
                
                # CORREÇÃO: Calcular valor total = vr_unit * dias
                valor_total = vr_unit_float * dias_int
                
                # Buscar dados bancários do funcionário
                dados_bancarios = self.buscar_dados_bancarios_funcionario(cpf_formatado)
                
                # Criar registro de TRANSPORTE
                registro_transporte = {
                    'data': data_rel,
                    'cnpj_cpf': cpf_formatado,
                    'nome': nome_limpo,
                    'categoria': 'MO',
                    'tp_desp': '1',
                    'referencia': 'TRANSPORTE',
                    'etapa_obra': '',  # Será preenchido após seleção do usuário
                    'insumo': '',
                    'nf': '',
                    'vr_unit': f"{vr_unit_float:.2f}",
                    'dias': dias_int,
                    'valor': f"{valor_total:.2f}",
                    'dt_vencto': data_rel,
                    'dados_bancarios': '',
                    'observacao': f"IMPORTADO TRANSPORTE - {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
                    'forma_pagamento': 'PIX'
                }
                
                # Adicionar registro de transporte
                registros_lote.append(registro_transporte)
                registros_processados += 1
                
                logger.debug(f"✅ Registro de TRANSPORTE criado para {nome_limpo}")
                
                # CORREÇÃO: Criar registro de CAFÉ manualmente (replicando a lógica existente)
                try:
                    # Buscar valor do café nas configurações (igual ao método adicionar_dados)
                    from src.configuracoes_sistema import GerenciadorConfiguracoes
                    config = GerenciadorConfiguracoes.carregar_configuracoes()
                    
                    if config and 'cafe' in config and 'valor_atual' in config['cafe']:
                        vr_unit_cafe = float(config['cafe']['valor_atual'])
                    else:
                        vr_unit_cafe = 4.0  # Valor padrão caso não encontre configuração
                        
                    valor_cafe_total = vr_unit_cafe * dias_int
                    
                    # Criar dados do lançamento do CAFÉ (copiando estrutura do transporte)
                    dados_cafe = registro_transporte.copy()
                    dados_cafe.update({
                        'referencia': 'CAFÉ',
                        'vr_unit': f"{vr_unit_cafe:.2f}",
                        'valor': f"{valor_cafe_total:.2f}",
                        'observacao': f"IMPORTADO CAFÉ (AUTO) - {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
                    })
                    
                    registros_lote.append(dados_cafe)
                    logger.debug(f"✅ Registro de CAFÉ criado para {nome_limpo} - {dias_int} dias × R$ {vr_unit_cafe:.2f} = R$ {valor_cafe_total:.2f}")
                    
                except Exception as e:
                    logger.debug(f"⚠️ Erro ao criar CAFÉ para {nome_limpo}: {str(e)}")
                    # Continuar processamento mesmo se café falhar
                
                # IMPORTANTE: Agora tanto TRANSPORTE quanto CAFÉ são criados na importação
                
            except Exception as e:
                erro_msg = f"Linha {idx+1}: Erro ao processar - {str(e)}"
                erros.append(erro_msg)
                logger.debug(f"❌ {erro_msg}")
                continue
        
        # Mostrar erros se houver
        if erros:
            logger.debug(f"\n⚠️ Encontrados {len(erros)} erros:")
            for erro in erros[:10]:
                logger.debug(f"  - {erro}")
            if len(erros) > 10:
                logger.debug(f"  - ... e mais {len(erros) - 10} erros")

        # ===== TRIAGEM DE FORNECEDORES (NOVO) =====
        from src.fornecedores.conciliar_importacao import classificar_colaboradores
        from src.fornecedores.triagem_importacao_rh import TriagemImportacaoRH

        # Um candidato por CPF único basta — não precisa duplicar TRANSPORTE e CAFÉ,
        # classificar_colaboradores já consolida repetições internamente, mas aqui
        # já filtramos para não montar a lista maior à toa.
        candidatos = [
            {'cpf': r['cnpj_cpf'], 'nome': r['nome'], 'dados_bancarios': r.get('dados_bancarios', '')}
            for r in registros_lote if r.get('referencia') == 'TRANSPORTE'
        ]
        ok, pendencias = classificar_colaboradores(candidatos, self.sistema, origem="Transporte")

        if pendencias:
            resultado = TriagemImportacaoRH(self.sistema.root, self.sistema, pendencias).executar()
            if resultado['cancelado']:
                custom_messagebox("info", "Importação Cancelada",
                    "A importação de transporte foi cancelada. Nenhum dado foi salvo.")
                return 0

            fora = set(resultado['cpfs_excluidos'])
            registros_lote = [
                r for r in registros_lote
                if ''.join(filter(str.isdigit, r['cnpj_cpf'])) not in fora
            ]
        # ===== FIM DA TRIAGEM =====

        self.sistema.dados_para_incluir.extend(registros_lote)

        logger.debug(f"✅ Processamento concluído: {len(registros_lote)} registros de transporte/café criados")
        return len(registros_lote)

    def extrair_valor_coluna_transporte(self, row, letra_coluna, indice):
        """
        Extrai valor de uma coluna específica por letra (B, C, D, E) ou índice
        """
        try:
            # Primeiro tentar por letra da coluna se o DataFrame tem colunas nomeadas assim
            if hasattr(row, 'index') and letra_coluna in row.index:
                valor = row[letra_coluna]
            # Tentar por índice numérico
            elif hasattr(row, 'iloc') and len(row) > indice:
                valor = row.iloc[indice]
            # Se row for uma Series com índices numéricos
            elif len(row) > indice:
                valor = row.iloc[indice] if hasattr(row, 'iloc') else row[indice]
            else:
                return None
            
            # Tratar valores NaN ou vazios
            if pd.isna(valor) or valor == '':
                return None
                
            return valor
            
        except Exception as e:
            logger.debug(f"Erro ao extrair coluna {letra_coluna} (índice {indice}): {str(e)}")
            return None

    def calcular_data_referencia_transporte(self):
        """
        Calcula a data de referência baseada na regra: dia 5 ou 20
        """
        hoje = datetime.now()
        
        if 6 <= hoje.day <= 20:
            # Se estivermos entre dia 6 e 20, a referência é dia 20 do mesmo mês
            data_rel = hoje.replace(day=20)
        else:
            if hoje.day > 20:
                # Se estivermos após dia 20, a referência é dia 5 do próximo mês
                proximo_mes = (hoje.replace(day=1) + relativedelta(months=1))
                data_rel = proximo_mes.replace(day=5)
            else:
                # Se estivermos antes do dia 6, a referência é dia 5 do mesmo mês
                data_rel = hoje.replace(day=5)
        
        return data_rel.strftime('%d/%m/%Y')

    def buscar_dados_bancarios_funcionario(self, cpf):
        """
        Busca dados bancários do funcionário na base de fornecedores
        """
        try:
            # Usar a função existente do sistema
            if hasattr(self.sistema, 'buscar_fornecedor_completo'):
                fornecedor = self.sistema.buscar_fornecedor_completo(cpf)
                if fornecedor:
                    # Preferir PIX se disponível
                    if fornecedor.get('chave_pix'):
                        return f"PIX: {fornecedor['chave_pix']}"
                    else:
                        # Montar dados bancários para TED
                        partes = []
                        if fornecedor.get('banco'): partes.append(str(fornecedor['banco']))
                        if fornecedor.get('op'): partes.append(str(fornecedor['op']))
                        if fornecedor.get('agencia'): partes.append(str(fornecedor['agencia']))
                        if fornecedor.get('conta'): partes.append(str(fornecedor['conta']))
                        partes.append(cpf)  # Sempre adicionar CPF

                        return ' - '.join(partes) if partes else 'DADOS BANCÁRIOS NÃO CADASTRADOS'

            return 'DADOS BANCÁRIOS NÃO CADASTRADOS'

        except Exception as e:
            logger.debug(f"Erro ao buscar dados bancários para {cpf}: {str(e)}")
            return 'DADOS BANCÁRIOS NÃO CADASTRADOS'

    def importar_diarias(self):
        """
        Importa dados de DIÁRIA de colaboradores.
        Processa TODAS as abas do arquivo Excel. Em cada aba, detecta automaticamente
        as colunas pelo nome do cabeçalho. Suporta planilhas com ou sem coluna CPF
        e com número variável de colunas de presença diária. Quando não há coluna
        CPF, tenta extrair o número a partir do campo Dados Bancários.
        """
        import unicodedata
        import re

        def _norm(texto):
            s = unicodedata.normalize('NFKD', str(texto))
            return ''.join(c for c in s if not unicodedata.combining(c)).strip().upper()

        def _extrair_cpf_banco(texto):
            # Formato pontilhado: 123.456.789-00
            m = re.search(r'\d{3}\.\d{3}\.\d{3}-\d{2}', texto)
            if m:
                return ''.join(filter(str.isdigit, m.group()))
            # Após keyword CPF com pontuação variada: CPF.:11111111111 / CPF: 11111111111
            m = re.search(r'CPF\s*[.:]*\s*(\d{11})', texto, re.IGNORECASE)
            if m:
                return m.group(1)
            return None

        def _processar_aba(df, nome_aba, timestamp, data_rel):
            """Processa uma aba e retorna (registros_novos, erros_aba)."""
            registros = []
            erros = []

            # Localizar linha de cabeçalho
            header_row_idx = None
            for i, row in df.iterrows():
                vals = [_norm(v) for v in row if not pd.isna(v)]
                if any(v in ('COLABORADOR', 'CPF') for v in vals) and \
                   any('VALOR' in v and 'DI' in v for v in vals):
                    header_row_idx = i
                    break

            if header_row_idx is None:
                logger.debug(f"Aba '{nome_aba}': cabeçalho não encontrado, ignorada")
                return registros, erros

            # Mapear colunas pelo cabeçalho
            header = df.iloc[header_row_idx]
            col_map = {}
            for ci, val in enumerate(header):
                if pd.isna(val):
                    continue
                vn = _norm(val)
                if vn == 'CPF':
                    col_map['cpf'] = ci
                elif vn in ('COLABORADOR', 'NOME', 'NOME EMPREGADO'):
                    col_map['nome'] = ci
                elif 'VALOR' in vn and 'DI' in vn:
                    col_map['vr_unit'] = ci
                elif vn == 'T':
                    col_map['dias'] = ci
                elif vn == 'TOTAL':
                    col_map['total'] = ci
                elif 'DADOS BANC' in vn or 'CONTA BANC' in vn:
                    col_map['dados_bancarios'] = ci
                elif 'DATA' in vn and 'PAG' in vn:          # <<< NOVO
                    col_map['dt_vencto'] = ci 

            faltando = [c for c in ('nome', 'vr_unit', 'dias', 'dt_vencto') if c not in col_map]
            if faltando:
                logger.debug(f"Aba '{nome_aba}': colunas obrigatórias ausentes {faltando}, ignorada")
                return registros, erros

            logger.debug(f"Aba '{nome_aba}': col_map={col_map}")

            for idx, row in df.iterrows():
                if idx < header_row_idx + 2:
                    continue

                try:
                    def _cel(ci):
                        if ci < 0 or ci >= len(row):
                            return None
                        v = row.iloc[ci]
                        if pd.isna(v) or str(v).strip() in ('', 'nan', 'NaN', 'NaT'):
                            return None
                        return v

                    nome_raw = _cel(col_map['nome'])
                    if not nome_raw:
                        continue
                    nome_limpo = str(nome_raw).strip().upper()
                    if nome_limpo in ('COLABORADOR', 'NOME', 'FUNCIONARIO', 'FUNCIONÁRIO'):
                        continue

                    vr_unit_raw = _cel(col_map['vr_unit'])
                    dias_raw = _cel(col_map['dias'])

                    if not vr_unit_raw:
                        erros.append(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - valor diária ausente")
                        continue
                    if not dias_raw:
                        logger.debug(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - dias ausentes, ignorado")
                        continue

                    try:
                        vr_unit_float = float(str(vr_unit_raw).replace(',', '.'))
                        if vr_unit_float <= 0:
                            erros.append(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - valor inválido")
                            continue
                    except (ValueError, TypeError):
                        erros.append(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - valor não numérico")
                        continue

                    try:
                        dias_int = float(str(dias_raw).replace(',', '.'))
                        if dias_int <= 0:
                            logger.debug(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - 0 dias, ignorado")
                            continue
                    except (ValueError, TypeError):
                        erros.append(f"[{nome_aba}] Linha {idx+1}: {nome_limpo} - dias não numérico")
                        continue

                    # Data de vencimento: usa DATA PAGTO da planilha; fallback = data_rel
                    dt_vencto_val = data_rel                                     
                    if 'dt_vencto' in col_map:                                   # <<< NOVO
                        dt_raw = _cel(col_map['dt_vencto'])                      # <<< NOVO
                        if dt_raw:                                                # <<< NOVO
                            try:                                                  # <<< NOVO
                                import datetime as _dt                            # <<< NOVO
                                # pandas pode entregar string ou Timestamp        # <<< NOVO
                                if hasattr(dt_raw, 'strftime'):                   # <<< NOVO
                                    dt_vencto_val = dt_raw.strftime('%d/%m/%Y')  # <<< NOVO
                                else:                                             # <<< NOVO
                                    parsed = _dt.datetime.strptime(              # <<< NOVO
                                        str(dt_raw)[:10], '%Y-%m-%d')            # <<< NOVO
                                    dt_vencto_val = parsed.strftime('%d/%m/%Y')  # <<< NOVO
                            except Exception:                                     # <<< NOVO
                                pass  # mantém data_rel como fallback 

                    dados_bancarios = ''
                    if 'dados_bancarios' in col_map:
                        db_raw = _cel(col_map['dados_bancarios'])
                        if db_raw:
                            dados_bancarios = str(db_raw).strip()

                    cpf_formatado = ''
                    if 'cpf' in col_map:
                        cpf_raw = _cel(col_map['cpf'])
                        if cpf_raw:
                            cpf_n = ''.join(filter(str.isdigit, str(cpf_raw)))
                            if len(cpf_n) == 11:
                                cpf_formatado = f"{cpf_n[:3]}.{cpf_n[3:6]}.{cpf_n[6:9]}-{cpf_n[9:]}"
                    if not cpf_formatado and dados_bancarios:
                        cpf_n = _extrair_cpf_banco(dados_bancarios) or ''
                        if len(cpf_n) == 11:
                            cpf_formatado = f"{cpf_n[:3]}.{cpf_n[3:6]}.{cpf_n[6:9]}-{cpf_n[9:]}"

                    registros.append({
                        'data': data_rel,
                        'cnpj_cpf': cpf_formatado,
                        'nome': nome_limpo,
                        'categoria': 'MO',
                        'tp_desp': '1',
                        'referencia': 'DIÁRIA',
                        'etapa_obra': '',
                        'insumo': '',
                        'nf': '',
                        'vr_unit': f"{vr_unit_float:.2f}",
                        'dias': dias_int,
                        'valor': f"{vr_unit_float * dias_int:.2f}",
                        'dt_vencto': dt_vencto_val,
                        'dados_bancarios': dados_bancarios,
                        'observacao': f"IMPORTADO DIARIAS - {timestamp}",
                        'forma_pagamento': 'PIX'
                    })
                    logger.debug(
                        f"✅ [{nome_aba}] {nome_limpo} | CPF={cpf_formatado or '?'} | "
                        f"{dias_int}d × R${vr_unit_float:.2f}"
                    )

                except Exception as e:
                    erros.append(f"[{nome_aba}] Linha {idx+1}: Erro - {str(e)}")
                    logger.debug(f"❌ [{nome_aba}] Linha {idx+1}: {str(e)}")

            return registros, erros

        # --- início do método principal ---

        if not self.sistema.cliente_atual:
            custom_messagebox("error", "Erro",
                "Nenhum cliente selecionado. Por favor, selecione um cliente antes de importar diárias.")
            return

        arquivo = filedialog.askopenfilename(
            title="Selecione a planilha de DIÁRIAS",
            filetypes=[
                ("Arquivos Excel", "*.xlsx *.xls *.xlsm *.xlsb"),
                ("Todos os formatos suportados", "*.xlsx *.xls *.xlsm *.xlsb")
            ],
            initialdir=str(self.pasta_rh)
        )

        if not arquivo:
            return

        try:
            xl = pd.ExcelFile(arquivo)
            timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
            data_rel = self.calcular_data_referencia_transporte()
            todos_registros = []
            todos_erros = []

            for nome_aba in xl.sheet_names:
                df = pd.read_excel(xl, sheet_name=nome_aba, header=None, dtype=str)
                regs, errs = _processar_aba(df, nome_aba, timestamp, data_rel)
                todos_registros.extend(regs)
                todos_erros.extend(errs)

            for erro in todos_erros[:10]:
                logger.debug(f"  ⚠️ {erro}")

            candidatos = [{'cpf': r['cnpj_cpf'], 'nome': r['nome'], 'dados_bancarios': r['dados_bancarios']}
                        for r in todos_registros]
            ok, pendencias = classificar_colaboradores(candidatos, self.sistema, origem="Diárias")
            if pendencias:
                resultado = TriagemImportacaoRH(self.sistema.root, self.sistema, pendencias).executar()
                if resultado['cancelado']:
                    custom_messagebox("info", "Importação Cancelada", "Nenhum dado foi salvo.")
                    return
                fora = set(resultado['cpfs_excluidos'])
                todos_registros = [r for r in todos_registros
                                    if ''.join(filter(str.isdigit, r['cnpj_cpf'])) not in fora]
            
            if not todos_registros:
                custom_messagebox("warning", "Nenhum Registro",
                    "Nenhum registro de diárias foi encontrado no arquivo.\n\n"
                    "Verifique se as abas contêm dados e se o cabeçalho está correto.")
                return

            for r in todos_registros:
                self.sistema.dados_para_incluir.append(r)

            etapa_obra = self.solicitar_etapa_obra()

            if etapa_obra is None:
                self.sistema.dados_para_incluir = [
                    r for r in self.sistema.dados_para_incluir
                    if 'IMPORTADO DIARIAS' not in r.get('observacao', '')
                ]
                custom_messagebox("info", "Importação Cancelada",
                    "A importação foi cancelada. Nenhum dado foi salvo.")
                return

            for r in self.sistema.dados_para_incluir:
                if 'IMPORTADO DIARIAS' in r.get('observacao', ''):
                    r['etapa_obra'] = etapa_obra

            sem_cpf = sum(1 for r in todos_registros if not r.get('cnpj_cpf'))
            avisos = ''
            if sem_cpf:
                avisos += f"\n\n⚠️ {sem_cpf} registro(s) sem CPF identificado — verifique os dados bancários."
            if todos_erros:
                avisos += f"\n⚠️ {len(todos_erros)} linha(s) ignorada(s)."

            custom_messagebox("info", "Sucesso na Importação",
                f"📋 Importação de DIÁRIAS concluída!\n\n"
                f"📊 Resultados:\n"
                f"• Lançamentos de DIÁRIA: {len(todos_registros)}\n"
                f"• Abas processadas: {len(xl.sheet_names)}\n\n"
                f"👤 Cliente: {self.sistema.cliente_atual.upper()}\n"
                f"🏗️ Etapa: {etapa_obra}"
                f"{avisos}"
            )

            if custom_messagebox("yesno", "Visualizar Lançamentos",
                "Deseja visualizar os lançamentos antes de salvar?"):
                self.sistema.visualizar_lancamentos()

        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao importar diárias: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

class GerenciadorLancamentos:
    def __init__(self, sistema_principal):
        self.sistema = sistema_principal
        self.janela = None
        self.tree_lancamentos = None
        self.dados_originais = []

        # Variáveis para controle de busca
        self.entry_busca = None
        self.label_resultados = None
        self.ultimo_termo_busca = ""

        # Armazenar TODOS os IDs dos itens
        self.todos_itens_tree = []

        self._itens_marcados = set()

        self.gestor_taxas = GestorTaxasAdministracao(sistema_principal)
        self.preferencias_ordenacao = self.carregar_preferencias_ordenacao()
        
    def abrir_gerenciador(self):
        """Abre a janela de gerenciamento de lançamentos"""
        if not self.sistema.cliente_atual:
            custom_messagebox("error", "Erro", "Selecione um cliente primeiro!")
            return
            
        self.janela = tk.Toplevel(self.sistema.root)
        self.janela.title(f"Gerenciar Lançamentos - {self.sistema.cliente_atual}")
        self.janela.geometry("1000x700")
        
        # Configurar janela
        self.janela.transient(self.sistema.root)
        self.janela.grab_set()
        
        self.criar_interface()
        self.carregar_lancamentos()
        
    def criar_interface(self):
        """Cria a interface do gerenciador - VERSÃO COM EXCLUSÃO EM LOTE"""
        main_frame = ttk.Frame(self.janela, padding="10")
        main_frame.pack(fill='both', expand=True)

        # ── Busca Rápida ─────────────────────────────────────────────────────────
        frame_busca = ttk.LabelFrame(main_frame, text="🔍 Busca Rápida")
        frame_busca.pack(fill='x', pady=(0, 5))

        frame_busca_interno = ttk.Frame(frame_busca)
        frame_busca_interno.pack(fill='x', padx=10, pady=8)

        ttk.Label(frame_busca_interno, text="Buscar:",
                font=('TkDefaultFont', 9, 'bold')).pack(side='left', padx=(0, 5))

        self.entry_busca = ttk.Entry(frame_busca_interno, width=50)
        self.entry_busca.pack(side='left', padx=5, fill='x', expand=True)

        self.label_resultados = ttk.Label(
            frame_busca_interno,
            text="Digite para buscar em Referência, Nome, NF e Observação",
            font=('TkDefaultFont', 8, 'italic'),
            foreground='gray'
        )
        self.label_resultados.pack(side='left', padx=(10, 5))

        ttk.Button(frame_busca_interno, text="✖ Limpar",
                command=self.limpar_busca, width=10).pack(side='left', padx=5)

        self.entry_busca.bind('<KeyRelease>', self.buscar_texto_evento)
        self.entry_busca.bind('<Return>', lambda e: self.aplicar_filtros())

        # ── Filtros ───────────────────────────────────────────────────────────────
        frame_filtros = ttk.LabelFrame(main_frame, text="Filtros")
        frame_filtros.pack(fill='x', pady=(0, 10))

        frame_filtros_linha1 = ttk.Frame(frame_filtros)
        frame_filtros_linha1.pack(fill='x', padx=5, pady=5)

        ttk.Label(frame_filtros_linha1, text="Data Início:").pack(side='left', padx=(0, 5))
        self.data_inicio = DateEntry(frame_filtros_linha1, width=12,
                                    date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_inicio.pack(side='left', padx=(0, 10))

        ttk.Label(frame_filtros_linha1, text="Data Fim:").pack(side='left', padx=(0, 5))
        self.data_fim = DateEntry(frame_filtros_linha1, width=12,
                                date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_fim.pack(side='left', padx=(0, 10))

        self.inicializar_datas_padrao()

        ttk.Label(frame_filtros_linha1, text="Status:").pack(side='left', padx=(0, 5))
        self.combo_status = ttk.Combobox(
            frame_filtros_linha1,
            values=['Todos', 'Ativos', 'Excluídos'],
            state='readonly', width=10
        )
        self.combo_status.set('Ativos')
        self.combo_status.pack(side='left', padx=(0, 10))

        ttk.Button(frame_filtros_linha1, text="Filtrar",
                command=self.filtrar_com_feedback).pack(side='left', padx=5)

        # ── Ordenação ─────────────────────────────────────────────────────────────
        frame_ordenacao = ttk.Frame(frame_filtros)
        frame_ordenacao.pack(fill='x', padx=5, pady=(0, 5))

        ttk.Label(frame_ordenacao, text="🔽 Ordenar por:",
                font=('TkDefaultFont', 9, 'bold')).pack(side='left', padx=(0, 10))

        ttk.Label(frame_ordenacao, text="1º:").pack(side='left', padx=(0, 5))
        self.combo_ordem_1 = ttk.Combobox(
            frame_ordenacao,
            values=['Data', 'Nome', 'Referência', 'Valor', 'Vencimento', 'Tipo'],
            state='readonly', width=12
        )
        self.combo_ordem_1.set('Data')
        self.combo_ordem_1.pack(side='left', padx=(0, 5))

        self.combo_direcao_1 = ttk.Combobox(
            frame_ordenacao,
            values=['↑ Crescente', '↓ Decrescente'],
            state='readonly', width=12
        )
        self.combo_direcao_1.set('↑ Crescente')
        self.combo_direcao_1.pack(side='left', padx=(0, 15))

        ttk.Label(frame_ordenacao, text="2º:").pack(side='left', padx=(0, 5))
        self.combo_ordem_2 = ttk.Combobox(
            frame_ordenacao,
            values=['Nenhum', 'Data', 'Nome', 'Referência', 'Valor', 'Vencimento', 'Tipo'],
            state='readonly', width=12
        )
        self.combo_ordem_2.set('Nome')
        self.combo_ordem_2.pack(side='left', padx=(0, 5))

        self.combo_direcao_2 = ttk.Combobox(
            frame_ordenacao,
            values=['↑ Crescente', '↓ Decrescente'],
            state='readonly', width=12
        )
        self.combo_direcao_2.set('↑ Crescente')
        self.combo_direcao_2.pack(side='left', padx=(0, 15))

        ttk.Label(frame_ordenacao, text="3º:").pack(side='left', padx=(0, 5))
        self.combo_ordem_3 = ttk.Combobox(
            frame_ordenacao,
            values=['Nenhum', 'Data', 'Nome', 'Referência', 'Valor', 'Vencimento', 'Tipo'],
            state='readonly', width=12
        )
        self.combo_ordem_3.set('Valor')
        self.combo_ordem_3.pack(side='left', padx=(0, 5))

        self.combo_direcao_3 = ttk.Combobox(
            frame_ordenacao,
            values=['↑ Crescente', '↓ Decrescente'],
            state='readonly', width=12
        )
        self.combo_direcao_3.set('↓ Decrescente')
        self.combo_direcao_3.pack(side='left', padx=(0, 15))

        frame_botoes_ordenacao = ttk.Frame(frame_ordenacao)
        frame_botoes_ordenacao.pack(side='left', padx=5)

        ttk.Button(frame_botoes_ordenacao, text="📊 Aplicar",
                command=self.aplicar_ordenacao_e_salvar,
                width=10).pack(side='left', padx=2)

        ttk.Button(frame_botoes_ordenacao, text="🔄 Padrão",
                command=self.restaurar_ordenacao_padrao,
                width=10).pack(side='left', padx=2)

        self.var_destacar_duplicatas = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            frame_ordenacao,
            text="⚠️ Destacar possíveis duplicatas",
            variable=self.var_destacar_duplicatas,
            command=self.aplicar_ordenacao_e_salvar
        ).pack(side='left', padx=10)

        self.aplicar_preferencias_ordenacao()

        # ── Treeview ──────────────────────────────────────────────────────────────
        frame_lista = ttk.Frame(main_frame)
        frame_lista.pack(fill='both', expand=True)

        colunas = ('✓', 'Data', 'Tipo', 'Nome', 'Referência', 'NF',
                'Valor', 'Vencimento', 'Status', 'ID')

        self.tree_lancamentos = ttk.Treeview(
            frame_lista, columns=colunas, show='headings',
            height=20, selectmode='extended'
        )

        col_config = {
            '✓':          (28,  False, 'center'),
            'ID':         (0,   False, 'center'),
            'Data':       (70,  False, 'center'),
            'Vencimento': (70,  False, 'center'),
            'Tipo':       (35,  False, 'center'),
            'Valor':      (100, False, 'e'),
            'NF':         (70,  False, 'center'),
            'Status':     (75,  False, 'center'),
            'Nome':       (200, True,  'w'),
            'Referência': (200, True,  'w'),
        }

        for col in colunas:
            largura, stretch, ancora = col_config.get(col, (100, True, 'w'))
            self.tree_lancamentos.heading(col, text=col)
            self.tree_lancamentos.column(col, width=largura, stretch=stretch, anchor=ancora)

        self.tree_lancamentos.column('ID', width=0, minwidth=0, stretch=False)

        scrolly = ttk.Scrollbar(frame_lista, orient='vertical',
                                command=self.tree_lancamentos.yview)
        scrollx = ttk.Scrollbar(frame_lista, orient='horizontal',
                                command=self.tree_lancamentos.xview)
        self.tree_lancamentos.configure(yscrollcommand=scrolly.set,
                                        xscrollcommand=scrollx.set)

        self.tree_lancamentos.grid(row=0, column=0, sticky='nsew')
        scrolly.grid(row=0, column=1, sticky='ns')
        scrollx.grid(row=1, column=0, sticky='ew')

        frame_lista.grid_rowconfigure(0, weight=1)
        frame_lista.grid_columnconfigure(0, weight=1)

        # ── Botões e totalizadores ────────────────────────────────────────────────
        # ATENÇÃO: frame_botoes deve ser criado ANTES de frame_selecao
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))

        # --- Linha de seleção e totalizadores ------------------------------------
        frame_selecao = ttk.Frame(frame_botoes)
        frame_selecao.pack(fill='x', pady=(0, 5))

        frame_info_selecao = ttk.Frame(frame_selecao)
        frame_info_selecao.pack(side='left', fill='x', expand=True)

        # Quantidade selecionada
        self.label_selecao = ttk.Label(
            frame_info_selecao,
            text="Nenhum item selecionado",
            font=('TkDefaultFont', 9, 'italic')
        )
        self.label_selecao.pack(side='left', padx=(0, 15))

        # Somatório dos selecionados (verde)
        self.label_somatorio = ttk.Label(
            frame_info_selecao,
            text="",
            font=('TkDefaultFont', 10, 'bold'),
            foreground='#006400'
        )
        self.label_somatorio.pack(side='left', padx=(0, 20))

        # Total de todos os visíveis (azul) ← NOVO
        self.label_total_visiveis = ttk.Label(
            frame_info_selecao,
            text="",
            font=('TkDefaultFont', 10, 'bold'),
            foreground='#00008B'
        )
        self.label_total_visiveis.pack(side='left', padx=(0, 10))

        ttk.Button(frame_selecao, text="Selecionar Todos Visíveis",
                command=self.selecionar_todos_visiveis).pack(side='right', padx=2)
        ttk.Button(frame_selecao, text="Limpar Seleção",
                command=self.limpar_selecao).pack(side='right', padx=2)

        # --- Ações principais ----------------------------------------------------
        frame_acoes = ttk.Frame(frame_botoes)
        frame_acoes.pack(fill='x', pady=(5, 0))

        ttk.Button(frame_acoes, text="Editar",
                command=self.editar_lancamento).pack(side='left', padx=5)
        ttk.Button(frame_acoes, text="📝 Editar em Massa",
                command=self.editar_em_massa).pack(side='left', padx=5)
        ttk.Button(frame_acoes, text="Ver Histórico",
                command=self.visualizar_historico_lancamento).pack(side='left', padx=5)

        ttk.Separator(frame_acoes, orient='vertical').pack(side='left', fill='y', padx=10)

        self.btn_excluir_individual = ttk.Button(frame_acoes, text="Excluir",
                                                command=self.excluir_lancamento)
        self.btn_excluir_individual.pack(side='left', padx=2)

        self.btn_excluir_lote = ttk.Button(frame_acoes, text="Excluir Selecionados",
                                        command=self.excluir_lote, state='disabled')
        self.btn_excluir_lote.pack(side='left', padx=2)

        self.btn_restaurar_individual = ttk.Button(frame_acoes, text="Restaurar",
                                                command=self.restaurar_lancamento)
        self.btn_restaurar_individual.pack(side='left', padx=2)

        self.btn_restaurar_lote = ttk.Button(frame_acoes, text="Restaurar Selecionados",
                                            command=self.restaurar_lote, state='disabled')
        self.btn_restaurar_lote.pack(side='left', padx=2)

        ttk.Separator(frame_acoes, orient='vertical').pack(side='left', fill='y', padx=10)

        ttk.Button(frame_acoes, text="Atualizar",
                command=self.carregar_lancamentos).pack(side='left', padx=5)
        ttk.Button(frame_acoes, text="Fechar",
                command=self.janela.destroy).pack(side='right', padx=5)

        # ── Tags de cor ───────────────────────────────────────────────────────────
        self.tree_lancamentos.tag_configure('excluido', background='#ffcccc')
        self.tree_lancamentos.tag_configure('normal', background='white')
        self.tree_lancamentos.tag_configure('selecionado', background='#e6f3ff')
        self.tree_lancamentos.tag_configure('busca_encontrada', background='#ffffcc')
        self.tree_lancamentos.tag_configure('possivel_duplicata',
                                            background='#ffe6cc', foreground='#cc6600')

        # ── Bind checkbox + eventos ───────────────────────────────────────────────
        self.tree_lancamentos.bind('<ButtonRelease-1>', self._toggle_checkbox)
        self.configurar_atalhos()
        self.configurar_eventos_selecao()

    def atualizar_totalizador_visiveis(self):
        """
        Soma os valores de TODOS os itens visíveis no momento e
        atualiza self.label_total_visiveis.

        Chamado ao final de aplicar_filtros() e carregar_lancamentos().
        """
        try:
            if not hasattr(self, 'label_total_visiveis'):
                return

            itens_visiveis = self.tree_lancamentos.get_children()

            if not itens_visiveis:
                self.label_total_visiveis.config(text="")
                return

            total = 0.0
            for item in itens_visiveis:
                try:
                    # Índice 6 → coluna 'Valor' (após inserção da coluna ✓)
                    valor_str = str(self.tree_lancamentos.item(item)['values'][6])
                    valor_limpo = valor_str.replace('.', '').replace(',', '.')
                    total += float(valor_limpo)
                except (ValueError, IndexError):
                    continue

            qtd = len(itens_visiveis)
            total_fmt = (
                f"R$ {total:,.2f}"
                .replace(',', 'X').replace('.', ',').replace('X', '.')
            )
            self.label_total_visiveis.config(
                text=f"Total ({qtd} itens): {total_fmt}"
            )

        except Exception as e:
            logger.debug(f"Erro ao atualizar totalizador: {e}")

    def _toggle_checkbox(self, event):
        try:
            
            col_id    = self.tree_lancamentos.identify_column(event.x)
            col_index = int(col_id.replace('#', '')) - 1
            
            
            if col_index != 0:
                return

            item = self.tree_lancamentos.identify_row(event.y)
            if not item:
                return

            valores = list(self.tree_lancamentos.item(item)['values'])

            if item in self._itens_marcados:
                self._itens_marcados.discard(item)
                valores[0] = '☐'
            else:
                self._itens_marcados.add(item)
                valores[0] = '☑'

            self.tree_lancamentos.item(item, values=valores)
            
            self.tree_lancamentos.after_idle(self._atualizar_labels_checkbox)

            return 'break'

        except Exception as e:
            logger.debug(f"Erro em _toggle_checkbox: {e}")


    def _atualizar_labels_checkbox(self):
        try:
            visiveis = set(self.tree_lancamentos.get_children())
            marcados_visiveis = self._itens_marcados & visiveis
            qtd = len(marcados_visiveis)

            self.tree_lancamentos.unbind('<<TreeviewSelect>>')

            if marcados_visiveis:
                self.tree_lancamentos.selection_set(tuple(marcados_visiveis))
            else:
                self.tree_lancamentos.selection_remove(self.tree_lancamentos.selection())

            if qtd == 0:
                self.label_selecao.config(text="Nenhum item selecionado")
                self.label_somatorio.config(text="")
                self.btn_excluir_individual.config(state='disabled')
                self.btn_excluir_lote.config(state='disabled')
                self.btn_restaurar_individual.config(state='disabled')
                self.btn_restaurar_lote.config(state='disabled')
            else:
                total = 0.0
                for item in marcados_visiveis:
                    try:
                        valor_str = str(self.tree_lancamentos.item(item)['values'][6])
                        total += float(valor_str.replace('.', '').replace(',', '.'))
                    except (ValueError, IndexError):
                        continue

                total_fmt = (f"R$ {total:,.2f}"
                            .replace(',', 'X').replace('.', ',').replace('X', '.'))

                if qtd == 1:
                    self.label_selecao.config(text="1 item selecionado")
                    self.label_somatorio.config(text=f"Valor: {total_fmt}")
                    self.btn_excluir_individual.config(state='normal')
                    self.btn_excluir_lote.config(state='disabled')
                    self.btn_restaurar_individual.config(state='normal')
                    self.btn_restaurar_lote.config(state='disabled')
                else:
                    self.label_selecao.config(text=f"{qtd} itens selecionados")
                    self.label_somatorio.config(text=f"Total: {total_fmt}")
                    self.btn_excluir_individual.config(state='disabled')
                    self.btn_excluir_lote.config(state='normal')
                    self.btn_restaurar_individual.config(state='disabled')
                    self.btn_restaurar_lote.config(state='normal')

            # Forçar redesenho dos labels na tela
            self.label_selecao.update_idletasks()
            self.label_somatorio.update_idletasks()

        except Exception as e:
            logger.debug(f"Erro em _atualizar_labels_checkbox: {e}")

    def configurar_eventos_selecao(self):
        """Configura eventos para controle de seleção múltipla"""
        try:
            # <<TreeviewSelect>> removido — o controle de seleção agora é
            # feito por _toggle_checkbox + _atualizar_labels_checkbox
            
            # Ctrl+Click e Shift+Click: atualizar após o Treeview processar
            def on_ctrl_click(event):
                self.tree_lancamentos.after_idle(self.atualizar_interface_selecao)
            
            def on_shift_click(event):
                self.tree_lancamentos.after_idle(self.atualizar_interface_selecao)
            
            self.tree_lancamentos.bind('<Control-Button-1>', on_ctrl_click)
            self.tree_lancamentos.bind('<Shift-Button-1>', on_shift_click)
            
            logger.debug("DEBUG: Eventos de seleção configurados")
            
        except Exception as e:
            logger.debug(f"Erro ao configurar eventos de seleção: {str(e)}")

    def atualizar_interface_selecao(self):
        """Atualiza a interface baseada na seleção atual"""
        try:
            # Se há itens marcados via checkbox, deixar _atualizar_labels_checkbox
            # ser o responsável pelos labels — evita sobrescrita
            if hasattr(self, '_itens_marcados') and self._itens_marcados:
                # Apenas atualizar estado dos botões
                qtd = len(self._itens_marcados & set(self.tree_lancamentos.get_children()))
            else:
                qtd = len(self.tree_lancamentos.selection())

            if qtd == 0:
                self.label_selecao.config(text="Nenhum item selecionado")
                self.label_somatorio.config(text="")
                self.btn_excluir_individual.config(state='disabled')
                self.btn_excluir_lote.config(state='disabled')
                self.btn_restaurar_individual.config(state='disabled')
                self.btn_restaurar_lote.config(state='disabled')

            elif qtd == 1:
                self.btn_excluir_individual.config(state='normal')
                self.btn_excluir_lote.config(state='disabled')
                self.btn_restaurar_individual.config(state='normal')
                self.btn_restaurar_lote.config(state='disabled')

            else:
                self.btn_excluir_individual.config(state='disabled')
                self.btn_excluir_lote.config(state='normal')
                self.btn_restaurar_individual.config(state='disabled')
                self.btn_restaurar_lote.config(state='normal')

        except Exception as e:
            logger.debug(f"Erro ao atualizar interface de seleção: {str(e)}")

    def limpar_selecao(self):
        try:
            self._itens_marcados.clear()
            self.tree_lancamentos.selection_remove(self.tree_lancamentos.selection())

            for item in self.tree_lancamentos.get_children():
                v = list(self.tree_lancamentos.item(item)['values'])
                v[0] = '☐'
                self.tree_lancamentos.item(item, values=v)

            self.atualizar_interface_selecao()
            logger.debug("DEBUG: Seleção limpa")

        except Exception as e:
            logger.debug(f"Erro ao limpar seleção: {str(e)}")


    def selecionar_todos_visiveis(self):
        try:
            items_visiveis = self.tree_lancamentos.get_children()

            if not items_visiveis:
                custom_messagebox("info", "Seleção", "Nenhum item visível para selecionar")
                return

            self._itens_marcados = set(items_visiveis)
            self.tree_lancamentos.selection_set(items_visiveis)

            for item in items_visiveis:
                v = list(self.tree_lancamentos.item(item)['values'])
                v[0] = '☑'
                self.tree_lancamentos.item(item, values=v)

            self._atualizar_labels_checkbox()
            logger.debug(f"DEBUG: Selecionados {len(items_visiveis)} itens visíveis")

        except Exception as e:
            logger.debug(f"Erro ao selecionar todos os itens: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao selecionar itens: {str(e)}")

    def obter_dados_selecionados(self):
        """Obtém dados dos itens selecionados para processamento"""
        try:
            items_selecionados = self.tree_lancamentos.selection()
            
            if not items_selecionados:
                return []
            
            dados_selecionados = []
            
            for item in items_selecionados:
                valores = self.tree_lancamentos.item(item)['values']
                
                # Extrair informações principais
                dados_item = {
                    'item_id': item,  # ID do item no Treeview
                    'data': valores[1],
                    'nr_relatorio': valores[1],
                    'tp_desp': valores[2],
                    'nome': valores[3],
                    'referencia': valores[4],
                    'nf': valores[5],
                    'valor': valores[6],
                    'vencimento': valores[7],
                    'status': valores[8],
                    'id_lancamento': valores[9]
                }
                
                dados_selecionados.append(dados_item)
            
            return dados_selecionados
            
        except Exception as e:
            logger.debug(f"Erro ao obter dados selecionados: {str(e)}")
            return []

    def excluir_lote(self):
        """Executa exclusão em lote dos itens selecionados"""
        try:
            dados_selecionados = self.obter_dados_selecionados()
            
            if not dados_selecionados:
                custom_messagebox("warning", "Aviso", "Nenhum item selecionado para exclusão")
                return
            
            qtd_selecionados = len(dados_selecionados)
            
            # Verificar se há itens já excluídos
            ja_excluidos = [item for item in dados_selecionados if item['status'] == 'EXCLUIDO']
            ativos = [item for item in dados_selecionados if item['status'] != 'EXCLUIDO']
            
            if not ativos:
                custom_messagebox("info", "Informação", 
                                f"Todos os {qtd_selecionados} itens selecionados já estão excluídos")
                return
            
            # Verificar se há taxas de administração
            taxas_admin = [item for item in ativos if str(item['tp_desp']) == '7']
            qtd_taxas = len(taxas_admin)
            qtd_normais = len(ativos) - qtd_taxas
            
            # Montar mensagem de confirmação detalhada
            mensagem = f"EXCLUSÃO EM LOTE\n\n"
            mensagem += f"📊 RESUMO DA SELEÇÃO:\n"
            mensagem += f"• {len(ativos)} itens serão excluídos\n"
            
            if ja_excluidos:
                mensagem += f"• {len(ja_excluidos)} já estavam excluídos (ignorados)\n"
            
            if qtd_taxas > 0:
                mensagem += f"• ⚠️ {qtd_taxas} TAXA(S) DE ADMINISTRAÇÃO\n"
            
            if qtd_normais > 0:
                mensagem += f"• {qtd_normais} lançamento(s) normal(is)\n"
            
            mensagem += f"\n🎯 PERÍODO AFETADO:\n"
            
            # Obter intervalo de datas
            datas = [item['data'] for item in ativos if item['data']]
            if datas:
                datas_ordenadas = sorted(set(datas))
                if len(datas_ordenadas) == 1:
                    mensagem += f"• {datas_ordenadas[0]}\n"
                else:
                    mensagem += f"• De {datas_ordenadas[0]} até {datas_ordenadas[-1]}\n"
            
            # Calcular valor total
            valor_total = 0
            for item in ativos:
                try:
                    # Limpar formatação do valor
                    valor_str = str(item['valor']).replace('.', '').replace(',', '.')
                    valor_total += float(valor_str)
                except:
                    pass
            
            if valor_total > 0:
                mensagem += f"\n💰 VALOR TOTAL: R$ {valor_total:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
            
            if qtd_taxas > 0:
                mensagem += f"\n\n⚠️ ATENÇÃO ESPECIAL:\n"
                mensagem += f"Esta operação inclui TAXAS DE ADMINISTRAÇÃO!\n"
                mensagem += f"Verifique se não há duplicação antes de prosseguir.\n"
            
            mensagem += f"\n🔄 As taxas restantes serão verificadas automaticamente.\n"
            mensagem += f"\n❓ Deseja realmente continuar com a exclusão em lote?"
            
            # Confirmar operação
            if not custom_messagebox("yesno", "Confirmação - Exclusão em Lote", mensagem):
                return
            
            # Executar exclusões
            sucessos = 0
            erros = []
            datas_afetadas = set()
            
            progress_window = self.criar_janela_progresso("Excluindo lançamentos...", len(ativos))
            
            try:
                for i, item in enumerate(ativos):
                    try:
                        # Atualizar progresso
                        self.atualizar_progresso(progress_window, i + 1, 
                                            f"Excluindo: {item['nome'][:30]}...")
                        
                        # Executar exclusão
                        self.atualizar_status_lancamento(item['id_lancamento'], 'EXCLUIDO')
                        
                        # Coletar data para verificação posterior
                        if item['data']:
                            try:
                                data_obj = datetime.strptime(item['data'], '%d/%m/%Y').date()
                                datas_afetadas.add(data_obj)
                            except:
                                pass
                        
                        sucessos += 1
                        
                    except Exception as e:
                        erros.append(f"ID {item['id_lancamento']}: {str(e)}")
                        continue
                
            finally:
                progress_window.destroy()
            
            # Verificar recálculo de taxas para as datas afetadas
            self.verificar_recalculo_datas_afetadas(datas_afetadas, "EXCLUSAO")
            
            # Recarregar interface
            self.carregar_lancamentos()
            
            # Mostrar resultado
            mensagem_resultado = f"EXCLUSÃO EM LOTE CONCLUÍDA\n\n"
            mensagem_resultado += f"✅ {sucessos} lançamentos excluídos com sucesso\n"
            
            if erros:
                mensagem_resultado += f"❌ {len(erros)} erros encontrados:\n"
                for erro in erros[:5]:  # Mostrar apenas os primeiros 5 erros
                    mensagem_resultado += f"• {erro}\n"
                if len(erros) > 5:
                    mensagem_resultado += f"• ... e mais {len(erros) - 5} erros\n"
            
            if datas_afetadas:
                mensagem_resultado += f"\n🔄 {len(datas_afetadas)} data(s) verificada(s) para recálculo de taxas"
            
            custom_messagebox("info", "Resultado da Exclusão em Lote", mensagem_resultado)
            
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro na exclusão em lote: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro na exclusão em lote: {str(e)}")

    def restaurar_lote(self):
        """Executa restauração em lote dos itens selecionados"""
        try:
            dados_selecionados = self.obter_dados_selecionados()
            
            if not dados_selecionados:
                custom_messagebox("warning", "Aviso", "Nenhum item selecionado para restauração")
                return
            
            qtd_selecionados = len(dados_selecionados)
            
            # Verificar se há itens já ativos
            ja_ativos = [item for item in dados_selecionados if item['status'] != 'EXCLUIDO']
            excluidos = [item for item in dados_selecionados if item['status'] == 'EXCLUIDO']
            
            if not excluidos:
                custom_messagebox("info", "Informação", 
                                f"Todos os {qtd_selecionados} itens selecionados já estão ativos")
                return
            
            # Verificar se há taxas de administração
            taxas_admin = [item for item in excluidos if str(item['tp_desp']) == '7']
            qtd_taxas = len(taxas_admin)
            qtd_normais = len(excluidos) - qtd_taxas
            
            # Montar mensagem de confirmação
            mensagem = f"RESTAURAÇÃO EM LOTE\n\n"
            mensagem += f"📊 RESUMO DA SELEÇÃO:\n"
            mensagem += f"• {len(excluidos)} itens serão restaurados\n"
            
            if ja_ativos:
                mensagem += f"• {len(ja_ativos)} já estavam ativos (ignorados)\n"
            
            if qtd_taxas > 0:
                mensagem += f"• ⚠️ {qtd_taxas} TAXA(S) DE ADMINISTRAÇÃO\n"
            
            if qtd_normais > 0:
                mensagem += f"• {qtd_normais} lançamento(s) normal(is)\n"
            
            if qtd_taxas > 0:
                mensagem += f"\n⚠️ ATENÇÃO ESPECIAL:\n"
                mensagem += f"Esta operação inclui TAXAS DE ADMINISTRAÇÃO!\n"
                mensagem += f"Verifique se não haverá duplicação.\n"
            
            mensagem += f"\n🔄 As taxas serão verificadas automaticamente.\n"
            mensagem += f"\n❓ Deseja realmente continuar com a restauração em lote?"
            
            # Confirmar operação
            if not custom_messagebox("yesno", "Confirmação - Restauração em Lote", mensagem):
                return
            
            # Executar restaurações
            sucessos = 0
            erros = []
            datas_afetadas = set()
            
            progress_window = self.criar_janela_progresso("Restaurando lançamentos...", len(excluidos))
            
            try:
                for i, item in enumerate(excluidos):
                    try:
                        # Atualizar progresso
                        self.atualizar_progresso(progress_window, i + 1, 
                                            f"Restaurando: {item['nome'][:30]}...")
                        
                        # Executar restauração
                        self.atualizar_status_lancamento(item['id_lancamento'], 'ATIVO')
                        
                        # Coletar data para verificação posterior
                        if item['data']:
                            try:
                                data_obj = datetime.strptime(item['data'], '%d/%m/%Y').date()
                                datas_afetadas.add(data_obj)
                            except:
                                pass
                        
                        sucessos += 1
                        
                    except Exception as e:
                        erros.append(f"ID {item['id_lancamento']}: {str(e)}")
                        continue
                
            finally:
                progress_window.destroy()
            
            # Verificar recálculo de taxas para as datas afetadas
            self.verificar_recalculo_datas_afetadas(datas_afetadas, "ALTERACAO")
            
            # Recarregar interface
            self.carregar_lancamentos()
            
            # Mostrar resultado
            mensagem_resultado = f"RESTAURAÇÃO EM LOTE CONCLUÍDA\n\n"
            mensagem_resultado += f"✅ {sucessos} lançamentos restaurados com sucesso\n"
            
            if erros:
                mensagem_resultado += f"❌ {len(erros)} erros encontrados:\n"
                for erro in erros[:5]:
                    mensagem_resultado += f"• {erro}\n"
                if len(erros) > 5:
                    mensagem_resultado += f"• ... e mais {len(erros) - 5} erros\n"
            
            if datas_afetadas:
                mensagem_resultado += f"\n🔄 {len(datas_afetadas)} data(s) verificada(s) para recálculo de taxas"
            
            custom_messagebox("info", "Resultado da Restauração em Lote", mensagem_resultado)
            
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro na restauração em lote: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro na restauração em lote: {str(e)}")

    def criar_janela_progresso(self, titulo, total_items):
        """Cria janela de progresso para operações em lote"""
        try:
            janela_progress = tk.Toplevel(self.janela)
            janela_progress.title(titulo)
            janela_progress.geometry("400x120")
            janela_progress.transient(self.janela)
            janela_progress.grab_set()
            
            # Centralizar janela
            janela_progress.update_idletasks()
            x = (janela_progress.winfo_screenwidth() // 2) - (400 // 2)
            y = (janela_progress.winfo_screenheight() // 2) - (120 // 2)
            janela_progress.geometry(f"400x120+{x}+{y}")
            
            frame = ttk.Frame(janela_progress, padding="20")
            frame.pack(fill='both', expand=True)
            
            # Label de status
            label_status = ttk.Label(frame, text="Preparando...", font=('TkDefaultFont', 10))
            label_status.pack(pady=(0, 10))
            
            # Barra de progresso
            progress_var = tk.DoubleVar()
            progress_bar = ttk.Progressbar(frame, variable=progress_var, maximum=total_items, 
                                        mode='determinate', length=350)
            progress_bar.pack(pady=(0, 10))
            
            # Label de contagem
            label_count = ttk.Label(frame, text=f"0 / {total_items}", font=('TkDefaultFont', 9))
            label_count.pack()
            
            # Armazenar referências para atualização
            janela_progress.label_status = label_status
            janela_progress.progress_var = progress_var
            janela_progress.label_count = label_count
            janela_progress.total_items = total_items
            
            # Forçar atualização da interface
            janela_progress.update()
            
            return janela_progress
            
        except Exception as e:
            logger.debug(f"Erro ao criar janela de progresso: {str(e)}")
            return None

    def atualizar_progresso(self, janela_progress, item_atual, mensagem=""):
        """Atualiza a janela de progresso"""
        try:
            if not janela_progress:
                return
            
            # Atualizar barra de progresso
            janela_progress.progress_var.set(item_atual)
            
            # Atualizar status
            if mensagem:
                janela_progress.label_status.config(text=mensagem)
            
            # Atualizar contagem
            janela_progress.label_count.config(
                text=f"{item_atual} / {janela_progress.total_items}"
            )
            
            # Forçar atualização da interface
            janela_progress.update_idletasks()
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar progresso: {str(e)}")
    
    def configurar_atalhos(self):
        """
        VERSÃO APRIMORADA: Configurar atalhos incluindo busca
        """
        try:
            # ATALHOS ORIGINAIS (mantidos)
            def on_double_click(event):
                if self.tree_lancamentos.selection():
                    self.visualizar_historico_lancamento()
            
            self.tree_lancamentos.bind('<Double-1>', on_double_click)
            
            def on_key_h(event):
                if self.tree_lancamentos.selection():
                    self.visualizar_historico_lancamento()
            
            self.janela.bind('<Key-h>', on_key_h)
            self.janela.bind('<Key-H>', on_key_h)
            
            # NOVO: Ctrl+F para focar no campo de busca
            def on_ctrl_f(event):
                self.entry_busca.focus_set()
                self.entry_busca.select_range(0, tk.END)
                return "break"
            
            self.janela.bind('<Control-f>', on_ctrl_f)
            self.janela.bind('<Control-F>', on_ctrl_f)
            
            # Ctrl+O: Aplicar ordenação
            def on_ctrl_o(event):
                self.aplicar_ordenacao()
                return "break"

            self.janela.bind('<Control-o>', on_ctrl_o)

            # Ctrl+Shift+O: Restaurar ordenação padrão
            def on_ctrl_shift_o(event):
                self.restaurar_ordenacao_padrao()
                return "break"

            self.janela.bind('<Control-Shift-O>', on_ctrl_shift_o)

            # NOVO: ESC para limpar busca
            def on_escape(event):
                # Se o foco está no campo de busca, limpar busca
                if self.entry_busca == self.janela.focus_get():
                    self.limpar_busca()
                else:
                    # Senão, limpar seleção (comportamento original)
                    self.limpar_selecao()
                return "break"
            
            self.janela.bind('<Escape>', on_escape)
            
            # Ctrl+A: Selecionar todos
            def on_ctrl_a(event):
                self.selecionar_todos_visiveis()
                return "break"
            
            self.janela.bind('<Control-a>', on_ctrl_a)
            
            # Delete: Excluir selecionados
            def on_delete(event):
                items_selecionados = self.tree_lancamentos.selection()
                if len(items_selecionados) == 1:
                    self.excluir_lancamento()
                elif len(items_selecionados) > 1:
                    self.excluir_lote()
                return "break"
            
            self.janela.bind('<Delete>', on_delete)
            
            # Ctrl+R: Restaurar
            def on_ctrl_r(event):
                items_selecionados = self.tree_lancamentos.selection()
                if len(items_selecionados) == 1:
                    self.restaurar_lancamento()
                elif len(items_selecionados) > 1:
                    self.restaurar_lote()
                return "break"
            
            self.janela.bind('<Control-r>', on_ctrl_r)
            
            # F5: Atualizar
            def on_f5(event):
                self.carregar_lancamentos()
                return "break"
            
            self.janela.bind('<F5>', on_f5)
            
            logger.debug("DEBUG: Atalhos configurados (incluindo Ctrl+F para busca)")
            
        except Exception as e:
            logger.debug(f"Erro ao configurar atalhos: {str(e)}")

    def formatar_tipo_despesa(self, tp_desp):
        """Formata tipo de despesa como inteiro"""
        try:
            if pd.isna(tp_desp) or tp_desp == "":
                return ""
            
            # Converter para float primeiro, depois para int para remover decimais
            valor_numerico = float(tp_desp)
            return str(int(valor_numerico))
            
        except (ValueError, TypeError):
            # Se não conseguir converter, retornar como string
            return str(tp_desp)

    def inicializar_datas_padrao(self):
        """
        Define o intervalo de datas como a QUINZENA ATUAL.

        Quinzena do relatório do dia 20:  06/MM  →  20/MM
        Quinzena do relatório do dia 5:   21/MM  →  05/(MM+1)
        """
        try:
            hoje      = datetime.now().date()
            dia       = hoje.day
            mes       = hoje.month
            ano       = hoje.year

            if 6 <= dia <= 20:
                # ── Quinzena "20": do dia 6 ao dia 20 do mês atual
                data_inicio_padrao = hoje.replace(day=6)
                data_fim_padrao    = hoje.replace(day=20)
            else:
                # ── Quinzena "5": do dia 21 do mês atual ao dia 5 do próximo mês
                data_inicio_padrao = hoje.replace(day=21)

                if mes == 12:
                    data_fim_padrao = datetime(ano + 1, 1, 5).date()
                else:
                    data_fim_padrao = datetime(ano, mes + 1, 5).date()

                # Caso hoje seja entre 1–5: a quinzena "5" pertence ao mês anterior
                if dia <= 5:
                    # Ex.: hoje = 03/07 → quinzena = 21/06 a 05/07
                    if mes == 1:
                        data_inicio_padrao = datetime(ano - 1, 12, 21).date()
                    else:
                        data_inicio_padrao = datetime(ano, mes - 1, 21).date()
                    data_fim_padrao = hoje.replace(day=5)

            if hasattr(self, 'data_inicio') and self.data_inicio:
                self.data_inicio.set_date(data_inicio_padrao)
            if hasattr(self, 'data_fim') and self.data_fim:
                self.data_fim.set_date(data_fim_padrao)

            logger.debug(
                f"DEBUG: Quinzena atual → início {data_inicio_padrao}, fim {data_fim_padrao}"
            )

        except Exception as e:
            logger.debug(f"DEBUG: Erro ao inicializar datas padrão: {e}")


    def obter_ordenacao_padrao(self):
        """
        Retorna a configuração de ordenação padrão recomendada
        
        Returns:
            dict: Configuração padrão de ordenação
        """
        return {
            'ordem_1': 'Data',
            'direcao_1': '↑ Crescente',
            'ordem_2': 'Nome',
            'direcao_2': '↑ Crescente',
            'ordem_3': 'Valor',
            'direcao_3': '↓ Decrescente',
            'destacar_duplicatas': False
        }

    def salvar_preferencias_ordenacao(self):
        """
        Salva as preferências de ordenação atuais
        """
        try:
            import json
            
            # Coletar preferências atuais
            preferencias = {
                'ordem_1': self.combo_ordem_1.get(),
                'direcao_1': self.combo_direcao_1.get(),
                'ordem_2': self.combo_ordem_2.get(),
                'direcao_2': self.combo_direcao_2.get(),
                'ordem_3': self.combo_ordem_3.get(),
                'direcao_3': self.combo_direcao_3.get(),
                'destacar_duplicatas': self.var_destacar_duplicatas.get()
            }
            
            # Criar diretório se não existir
            PASTA_CLIENTES.mkdir(parents=True, exist_ok=True)
            
            # Salvar arquivo
            with open(ARQUIVO_PREFERENCIAS_ORDENACAO, 'w', encoding='utf-8') as f:
                json.dump(preferencias, f, indent=4, ensure_ascii=False)
            
            logger.debug(f"DEBUG: Preferências de ordenação salvas: {preferencias}")
            
            # Atualizar preferências em memória
            self.preferencias_ordenacao = preferencias
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao salvar preferências de ordenação: {str(e)}")
            return False

    def aplicar_preferencias_ordenacao(self):
        """
        Aplica as preferências de ordenação aos combos
        """
        try:
            if not self.preferencias_ordenacao:
                self.preferencias_ordenacao = self.obter_ordenacao_padrao()
            
            # Aplicar aos combos
            self.combo_ordem_1.set(self.preferencias_ordenacao.get('ordem_1', 'Data'))
            self.combo_direcao_1.set(self.preferencias_ordenacao.get('direcao_1', '↑ Crescente'))
            
            self.combo_ordem_2.set(self.preferencias_ordenacao.get('ordem_2', 'Nome'))
            self.combo_direcao_2.set(self.preferencias_ordenacao.get('direcao_2', '↑ Crescente'))
            
            self.combo_ordem_3.set(self.preferencias_ordenacao.get('ordem_3', 'Valor'))
            self.combo_direcao_3.set(self.preferencias_ordenacao.get('direcao_3', '↓ Decrescente'))
            
            self.var_destacar_duplicatas.set(self.preferencias_ordenacao.get('destacar_duplicatas', False))
            
            logger.debug("DEBUG: Preferências de ordenação aplicadas aos controles")
            
        except Exception as e:
            logger.error(f"Erro ao aplicar preferências de ordenação: {str(e)}")

    def restaurar_ordenacao_padrao(self):
        """
        Restaura a ordenação padrão recomendada
        """
        try:
            padrao = self.obter_ordenacao_padrao()
            
            # Aplicar aos combos
            self.combo_ordem_1.set(padrao['ordem_1'])
            self.combo_direcao_1.set(padrao['direcao_1'])
            
            self.combo_ordem_2.set(padrao['ordem_2'])
            self.combo_direcao_2.set(padrao['direcao_2'])
            
            self.combo_ordem_3.set(padrao['ordem_3'])
            self.combo_direcao_3.set(padrao['direcao_3'])
            
            self.var_destacar_duplicatas.set(padrao['destacar_duplicatas'])
            
            # Salvar como nova preferência
            self.salvar_preferencias_ordenacao()
            
            # Aplicar ordenação
            self.aplicar_ordenacao()
            
            custom_messagebox("info", "Ordenação Restaurada", 
                            "Ordenação padrão restaurada:\n\n"
                            "1º: Data (crescente)\n"
                            "2º: Nome (crescente)\n"
                            "3º: Valor (decrescente)")
            
            logger.debug("DEBUG: Ordenação padrão restaurada e aplicada")
            
        except Exception as e:
            logger.error(f"Erro ao restaurar ordenação padrão: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao restaurar ordenação padrão: {str(e)}")

    def carregar_lancamentos(self):
        """
        Carrega os lançamentos da planilha
        VERSÃO COM ORDENAÇÃO
        """
        try:
            from openpyxl import load_workbook
            import pandas as pd
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            
            # Carregar dados
            df = pd.read_excel(arquivo_cliente, sheet_name='Dados', converters=CONVERSORES_DADOS)
            df = df.fillna("")
            
            # Preencher status em branco
            df['STATUS'] = df['STATUS'].replace('', 'ATIVO')
            df['STATUS'] = df['STATUS'].fillna('ATIVO')
            
            # Gerenciar IDs (mantém código existente)
            if 'ID_LANCAMENTO' not in df.columns:
                df['ID_LANCAMENTO'] = range(1, len(df) + 1)
            else:
                # ... código existente de correção de IDs ...
                df['ID_LANCAMENTO'] = pd.to_numeric(df['ID_LANCAMENTO'], errors='coerce')
                
                ids_validos = df['ID_LANCAMENTO'].dropna()
                if len(ids_validos) > 0:
                    proximo_id = int(ids_validos.max()) + 1
                else:
                    proximo_id = 1
                
                mask_nan = df['ID_LANCAMENTO'].isna()
                indices_nan = df.index[mask_nan].tolist()
                for idx in indices_nan:
                    df.loc[idx, 'ID_LANCAMENTO'] = proximo_id
                    proximo_id += 1
                
                duplicados_restantes = df[df.duplicated(subset=['ID_LANCAMENTO'], keep='first')]
                for idx in duplicados_restantes.index:
                    df.loc[idx, 'ID_LANCAMENTO'] = proximo_id
                    proximo_id += 1
            
            df['ID_LANCAMENTO'] = df['ID_LANCAMENTO'].astype(int)
            
            # Salvar correções se necessário (mantém código existente)
            ids_mudaram = not df['ID_LANCAMENTO'].equals(
                pd.read_excel(arquivo_cliente, sheet_name='Dados')['ID_LANCAMENTO']
            ) if 'ID_LANCAMENTO' in pd.read_excel(arquivo_cliente, sheet_name='Dados').columns else True
            
            if ids_mudaram:
                self.salvar_correcoes_ids(arquivo_cliente, df)

            # corrigir STATUS vazio na planilha
            self.corrigir_planilha_status(arquivo_cliente, df)
            
            # Salvar dados originais
            self.dados_originais = df.copy()
            
            # ===== NOVO: APLICAR ORDENAÇÃO =====
            df = self.ordenar_dados(df)
            
            # ===== NOVO: IDENTIFICAR POSSÍVEIS DUPLICATAS =====
            duplicatas_detectadas = set()
            if self.var_destacar_duplicatas.get():
                duplicatas_detectadas = self.identificar_possiveis_duplicatas(df)
            
            # Desabilitar redesenho durante inserção
            self.tree_lancamentos.config(takefocus=0)
            
            # Limpar tree e lista
            for item in self.tree_lancamentos.get_children():
                self.tree_lancamentos.delete(item)
            
            self.todos_itens_tree = []
            
            # Inserir todos os itens
            for idx, row in df.iterrows():
                status = row.get('STATUS', 'ATIVO')
                if status == '' or pd.isna(status):
                    status = 'ATIVO'

                # Ignorar linhas completamente vazias (sem data e sem nome)
                nome_vazio = not str(row.get('NOME', '')).strip() or pd.isna(row.get('NOME', ''))
                data_vazia = not str(row.get('DATA_REL', '')).strip() or pd.isna(row.get('DATA_REL', ''))
                if nome_vazio and data_vazia:
                    continue
                
                # Determinar tag
                tags = []
                if status == 'EXCLUIDO':
                    tags.append('excluido')
                else:
                    tags.append('normal')
                
                # ===== NOVO: Adicionar tag de duplicata se detectada =====
                id_lancamento = int(row['ID_LANCAMENTO'])
                if id_lancamento in duplicatas_detectadas:
                    tags.append('possivel_duplicata')
                
                # Formatar valores
                data_rel = self.formatar_data(row['DATA_REL'])
                data_vencto = self.formatar_data(row['DT_VENCTO'])
                valor = self.formatar_valor(row['VALOR'])
                tp_desp = self.formatar_tipo_despesa(row['TP_DESP'])
                
                valores_tree = ('☐', data_rel, tp_desp, row['NOME'], 
                            row['REFERÊNCIA'], row['NF'], valor, data_vencto, status, id_lancamento)
                
                # Inserir item
                item_id = self.tree_lancamentos.insert('', 'end', 
                    values=valores_tree,
                    tags=tuple(tags))
            
                # Adicionar à lista de todos os itens
                self.todos_itens_tree.append(item_id)
            
            # Reabilitar foco
            self.tree_lancamentos.config(takefocus=1)
            
            logger.debug(f"Carregados {len(df)} lançamentos")
            
            # Aplicar filtros padrão
            self.aplicar_filtros()
            self.atualizar_totalizador_visiveis()
            
            logger.debug(f"Carregamento concluído")
            
        except Exception as e:
            logger.error(f"Erro ao carregar lançamentos: {str(e)}")
            import traceback
            custom_messagebox("error", "Erro", f"Erro ao carregar lançamentos: {str(e)}")

    def identificar_possiveis_duplicatas(self, df):
        """
        Identifica possíveis lançamentos duplicados
        
        Args:
            df: DataFrame com os lançamentos
            
        Returns:
            set: IDs dos lançamentos que podem ser duplicatas
        """
        try:
            duplicatas = set()
            
            # Agrupar por Data + Nome + Valor
            grupos = df.groupby(['DATA_REL', 'NOME', 'VALOR'])
            
            for grupo_chave, grupo_df in grupos:
                if len(grupo_df) > 1:
                    # Múltiplos lançamentos com mesma data, nome e valor
                    for id_lanc in grupo_df['ID_LANCAMENTO']:
                        duplicatas.add(int(id_lanc))
            
            if duplicatas:
                logger.debug(f"DEBUG: {len(duplicatas)} possíveis duplicatas identificadas")
            
            return duplicatas
            
        except Exception as e:
            logger.error(f"Erro ao identificar duplicatas: {str(e)}")
            return set()

    def salvar_correcoes_ids(self, arquivo_cliente, df_corrigido):
        """
        Salva as correções de ID na planilha Excel
        """
        try:
            from openpyxl import load_workbook
            
            # Carregar workbook existente
            wb = load_workbook(arquivo_cliente)
            ws = wb['Dados']
            
            # Encontrar coluna ID_LANCAMENTO
            id_col = None
            for col in range(1, ws.max_column + 1):
                if ws.cell(row=1, column=col).value == 'ID_LANCAMENTO':
                    id_col = col
                    break
            
            if id_col is None:
                logger.debug("DEBUG: Coluna ID_LANCAMENTO não encontrada na planilha")
                return
            
            # Atualizar IDs na planilha
            for idx, row in df_corrigido.iterrows():
                excel_row = idx + 2  # +2 porque pandas usa índice 0 e Excel começa na linha 1, plus header
                id_value = int(row['ID_LANCAMENTO'])
                ws.cell(row=excel_row, column=id_col).value = id_value
            
            # Salvar workbook
            salvar_planilha_segura(wb, arquivo_cliente)
            logger.debug("DEBUG: IDs corrigidos salvos na planilha")
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao salvar correções de ID: {str(e)}")


    def corrigir_planilha_status(self, arquivo_cliente, df):
        """Corrige o status na planilha para dados antigos"""
        try:
            wb = load_workbook(arquivo_cliente)
            ws = wb['Dados']
            
            # Adicionar cabeçalho STATUS se não existir
            if ws.cell(row=1, column=14).value != 'STATUS':
                ws.cell(row=1, column=14, value='STATUS')
            
            # Adicionar cabeçalho ID_LANCAMENTO se não existir
            if ws.cell(row=1, column=15).value != 'ID_LANCAMENTO':
                ws.cell(row=1, column=15, value='ID_LANCAMENTO')
            
            # Adicionar cabeçalho HISTORICO_ALTERACAO se não existir
            if ws.cell(row=1, column=16).value != 'HISTORICO_ALTERACAO':
                ws.cell(row=1, column=16, value='HISTORICO_ALTERACAO')
            
            # Preencher STATUS e ID para todas as linhas
            for idx, (df_idx, row) in enumerate(df.iterrows(), start=2):
                # STATUS
                status_atual = ws.cell(row=idx, column=14).value
                if not status_atual or status_atual == '':
                    ws.cell(row=idx, column=14, value='ATIVO')
                
                # ID_LANCAMENTO - CORREÇÃO: usar o ID do DataFrame
                ws.cell(row=idx, column=15, value=int(row['ID_LANCAMENTO']))
            
            salvar_planilha_segura(wb, arquivo_cliente)
                        
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao corrigir status na planilha: {str(e)}")
            # Não levantar exceção aqui para não interromper o carregamento
    
    def normalizar_texto(self, texto):
        """
        Normaliza texto para busca: remove acentos, converte para minúsculas
        
        Args:
            texto: String para normalizar
            
        Returns:
            String normalizada
        """
        if not texto or pd.isna(texto):
            return ""
        
        texto = str(texto).lower()
        
        # Remover acentos
        texto = unicodedata.normalize('NFKD', texto)
        texto = texto.encode('ASCII', 'ignore').decode('ASCII')
        
        return texto
    
    def buscar_texto_evento(self, event=None):
        """
        Evento disparado quando o usuário digita no campo de busca
        Aplica busca em tempo real
        """
        try:
            termo_busca = self.entry_busca.get().strip()
            
            # Se o termo mudou, aplicar filtros
            if termo_busca != self.ultimo_termo_busca:
                self.ultimo_termo_busca = termo_busca
                self.aplicar_filtros()
                
        except Exception as e:
            logger.debug(f"Erro ao buscar texto: {str(e)}")
    
    def limpar_busca(self):
        """
        Limpa o campo de busca e reaplica os filtros
        """
        try:
            self.entry_busca.delete(0, tk.END)
            self.ultimo_termo_busca = ""
            self.label_resultados.config(
                text="Digite para buscar em Referência, Nome, NF e Observação",
                foreground='gray'
            )
            self.aplicar_filtros()
            
        except Exception as e:
            logger.debug(f"Erro ao limpar busca: {str(e)}")
    
    def item_corresponde_busca(self, item_valores, termo_busca_normalizado):
        """
        Verifica se um item corresponde ao termo de busca
        
        Args:
            item_valores: Tupla com valores do item (da Treeview)
            termo_busca_normalizado: Termo de busca já normalizado
            
        Returns:
            bool: True se o item corresponde à busca
        """
        if not termo_busca_normalizado:
            return True
        
        # Colunas: ✓=0 Data=1 Tipo=2 Nome=3 Ref=4 NF=5 Valor=6 Venc=7 Status=8 ID=9
        
        try:
            # Buscar em: Nome (2), Referência (3), NF (4)
            campos_busca = [
                str(item_valores[2]),  # Nome
                str(item_valores[3]),  # Referência
                str(item_valores[5]),  # NF
            ]
            
            # Adicionar observação se disponível (precisa buscar nos dados originais)
            id_lancamento = item_valores[9]
            if hasattr(self, 'dados_originais') and not self.dados_originais.empty:
                mask = self.dados_originais['ID_LANCAMENTO'] == id_lancamento
                dados = self.dados_originais[mask]
                if not dados.empty:
                    observacao = dados.iloc[0].get('OBSERVAÇÃO', '')
                    if observacao and not pd.isna(observacao):
                        campos_busca.append(str(observacao))
            
            # Normalizar e buscar em cada campo
            for campo in campos_busca:
                campo_normalizado = self.normalizar_texto(campo)
                if termo_busca_normalizado in campo_normalizado:
                    return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Erro ao verificar correspondência de busca: {str(e)}")
            return False
    
    def filtrar_com_feedback(self):
        """
        Aplica filtros com feedback visual ao usuário
        NOVO MÉTODO - Melhora a resposta do botão Filtrar
        """
        try:
            # Mudar cursor para ocupado
            self.janela.config(cursor="watch")
            self.janela.update_idletasks()
            
            # Log inicial
            data_inicio = self.data_inicio.get_date()
            data_fim = self.data_fim.get_date()
            status = self.combo_status.get()
            termo_busca = self.entry_busca.get().strip() if self.entry_busca else ""
            
            logger.debug(f"DEBUG: Iniciando filtragem - Data: {data_inicio} a {data_fim}, "
                        f"Status: {status}, Busca: '{termo_busca}'")
            
            # Aplicar filtros
            self.aplicar_filtros()
            
            # Restaurar cursor
            self.janela.config(cursor="")
            
            logger.debug("DEBUG: Filtros aplicados com sucesso")
            
        except Exception as e:
            self.janela.config(cursor="")
            logger.debug(f"Erro ao aplicar filtros: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def aplicar_filtros(self):
        """
        Aplica filtros de data, status e busca por texto nos lançamentos
        VERSÃO FINAL DE PRODUÇÃO
        
        """
        try:
            # Obter filtros
            status_filtro = self.combo_status.get()
            data_inicio = self.data_inicio.get_date()
            data_fim = self.data_fim.get_date()
            
            # Obter termo de busca
            termo_busca = ""
            termo_busca_normalizado = ""
            if hasattr(self, 'entry_busca') and self.entry_busca:
                termo_busca = self.entry_busca.get().strip()
                if termo_busca:
                    termo_busca_normalizado = self.normalizar_texto(termo_busca)
            
            # Log resumido
            logger.debug(f"Aplicando filtros - Status: {status_filtro}, "
                        f"Data: {data_inicio} a {data_fim}, Busca: '{termo_busca}'")
            
            # Contadores
            itens_visiveis = 0
            itens_ocultos = 0
            itens_encontrados_busca = 0
            
            # Obter lista de TODOS os itens
            if not hasattr(self, 'todos_itens_tree'):
                logger.warning("Lista todos_itens_tree não existe, criando fallback")
                self.todos_itens_tree = list(self.tree_lancamentos.get_children())
            
            todos_itens = self.todos_itens_tree
            total_itens = len(todos_itens)
            
            if total_itens == 0:
                logger.warning("Nenhum item para filtrar")
                return
            
            # ====================================================================
            # OTIMIZAÇÃO: Desabilitar redesenho durante processamento
            # ====================================================================
            # Isso evita o "flicker" de itens "correndo" na tela
            self.tree_lancamentos.config(takefocus=0)
            
            # Processar todos os itens
            for i, item in enumerate(todos_itens):
                try:
                    # Obter valores do item
                    try:
                        valores = self.tree_lancamentos.item(item, 'values')
                    except tk.TclError:
                        # Item não existe mais
                        continue
                    
                    if len(valores) < 9:
                        continue
                    
                    data_rel_str = valores[1]
                    status_item = valores[8]
                    
                    # Determinar se item deve ser mostrado
                    mostrar = True
                    encontrado_na_busca = False
                    
                    # Filtro por status
                    if status_filtro == 'Ativos' and status_item != 'ATIVO':
                        mostrar = False
                    elif status_filtro == 'Excluídos' and status_item != 'EXCLUIDO':
                        mostrar = False
                    
                    # Filtro por data
                    if mostrar and data_rel_str and data_rel_str.strip():
                        try:
                            data_rel = datetime.strptime(data_rel_str, '%d/%m/%Y').date()
                            if data_rel < data_inicio or data_rel > data_fim:
                                mostrar = False
                        except:
                            pass
                    
                    # Filtro por busca de texto
                    if mostrar and termo_busca_normalizado:
                        if self.item_corresponde_busca(valores, termo_busca_normalizado):
                            encontrado_na_busca = True
                            itens_encontrados_busca += 1
                        else:
                            mostrar = False
                    
                    # Verificar se item está visível atualmente
                    itens_visiveis_agora = self.tree_lancamentos.get_children()
                    item_esta_visivel = item in itens_visiveis_agora
                    
                    # Aplicar mudança de visibilidade
                    if mostrar:
                        # Item deve estar visível
                        if not item_esta_visivel:
                            try:
                                self.tree_lancamentos.reattach(item, '', tk.END)
                            except:
                                pass
                        
                        itens_visiveis += 1
                        
                        # Aplicar tags apropriadas
                        try:
                            if encontrado_na_busca and termo_busca_normalizado:
                                if status_item == 'EXCLUIDO':
                                    self.tree_lancamentos.item(item, tags=('excluido', 'busca_encontrada'))
                                else:
                                    self.tree_lancamentos.item(item, tags=('busca_encontrada',))
                            else:
                                if status_item == 'EXCLUIDO':
                                    self.tree_lancamentos.item(item, tags=('excluido',))
                                else:
                                    self.tree_lancamentos.item(item, tags=('normal',))
                        except:
                            pass
                    else:
                        # Item deve estar oculto
                        if item_esta_visivel:
                            try:
                                self.tree_lancamentos.detach(item)
                            except:
                                pass
                        
                        itens_ocultos += 1
                    
                    # Atualizar UI periodicamente (a cada 200 itens para reduzir flicker)
                    if i % 200 == 0 and i > 0:
                        self.janela.update_idletasks()
                    
                except Exception as e:
                    # Silenciosamente ignorar erros em itens individuais
                    continue
            
            # ====================================================================
            # Reabilitar foco e forçar atualização visual final
            # ====================================================================
            self.tree_lancamentos.config(takefocus=1)
            self.tree_lancamentos.update_idletasks()
            self.janela.update_idletasks()
            
            # Atualizar label de resultados da busca
            if hasattr(self, 'label_resultados'):
                if termo_busca_normalizado:
                    if itens_encontrados_busca > 0:
                        self.label_resultados.config(
                            text=f"✓ {itens_encontrados_busca} resultado(s) encontrado(s)",
                            foreground='green'
                        )
                    else:
                        self.label_resultados.config(
                            text="✗ Nenhum resultado encontrado",
                            foreground='red'
                        )
                else:
                    self.label_resultados.config(
                        text="Digite para buscar em Referência, Nome, NF e Observação",
                        foreground='gray'
                    )
            
            self.atualizar_totalizador_visiveis()

            # Log resumido do resultado
            logger.debug(f"Filtros aplicados - {itens_visiveis} visíveis, "
                        f"{itens_ocultos} ocultos, {itens_encontrados_busca} encontrados na busca")
                        
        except Exception as e:
            logger.error(f"Erro ao aplicar filtros: {str(e)}")
            import traceback
            traceback.print_exc()

    def ordenar_dados(self, dados_df):
        """
        Ordena o DataFrame de acordo com as opções selecionadas
        
        Args:
            dados_df: DataFrame com os dados a ordenar
            
        Returns:
            DataFrame ordenado
        """
        try:
            if dados_df.empty:
                return dados_df
            
            # Coletar critérios de ordenação
            criterios = []
            ascendings = []
            
            # Mapeamento de nomes exibidos para colunas
            mapa_colunas = {
                'Data': 'DATA_REL',
                'Nome': 'NOME',
                'Referência': 'REFERÊNCIA',
                'Valor': 'VALOR',
                'Vencimento': 'DT_VENCTO',
                'Tipo': 'TP_DESP'
            }
            
            # Processar cada nível de ordenação
            for combo_ordem, combo_direcao in [
                (self.combo_ordem_1, self.combo_direcao_1),
                (self.combo_ordem_2, self.combo_direcao_2),
                (self.combo_ordem_3, self.combo_direcao_3)
            ]:
                criterio = combo_ordem.get()
                
                if criterio and criterio != 'Nenhum':
                    coluna = mapa_colunas.get(criterio)
                    
                    if coluna and coluna in dados_df.columns:
                        criterios.append(coluna)
                        
                        # Determinar direção
                        direcao = combo_direcao.get()
                        ascendings.append(direcao.startswith('↑'))
            
            # Se não há critérios, retornar sem ordenar
            if not criterios:
                return dados_df
            
            # Preparar dados para ordenação
            df_ordenado = dados_df.copy()
            
            # Converter valores para ordenação correta
            for criterio in criterios:
                if criterio == 'VALOR':
                    # Converter valores para float para ordenação numérica
                    df_ordenado['_VALOR_SORT'] = pd.to_numeric(
                        df_ordenado['VALOR'], errors='coerce'
                    ).fillna(0)
                    
                elif criterio in ['DATA_REL', 'DT_VENCTO']:
                    # Converter datas para datetime
                    coluna_sort = f'_{criterio}_SORT'
                    df_ordenado[coluna_sort] = pd.to_datetime(
                        df_ordenado[criterio], format='%d/%m/%Y', errors='coerce'
                    )
            
            # Substituir critérios por versões convertidas
            criterios_ordenacao = []
            for crit in criterios:
                if crit == 'VALOR':
                    criterios_ordenacao.append('_VALOR_SORT')
                elif crit in ['DATA_REL', 'DT_VENCTO']:
                    criterios_ordenacao.append(f'_{crit}_SORT')
                else:
                    criterios_ordenacao.append(crit)
            
            # Aplicar ordenação
            df_ordenado = df_ordenado.sort_values(
                by=criterios_ordenacao,
                ascending=ascendings,
                na_position='last'
            )
            
            # Remover colunas auxiliares
            colunas_temp = [col for col in df_ordenado.columns if col.startswith('_') and col.endswith('_SORT')]
            df_ordenado = df_ordenado.drop(columns=colunas_temp)
            
            logger.debug(f"DEBUG: Dados ordenados por {criterios} (ascendings: {ascendings})")
            
            return df_ordenado
            
        except Exception as e:
            logger.error(f"Erro ao ordenar dados: {str(e)}")
            import traceback
            traceback.print_exc()
            return dados_df

    def aplicar_ordenacao(self):
        """Aplica a ordenação selecionada aos dados exibidos (sem salvar)"""
        try:
            # Recarregar e reaplicar filtros com nova ordenação
            self.carregar_lancamentos()
            
        except Exception as e:
            logger.error(f"Erro ao aplicar ordenação: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao aplicar ordenação: {str(e)}")

    def aplicar_ordenacao_e_salvar(self):
        """Aplica a ordenação e salva as preferências"""
        try:
            # Salvar preferências
            if self.salvar_preferencias_ordenacao():
                logger.debug("DEBUG: Preferências de ordenação salvas")
            
            # Aplicar ordenação
            self.aplicar_ordenacao()
            
        except Exception as e:
            logger.error(f"Erro ao aplicar ordenação e salvar: {str(e)}")
            custom_messagebox("error", "Erro", f"Erro ao aplicar ordenação: {str(e)}")

    def carregar_preferencias_ordenacao(self):
        """
        Carrega as preferências de ordenação salvas com validação
        
        Returns:
            dict: Preferências carregadas ou padrão se não existir/inválido
        """
        try:
            if ARQUIVO_PREFERENCIAS_ORDENACAO.exists():
                import json
                with open(ARQUIVO_PREFERENCIAS_ORDENACAO, 'r', encoding='utf-8') as f:
                    preferencias = json.load(f)
                    
                    # Validar se contém todas as chaves necessárias
                    chaves_necessarias = ['ordem_1', 'direcao_1', 'ordem_2', 'direcao_2', 
                                        'ordem_3', 'direcao_3', 'destacar_duplicatas']
                    
                    if all(chave in preferencias for chave in chaves_necessarias):
                        logger.debug(f"DEBUG: Preferências de ordenação carregadas: {preferencias}")
                        return preferencias
                    else:
                        logger.warning("DEBUG: Arquivo de preferências incompleto, usando padrão")
                        return self.obter_ordenacao_padrao()
            else:
                logger.debug("DEBUG: Arquivo de preferências não existe, usando padrão")
                return self.obter_ordenacao_padrao()
                
        except Exception as e:
            logger.error(f"Erro ao carregar preferências de ordenação: {str(e)}")
            logger.debug("DEBUG: Usando ordenação padrão devido ao erro")
            return self.obter_ordenacao_padrao()

    def editar_lancamento(self):
        """Abre editor para o lançamento selecionado - VERSÃO ATUALIZADA"""
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para editar")
            return
        
        try:
            valores = self.tree_lancamentos.item(item_selecionado[0])['values']
            
            # Verificar se temos valores suficientes
            if len(valores) < 9:
                custom_messagebox("error", "Erro", "Dados insuficientes no lançamento selecionado")
                return
                
            id_lancamento = valores[9]  # ID do lançamento (10ª coluna, índice 9)
            
            # Verificar se o ID é válido
            if not id_lancamento or pd.isna(id_lancamento):
                custom_messagebox("error", "Erro", "ID do lançamento não encontrado")
                return
            
            # Buscar dados completos
            try:
                # Converter ID para o tipo correto se necessário
                if isinstance(id_lancamento, str):
                    try:
                        id_lancamento = int(float(id_lancamento))
                    except ValueError:
                        custom_messagebox("error", "Erro", f"ID inválido: {id_lancamento}")
                        return
                
                # Buscar no DataFrame
                lancamento = None
                mask = self.dados_originais['ID_LANCAMENTO'] == id_lancamento
                dados_filtrados = self.dados_originais[mask]
                
                if not dados_filtrados.empty:
                    lancamento = dados_filtrados.iloc[0]
                else:
                    # Busca alternativa se não encontrou
                    for idx, row in self.dados_originais.iterrows():
                        row_id = row.get('ID_LANCAMENTO')
                        if pd.notna(row_id):
                            try:
                                if int(float(row_id)) == int(float(id_lancamento)):
                                    lancamento = row
                                    break
                            except (ValueError, TypeError):
                                continue
                
                if lancamento is None:
                    custom_messagebox("error", "Erro", 
                        f"Lançamento com ID {id_lancamento} não encontrado nos dados carregados")
                    return
                
                # CORREÇÃO: Abrir editor com callback correto
                editor = EditorLancamentoCompleto(self.janela, lancamento, self.salvar_edicao)
                
            except Exception as e:
                import traceback
                logger.debug(traceback.format_exc())
                custom_messagebox("error", "Erro", f"Erro ao abrir editor: {str(e)}")
                
        except Exception as e:
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao editar lançamento: {str(e)}")
    
    def editar_em_massa(self):
        """Abre editor para alteração em massa dos lançamentos selecionados - VERSÃO CORRIGIDA"""
        items_selecionados = self.tree_lancamentos.selection()
        
        if not items_selecionados:
            custom_messagebox("warning", "⚠️ Nenhum Item Selecionado", 
                            "Para editar em massa:\n\n"
                            "1. Selecione os lançamentos desejados usando Ctrl+Click ou Shift+Click\n"
                            "2. Clique em 'Editar em Massa'\n\n"
                            "💡 Dica: Use Ctrl+A para selecionar todos os itens visíveis!")
            return
        
        qtd_selecionados = len(items_selecionados)
        
        if qtd_selecionados == 1:
            resposta = custom_messagebox("yesno", 
                "Edição Individual ou em Massa?",
                "Você selecionou apenas 1 lançamento.\n\n"
                "Deseja usar o editor em massa mesmo assim?\n"
                "(Não = abrirá o editor individual normal)")
            
            if not resposta:
                self.editar_lancamento()
                return
        
        # Coletar dados dos lançamentos selecionados
        dados_selecionados = []
        ids_selecionados = []
        
        for item in items_selecionados:
            try:
                valores = self.tree_lancamentos.item(item)['values']
                
                if len(valores) < 9:
                    logger.debug(f"DEBUG: Item com dados insuficientes: {valores}")
                    continue
                
                id_lancamento = valores[9]
                
                # Validação: Verificar se o ID existe
                mask = self.dados_originais['ID_LANCAMENTO'] == id_lancamento
                dados_completos = self.dados_originais[mask]
                
                if dados_completos.empty:
                    logger.debug(f"⚠️ ID {id_lancamento} não encontrado!")
                    continue
                
                lancamento_completo = dados_completos.iloc[0]
                
                # Montar estrutura de dados
                dados_item = {
                    'data': valores[1],
                    'tp_desp': str(valores[2]),
                    'nome': valores[3],       
                    'referencia': valores[4],
                    'nf': valores[5],
                    'valor': valores[6],
                    'dt_vencto': valores[7],
                    'status': valores[8],
                    'id_lancamento': id_lancamento,
                    'cnpj_cpf': str(lancamento_completo.get('CNPJ_CPF', '')),
                    'categoria': str(lancamento_completo.get('CATEGORIA', '')),
                    'vr_unit': str(lancamento_completo.get('VR_UNIT', '')),
                    'dias': str(lancamento_completo.get('DIAS', '1')),
                    'dados_bancarios': str(lancamento_completo.get('DADOS_BANCARIOS', '')),
                    'observacao': str(lancamento_completo.get('OBSERVAÇÃO', '')),
                    'etapa_obra': str(lancamento_completo.get('ETAPA_OBRA', '')),
                    'insumo': str(lancamento_completo.get('INSUMO', ''))
                }
                
                dados_selecionados.append(dados_item)
                ids_selecionados.append(id_lancamento)
                
                logger.debug(f"✅ Preparado lançamento ID {id_lancamento}: {dados_item['nome']}")
                
            except Exception as e:
                logger.debug(f"❌ Erro ao processar item: {str(e)}")
                continue
        
        if not dados_selecionados:
            custom_messagebox("error", "Erro", 
                            "Não foi possível coletar os dados dos lançamentos selecionados.")
            return
        
        logger.debug(f"DEBUG: {len(dados_selecionados)} lançamentos preparados")
        logger.debug(f"DEBUG: IDs: {ids_selecionados}")
        
        # Passar referência ao gerenciador =====
        editor = EditorEmMassaGerenciador(self.janela, dados_selecionados, 
                                        ids_selecionados, self)

    def verificar_recalculo_datas_afetadas(self, datas_afetadas, tipo_operacao):
        """
        Verifica e oferece recálculo de taxas para múltiplas datas afetadas
        
        Args:
            datas_afetadas: Set de objetos date que foram afetados
            tipo_operacao: String identificando a operação ("EXCLUSAO", "ALTERACAO", "RESTAURACAO")
        """
        try:
            if not datas_afetadas:
                logger.debug("DEBUG: Nenhuma data para verificar recálculo")
                return
            
            logger.debug(f"DEBUG: Verificando recálculo para {len(datas_afetadas)} data(s)")
            
            # Verificar cada data afetada
            for data_verificar in sorted(datas_afetadas):
                try:
                    logger.debug(f"DEBUG: Verificando data {data_verificar}")
                    
                    # Chamar o sistema de verificação unificado
                    if hasattr(self.sistema, 'chamar_apos_operacao_lancamento'):
                        resultado = self.sistema.chamar_apos_operacao_lancamento(data_verificar, tipo_operacao)
                        
                        if resultado.get("sucesso"):
                            logger.debug(f"✅ Verificação OK para {data_verificar}: {resultado.get('mensagem')}")
                        else:
                            logger.debug(f"⚠️ Problema na verificação para {data_verificar}: {resultado.get('mensagem')}")
                    else:
                        logger.debug(f"⚠️ Método de verificação não disponível")
                        
                except Exception as e:
                    logger.debug(f"❌ Erro ao verificar {data_verificar}: {str(e)}")
                    continue
                    
        except Exception as e:
            logger.debug(f"DEBUG: Erro geral na verificação de recálculo: {str(e)}")

    def excluir_lancamento(self):
        """
        Versão corrigida que usa o novo sistema de verificação após exclusão
        """
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para excluir")
            return
        
        valores = self.tree_lancamentos.item(item_selecionado[0])['values']
        tp_desp = valores[2]         # Tipo de despesa
        nome_lancamento = valores[3]  # Nome
        referencia = valores[4]      # Referência
        valor = valores[6]           # Valor
        data_lancamento = valores[1] # Data
        status_atual = valores[8]    # Status
        id_lancamento = valores[9]   # ID
        
        # Verificar se já está excluído
        if status_atual == 'EXCLUIDO':
            custom_messagebox("info", "Informação", "Este lançamento já está excluído")
            return
        
        # Verificar se é uma taxa de administração
        eh_taxa = (tp_desp == 7)
        
        if eh_taxa:
            if not custom_messagebox("yesno", "Confirmação - Taxa de Administração", 
                                f"Você está excluindo uma TAXA DE ADMINISTRAÇÃO:\n\n"
                                f"📋 {referencia}\n"
                                f"💰 {valor}\n"
                                f"📅 {data_lancamento}\n\n"
                                f"⚠️ ATENÇÃO: A exclusão de uma taxa pode afetar os cálculos!\n\n"
                                f"Deseja realmente continuar?"):
                return
        else:
            if not custom_messagebox("yesno", "Confirmação", 
                                f"Deseja realmente excluir este lançamento?\n\n"
                                f"👤 {nome_lancamento}\n"
                                f"📋 {referencia}\n"
                                f"💰 {valor}\n"
                                f"📅 {data_lancamento}\n\n"
                                f"🔄 As taxas de administração do tipo % deverão ser verificadas."):
                return
        
        try:
            id_lancamento = valores[9]
            
            logger.debug(f"DEBUG: Excluindo lançamento ID {id_lancamento}")
            
            # Atualizar status para EXCLUIDO
            self.atualizar_status_lancamento(id_lancamento, 'EXCLUIDO')
            logger.debug(f"DEBUG: Status atualizado para EXCLUIDO")

            # ===== NOVA INTEGRAÇÃO: Usar método unificado =====
            logger.debug(f"DEBUG: Iniciando verificação de recálculo para data {data_lancamento}")
            data_para_recalculo = datetime.strptime(data_lancamento, '%d/%m/%Y').date()
            
            # Aguardar um pouco para garantir que a exclusão foi salva
            import time
            time.sleep(0.5)
            
            # CORREÇÃO: Usar o novo método de verificação
            # resultado_verificacao = self.sistema.chamar_apos_operacao_lancamento(data_para_recalculo, "EXCLUSAO")
            
            # Recarregar lista
            self.carregar_lancamentos()
            
            # Mostrar resultado
            if eh_taxa:
                mensagem = "Taxa de administração excluída com sucesso!"
                mensagem += "\n\n⚠️ IMPORTANTE: Verifique se há outras taxas para esta data que precisam de ajuste."
            else:
                mensagem = "Lançamento excluído com sucesso!"
                
                # if resultado_verificacao["sucesso"]:
                #     # Verificar se houve recálculo automático baseado no resultado
                #     if ("recalculadas" in resultado_verificacao["mensagem"] or 
                #         "Recálculo Concluído" in str(resultado_verificacao)):
                #         mensagem += f"\n\n✅ Taxas foram recalculadas automaticamente!"
                #     elif "corretas" in resultado_verificacao["mensagem"]:
                #         mensagem += f"\n\n✅ Taxas verificadas - estão corretas"
                #     elif "cancelado" in resultado_verificacao["mensagem"]:
                #         mensagem += f"\n\n⚠️ Recálculo foi oferecido mas cancelado pelo usuário"
                #     else:
                #         mensagem += f"\n\n{resultado_verificacao['mensagem']}"
                # else:
                #     mensagem += f"\n\n⚠️ AVISO: {resultado_verificacao['mensagem']}"
            
            custom_messagebox("info", "Sucesso", mensagem)
            
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro ao excluir: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro ao excluir lançamento: {str(e)}")

    def restaurar_lancamento(self):
        """
        Versão corrigida que usa o novo sistema de verificação após restauração
        """
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para restaurar")
            return
        
        valores = self.tree_lancamentos.item(item_selecionado[0])['values']
        tp_desp = valores[2]         # Tipo de despesa
        nome_lancamento = valores[3]  # Nome
        referencia = valores[4]      # Referência
        valor = valores[6]           # Valor
        data_lancamento = valores[1] # Data
        status_atual = valores[8]    # Status
        id_lancamento = valores[9]   # ID
        
        # Verificar se já está ativo
        if status_atual != 'EXCLUIDO':
            custom_messagebox("info", "Informação", "Este lançamento já está ativo")
            return
        
        # Verificar se é uma taxa de administração
        eh_taxa = (tp_desp == 7)
        
        # Confirmar restauração
        if eh_taxa:
            if not custom_messagebox("yesno", "Confirmação - Taxa de Administração", 
                                f"Você está restaurando uma TAXA DE ADMINISTRAÇÃO:\n\n"
                                f"📋 {referencia}\n"
                                f"💰 {valor}\n"
                                f"📅 {data_lancamento}\n\n"
                                f"⚠️ ATENÇÃO: Verifique se não há duplicação de taxas!\n\n"
                                f"Deseja realmente continuar?"):
                return
        else:
            if not custom_messagebox("yesno", "Confirmação", 
                                f"Deseja realmente restaurar este lançamento?\n\n"
                                f"👤 {nome_lancamento}\n"
                                f"📋 {referencia}\n"
                                f"💰 {valor}\n"
                                f"📅 {data_lancamento}\n\n"
                                f"🔄 As taxas de administração do tipo % deverão ser verificadas."):
                return
        
        try:
            id_lancamento = valores[9]
            
            logger.debug(f"DEBUG: Restaurando lançamento ID {id_lancamento}")
            
            # Atualizar status para ATIVO
            self.atualizar_status_lancamento(id_lancamento, 'ATIVO')
            logger.debug(f"DEBUG: Status atualizado para ATIVO")

            # ===== NOVA INTEGRAÇÃO: Usar método unificado =====
            logger.debug(f"DEBUG: Iniciando verificação de recálculo para data {data_lancamento}")
            data_para_recalculo = datetime.strptime(data_lancamento, '%d/%m/%Y').date()
            
            # Aguardar um pouco para garantir que a restauração foi salva
            import time
            time.sleep(0.5)
            
            # CORREÇÃO: Usar o novo método de verificação
            # resultado_verificacao = self.sistema.chamar_apos_operacao_lancamento(data_para_recalculo, "ALTERACAO")
            
            # Recarregar lista
            self.carregar_lancamentos()
            
            # Mostrar resultado
            if eh_taxa:
                mensagem = "Taxa de administração restaurada com sucesso!"
                mensagem += "\n\n⚠️ IMPORTANTE: Verifique se não há duplicação de taxas para esta data."
            else:
                mensagem = "Lançamento restaurado com sucesso!"
                
                # if resultado_verificacao["sucesso"]:
                #     # Verificar se houve recálculo automático baseado no resultado
                #     if ("recalculadas" in resultado_verificacao["mensagem"] or 
                #         "Recálculo Concluído" in str(resultado_verificacao)):
                #         mensagem += f"\n\n✅ Taxas foram recalculadas automaticamente!"
                #     elif "corretas" in resultado_verificacao["mensagem"]:
                #         mensagem += f"\n\n✅ Taxas verificadas - estão corretas"
                #     elif "cancelado" in resultado_verificacao["mensagem"]:
                #         mensagem += f"\n\n⚠️ Recálculo foi oferecido mas cancelado pelo usuário"
                #     else:
                #         mensagem += f"\n\n{resultado_verificacao['mensagem']}"
                # else:
                #     mensagem += f"\n\n⚠️ AVISO: {resultado_verificacao['mensagem']}"
            
            custom_messagebox("info", "Sucesso", mensagem)
            
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro ao restaurar: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro ao restaurar lançamento: {str(e)}")        

    def visualizar_historico_lancamento(self):
        """Visualiza o histórico de alterações de um lançamento com correção robusta"""
        try:
            # Verificar se há item selecionado
            selected_items = self.tree_lancamentos.selection()
            if not selected_items:
                custom_messagebox("info", "Seleção", "Selecione um lançamento para ver o histórico!")
                return
            
            # Obter o item selecionado
            item = selected_items[0]
            valores = self.tree_lancamentos.item(item, 'values')
            
            # CORREÇÃO: O ID está na última posição (índice 9)
            # Colunas: (✓, 'Data', 'Tipo', 'Nome', 'Referência', 'NF', 'Valor', 'Vencimento', 'Status', 'ID')
            id_lancamento = valores[9]  # ID é o último elemento
            
            logger.debug(f"DEBUG: Buscando histórico para ID: {id_lancamento} (tipo: {type(id_lancamento)})")
            
            # CORREÇÃO: Verificar se dados_originais existe e não está vazio
            if not hasattr(self, 'dados_originais') or self.dados_originais.empty:
                custom_messagebox("error", "Erro", "Dados não carregados. Clique em 'Atualizar' primeiro!")
                return
            
            # CORREÇÃO: Converter ID para o mesmo tipo usado no DataFrame
            try:
                # Primeiro, verificar qual tipo está sendo usado na coluna ID_LANCAMENTO
                id_col_dtype = self.dados_originais['ID_LANCAMENTO'].dtype
                logger.debug(f"DEBUG: Tipo da coluna ID_LANCAMENTO: {id_col_dtype}")
                
                # Converter o ID para o tipo correto
                if 'int' in str(id_col_dtype):
                    id_busca = int(float(str(id_lancamento)))  # Conversão robusta via float primeiro
                else:
                    id_busca = str(id_lancamento)
                    
                logger.debug(f"DEBUG: ID convertido para busca: {id_busca} (tipo: {type(id_busca)})")
                
            except (ValueError, TypeError) as e:
                logger.debug(f"DEBUG: Erro na conversão do ID: {e}")
                custom_messagebox("error", "Erro", f"ID inválido: {id_lancamento}")
                return
            
            # CORREÇÃO: Busca mais robusta com verificação de resultado
            filtro = self.dados_originais['ID_LANCAMENTO'] == id_busca
            lancamentos_encontrados = self.dados_originais[filtro]
            
            logger.debug(f"DEBUG: Lançamentos encontrados: {len(lancamentos_encontrados)}")
            
            if lancamentos_encontrados.empty:
                # DEBUG: Mostrar alguns IDs disponíveis para comparação
                ids_disponiveis = self.dados_originais['ID_LANCAMENTO'].head(10).tolist()
                logger.debug(f"DEBUG: Primeiros 10 IDs disponíveis: {ids_disponiveis}")
                
                custom_messagebox("error", "Erro", 
                    f"Lançamento com ID {id_busca} não encontrado!\n"
                    f"Clique em 'Atualizar' para recarregar os dados.")
                return
            
            # Obter o lançamento (agora sabemos que existe)
            lancamento = lancamentos_encontrados.iloc[0]
            
            # Criar janela de histórico - TAMANHO REDUZIDO
            janela_historico = tk.Toplevel(self.janela)
            janela_historico.title(f"Histórico do Lançamento - ID {id_busca}")
            janela_historico.geometry("700x300")  # Reduzido de 800x600 para 700x400
            janela_historico.transient(self.janela)
            janela_historico.grab_set()
            
            # Frame principal
            frame_principal = ttk.Frame(janela_historico, padding="10")
            frame_principal.pack(fill='both', expand=True)
            
            # Informações do lançamento - FORMATO MAIS COMPACTO
            frame_info = ttk.LabelFrame(frame_principal, text="Informações do Lançamento")
            frame_info.pack(fill='x', pady=(0, 10))
            
            # LAYOUT EM DUAS COLUNAS para economizar espaço vertical
            info_frame_interno = ttk.Frame(frame_info)
            info_frame_interno.pack(fill='x', padx=10, pady=5)
            
            # Coluna esquerda
            frame_esq = ttk.Frame(info_frame_interno)
            frame_esq.pack(side='left', fill='x', expand=True)
            
            ttk.Label(frame_esq, text=f"ID: {lancamento['ID_LANCAMENTO']}", font=('TkDefaultFont', 9, 'bold')).pack(anchor='w')
            ttk.Label(frame_esq, text=f"Nome: {lancamento['NOME']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            ttk.Label(frame_esq, text=f"Referência: {lancamento['REFERÊNCIA']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            
            # Coluna direita
            frame_dir = ttk.Frame(info_frame_interno)
            frame_dir.pack(side='right', fill='x', expand=True)
            
            ttk.Label(frame_dir, text=f"Valor: R$ {lancamento['VALOR']:,.2f}", font=('TkDefaultFont', 9)).pack(anchor='w')
            ttk.Label(frame_dir, text=f"Status: {lancamento['STATUS']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            
            # Frame do histórico - ALTURA FIXA E MENOR
            frame_historico = ttk.LabelFrame(frame_principal, text="Histórico de Alterações")
            frame_historico.pack(fill='x', pady=(0, 10))  # fill='x' em vez de fill='both', expand=True
            
            # Text widget para mostrar o histórico - ALTURA FIXA
            text_historico = tk.Text(frame_historico, wrap='word', font=('Consolas', 9), height=8)  # height=8 linhas fixas
            scrollbar_hist = ttk.Scrollbar(frame_historico, orient='vertical', command=text_historico.yview)
            text_historico.configure(yscrollcommand=scrollbar_hist.set)
            
            # Obter histórico
            historico = lancamento.get('HISTORICO_ALTERACAO', '')
            if historico and str(historico) not in ['', 'nan', 'None']:
                text_historico.insert('1.0', str(historico))
            else:
                text_historico.insert('1.0', "Nenhum histórico de alterações registrado.")
            
            text_historico.config(state='disabled')  # Apenas leitura
            
            # Posicionar elementos com padding reduzido
            text_historico.pack(side='left', fill='both', expand=True, padx=(10, 0), pady=5)
            scrollbar_hist.pack(side='right', fill='y', pady=5)
            
            # Frame de botões para melhor organização
            frame_botoes = ttk.Frame(frame_principal)
            frame_botoes.pack(fill='x', pady=(5, 0))
            
            # Botão fechar centralizado
            ttk.Button(frame_botoes, text="Fechar", 
                    command=janela_historico.destroy).pack(side='right')
            
            logger.debug(f"DEBUG: Histórico exibido com sucesso para ID {id_busca}")
            
        except Exception as e:
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao visualizar histórico: {str(e)}")
            logger.debug(f"DEBUG: Erro completo: {str(e)}")

    def salvar_edicao(self, id_lancamento, dados_editados):
        """
        Callback chamado pelo EditorLancamentoCompleto após edição
        
        Args:
            id_lancamento: ID do lançamento sendo editado
            dados_editados: Novos dados do lançamento
        
        Returns:
            bool: True se salvou com sucesso, False caso contrário
        """
        try:
            logger.debug(f"=== INÍCIO SALVAR_EDICAO ===")
            logger.debug(f"Salvando edição do lançamento ID {id_lancamento}")
            
            # ✅ BUSCAR DADOS ORIGINAIS PARA COMPARAÇÃO E HISTÓRICO
            dados_originais = None
            data_original = None
            
            if hasattr(self, 'dados_originais') and not self.dados_originais.empty:
                mask = self.dados_originais['ID_LANCAMENTO'] == id_lancamento
                dados_filtrados = self.dados_originais[mask]
                
                if not dados_filtrados.empty:
                    dados_originais = dados_filtrados.iloc[0]
                    data_original = dados_originais.get('DATA_REL')
                    
                    # Converter data original se necessário
                    if pd.notna(data_original):
                        if isinstance(data_original, str):
                            data_original = datetime.strptime(data_original, '%d/%m/%Y').date()
                        else:
                            data_original = data_original.date()
                    
                    logger.debug(f"DEBUG: Dados originais encontrados para ID {id_lancamento}")
                else:
                    logger.warning(f"⚠️ Dados originais não encontrados para ID {id_lancamento}")
            else:
                logger.warning(f"⚠️ DataFrame dados_originais não disponível")
            
            # ✅ OBTER DATA EDITADA
            data_editada = None
            if dados_editados.get('data'):
                if isinstance(dados_editados['data'], str):
                    data_editada = datetime.strptime(dados_editados['data'], '%d/%m/%Y').date()
                else:
                    data_editada = dados_editados['data']
            
            logger.debug(f"DEBUG: Data original: {data_original}, Data editada: {data_editada}")
            
            # ✅ DEBUG: Mostrar dados recebidos
            logger.debug(f"DEBUG: Dados editados recebidos:")
            for campo, valor in dados_editados.items():
                logger.debug(f"  - {campo}: '{valor}' (tipo: {type(valor).__name__})")
            
            # ✅ SALVAR A EDIÇÃO NA PLANILHA
            sucesso_salvamento = self._executar_salvamento_edicao(
                id_lancamento, 
                dados_editados, 
                dados_originais
            )
            
            if not sucesso_salvamento:
                logger.error(f"❌ Falha ao salvar edição do lançamento ID {id_lancamento}")
                return False
            
            logger.debug(f"✅ Edição salva na planilha com sucesso")
            
            # ✅ DETERMINAR QUAIS DATAS PRECISAM SER VERIFICADAS
            datas_para_verificar = set()
            if data_original:
                datas_para_verificar.add(data_original)
            if data_editada and data_editada != data_original:
                datas_para_verificar.add(data_editada)
            
            # ✅ VERIFICAR RECÁLCULO DE TAXAS (se houver sistema de taxas)
            if datas_para_verificar and hasattr(self.sistema, 'chamar_apos_operacao_lancamento'):
                logger.debug(f"DEBUG: Verificando recálculo para {len(datas_para_verificar)} data(s)")
                for data_verificar in datas_para_verificar:
                    try:
                        self.sistema.chamar_apos_operacao_lancamento(data_verificar, "ALTERACAO")
                    except Exception as e:
                        logger.warning(f"⚠️ Erro ao verificar recálculo para {data_verificar}: {str(e)}")
            
            # ✅ RECARREGAR A VISUALIZAÇÃO
            if hasattr(self, 'carregar_lancamentos'):
                logger.debug(f"DEBUG: Recarregando visualização")
                self.carregar_lancamentos()
            
            logger.info(f"✅ Edição do lançamento ID {id_lancamento} salva com sucesso")
            logger.debug(f"=== FIM SALVAR_EDICAO (SUCESSO) ===")
            return True
            
        except Exception as e:
            import traceback
            logger.error(f"❌ Erro ao salvar edição: {str(e)}")
            logger.debug(f"=== TRACEBACK COMPLETO ===")
            logger.debug(traceback.format_exc())
            logger.debug(f"=== DADOS QUE CAUSARAM O ERRO ===")
            logger.debug(f"ID: {id_lancamento}")
            logger.debug(f"Dados editados: {dados_editados}")
            logger.debug(f"=== FIM SALVAR_EDICAO (ERRO) ===")
            return False
    
    def _executar_salvamento_edicao(self, id_lancamento, dados_editados, dados_originais):
        """
        Executa o salvamento físico da edição na planilha
        
        Args:
            id_lancamento: ID do lançamento
            dados_editados: Novos dados
            dados_originais: Dados originais (para histórico)
        
        Returns:
            bool: True se salvou com sucesso
        """
        try:
            # ✅ DEBUG: Verificar dados recebidos
            logger.debug(f"DEBUG: Salvando ID {id_lancamento}")
            logger.debug(f"DEBUG: Dados editados recebidos:")
            for campo, valor in dados_editados.items():
                logger.debug(f"  - {campo}: '{valor}' (tipo: {type(valor).__name__})")
        
            # Abrir arquivo
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            wb = load_workbook(arquivo_cliente)
            ws = wb["Dados"]
            
            # Encontrar a linha do lançamento
            linha_encontrada = None
            for row_num in range(2, ws.max_row + 1):
                id_na_planilha = ws.cell(row=row_num, column=15).value  # Coluna O (ID_LANCAMENTO)
                
                if str(id_na_planilha) == str(id_lancamento):
                    linha_encontrada = row_num
                    break
            
            if not linha_encontrada:
                logger.debug(f"DEBUG: Lançamento ID {id_lancamento} não encontrado na planilha")
                wb.close()
                return False
            
            logger.debug(f"DEBUG: Editando lançamento na linha {linha_encontrada}")
            
            # ===== FUNÇÃO AUXILIAR PARA CONVERTER VALORES NUMÉRICOS =====
            def converter_valor_numerico(valor_str, tipo='float'):
                """
                Converte string para número de forma segura
                """
                logger.debug(f"DEBUG converter_valor_numerico: entrada='{valor_str}' tipo={tipo}")
                
                if not valor_str or pd.isna(valor_str) or str(valor_str).strip() == '':
                    logger.debug(f"DEBUG converter_valor_numerico: valor vazio, retornando None")
                    return None
                
                try:
                    valor_str = str(valor_str).strip()
                    
                    # Contar pontos e vírgulas
                    qtd_pontos = valor_str.count('.')
                    qtd_virgulas = valor_str.count(',')
                    
                    logger.debug(f"DEBUG converter_valor_numerico: pontos={qtd_pontos}, vírgulas={qtd_virgulas}")
                    
                    # Formato brasileiro: 1.234.567,89
                    if qtd_virgulas == 1 and qtd_pontos >= 0:
                        valor_limpo = valor_str.replace('.', '').replace(',', '.')
                        logger.debug(f"DEBUG converter_valor_numerico: formato BR detectado, limpo='{valor_limpo}'")
                    
                    # Formato americano: 1,234,567.89
                    elif qtd_pontos == 1 and qtd_virgulas >= 0:
                        valor_limpo = valor_str.replace(',', '')
                        logger.debug(f"DEBUG converter_valor_numerico: formato US detectado, limpo='{valor_limpo}'")
                    
                    # Sem formatação
                    else:
                        valor_limpo = valor_str.replace(',', '.')
                        logger.debug(f"DEBUG converter_valor_numerico: sem formato, limpo='{valor_limpo}'")
                    
                    # Converter
                    if tipo == 'int':
                        resultado = int(float(valor_limpo))
                    else:
                        resultado = float(valor_limpo)
                    
                    logger.debug(f"DEBUG converter_valor_numerico: conversão OK, resultado={resultado}")
                    return resultado
                    
                except Exception as e:
                    logger.error(f"ERROR converter_valor_numerico: Erro ao converter '{valor_str}': {str(e)}")
                    import traceback
                    logger.debug(traceback.format_exc())
                    return None
            
            # ===== ATUALIZAR OS DADOS NA PLANILHA =====
            
            # Data do relatório (Coluna A)
            if dados_editados.get('data'):
                try:
                    data_rel = datetime.strptime(dados_editados['data'], '%d/%m/%Y') if isinstance(dados_editados['data'], str) else dados_editados['data']
                    ws.cell(row=linha_encontrada, column=1, value=data_rel)
                    ws.cell(row=linha_encontrada, column=1).number_format = 'DD/MM/YYYY'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar data: {str(e)}")
            
            # Tipo de despesa (Coluna B)
            if dados_editados.get('tp_desp'):
                try:
                    tp_desp_valor = converter_valor_numerico(dados_editados['tp_desp'], 'int')
                    if tp_desp_valor is not None:
                        ws.cell(row=linha_encontrada, column=2, value=tp_desp_valor)
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar tipo despesa: {str(e)}")
            
            # CNPJ/CPF (Coluna C) - CORREÇÃO ROBUSTA
            cnpj_cpf_valor = dados_editados.get('cnpj_cpf', '')
            try:
                # Salvar como texto, preservando formatação original
                # A planilha espera formato com pontos, traços e barras
                cnpj_cpf_str = str(cnpj_cpf_valor).strip()
                
                # Se estiver vazio, manter vazio
                if cnpj_cpf_str and cnpj_cpf_str not in ['nan', 'None', '']:
                    # Salvar como texto para preservar zeros à esquerda e formatação
                    ws.cell(row=linha_encontrada, column=3, value=cnpj_cpf_str)
                    # Forçar formato de texto
                    ws.cell(row=linha_encontrada, column=3).number_format = '@'
                else:
                    ws.cell(row=linha_encontrada, column=3, value='')
                
                logger.debug(f"DEBUG: CNPJ/CPF salvo: '{cnpj_cpf_str}'")
                
            except Exception as e:
                logger.debug(f"DEBUG: Erro ao salvar CNPJ/CPF '{cnpj_cpf_valor}': {str(e)}")
                # Em caso de erro, salvar string vazia
                ws.cell(row=linha_encontrada, column=3, value='')
            
            # Nome (Coluna D)
            ws.cell(row=linha_encontrada, column=4, value=dados_editados.get('nome', ''))
            
            # Referência (Coluna E)
            ws.cell(row=linha_encontrada, column=5, value=dados_editados.get('referencia', ''))
            
            # Verificar se os cabeçalhos existem e criar se necessário
            if ws.cell(row=1, column=17).value != 'ETAPA_OBRA':
                ws.cell(row=1, column=17, value='ETAPA_OBRA')
            
            if ws.cell(row=1, column=18).value != 'INSUMO':
                ws.cell(row=1, column=18, value='INSUMO')
            
            # Etapa da Obra (Coluna Q)
            ws.cell(row=linha_encontrada, column=17, value=dados_editados.get('etapa_obra', ''))
            
            # Insumo (Coluna R)
            ws.cell(row=linha_encontrada, column=18, value=dados_editados.get('insumo', ''))
            
            # NF (Coluna F)
            ws.cell(row=linha_encontrada, column=6, value=dados_editados.get('nf', ''))
            
            # Valor Unitário (Coluna G) - CONVERSÃO SEGURA
            if dados_editados.get('vr_unit'):
                try:
                    vr_unit = converter_valor_numerico(dados_editados['vr_unit'])
                    if vr_unit is not None:
                        ws.cell(row=linha_encontrada, column=7, value=vr_unit)
                        ws.cell(row=linha_encontrada, column=7).number_format = '#,##0.00'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar valor unitário: {str(e)}")
            
            # Dias (Coluna H) - CONVERSÃO SEGURA
            if dados_editados.get('dias'):
                try:
                    dias = converter_valor_numerico(dados_editados['dias'])
                    if dias is not None:
                        ws.cell(row=linha_encontrada, column=8, value=dias)
                        ws.cell(row=linha_encontrada, column=8).number_format = '0.0'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar dias: {str(e)}")
            
            # Valor Total (Coluna I) - CONVERSÃO SEGURA
            if dados_editados.get('valor'):
                try:
                    valor = converter_valor_numerico(dados_editados['valor'])
                    if valor is not None:
                        ws.cell(row=linha_encontrada, column=9, value=valor)
                        ws.cell(row=linha_encontrada, column=9).number_format = '#,##0.00'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar valor total: {str(e)}")
            
            # Data de Vencimento (Coluna J)
            if dados_editados.get('dt_vencto'):
                try:
                    dt_vencto = datetime.strptime(dados_editados['dt_vencto'], '%d/%m/%Y') if isinstance(dados_editados['dt_vencto'], str) else dados_editados['dt_vencto']
                    ws.cell(row=linha_encontrada, column=10, value=dt_vencto)
                    ws.cell(row=linha_encontrada, column=10).number_format = 'DD/MM/YYYY'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar data vencimento: {str(e)}")
            
            # Categoria (Coluna K)
            ws.cell(row=linha_encontrada, column=11, value=dados_editados.get('categoria', ''))
            
            # Dados Bancários (Coluna L)
            ws.cell(row=linha_encontrada, column=12, value=dados_editados.get('dados_bancarios', ''))
            
            # ===== OBSERVAÇÃO COM HISTÓRICO DE EDIÇÃO (Coluna M) =====
            observacao_atual = ws.cell(row=linha_encontrada, column=13).value or ""
            observacao_editada = dados_editados.get('observacao', '')

            # Garantir que ambos sejam string antes de .strip()
            if not isinstance(observacao_atual, str):
                observacao_atual = '' if pd.isna(observacao_atual) else str(observacao_atual)
            if not isinstance(observacao_editada, str):
                observacao_editada = '' if pd.isna(observacao_editada) else str(observacao_editada)
            
            # Limpar edições anteriores da observação
            if 'EDITADO EM:' in observacao_atual:
                observacao_base = observacao_atual.split(' - EDITADO EM:')[0]
            else:
                observacao_base = observacao_atual
            
            # Se a observação mudou, usar a nova; senão manter a base
            if observacao_editada.strip() and observacao_editada.strip() != observacao_base.strip():
                observacao_final = observacao_editada
            else:
                observacao_final = observacao_base
            
            # Adicionar timestamp de edição
            timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
            prefixo = f"{observacao_final} - " if observacao_final.strip() else ""
            observacao_com_historico = f"{prefixo}EDITADO EM: {timestamp}"
            
            ws.cell(row=linha_encontrada, column=13, value=observacao_com_historico)
            
            # ===== HISTÓRICO DE ALTERAÇÕES (Coluna P) =====
            historico_atual = ws.cell(row=linha_encontrada, column=16).value or ""
            
            # Criar resumo das principais alterações
            alteracoes = []
            
            if dados_originais is not None:
                # Verificar principais campos que mudaram
                try:
                    valor_editado = converter_valor_numerico(dados_editados.get('valor'))
                    valor_original = converter_valor_numerico(dados_originais.get('VALOR', ''))
                    
                    if valor_editado is not None and valor_original is not None and valor_editado != valor_original:
                        alteracoes.append(f"VALOR: {valor_original:.2f} → {valor_editado:.2f}")
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao comparar valores: {str(e)}")
                
                # Comparar datas
                try:
                    if dados_editados.get('data'):
                        data_antiga = dados_originais.get('DATA_REL')
                        if pd.notna(data_antiga):
                            if isinstance(data_antiga, str):
                                data_antiga_str = data_antiga
                            else:
                                data_antiga_str = data_antiga.strftime('%d/%m/%Y')
                            
                            data_nova_str = dados_editados['data'] if isinstance(dados_editados['data'], str) else dados_editados['data'].strftime('%d/%m/%Y')
                            
                            if data_antiga_str != data_nova_str:
                                alteracoes.append(f"DATA: {data_antiga_str} → {data_nova_str}")
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao comparar datas: {str(e)}")
                
                # Verificar alterações nos campos de texto
                for campo_editado, campo_original, nome_campo in [
                    ('etapa_obra', 'ETAPA_OBRA', 'ETAPA_OBRA'),
                    ('insumo', 'INSUMO', 'INSUMO'),
                    ('nome', 'NOME', 'NOME'),
                    ('referencia', 'REFERÊNCIA', 'REFERENCIA')
                ]:
                    try:
                        valor_editado = str(dados_editados.get(campo_editado, '')).strip()
                        valor_original = str(dados_originais.get(campo_original, '')).strip()
                        
                        if valor_editado != valor_original and (valor_editado or valor_original):
                            # Limitar tamanho para o histórico
                            valor_editado_curto = valor_editado[:30] + '...' if len(valor_editado) > 30 else valor_editado
                            valor_original_curto = valor_original[:30] + '...' if len(valor_original) > 30 else valor_original
                            alteracoes.append(f"{nome_campo}: {valor_original_curto} → {valor_editado_curto}")
                    except Exception as e:
                        logger.debug(f"DEBUG: Erro ao comparar {nome_campo}: {str(e)}")
            
            # Se não conseguiu detectar alterações específicas, registrar edição geral
            if not alteracoes:
                alteracoes = ["EDITADO"]
            
            # Adicionar ao histórico
            nova_entrada = f"EDIÇÃO: {', '.join(alteracoes[:3])} - {timestamp}"  # Limitar a 3 alterações
            
            novo_historico = nova_entrada
            if historico_atual:
                # Limitar histórico para não ficar muito longo (manter últimas 5 entradas)
                historico_partes = historico_atual.split(' | ')
                if len(historico_partes) >= 5:
                    historico_partes = historico_partes[-4:]  # Manter últimas 4
                novo_historico = ' | '.join(historico_partes) + ' | ' + nova_entrada
            
            ws.cell(row=linha_encontrada, column=16, value=novo_historico)
            
            # Salvar arquivo
            salvar_planilha_segura(wb, arquivo_cliente)
            wb.close()
            
            logger.debug(f"✅ Edição salva com sucesso na linha {linha_encontrada}")
            return True
            
        except Exception as e:
            import traceback
            logger.debug(f"DEBUG: Erro ao salvar edição na planilha: {traceback.format_exc()}")
            if 'wb' in locals():
                try:
                    wb.close()
                except:
                    pass
            return False
    
    def atualizar_status_lancamento(self, id_lancamento, novo_status):
        """Atualiza o status de um lançamento específico"""
        try:
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            
            # Carregar workbook
            wb = load_workbook(arquivo_cliente)
            ws = wb['Dados']
            
            # Verificar se colunas existem, se não, criar
            if ws.cell(row=1, column=14).value != 'STATUS':
                ws.cell(row=1, column=14, value='STATUS')
            
            if ws.cell(row=1, column=15).value != 'ID_LANCAMENTO':
                ws.cell(row=1, column=15, value='ID_LANCAMENTO')
                
            if ws.cell(row=1, column=16).value != 'HISTORICO_ALTERACAO':
                ws.cell(row=1, column=16, value='HISTORICO_ALTERACAO')
            
            # Encontrar e atualizar linha
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=15).value == id_lancamento:
                    # Atualizar status
                    ws.cell(row=row, column=14, value=novo_status)
                    
                    # Adicionar ao histórico
                    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    historico_atual = ws.cell(row=row, column=16).value or ""
                    
                    if novo_status == 'EXCLUIDO':
                        acao = f"EXCLUÍDO EM: {timestamp}"
                    elif novo_status == 'ATIVO':
                        acao = f"RESTAURADO EM: {timestamp}"
                    else:
                        acao = f"STATUS ALTERADO PARA {novo_status} EM: {timestamp}"
                    
                    if historico_atual:
                        novo_historico = f"{historico_atual} | {acao}"
                    else:
                        novo_historico = acao
                        
                    ws.cell(row=row, column=16, value=novo_historico)
                    break
            
            salvar_planilha_segura(wb, arquivo_cliente)
            
        except Exception as e:
            raise Exception(f"Erro ao atualizar status: {str(e)}")
    
    def formatar_data(self, data):
        """Formata data para exibição"""
        if pd.isna(data) or data == "":
            return ""
        try:
            if isinstance(data, str):
                return data
            return data.strftime('%d/%m/%Y')
        except:
            return str(data)
    
    def formatar_valor(self, valor):
        """Formata valor para exibição"""
        try:
            if isinstance(valor, str):
                valor = float(valor.replace(',', '.'))
            return f"{valor:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        except:
            return str(valor)

class EditorLancamentoCompleto:
    def __init__(self, parent, lancamento, callback_salvar):
        self.janela = tk.Toplevel(parent)
        self.janela.title("Editar Lançamento")
        self.janela.geometry("700x600")
        self.lancamento = lancamento
        self.callback_salvar = callback_salvar
        
        # Configurar janela
        self.janela.transient(parent)
        self.janela.grab_set()
        
        self.criar_interface()
        self.preencher_dados()
        
    def criar_interface(self):
        """Cria a interface do editor"""
        # Frame principal com scroll
        main_frame = ttk.Frame(self.janela, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # Dados básicos
        frame_basicos = ttk.LabelFrame(main_frame, text="Dados Básicos")
        frame_basicos.pack(fill='x', pady=5)
        
        # Data do Relatório
        ttk.Label(frame_basicos, text="Data do Relatório:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.data_rel = DateEntry(frame_basicos, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_rel.grid(row=0, column=1, padx=5, pady=2, sticky='w')
        
        # Tipo de Despesa
        ttk.Label(frame_basicos, text="Tipo Despesa:").grid(row=0, column=2, padx=5, pady=2, sticky='w')
        self.tp_desp = ttk.Entry(frame_basicos, width=5)
        self.tp_desp.grid(row=0, column=3, padx=5, pady=2, sticky='w')
        
        # Dados do Fornecedor
        frame_fornecedor = ttk.LabelFrame(main_frame, text="Dados do Fornecedor")
        frame_fornecedor.pack(fill='x', pady=5)
        
        ttk.Label(frame_fornecedor, text="CNPJ/CPF:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.cnpj_cpf = ttk.Entry(frame_fornecedor, width=20)
        self.cnpj_cpf.grid(row=0, column=1, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_fornecedor, text="Nome:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        self.nome = ttk.Entry(frame_fornecedor, width=50)
        self.nome.grid(row=1, column=1, columnspan=3, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_fornecedor, text="Categoria:").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        self.categoria = ttk.Entry(frame_fornecedor, width=10)
        self.categoria.grid(row=2, column=1, padx=5, pady=2, sticky='w')
        
        # Dados da Despesa
        frame_despesa = ttk.LabelFrame(main_frame, text="Dados da Despesa")
        frame_despesa.pack(fill='x', pady=5)
        
        ttk.Label(frame_despesa, text="Referência:").grid(row=0, column=0, padx=5, pady=2, sticky='w')
        self.referencia = ttk.Entry(frame_despesa, width=40)
        self.referencia.grid(row=0, column=1, columnspan=3, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_despesa, text="Etapa da Obra:").grid(row=1, column=0, padx=5, pady=2, sticky='w')
        
        # Obter lista de etapas das configurações
        try:
            from src.configuracoes_sistema import GerenciadorConfiguracoes
            etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        except ImportError:
            etapas_obra = []  # Lista vazia se não conseguir importar
        
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
        self.etapa_obra = ComboboxAutocompletar(
            frame_despesa,
            values=etapas_obra,
            config_key='etapas_obra',
            config_manager=GerenciadorConfiguracoes,
            width=30,
            state='normal'
        )
        self.etapa_obra.grid(row=1, column=1, columnspan=2, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_despesa, text="Insumo:").grid(row=2, column=0, padx=5, pady=2, sticky='w')
        
        # Obter lista de insumos das configurações
        try:
            insumos = GerenciadorConfiguracoes.get_insumos()
        except (ImportError, AttributeError):
            insumos = []  # Lista vazia se não conseguir importar
        
        insumos = GerenciadorConfiguracoes.get_insumos()
        self.insumo = ComboboxAutocompletar(
            frame_despesa,
            values=insumos,
            config_key='insumos',
            config_manager=GerenciadorConfiguracoes,
            width=30,
            state='normal'
        )
        self.insumo.grid(row=2, column=1, columnspan=2, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_despesa, text="NF:").grid(row=3, column=0, padx=5, pady=2, sticky='w')
        self.nf = ttk.Entry(frame_despesa, width=15)
        self.nf.grid(row=3, column=1, padx=5, pady=2, sticky='w')
        
        ttk.Label(frame_despesa, text="Valor Unitário:").grid(row=4, column=0, padx=5, pady=2, sticky='w')
        self.vr_unit = ttk.Entry(frame_despesa, width=15)
        self.vr_unit.grid(row=4, column=1, padx=5, pady=2, sticky='w')
        
        ttk.Label(frame_despesa, text="Dias:").grid(row=4, column=2, padx=5, pady=2, sticky='w')
        self.dias = ttk.Entry(frame_despesa, width=8)
        self.dias.grid(row=4, column=3, padx=5, pady=2, sticky='w')
        
        ttk.Label(frame_despesa, text="Valor Total:").grid(row=5, column=0, padx=5, pady=2, sticky='w')
        # Frame para agrupar valor + indicador
        frame_valor_total = ttk.Frame(frame_despesa)
        frame_valor_total.grid(row=5, column=1, columnspan=2, padx=5, pady=2, sticky='w')

        self.valor = ttk.Entry(frame_valor_total, width=15, state='readonly')
        self.valor.pack(side='left')

        # Label indicando que é calculado
        ttk.Label(frame_valor_total, text="(calculado)", 
                font=('TkDefaultFont', 8, 'italic'), 
                foreground='gray').pack(side='left', padx=5)
        
        ttk.Label(frame_despesa, text="Data Vencimento:").grid(row=5, column=2, padx=5, pady=2, sticky='w')
        self.dt_vencto = DateEntry(frame_despesa, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.dt_vencto.grid(row=5, column=3, padx=5, pady=2, sticky='w')
        
        # Dados Bancários e Observação
        ttk.Label(frame_despesa, text="Dados Bancários:").grid(row=6, column=0, padx=5, pady=2, sticky='w')
        self.dados_bancarios = ttk.Entry(frame_despesa, width=50)
        self.dados_bancarios.grid(row=6, column=1, columnspan=3, padx=5, pady=2, sticky='ew')
        
        ttk.Label(frame_despesa, text="Observação:").grid(row=7, column=0, padx=5, pady=2, sticky='w')
        self.observacao = ttk.Entry(frame_despesa, width=50)
        self.observacao.grid(row=7, column=1, columnspan=3, padx=5, pady=2, sticky='ew')
        
        # Configurar expansão
        frame_fornecedor.columnconfigure(1, weight=1)
        frame_despesa.columnconfigure(1, weight=1)
        
        # Botões
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=10)
        
        ttk.Button(frame_botoes, text="Salvar", command=self.salvar).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Cancelar", command=self.janela.destroy).pack(side='left', padx=5)
        
        # Bindings para cálculo automático
        self.vr_unit.bind('<KeyRelease>', self.calcular_total)
        self.dias.bind('<KeyRelease>', self.calcular_total)
        
    def preencher_dados(self):
        """Preenche os campos com os dados do lançamento"""
        try:
            # Datas
            if pd.notna(self.lancamento['DATA_REL']):
                self.data_rel.set_date(pd.to_datetime(self.lancamento['DATA_REL']))
            if pd.notna(self.lancamento['DT_VENCTO']):
                self.dt_vencto.set_date(pd.to_datetime(self.lancamento['DT_VENCTO']))
            
            # Campos de texto
            tp_desp_valor = self.lancamento.get('TP_DESP', '')
            if pd.notna(tp_desp_valor):
                self.tp_desp.insert(0, str(int(float(tp_desp_valor))))
            
            self.cnpj_cpf.insert(0, str(self.lancamento.get('CNPJ_CPF', '')))
            self.nome.insert(0, str(self.lancamento.get('NOME', '')))
            self.categoria.insert(0, str(self.lancamento.get('CATEGORIA', '')))
            self.referencia.insert(0, str(self.lancamento.get('REFERÊNCIA', '')))
            
            etapa_obra_valor = str(self.lancamento.get('ETAPA_OBRA', ''))
            if etapa_obra_valor and etapa_obra_valor != 'nan':
                self.etapa_obra.set(etapa_obra_valor)
            
            insumo_valor = str(self.lancamento.get('INSUMO', ''))
            if insumo_valor and insumo_valor != 'nan':
                self.insumo.set(insumo_valor)
                
            self.nf.insert(0, str(self.lancamento.get('NF', '')))
            
            # Valores numéricos
            vr_unit_valor = self.lancamento.get('VR_UNIT', '')
            if pd.notna(vr_unit_valor) and vr_unit_valor != '':
                self.vr_unit.insert(0, str(float(vr_unit_valor)).replace('.', ','))
            
            dias_valor = self.lancamento.get('DIAS', '')
            if pd.notna(dias_valor) and dias_valor != '':
                self.dias.insert(0, str(float(dias_valor)).replace('.', ','))
                
            # ✅ VALOR TOTAL - Tratamento especial para campo readonly
            valor_valor = self.lancamento.get('VALOR', '')
            if pd.notna(valor_valor) and valor_valor != '':
                # Habilitar temporariamente
                self.valor.config(state='normal')
                self.valor.delete(0, tk.END)
                self.valor.insert(0, f"{float(valor_valor):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
                # Desabilitar novamente
                self.valor.config(state='readonly')
            
            self.dados_bancarios.insert(0, str(self.lancamento.get('DADOS_BANCARIOS', '')))
            
            # CORREÇÃO: Preencher apenas a observação original (sem histórico de edições)
            observacao_original = str(self.lancamento.get('OBSERVAÇÃO', ''))
            # Remover informações de edição anteriores se existirem
            if 'EDITADO EM:' in observacao_original:
                observacao_original = observacao_original.split(' - EDITADO EM:')[0]
            
            self.observacao.insert(0, observacao_original)
            
        except Exception as e:
            logger.debug(f"Erro ao preencher dados: {str(e)}")
    
    def calcular_total(self, event=None):
        """Calcula o valor total automaticamente com formatação brasileira"""
        try:
            # Obter valores
            vr_unit_str = self.vr_unit.get().strip()
            dias_str = self.dias.get().strip()
            
            if not vr_unit_str:
                return
            
            # Converter para float
            vr_unit = float(vr_unit_str.replace('.', '').replace(',', '.'))
            dias = float(dias_str.replace(',', '.')) if dias_str else 1.0
            
            # Calcular total
            total = vr_unit * dias
            
            # ✅ Atualizar campo readonly temporariamente
            self.valor.config(state='normal')
            self.valor.delete(0, tk.END)
            self.valor.insert(0, f"{total:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
            self.valor.config(state='readonly')
            
            logger.debug(f"DEBUG: Cálculo automático - VrUnit: {vr_unit} × Dias: {dias} = Total: {total}")
            
        except ValueError as e:
            logger.debug(f"DEBUG: Erro no cálculo automático: {str(e)}")
            pass
        except Exception as e:
            logger.debug(f"DEBUG: Erro inesperado no cálculo: {str(e)}")
            pass

    def salvar(self):
        """Salva as alterações"""
        try:
            # Validações básicas
            if not self.nome.get().strip():
                custom_messagebox("error", "Erro", "Nome é obrigatório!")
                return
            
            # ✅ Valor agora vem do campo readonly
            valor_str = self.valor.get().strip()
            if not valor_str:
                custom_messagebox("error", "Erro", "Valor é obrigatório!")
                return
            
            # ✅ VALIDAÇÃO: Verificar se o valor é razoável (SEM CONVERTER AINDA)
            try:
                # Remover formatação apenas para validação
                valor_limpo = valor_str.replace('.', '').replace(',', '.')
                valor_float = float(valor_limpo)
                
                # Alertar se o valor parece muito alto
                if valor_float > 1000000:
                    if not custom_messagebox("yesno", "⚠️ Confirmação de Valor Alto",
                        f"O valor informado é muito alto:\n\n"
                        f"R$ {valor_float:,.2f}\n\n"
                        f"Deseja realmente salvar este valor?".replace(',', 'X').replace('.', ',').replace('X', '.')):
                        return
            except Exception as e:
                custom_messagebox("error", "Erro", f"Valor inválido: {valor_str}")
                logger.debug(f"DEBUG: Erro ao validar valor '{valor_str}': {str(e)}")
                return
            
            # ✅ COLETAR DADOS - Enviar como STRING, conversão será feita no salvamento
            dados_editados = {
                'data': self.data_rel.get(),
                'tp_desp': self.tp_desp.get(),
                'cnpj_cpf': self.cnpj_cpf.get(),
                'nome': self.nome.get().upper(),
                'categoria': self.categoria.get().upper(),
                'referencia': self.referencia.get().upper(),
                'etapa_obra': self.etapa_obra.get(), 
                'insumo': self.insumo.get(),
                'nf': self.nf.get().upper(),
                'vr_unit': self.vr_unit.get(),      # String com formato BR
                'dias': self.dias.get() or '1',     # String
                'valor': self.valor.get(),          # String com formato BR
                'dt_vencto': self.dt_vencto.get(),
                'dados_bancarios': self.dados_bancarios.get(),
                'observacao': self.observacao.get().upper()
            }
            
            # ✅ DEBUG: Mostrar dados antes de enviar
            logger.debug(f"DEBUG: Dados coletados para salvar:")
            logger.debug(f"  - vr_unit: '{dados_editados['vr_unit']}'")
            logger.debug(f"  - dias: '{dados_editados['dias']}'")
            logger.debug(f"  - valor: '{dados_editados['valor']}'")
            
            # Chamar callback para salvar
            id_lancamento = self.lancamento.get('ID_LANCAMENTO')
            
            if not id_lancamento or pd.isna(id_lancamento):
                custom_messagebox("error", "Erro", "ID do lançamento não encontrado!")
                return
            
            if self.callback_salvar(id_lancamento, dados_editados):
                custom_messagebox("info", "Sucesso", "Lançamento atualizado com sucesso!")
                self.janela.destroy()
            else:
                custom_messagebox("error", "Erro", 
                                "Erro ao salvar alterações!\n\n"
                                "Verifique se o arquivo não está aberto em outro programa.")
                    
        except Exception as e:
            import traceback
            logger.error(f"Erro ao salvar edição: {str(e)}")
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", 
                            f"Erro ao salvar: {str(e)}\n\n"
                            "Verifique se o arquivo não está aberto em outro programa.")       

class EditorEmMassaGerenciador:
    """
    Editor para alteração em massa de lançamentos - VERSÃO CORRIGIDA
    
    Mudança principal: Processa cada lançamento individualmente, 
    buscando dados diretamente da planilha ao invés de usar cache em memória
    """
    
    def __init__(self, parent, dados_lancamentos, ids_lancamentos, gerenciador):
        """
        Args:
            parent: Janela pai
            dados_lancamentos: Lista de dicionários com dados dos lançamentos
            ids_lancamentos: Lista de IDs REAIS dos lançamentos
            gerenciador: Referência ao GerenciadorLancamentos (para acesso ao sistema)
        """
        self.parent = parent
        self.dados_lancamentos = dados_lancamentos
        self.ids_lancamentos = ids_lancamentos
        self.gerenciador = gerenciador  # MUDANÇA: Armazenar referência ao gerenciador
        self.campos_selecionados = {}
        
        # VALIDAÇÃO: Verificar consistência
        if len(dados_lancamentos) != len(ids_lancamentos):
            logger.debug(f"⚠️ INCONSISTÊNCIA: {len(dados_lancamentos)} dados vs {len(ids_lancamentos)} IDs")
        
        logger.debug(f"DEBUG: EditorEmMassa inicializado com {len(ids_lancamentos)} lançamentos")
        logger.debug(f"DEBUG: IDs: {ids_lancamentos}")
        
        self.criar_janela()
    
    def criar_janela(self):
        """Cria a interface do editor em massa"""
        self.janela = tk.Toplevel(self.parent)
        self.janela.title(f"Edição em Massa - {len(self.dados_lancamentos)} lançamentos")
        self.janela.geometry("650x600")
        self.janela.transient(self.parent)
        self.janela.grab_set()
        
        # Frame principal
        main_frame = ttk.Frame(self.janela, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # Informações
        frame_info = ttk.LabelFrame(main_frame, text="Informações")
        frame_info.pack(fill='x', pady=(0, 10))
        
        info_text = f"Você está editando {len(self.dados_lancamentos)} lançamentos simultaneamente.\n\n"
        info_text += "Marque apenas os campos que deseja alterar.\n"
        info_text += "⚠️ As alterações serão aplicadas individualmente a cada lançamento!"
        
        ttk.Label(frame_info, text=info_text, 
                 font=('TkDefaultFont', 9), foreground='red').pack(padx=10, pady=10)
        
        # Frame de campos
        frame_campos = ttk.LabelFrame(main_frame, text="Campos para Edição em Massa")
        frame_campos.pack(fill='both', expand=True, pady=(0, 10))
        
        # Canvas com scrollbar
        canvas = tk.Canvas(frame_campos)
        scrollbar = ttk.Scrollbar(frame_campos, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Criar campos editáveis
        self.criar_campos_editaveis(scrollable_frame)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Botões
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))
        
        ttk.Button(frame_botoes, text="Marcar Todos os Campos",
                  command=self.marcar_todos).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Desmarcar Todos os Campos",
                  command=self.desmarcar_todos).pack(side='left', padx=5)
        
        ttk.Button(frame_botoes, text="✅ Aplicar Alterações",
                  command=self.aplicar_alteracoes).pack(side='right', padx=5)
        ttk.Button(frame_botoes, text="❌ Cancelar",
                  command=self.janela.destroy).pack(side='right', padx=5)
    
    def criar_campos_editaveis(self, parent):
        """Cria os campos que podem ser editados em massa"""
        
        # Lista de campos editáveis
        campos = [
            ('data', 'Data do Relatório', 'date'),
            ('tp_desp', 'Tipo de Despesa', 'combo_tipo'),
            ('referencia', 'Referência', 'entry'),
            ('etapa_obra', 'Etapa da Obra', 'combo_autocomplete_etapa'),   # ← mudou
            ('insumo', 'Insumo', 'combo_autocomplete_insumo'),             # ← mudou
            ('nf', 'NF', 'entry'),
            ('dt_vencto', 'Data de Vencimento', 'date'),
            ('observacao', 'Observação', 'text')
        ]
        
        row = 0
        for campo_id, campo_label, campo_tipo in campos:
            # Checkbox para marcar campo
            var_check = tk.BooleanVar(value=False)
            check = ttk.Checkbutton(parent, text="", variable=var_check,
                                   command=lambda f=campo_id: self.toggle_campo(f))
            check.grid(row=row, column=0, sticky='w', padx=5, pady=5)
            
            # Label do campo
            label = ttk.Label(parent, text=f"{campo_label}:")
            label.grid(row=row, column=1, sticky='w', padx=5, pady=5)
            
            # Widget do campo
            if campo_tipo == 'date':
                widget = DateEntry(parent, width=15, date_pattern='dd/mm/yyyy', 
                                 locale='pt_BR', state='disabled')
            elif campo_tipo == 'combo_tipo':
                widget = ttk.Combobox(parent, width=25, state='disabled',
                                    values=['1', '2', '3', '4', '5', '6', '7'])
            elif campo_tipo == 'text':
                widget = tk.Text(parent, width=30, height=3, state='disabled')
            elif campo_tipo == 'combo_autocomplete_etapa':
                from src.configuracoes_sistema import GerenciadorConfiguracoes
                from src.widgets.combobox_autocompletar import ComboboxAutocompletar
                etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()
                widget = ComboboxAutocompletar(parent, values=etapas_obra,
                                    config_key='etapas_obra',
                                    config_manager=GerenciadorConfiguracoes,
                                    width=30, state='disabled')
            elif campo_tipo == 'combo_autocomplete_insumo':
                from src.configuracoes_sistema import GerenciadorConfiguracoes
                from src.widgets.combobox_autocompletar import ComboboxAutocompletar
                insumos = GerenciadorConfiguracoes.get_insumos()
                widget = ComboboxAutocompletar(parent, values=insumos,
                                    config_key='insumos',
                                    config_manager=GerenciadorConfiguracoes,
                                    width=30, state='disabled')
            else:  # entry
                widget = ttk.Entry(parent, width=30, state='disabled')
            
            widget.grid(row=row, column=2, sticky='ew', padx=5, pady=5)
            
            # Armazenar referências
            self.campos_selecionados[campo_id] = {
                'check_var': var_check,
                'widget': widget,
                'tipo': campo_tipo,
                'label': campo_label
            }
            
            row += 1
        
        # Configurar expansão da coluna
        parent.columnconfigure(2, weight=1)
    
    def toggle_campo(self, campo_id):
        """Habilita/desabilita um campo quando checkbox é marcado/desmarcado"""
        campo_info = self.campos_selecionados[campo_id]
        marcado = campo_info['check_var'].get()
        widget = campo_info['widget']
        
        if marcado:
            if isinstance(widget, tk.Text):
                widget.config(state='normal')
            elif isinstance(widget, DateEntry):
                widget.config(state='normal')
            else:
                widget.config(state='normal')
        else:
            if isinstance(widget, tk.Text):
                widget.config(state='disabled')
            elif isinstance(widget, DateEntry):
                widget.config(state='disabled')
            else:
                widget.config(state='disabled')
    
    def marcar_todos(self):
        """Marca todos os campos"""
        for campo_id, campo_info in self.campos_selecionados.items():
            campo_info['check_var'].set(True)
            self.toggle_campo(campo_id)
    
    def desmarcar_todos(self):
        """Desmarca todos os campos"""
        for campo_id, campo_info in self.campos_selecionados.items():
            campo_info['check_var'].set(False)
            self.toggle_campo(campo_id)
    
    def buscar_dados_originais_da_planilha(self, id_lancamento):
        """
        NOVA FUNÇÃO: Busca dados originais diretamente da planilha
        
        Args:
            id_lancamento: ID do lançamento a buscar
            
        Returns:
            dict: Dados originais do lançamento ou None se não encontrado
        """
        try:
            arquivo_cliente = PASTA_CLIENTES / f"{self.gerenciador.sistema.cliente_atual}.xlsx"
            
            # Carregar apenas os dados necessários
            df = pd.read_excel(arquivo_cliente, sheet_name='Dados', converters=CONVERSORES_DADOS)
            
            # Buscar o lançamento
            mask = df['ID_LANCAMENTO'] == id_lancamento
            dados_filtrados = df[mask]
            
            if dados_filtrados.empty:
                logger.debug(f"⚠️ ID {id_lancamento} não encontrado na planilha")
                return None
            
            lancamento = dados_filtrados.iloc[0]
            
            # Converter para dicionário com os campos necessários
            dados_originais = {
                'DATA_REL': lancamento.get('DATA_REL'),
                'TP_DESP': lancamento.get('TP_DESP'),
                'CNPJ_CPF': lancamento.get('CNPJ_CPF', ''),
                'NOME': lancamento.get('NOME'),
                'REFERÊNCIA': lancamento.get('REFERÊNCIA'),
                'NF': lancamento.get('NF', ''),
                'VR_UNIT': lancamento.get('VR_UNIT'),
                'DIAS': lancamento.get('DIAS', 1),
                'VALOR': lancamento.get('VALOR'),
                'DT_VENCTO': lancamento.get('DT_VENCTO'),
                'CATEGORIA': lancamento.get('CATEGORIA', ''),
                'DADOS_BANCARIOS': lancamento.get('DADOS_BANCARIOS', ''),
                'OBSERVAÇÃO': lancamento.get('OBSERVAÇÃO', ''),
                'ETAPA_OBRA': lancamento.get('ETAPA_OBRA', ''),
                'INSUMO': lancamento.get('INSUMO', ''),
                'STATUS': lancamento.get('STATUS', 'ATIVO'),
                'ID_LANCAMENTO': lancamento.get('ID_LANCAMENTO')
            }
            
            logger.debug(f"✅ Dados originais carregados para ID {id_lancamento}")
            return dados_originais
            
        except Exception as e:
            logger.debug(f"❌ Erro ao buscar dados originais da planilha: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return None
    
    def aplicar_alteracoes(self):
        """
        VERSÃO CORRIGIDA: Aplica alterações processando cada lançamento individualmente
        """
        try:
            # Verificar se há campos marcados
            campos_marcados = {
                campo_id: info for campo_id, info in self.campos_selecionados.items()
                if info['check_var'].get()
            }
            
            if not campos_marcados:
                custom_messagebox("warning", "Nenhum Campo Marcado",
                                "Marque pelo menos um campo para editar!")
                return
            
            # Coletar valores dos campos marcados
            novos_valores = {}
            for campo_id, campo_info in campos_marcados.items():
                widget = campo_info['widget']
                tipo = campo_info['tipo']
                
                try:
                    if tipo == 'date':
                        valor = widget.get_date().strftime('%d/%m/%Y')
                    elif tipo == 'text':
                        valor = widget.get('1.0', 'end-1c').strip().upper()
                    elif tipo == 'combo_tipo':
                        valor = widget.get()  # tipo despesa é só número, não precisa upper
                    else:  # entry, combo_autocomplete_etapa, combo_autocomplete_insumo
                        valor = widget.get().upper()
                        
                    novos_valores[campo_id] = valor
                    logger.debug(f"DEBUG: Campo {campo_id} = '{valor}'")
                    
                except Exception as e:
                    logger.debug(f"⚠️ Erro ao ler campo {campo_id}: {str(e)}")
                    custom_messagebox("error", "Erro", 
                                    f"Erro ao ler campo '{campo_info['label']}': {str(e)}")
                    return
            
            # Confirmar operação
            campos_texto = "\n".join([f"• {self.campos_selecionados[c]['label']}" 
                                     for c in novos_valores.keys()])
            
            mensagem = f"ATENÇÃO: Edição em Massa\n\n"
            mensagem += f"📊 Quantidade: {len(self.dados_lancamentos)} lançamentos\n\n"
            mensagem += f"📝 Campos que serão alterados:\n{campos_texto}\n\n"
            mensagem += f"⚠️ Cada lançamento será processado individualmente!\n"
            mensagem += f"⚠️ As alterações serão salvas IMEDIATAMENTE na planilha!\n\n"
            mensagem += f"Deseja continuar?"
            
            if not custom_messagebox("yesno", "Confirmação - Edição em Massa", mensagem):
                return
            
            # Aplicar alterações INDIVIDUALMENTE
            sucessos = 0
            erros = []
            
            # Criar janela de progresso
            progress_window = self.criar_janela_progresso(len(self.ids_lancamentos))
            
            try:
                for i, (dados_visual, id_lanc) in enumerate(zip(self.dados_lancamentos, self.ids_lancamentos)):
                    try:
                        # Atualizar progresso
                        self.atualizar_progresso(progress_window, i + 1,
                                               f"Processando: {dados_visual['nome'][:30]}...")
                        
                        logger.debug(f"\n{'='*60}")
                        logger.debug(f"DEBUG: Processando lançamento {i+1}/{len(self.ids_lancamentos)}")
                        logger.debug(f"DEBUG: ID = {id_lanc}")
                        
                        # MUDANÇA CRÍTICA: Buscar dados originais DIRETAMENTE DA PLANILHA
                        dados_originais = self.buscar_dados_originais_da_planilha(id_lanc)
                        
                        if dados_originais is None:
                            erros.append(f"ID {id_lanc}: Dados não encontrados na planilha")
                            logger.debug(f"❌ ID {id_lanc}: Não encontrado")
                            continue
                        
                        # Preparar dados completos mesclando originais + novos valores
                        dados_para_salvar = self.preparar_dados_para_salvamento(
                            dados_originais, novos_valores
                        )
                        
                        logger.debug(f"DEBUG: Dados preparados: {list(dados_para_salvar.keys())}")
                        
                        # Salvar usando o método do gerenciador
                        sucesso = self.gerenciador._executar_salvamento_edicao(
                            id_lanc, 
                            dados_para_salvar, 
                            dados_originais
                        )
                        
                        if sucesso:
                            sucessos += 1
                            logger.debug(f"✅ ID {id_lanc} atualizado com sucesso")
                        else:
                            erros.append(f"ID {id_lanc}: Falha no salvamento")
                            logger.debug(f"❌ ID {id_lanc}: Falha no salvamento")
                        
                    except Exception as e:
                        erros.append(f"ID {id_lanc}: {str(e)}")
                        logger.debug(f"❌ Erro no ID {id_lanc}: {str(e)}")
                        import traceback
                        logger.debug(traceback.format_exc())
                        continue
                
            finally:
                progress_window.destroy()
            
            logger.debug(f"\n{'='*60}")
            logger.debug(f"DEBUG: Processamento concluído")
            logger.debug(f"DEBUG: Sucessos = {sucessos}, Erros = {len(erros)}")
            
            # Recarregar a visualização
            if hasattr(self.gerenciador, 'carregar_lancamentos'):
                self.gerenciador.carregar_lancamentos()
            
            # Mostrar resultado
            mensagem_resultado = f"EDIÇÃO EM MASSA CONCLUÍDA\n\n"
            mensagem_resultado += f"✅ {sucessos} lançamentos atualizados com sucesso\n"
            
            if erros:
                mensagem_resultado += f"\n❌ {len(erros)} erros encontrados:\n"
                for erro in erros[:5]:
                    mensagem_resultado += f"• {erro}\n"
                if len(erros) > 5:
                    mensagem_resultado += f"• ... e mais {len(erros) - 5} erros\n"
            
            custom_messagebox("info", "Resultado", mensagem_resultado)
            
            # Fechar janela se teve sucesso
            if sucessos > 0:
                self.janela.destroy()
            
        except Exception as e:
            import traceback
            logger.debug(f"❌ ERRO na aplicação de alterações:")
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao aplicar alterações: {str(e)}")
    
    def preparar_dados_para_salvamento(self, dados_originais, novos_valores):
        dados_completos = {
            'data': dados_originais.get('DATA_REL'),
            'tp_desp': dados_originais.get('TP_DESP'),
            'cnpj_cpf': dados_originais.get('CNPJ_CPF', ''),
            'nome': dados_originais.get('NOME'),
            'referencia': dados_originais.get('REFERÊNCIA'),
            'nf': dados_originais.get('NF', ''),
            'vr_unit': dados_originais.get('VR_UNIT'),
            'dias': dados_originais.get('DIAS', 1),
            'valor': dados_originais.get('VALOR'),
            'dt_vencto': dados_originais.get('DT_VENCTO'),
            'categoria': dados_originais.get('CATEGORIA', ''),
            'dados_bancarios': dados_originais.get('DADOS_BANCARIOS', ''),
            'observacao': dados_originais.get('OBSERVAÇÃO', ''),
            'etapa_obra': dados_originais.get('ETAPA_OBRA', ''),
            'insumo': dados_originais.get('INSUMO', '')
        }

        # Normalizar campos de texto que podem vir como NaN (float) do pandas
        for campo_texto in ['nf', 'observacao', 'etapa_obra', 'insumo', 'categoria', 'dados_bancarios', 'cnpj_cpf']:
            valor = dados_completos.get(campo_texto)
            if valor is None or (isinstance(valor, float) and pd.isna(valor)):
                dados_completos[campo_texto] = ''
            else:
                dados_completos[campo_texto] = str(valor)
        
        # Converter data original se necessário
        if dados_completos['data'] and not isinstance(dados_completos['data'], str):
            if isinstance(dados_completos['data'], datetime):
                dados_completos['data'] = dados_completos['data'].strftime('%d/%m/%Y')
            else:
                dados_completos['data'] = str(dados_completos['data'])
        
        # Converter data de vencimento se necessário
        if dados_completos['dt_vencto'] and not isinstance(dados_completos['dt_vencto'], str):
            if isinstance(dados_completos['dt_vencto'], datetime):
                dados_completos['dt_vencto'] = dados_completos['dt_vencto'].strftime('%d/%m/%Y')
            else:
                dados_completos['dt_vencto'] = str(dados_completos['dt_vencto'])
        
        # Sobrescrever com novos valores
        dados_completos.update(novos_valores)
        
        return dados_completos
    
    def criar_janela_progresso(self, total_items):
        """Cria janela de progresso"""
        janela_progress = tk.Toplevel(self.janela)
        janela_progress.title("Aplicando Alterações")
        janela_progress.geometry("400x120")
        janela_progress.transient(self.janela)
        janela_progress.grab_set()
        
        # Centralizar
        janela_progress.update_idletasks()
        x = (janela_progress.winfo_screenwidth() // 2) - 200
        y = (janela_progress.winfo_screenheight() // 2) - 60
        janela_progress.geometry(f"400x120+{x}+{y}")
        
        frame = ttk.Frame(janela_progress, padding="20")
        frame.pack(fill='both', expand=True)
        
        # Labels
        label_status = ttk.Label(frame, text="Preparando...", font=('TkDefaultFont', 10))
        label_status.pack(pady=(0, 10))
        
        # Progress bar
        progress_var = tk.DoubleVar()
        progress_bar = ttk.Progressbar(frame, variable=progress_var, 
                                      maximum=total_items, mode='determinate', length=350)
        progress_bar.pack(pady=(0, 10))
        
        label_count = ttk.Label(frame, text=f"0 / {total_items}", font=('TkDefaultFont', 9))
        label_count.pack()
        
        # Armazenar referências
        janela_progress.label_status = label_status
        janela_progress.progress_var = progress_var
        janela_progress.label_count = label_count
        janela_progress.total_items = total_items
        
        janela_progress.update()
        return janela_progress
    
    def atualizar_progresso(self, janela_progress, item_atual, mensagem=""):
        """Atualiza janela de progresso"""
        try:
            if not janela_progress:
                return
            
            janela_progress.progress_var.set(item_atual)
            
            if mensagem:
                janela_progress.label_status.config(text=mensagem)
            
            janela_progress.label_count.config(
                text=f"{item_atual} / {janela_progress.total_items}"
            )
            
            janela_progress.update_idletasks()
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar progresso: {str(e)}")

class VisualizadorLancamentosFornecedor:
    def __init__(self, parent, sistema_principal):
        self.parent = parent
        self.sistema = sistema_principal
        self.janela = None
        self.tree_lancamentos = None
        self.dados_originais = []  # Para armazenar dados completos
        
    def formatar_cnpj_cpf(self, cnpj_cpf):
        """Formata CNPJ/CPF mantendo zeros à esquerda"""
        try:
            numeros = ''.join(filter(str.isdigit, str(cnpj_cpf)))
            
            if len(numeros) == 11:  # CPF
                cpf = numeros.zfill(11)
                return f"{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:]}"
            elif len(numeros) == 14:  # CNPJ
                cnpj = numeros.zfill(14)
                return f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:]}"
            else:
                return str(cnpj_cpf)
        except:
            return str(cnpj_cpf)
        
    def abrir_visualizador(self, cnpj_cpf_fornecedor, nome_fornecedor, tipo_pessoa):
        """Abre o visualizador para um fornecedor específico"""
        if not self.sistema.cliente_atual:
            custom_messagebox("error", "Erro", "Nenhum cliente selecionado!")
            return
            
        # Normalizar CNPJ/CPF com zeros à esquerda ANTES de formatar
        cnpj_cpf_str = str(cnpj_cpf_fornecedor)
        cnpj_cpf_numeros = ''.join(filter(str.isdigit, cnpj_cpf_str))
        
        if tipo_pessoa == 'PF':
            cnpj_cpf_normalizado = cnpj_cpf_numeros.zfill(11)
        else:  # PJ
            cnpj_cpf_normalizado = cnpj_cpf_numeros.zfill(14)
            
        cnpj_cpf_formatado = self.formatar_cnpj_cpf(cnpj_cpf_normalizado)
        
        self.dados_fornecedor = {
            'cnpj_cpf': cnpj_cpf_normalizado,
            'cnpj_cpf_formatado': cnpj_cpf_formatado,
            'nome': nome_fornecedor,
            'tipo_pessoa': tipo_pessoa
        }
        
        self.criar_janela()
        self.carregar_lancamentos()
        
    def criar_janela(self):
        """Cria a janela do visualizador com funcionalidades estendidas"""
        self.janela = tk.Toplevel(self.parent)
        self.janela.title(f"Lançamentos - {self.dados_fornecedor['nome']}")
        self.janela.geometry("1400x900")  # Aumentado para acomodar novos botões
        
        # Configurar janela
        self.janela.transient(self.parent)
        self.janela.grab_set()
        
        self.criar_interface()
        
    def criar_interface(self):
        """Cria a interface do visualizador com funcionalidades de edição"""
        # Frame principal
        main_frame = ttk.Frame(self.janela, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # Cabeçalho com informações do fornecedor
        frame_cabecalho = ttk.LabelFrame(main_frame, text="Informações do Fornecedor")
        frame_cabecalho.pack(fill='x', pady=(0, 10))
        
        info_frame = ttk.Frame(frame_cabecalho)
        info_frame.pack(fill='x', padx=10, pady=8)
        
        # Informações em duas colunas
        ttk.Label(info_frame, text="Nome:", font=('Arial', 10, 'bold')).grid(
            row=0, column=0, padx=5, pady=2, sticky='w')
        ttk.Label(info_frame, text=self.dados_fornecedor['nome'], 
                 font=('Arial', 10)).grid(row=0, column=1, padx=5, pady=2, sticky='w')
        
        ttk.Label(info_frame, text="CNPJ/CPF:", font=('Arial', 10, 'bold')).grid(
            row=0, column=2, padx=20, pady=2, sticky='w')
        ttk.Label(info_frame, text=self.dados_fornecedor['cnpj_cpf_formatado'], 
                 font=('Arial', 10)).grid(row=0, column=3, padx=5, pady=2, sticky='w')
        
        ttk.Label(info_frame, text="Cliente:", font=('Arial', 10, 'bold')).grid(
            row=1, column=0, padx=5, pady=2, sticky='w')
        ttk.Label(info_frame, text=self.sistema.cliente_atual, 
                 font=('Arial', 10)).grid(row=1, column=1, padx=5, pady=2, sticky='w')
        
        # Frame de filtros
        frame_filtros = ttk.LabelFrame(main_frame, text="Filtros")
        frame_filtros.pack(fill='x', pady=(0, 10))
        
        filtros_frame = ttk.Frame(frame_filtros)
        filtros_frame.pack(fill='x', padx=10, pady=8)
        
        # Filtro por período
        ttk.Label(filtros_frame, text="Período:").grid(row=0, column=0, padx=5, pady=5)
        self.data_inicio = DateEntry(filtros_frame, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_inicio.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(filtros_frame, text="até").grid(row=0, column=2, padx=5, pady=5)
        self.data_fim = DateEntry(filtros_frame, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_fim.grid(row=0, column=3, padx=5, pady=5)

        # Todo período
        self.todos_lancamentos_var = tk.BooleanVar(value=False)
        self.chk_todos = ttk.Checkbutton(
            filtros_frame,
            text="Todos os lançamentos",
            variable=self.todos_lancamentos_var,
            command=self.toggle_periodo_completo
        )
        self.chk_todos.grid(row=0, column=4, padx=15, pady=5)

        # Filtro por referência  
        ttk.Label(filtros_frame, text="Referência:").grid(row=0, column=5, padx=15, pady=5)
        self.filtro_referencia = ttk.Entry(filtros_frame, width=20)
        self.filtro_referencia.grid(row=0, column=6, padx=5, pady=5)

        # Filtro por status  
        ttk.Label(filtros_frame, text="Status:").grid(row=0, column=7, padx=15, pady=5)
        self.combo_status = ttk.Combobox(filtros_frame,
                                        values=['Todos', 'Ativos', 'Excluídos'],
                                        state='readonly', width=10)
        self.combo_status.set('Ativos')
        self.combo_status.grid(row=0, column=8, padx=5, pady=5)

        # Botões de filtro  
        ttk.Button(filtros_frame, text="Filtrar",
                command=self.aplicar_filtros).grid(row=0, column=9, padx=10, pady=5)
        ttk.Button(filtros_frame, text="Limpar",
                command=self.limpar_filtros).grid(row=0, column=10, padx=5, pady=5)
        
        # Campo de busca rápida
        frame_busca = ttk.Frame(filtros_frame)
        frame_busca.grid(row=1, column=0, columnspan=10, pady=10, sticky='ew')
        
        ttk.Label(frame_busca, text="Busca rápida por NF ou Observação:").pack(side='left', padx=5)
        self.busca_rapida = ttk.Entry(frame_busca, width=30)
        self.busca_rapida.pack(side='left', padx=5)
        self.busca_rapida.bind('<KeyRelease>', self.busca_incremental)
        
        # Frame da lista de lançamentos
        frame_lista = ttk.LabelFrame(main_frame, text="Lançamentos Encontrados")
        frame_lista.pack(fill='both', expand=True)
        
        # Treeview para lançamentos - ADICIONADA SELEÇÃO MÚLTIPLA
        colunas = ('Data Rel.', 'Nº Rel.', 'Tipo', 'Referência', 'NF', 'Valor', 'Vencimento', 'Status', 'Observação', 'ID')
        self.tree_lancamentos = ttk.Treeview(frame_lista, columns=colunas, show='headings', 
                                           height=18, selectmode='extended')  # Seleção múltipla
        
        # Configurar cabeçalhos e larguras
        larguras = {'Data Rel.': 90, 'Nº Rel.': 30, 'Tipo': 30, 'Referência': 200, 'NF': 100, 
                   'Valor': 100, 'Vencimento': 90, 'Status': 80, 'Observação': 220, 'ID': 0}
        
        for col in colunas:
            self.tree_lancamentos.heading(col, text=col)
            self.tree_lancamentos.column(col, width=larguras.get(col, 100))
            if col == 'Valor':
                self.tree_lancamentos.column(col, anchor='e')
            elif col == 'ID':
                self.tree_lancamentos.column(col, width=0, stretch=False)  # Oculto
        
        # Scrollbars
        scrolly = ttk.Scrollbar(frame_lista, orient='vertical', command=self.tree_lancamentos.yview)
        scrollx = ttk.Scrollbar(frame_lista, orient='horizontal', command=self.tree_lancamentos.xview)
        self.tree_lancamentos.configure(yscrollcommand=scrolly.set, xscrollcommand=scrollx.set)
        
        # Posicionar elementos
        self.tree_lancamentos.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        scrolly.pack(side='right', fill='y')
        scrollx.pack(side='bottom', fill='x')
        
        # Frame de informações de seleção (NOVO)
        frame_selecao = ttk.Frame(main_frame)
        frame_selecao.pack(fill='x', pady=(5, 0))
        
        self.label_selecao = ttk.Label(frame_selecao, text="Nenhum item selecionado", 
                                     font=('TkDefaultFont', 9, 'italic'))
        self.label_selecao.pack(side='left')
        
        ttk.Button(frame_selecao, text="Selecionar Todos Visíveis", 
                  command=self.selecionar_todos_visiveis).pack(side='right', padx=2)
        ttk.Button(frame_selecao, text="Limpar Seleção", 
                  command=self.limpar_selecao).pack(side='right', padx=2)
        
        # Frame de resumo
        frame_resumo = ttk.LabelFrame(main_frame, text="Resumo")
        frame_resumo.pack(fill='x', pady=(10, 0))
        
        resumo_frame = ttk.Frame(frame_resumo)
        resumo_frame.pack(fill='x', padx=10, pady=8)
        
        self.lbl_total_lancamentos = ttk.Label(resumo_frame, text="Total de Lançamentos: 0", 
                                             font=('Arial', 10, 'bold'))
        self.lbl_total_lancamentos.pack(side='left', padx=10)
        
        self.lbl_valor_total = ttk.Label(resumo_frame, text="Valor Total: R$ 0,00", 
                                       font=('Arial', 10, 'bold'))
        self.lbl_valor_total.pack(side='left', padx=10)
        
        self.lbl_ultimo_lancamento = ttk.Label(resumo_frame, text="Último Lançamento: -", 
                                             font=('Arial', 10))
        self.lbl_ultimo_lancamento.pack(side='left', padx=10)
        
        # Frame de botões - ESTENDIDO COM FUNCIONALIDADES DE EDIÇÃO
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))
        
        # === BOTÕES DE AÇÃO INDIVIDUAL ===
        self.btn_editar = ttk.Button(frame_botoes, text="Editar", 
                                    command=self.editar_lancamento)
        self.btn_editar.pack(side='left', padx=5)
        
        self.btn_ver_historico = ttk.Button(frame_botoes, text="Ver Histórico", 
                                          command=self.visualizar_historico_lancamento)
        self.btn_ver_historico.pack(side='left', padx=5)
        
        # Separador visual
        ttk.Separator(frame_botoes, orient='vertical').pack(side='left', fill='y', padx=10)
        
        # === BOTÕES DE EXCLUSÃO/RESTAURAÇÃO ===
        self.btn_excluir_individual = ttk.Button(frame_botoes, text="Excluir", 
                                                command=self.excluir_lancamento)
        self.btn_excluir_individual.pack(side='left', padx=2)
        
        self.btn_excluir_lote = ttk.Button(frame_botoes, text="Excluir Selecionados", 
                                         command=self.excluir_lote, state='disabled')
        self.btn_excluir_lote.pack(side='left', padx=2)
        
        self.btn_restaurar_individual = ttk.Button(frame_botoes, text="Restaurar", 
                                                 command=self.restaurar_lancamento)
        self.btn_restaurar_individual.pack(side='left', padx=2)
        
        self.btn_restaurar_lote = ttk.Button(frame_botoes, text="Restaurar Selecionados", 
                                           command=self.restaurar_lote, state='disabled')
        self.btn_restaurar_lote.pack(side='left', padx=2)
        
        # Separador visual
        ttk.Separator(frame_botoes, orient='vertical').pack(side='left', fill='y', padx=10)
        
        # === BOTÕES GERAIS ===
        ttk.Button(frame_botoes, text="Exportar Lista", 
                  command=self.exportar_lista).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Atualizar", 
                  command=self.carregar_lancamentos).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Ver Estatísticas", 
                  command=self.mostrar_estatisticas).pack(side='left', padx=5)
        
        ttk.Button(frame_botoes, text="Fechar", 
                  command=self.janela.destroy).pack(side='right', padx=5)
        
        # Configurar tags para cores
        self.tree_lancamentos.tag_configure('excluido', background='#ffcccc')
        self.tree_lancamentos.tag_configure('normal', background='white')
        self.tree_lancamentos.tag_configure('recente', background='#e8f5e8')
        
        # Configurar eventos
        self.configurar_eventos_selecao()
        self.configurar_atalhos()
        
        # Inicializar estado dos botões
        self.atualizar_interface_selecao()
        self.inicializar_datas_padrao()

    def configurar_eventos_selecao(self):
        """Configura eventos para controle de seleção múltipla"""
        try:
            def on_selection_change(event=None):
                self.atualizar_interface_selecao()
            
            self.tree_lancamentos.bind('<<TreeviewSelect>>', on_selection_change)
            self.tree_lancamentos.bind('<Double-1>', self.ver_detalhes_lancamento)
            
        except Exception as e:
            logger.debug(f"Erro ao configurar eventos de seleção: {str(e)}")

    def configurar_atalhos(self):
        """Configura atalhos de teclado"""
        try:
            # Duplo clique para ver detalhes
            self.tree_lancamentos.bind('<Double-1>', self.ver_detalhes_lancamento)
            
            # Tecla H para histórico
            def on_key_h(event):
                if self.tree_lancamentos.selection():
                    self.visualizar_historico_lancamento()
            
            self.janela.bind('<Key-h>', on_key_h)
            self.janela.bind('<Key-H>', on_key_h)
            
            # Delete para excluir
            def on_delete(event):
                items_selecionados = self.tree_lancamentos.selection()
                if len(items_selecionados) == 1:
                    self.excluir_lancamento()
                elif len(items_selecionados) > 1:
                    self.excluir_lote()
            
            self.janela.bind('<Delete>', on_delete)
            
            # Ctrl+A para selecionar todos
            def on_ctrl_a(event):
                self.selecionar_todos_visiveis()
                return "break"
            
            self.janela.bind('<Control-a>', on_ctrl_a)
            
            # Escape para limpar seleção
            def on_escape(event):
                self.limpar_selecao()
                return "break"
            
            self.janela.bind('<Escape>', on_escape)
            
            self.janela.focus_set()
            
        except Exception as e:
            logger.debug(f"Erro ao configurar atalhos: {str(e)}")

    def atualizar_interface_selecao(self):
        """Atualiza a interface baseada na seleção atual"""
        try:
            items_selecionados = self.tree_lancamentos.selection()
            qtd_selecionados = len(items_selecionados)
            
            # Atualizar label de seleção
            if qtd_selecionados == 0:
                self.label_selecao.config(text="Nenhum item selecionado")
            elif qtd_selecionados == 1:
                self.label_selecao.config(text="1 item selecionado")
            else:
                self.label_selecao.config(text=f"{qtd_selecionados} itens selecionados")
            
            # Controlar estado dos botões
            if qtd_selecionados == 0:
                # Nenhum selecionado - desabilitar todos
                self.btn_editar.config(state='disabled')
                self.btn_ver_historico.config(state='disabled')
                self.btn_excluir_individual.config(state='disabled')
                self.btn_excluir_lote.config(state='disabled')
                self.btn_restaurar_individual.config(state='disabled')
                self.btn_restaurar_lote.config(state='disabled')
                
            elif qtd_selecionados == 1:
                # Um selecionado - habilitar individuais
                self.btn_editar.config(state='normal')
                self.btn_ver_historico.config(state='normal')
                self.btn_excluir_individual.config(state='normal')
                self.btn_excluir_lote.config(state='disabled')
                self.btn_restaurar_individual.config(state='normal')
                self.btn_restaurar_lote.config(state='disabled')
                
            else:
                # Múltiplos selecionados - habilitar lote, desabilitar individuais
                self.btn_editar.config(state='disabled')
                self.btn_ver_historico.config(state='disabled')
                self.btn_excluir_individual.config(state='disabled')
                self.btn_excluir_lote.config(state='normal')
                self.btn_restaurar_individual.config(state='disabled')
                self.btn_restaurar_lote.config(state='normal')
            
        except Exception as e:
            logger.debug(f"Erro ao atualizar interface de seleção: {str(e)}")

    def selecionar_todos_visiveis(self):
        """Seleciona todos os itens visíveis na lista"""
        try:
            items_visiveis = self.tree_lancamentos.get_children()
            
            if not items_visiveis:
                custom_messagebox("info", "Seleção", "Nenhum item visível para selecionar")
                return
            
            self.tree_lancamentos.selection_set(items_visiveis)
            self.atualizar_interface_selecao()
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao selecionar itens: {str(e)}")

    def limpar_selecao(self):
        """Limpa a seleção atual"""
        try:
            self.tree_lancamentos.selection_remove(self.tree_lancamentos.selection())
            self.atualizar_interface_selecao()
            
        except Exception as e:
            logger.debug(f"Erro ao limpar seleção: {str(e)}")

    def obter_dados_selecionados(self):
        """Obtém dados dos itens selecionados para processamento"""
        try:
            items_selecionados = self.tree_lancamentos.selection()
            
            if not items_selecionados:
                return []
            
            dados_selecionados = []
            
            for item in items_selecionados:
                valores = self.tree_lancamentos.item(item)['values']
                
                dados_item = {
                    'item_id': item,
                    'data': valores[0],
                    'tp_desp': valores[1],
                    'referencia': valores[2],
                    'nf': valores[3],
                    'valor': valores[4],
                    'vencimento': valores[5],
                    'status': valores[6],
                    'observacao': valores[7],
                    'id_lancamento': valores[8]
                }
                
                dados_selecionados.append(dados_item)
            
            return dados_selecionados
            
        except Exception as e:
            logger.debug(f"Erro ao obter dados selecionados: {str(e)}")
            return []

    def editar_lancamento(self):
        """Edita o lançamento selecionado usando o editor do GerenciadorLancamentos"""
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para editar")
            return
        
        try:
            valores = self.tree_lancamentos.item(item_selecionado[0])['values']
            id_lancamento = valores[9]  # ID do lançamento
            
            # Buscar dados completos do lançamento
            lancamento = None
            for _, row in self.dados_originais.iterrows():
                if row.get('ID_LANCAMENTO') == id_lancamento:
                    lancamento = row
                    break
            
            if lancamento is None:
                custom_messagebox("error", "Erro", f"Lançamento com ID {id_lancamento} não encontrado")
                return
            
            # Abrir editor usando a classe do GerenciadorLancamentos
            # from src.sistema_entrada_dados import EditorLancamentoCompleto
            editor = EditorLancamentoCompleto(self.janela, lancamento, self.salvar_edicao)
                
        except Exception as e:
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao editar lançamento: {str(e)}")

    def salvar_edicao(self, id_lancamento, dados_editados):
        """
        Callback para salvar edições (usa lógica do GerenciadorLancamentos)
        VERSÃO CORRIGIDA - Com conversão adequada de valores numéricos
        """
        try:
            logger.debug(f"=== INÍCIO SALVAR_EDICAO (VisualizadorLancamentosFornecedor) ===")
            logger.debug(f"Salvando edição do lançamento ID {id_lancamento}")
            logger.debug(f"Dados recebidos: {dados_editados}")

            # Importar e usar o método de salvamento do GerenciadorLancamentos
            from openpyxl import load_workbook
            from datetime import datetime
            import pandas as pd
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            wb = load_workbook(arquivo_cliente)
            ws = wb["Dados"]
            
            # Encontrar a linha do lançamento
            linha_encontrada = None
            for row_num in range(2, ws.max_row + 1):
                id_na_planilha = ws.cell(row=row_num, column=15).value
                
                if str(id_na_planilha) == str(id_lancamento):
                    linha_encontrada = row_num
                    break
            
            if not linha_encontrada:
                wb.close()
                logger.error(f"Lançamento ID {id_lancamento} não encontrado na planilha")
                return False
            
            logger.debug(f"DEBUG: Editando lançamento na linha {linha_encontrada}")
            
            # ===== FUNÇÃO AUXILIAR PARA CONVERTER VALORES NUMÉRICOS =====
            def converter_valor_numerico(valor_str, tipo='float'):
                """
                Converte string para número de forma segura
                """
                logger.debug(f"DEBUG converter_valor_numerico: entrada='{valor_str}' tipo={tipo}")
                
                if not valor_str or pd.isna(valor_str) or str(valor_str).strip() == '':
                    logger.debug(f"DEBUG converter_valor_numerico: valor vazio, retornando None")
                    return None
                
                try:
                    valor_str = str(valor_str).strip()
                    
                    # Contar pontos e vírgulas
                    qtd_pontos = valor_str.count('.')
                    qtd_virgulas = valor_str.count(',')
                    
                    logger.debug(f"DEBUG converter_valor_numerico: pontos={qtd_pontos}, vírgulas={qtd_virgulas}")
                    
                    # Formato brasileiro: 1.234.567,89
                    if qtd_virgulas == 1 and qtd_pontos >= 0:
                        valor_limpo = valor_str.replace('.', '').replace(',', '.')
                        logger.debug(f"DEBUG converter_valor_numerico: formato BR detectado, limpo='{valor_limpo}'")
                    
                    # Formato americano: 1,234,567.89
                    elif qtd_pontos == 1 and qtd_virgulas >= 0:
                        valor_limpo = valor_str.replace(',', '')
                        logger.debug(f"DEBUG converter_valor_numerico: formato US detectado, limpo='{valor_limpo}'")
                    
                    # Sem formatação
                    else:
                        valor_limpo = valor_str.replace(',', '.')
                        logger.debug(f"DEBUG converter_valor_numerico: sem formato, limpo='{valor_limpo}'")
                    
                    # Converter
                    if tipo == 'int':
                        resultado = int(float(valor_limpo))
                    else:
                        resultado = float(valor_limpo)
                    
                    logger.debug(f"DEBUG converter_valor_numerico: conversão OK, resultado={resultado}")
                    return resultado
                    
                except Exception as e:
                    logger.error(f"ERROR converter_valor_numerico: Erro ao converter '{valor_str}': {str(e)}")
                    import traceback
                    logger.debug(traceback.format_exc())
                    return None
            
            # ===== ATUALIZAR OS DADOS NA PLANILHA =====
            
            # Data do relatório (Coluna A)
            if dados_editados.get('data'):
                try:
                    data_rel = datetime.strptime(dados_editados['data'], '%d/%m/%Y') if isinstance(dados_editados['data'], str) else dados_editados['data']
                    ws.cell(row=linha_encontrada, column=1, value=data_rel)
                    ws.cell(row=linha_encontrada, column=1).number_format = 'DD/MM/YYYY'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar data: {str(e)}")
            
            # Tipo de despesa (Coluna B)
            if dados_editados.get('tp_desp'):
                try:
                    tp_desp_valor = converter_valor_numerico(dados_editados['tp_desp'], 'int')
                    if tp_desp_valor is not None:
                        ws.cell(row=linha_encontrada, column=2, value=tp_desp_valor)
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar tipo despesa: {str(e)}")
            
            # CNPJ/CPF (Coluna C)
            cnpj_cpf_valor = dados_editados.get('cnpj_cpf', '')
            try:
                cnpj_cpf_str = str(cnpj_cpf_valor).strip()
                
                if cnpj_cpf_str and cnpj_cpf_str not in ['nan', 'None', '']:
                    ws.cell(row=linha_encontrada, column=3, value=cnpj_cpf_str)
                    ws.cell(row=linha_encontrada, column=3).number_format = '@'
                else:
                    ws.cell(row=linha_encontrada, column=3, value='')
                
                logger.debug(f"DEBUG: CNPJ/CPF salvo: '{cnpj_cpf_str}'")
                
            except Exception as e:
                logger.debug(f"DEBUG: Erro ao salvar CNPJ/CPF '{cnpj_cpf_valor}': {str(e)}")
                ws.cell(row=linha_encontrada, column=3, value='')
            
            # Nome (Coluna D)
            ws.cell(row=linha_encontrada, column=4, value=dados_editados.get('nome', ''))
            
            # Referência (Coluna E)
            ws.cell(row=linha_encontrada, column=5, value=dados_editados.get('referencia', ''))
            
            # NF (Coluna F)
            ws.cell(row=linha_encontrada, column=6, value=dados_editados.get('nf', ''))
            
            # Valor Unitário (Coluna G) - CONVERSÃO SEGURA
            if dados_editados.get('vr_unit'):
                try:
                    vr_unit = converter_valor_numerico(dados_editados['vr_unit'])
                    if vr_unit is not None:
                        ws.cell(row=linha_encontrada, column=7, value=vr_unit)
                        ws.cell(row=linha_encontrada, column=7).number_format = '#,##0.00'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar valor unitário: {str(e)}")
            
            # Dias (Coluna H) - CONVERSÃO SEGURA
            if dados_editados.get('dias'):
                try:
                    dias = converter_valor_numerico(dados_editados['dias'])
                    if dias is not None:
                        ws.cell(row=linha_encontrada, column=8, value=dias)
                        ws.cell(row=linha_encontrada, column=8).number_format = '0.0'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar dias: {str(e)}")
            
            # Valor Total (Coluna I) - CONVERSÃO SEGURA
            if dados_editados.get('valor'):
                try:
                    valor = converter_valor_numerico(dados_editados['valor'])
                    if valor is not None:
                        ws.cell(row=linha_encontrada, column=9, value=valor)
                        ws.cell(row=linha_encontrada, column=9).number_format = '#,##0.00'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar valor total: {str(e)}")
            
            # Data de Vencimento (Coluna J)
            if dados_editados.get('dt_vencto'):
                try:
                    dt_vencto = datetime.strptime(dados_editados['dt_vencto'], '%d/%m/%Y') if isinstance(dados_editados['dt_vencto'], str) else dados_editados['dt_vencto']
                    ws.cell(row=linha_encontrada, column=10, value=dt_vencto)
                    ws.cell(row=linha_encontrada, column=10).number_format = 'DD/MM/YYYY'
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar data vencimento: {str(e)}")
            
            # Categoria (Coluna K)
            ws.cell(row=linha_encontrada, column=11, value=dados_editados.get('categoria', ''))
            
            # Dados Bancários (Coluna L)
            ws.cell(row=linha_encontrada, column=12, value=dados_editados.get('dados_bancarios', ''))
            
            # Observação com timestamp de edição (Coluna M)
            observacao_editada = dados_editados.get('observacao', '')
            timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
            observacao_com_historico = f"{observacao_editada} - EDITADO EM: {timestamp}"
            ws.cell(row=linha_encontrada, column=13, value=observacao_com_historico)
            
            # Verificar e adicionar colunas ETAPA_OBRA e INSUMO se não existirem
            if ws.cell(row=1, column=17).value != 'ETAPA_OBRA':
                ws.cell(row=1, column=17, value='ETAPA_OBRA')
            
            if ws.cell(row=1, column=18).value != 'INSUMO':
                ws.cell(row=1, column=18, value='INSUMO')
            
            # Etapa da Obra (Coluna Q)
            if dados_editados.get('etapa_obra'):
                ws.cell(row=linha_encontrada, column=17, value=dados_editados['etapa_obra'])
            
            # Insumo (Coluna R)
            if dados_editados.get('insumo'):
                ws.cell(row=linha_encontrada, column=18, value=dados_editados['insumo'])
            
            # Salvar arquivo
            salvar_planilha_segura(wb, arquivo_cliente)
            wb.close()
            
            logger.debug(f"✅ Edição salva com sucesso")
            
            # Recarregar dados e atualizar visualização
            self.carregar_lancamentos()
            
            logger.debug(f"=== FIM SALVAR_EDICAO (SUCESSO) ===")
            return True
            
        except Exception as e:
            if 'wb' in locals():
                wb.close()
            logger.error(f"Erro ao salvar edição: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            logger.debug(f"=== FIM SALVAR_EDICAO (ERRO) ===")
            return False

    def excluir_lancamento(self):
        """Exclui um lançamento individual"""
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para excluir")
            return
        
        valores = self.tree_lancamentos.item(item_selecionado[0])['values']
        nome_fornecedor = self.dados_fornecedor['nome']
        referencia = valores[3]
        valor = valores[5]
        data_lancamento = valores[0]
        status_atual = valores[7]
        
        if status_atual == 'EXCLUIDO':
            custom_messagebox("info", "Informação", "Este lançamento já está excluído")
            return
        
        if custom_messagebox("yesno", "Confirmação", 
                            f"Deseja realmente excluir este lançamento?\n\n"
                            f"Fornecedor: {nome_fornecedor}\n"
                            f"Referência: {referencia}\n"
                            f"Valor: {valor}\n"
                            f"Data: {data_lancamento}"):
            try:
                id_lancamento = valores[9]
                self.atualizar_status_lancamento(id_lancamento, 'EXCLUIDO')
                
                # Verificar recálculo de taxas se necessário
                # self.verificar_recalculo_apos_alteracao(data_lancamento, "EXCLUSÃO")
                
                self.carregar_lancamentos()
                custom_messagebox("info", "Sucesso", "Lançamento excluído com sucesso!")
                
            except Exception as e:
                custom_messagebox("error", "Erro", f"Erro ao excluir lançamento: {str(e)}")

    def excluir_lote(self):
        """Exclui múltiplos lançamentos selecionados"""
        try:
            dados_selecionados = self.obter_dados_selecionados()
            
            if not dados_selecionados:
                custom_messagebox("warning", "Aviso", "Nenhum item selecionado para exclusão")
                return
            
            # Filtrar apenas lançamentos ativos
            ativos = [item for item in dados_selecionados if item['status'] != 'EXCLUIDO']
            
            if not ativos:
                custom_messagebox("info", "Informação", "Todos os itens selecionados já estão excluídos")
                return
            
            if custom_messagebox("yesno", "Confirmação de Exclusão em Lote", 
                                f"Deseja realmente excluir {len(ativos)} lançamento(s)?\n\n"
                                f"Fornecedor: {self.dados_fornecedor['nome']}\n"
                                f"Esta operação não pode ser desfeita facilmente."):
                
                sucesso = 0
                datas_afetadas = set()
                
                for item in ativos:
                    try:
                        self.atualizar_status_lancamento(item['id_lancamento'], 'EXCLUIDO')
                        # Coletar datas para verificação posterior
                        if item['data']:
                            data_obj = datetime.strptime(item['data'], '%d/%m/%Y').date()
                            datas_afetadas.add(data_obj)
                        sucesso += 1
                    except Exception as e:
                        logger.debug(f"Erro ao excluir item {item['id_lancamento']}: {str(e)}")
                        continue
                
                # Verificar recálculo para as datas afetadas
                # for data_afetada in datas_afetadas:
                #     self.verificar_recalculo_apos_alteracao(data_afetada.strftime('%d/%m/%Y'), "EXCLUSÃO")
                
                self.carregar_lancamentos()
                custom_messagebox("info", "Sucesso", f"{sucesso} lançamentos excluídos com sucesso!")
                
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro na exclusão em lote: {str(e)}")

    def restaurar_lancamento(self):
        """Restaura um lançamento individual"""
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            custom_messagebox("warning", "Aviso", "Selecione um lançamento para restaurar")
            return
        
        valores = self.tree_lancamentos.item(item_selecionado[0])['values']
        nome_fornecedor = self.dados_fornecedor['nome']
        referencia = valores[3]
        valor = valores[5]
        data_lancamento = valores[0]
        status_atual = valores[7]
        
        if status_atual != 'EXCLUIDO':
            custom_messagebox("info", "Informação", "Este lançamento já está ativo")
            return
        
        if custom_messagebox("yesno", "Confirmação", 
                            f"Deseja realmente restaurar este lançamento?\n\n"
                            f"Fornecedor: {nome_fornecedor}\n"
                            f"Referência: {referencia}\n"
                            f"Valor: {valor}\n"
                            f"Data: {data_lancamento}"):
            try:
                id_lancamento = valores[9]
                self.atualizar_status_lancamento(id_lancamento, 'ATIVO')
                
                # Verificar recálculo de taxas se necessário
                # self.verificar_recalculo_apos_alteracao(data_lancamento, "RESTAURAÇÃO")
                
                self.carregar_lancamentos()
                custom_messagebox("info", "Sucesso", "Lançamento restaurado com sucesso!")
                
            except Exception as e:
                custom_messagebox("error", "Erro", f"Erro ao restaurar lançamento: {str(e)}")

    def restaurar_lote(self):
        """Restaura múltiplos lançamentos selecionados"""
        try:
            dados_selecionados = self.obter_dados_selecionados()
            
            if not dados_selecionados:
                custom_messagebox("warning", "Aviso", "Nenhum item selecionado para restauração")
                return
            
            # Filtrar apenas lançamentos excluídos
            excluidos = [item for item in dados_selecionados if item['status'] == 'EXCLUIDO']
            
            if not excluidos:
                custom_messagebox("info", "Informação", "Todos os itens selecionados já estão ativos")
                return
            
            if custom_messagebox("yesno", "Confirmação de Restauração em Lote", 
                                f"Deseja realmente restaurar {len(excluidos)} lançamento(s)?\n\n"
                                f"Fornecedor: {self.dados_fornecedor['nome']}"):
                
                sucesso = 0
                datas_afetadas = set()
                
                for item in excluidos:
                    try:
                        self.atualizar_status_lancamento(item['id_lancamento'], 'ATIVO')
                        # Coletar datas para verificação posterior
                        if item['data']:
                            data_obj = datetime.strptime(item['data'], '%d/%m/%Y').date()
                            datas_afetadas.add(data_obj)
                        sucesso += 1
                    except Exception as e:
                        logger.debug(f"Erro ao restaurar item {item['id_lancamento']}: {str(e)}")
                        continue
                
                # Verificar recálculo para as datas afetadas
                # for data_afetada in datas_afetadas:
                #     self.verificar_recalculo_apos_alteracao(data_afetada.strftime('%d/%m/%Y'), "RESTAURAÇÃO")
                
                self.carregar_lancamentos()
                custom_messagebox("info", "Sucesso", f"{sucesso} lançamentos restaurados com sucesso!")
                
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro na restauração em lote: {str(e)}")

    def atualizar_status_lancamento(self, id_lancamento, novo_status):
        """Atualiza o status de um lançamento específico"""
        try:
            from openpyxl import load_workbook
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            wb = load_workbook(arquivo_cliente)
            ws = wb['Dados']
            
            # Verificar se colunas existem
            if ws.cell(row=1, column=14).value != 'STATUS':
                ws.cell(row=1, column=14, value='STATUS')
            if ws.cell(row=1, column=16).value != 'HISTORICO_ALTERACAO':
                ws.cell(row=1, column=16, value='HISTORICO_ALTERACAO')
            
            # Encontrar e atualizar linha
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=15).value == id_lancamento:
                    # Atualizar status
                    ws.cell(row=row, column=14, value=novo_status)
                    
                    # Adicionar ao histórico
                    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    historico_atual = ws.cell(row=row, column=16).value or ""
                    
                    if novo_status == 'EXCLUIDO':
                        acao = f"EXCLUÍDO EM: {timestamp}"
                    elif novo_status == 'ATIVO':
                        acao = f"RESTAURADO EM: {timestamp}"
                    else:
                        acao = f"STATUS ALTERADO PARA {novo_status} EM: {timestamp}"
                    
                    if historico_atual:
                        novo_historico = f"{historico_atual} | {acao}"
                    else:
                        novo_historico = acao
                        
                    ws.cell(row=row, column=16, value=novo_historico)
                    break
            
            salvar_planilha_segura(wb, arquivo_cliente)
            wb.close()
            
        except Exception as e:
            if 'wb' in locals():
                wb.close()
            raise Exception(f"Erro ao atualizar status: {str(e)}")

    def visualizar_historico_lancamento(self):
        """Visualiza o histórico de alterações de um lançamento"""
        try:
            selected_items = self.tree_lancamentos.selection()
            if not selected_items:
                custom_messagebox("info", "Seleção", "Selecione um lançamento para ver o histórico!")
                return
            
            item = selected_items[0]
            valores = self.tree_lancamentos.item(item, 'values')
            id_lancamento = valores[9]
            
            # Buscar dados completos do lançamento
            if not hasattr(self, 'dados_originais') or self.dados_originais.empty:
                custom_messagebox("error", "Erro", "Dados não carregados. Clique em 'Atualizar' primeiro!")
                return
            
            try:
                id_busca = int(float(str(id_lancamento)))
            except (ValueError, TypeError):
                custom_messagebox("error", "Erro", f"ID inválido: {id_lancamento}")
                return
            
            filtro = self.dados_originais['ID_LANCAMENTO'] == id_busca
            lancamentos_encontrados = self.dados_originais[filtro]
            
            if lancamentos_encontrados.empty:
                custom_messagebox("error", "Erro", f"Lançamento com ID {id_busca} não encontrado!")
                return
            
            lancamento = lancamentos_encontrados.iloc[0]
            
            # Criar janela de histórico
            janela_historico = tk.Toplevel(self.janela)
            janela_historico.title(f"Histórico do Lançamento - ID {id_busca}")
            janela_historico.geometry("700x400")
            janela_historico.transient(self.janela)
            janela_historico.grab_set()
            
            frame_principal = ttk.Frame(janela_historico, padding="10")
            frame_principal.pack(fill='both', expand=True)
            
            # Informações do lançamento
            frame_info = ttk.LabelFrame(frame_principal, text="Informações do Lançamento")
            frame_info.pack(fill='x', pady=(0, 10))
            
            info_frame_interno = ttk.Frame(frame_info)
            info_frame_interno.pack(fill='x', padx=10, pady=5)
            
            frame_esq = ttk.Frame(info_frame_interno)
            frame_esq.pack(side='left', fill='x', expand=True)
            
            ttk.Label(frame_esq, text=f"ID: {lancamento['ID_LANCAMENTO']}", font=('TkDefaultFont', 9, 'bold')).pack(anchor='w')
            ttk.Label(frame_esq, text=f"Fornecedor: {self.dados_fornecedor['nome']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            ttk.Label(frame_esq, text=f"Referência: {lancamento['REFERÊNCIA']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            
            frame_dir = ttk.Frame(info_frame_interno)
            frame_dir.pack(side='right', fill='x', expand=True)
            
            ttk.Label(frame_dir, text=f"Valor: R$ {lancamento['VALOR']:,.2f}", font=('TkDefaultFont', 9)).pack(anchor='w')
            ttk.Label(frame_dir, text=f"Status: {lancamento['STATUS']}", font=('TkDefaultFont', 9)).pack(anchor='w')
            
            # Histórico
            frame_historico = ttk.LabelFrame(frame_principal, text="Histórico de Alterações")
            frame_historico.pack(fill='x', pady=(0, 10))
            
            text_historico = tk.Text(frame_historico, wrap='word', font=('Consolas', 9), height=12)
            scrollbar_hist = ttk.Scrollbar(frame_historico, orient='vertical', command=text_historico.yview)
            text_historico.configure(yscrollcommand=scrollbar_hist.set)
            
            historico = lancamento.get('HISTORICO_ALTERACAO', '')
            if historico and str(historico) not in ['', 'nan', 'None']:
                text_historico.insert('1.0', str(historico))
            else:
                text_historico.insert('1.0', "Nenhum histórico de alterações registrado.")
            
            text_historico.config(state='disabled')
            
            text_historico.pack(side='left', fill='both', expand=True, padx=(10, 0), pady=5)
            scrollbar_hist.pack(side='right', fill='y', pady=5)
            
            # Botão fechar
            frame_botoes = ttk.Frame(frame_principal)
            frame_botoes.pack(fill='x', pady=(5, 0))
            
            ttk.Button(frame_botoes, text="Fechar", command=janela_historico.destroy).pack(side='right')
            
        except Exception as e:
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao visualizar histórico: {str(e)}")

    def carregar_lancamentos(self):
        """Carrega os lançamentos do fornecedor - VERSÃO COM VALIDAÇÃO ALGORÍTMICA"""
        try:
            from openpyxl import load_workbook
            import pandas as pd
            from src.config.utils import validar_cpf, validar_cnpj  # ← IMPORTAR DO UTILS
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            
            # Carregar dados preservando tipos
            df = pd.read_excel(arquivo_cliente, sheet_name='Dados', dtype={'CNPJ_CPF': str}, converters=CONVERSORES_DADOS)
            df = df.fillna("")

            self.df_completo = df.copy()  # Guardar ANTES do filtro por fornecedor
            
            # Adicionar coluna de status se não existir
            if 'STATUS' not in df.columns:
                df['STATUS'] = 'ATIVO'
            df['STATUS'] = df['STATUS'].replace('', 'ATIVO').fillna('ATIVO')
            
            # Adicionar ID_LANCAMENTO se não existir
            if 'ID_LANCAMENTO' not in df.columns:
                df['ID_LANCAMENTO'] = range(1, len(df) + 1)
            
            df['ID_LANCAMENTO'] = pd.to_numeric(df['ID_LANCAMENTO'], errors='coerce').fillna(0).astype(int)
            
            # === BUSCA CORRIGIDA POR FORNECEDOR ===
            
            # Pegar CNPJ/CPF e tipo_pessoa do fornecedor já armazenado
            cnpj_cpf_normalizado = self.dados_fornecedor['cnpj_cpf']
            tipo_pessoa = self.dados_fornecedor['tipo_pessoa']
            
            logger.debug(f"DEBUG: Buscando fornecedor:")
            logger.debug(f"       Nome: {self.dados_fornecedor['nome']}")
            logger.debug(f"       CNPJ/CPF normalizado: {cnpj_cpf_normalizado}")
            logger.debug(f"       Tipo: {tipo_pessoa}")
            
            # Função para normalizar CNPJ/CPF da planilha usando tipo_pessoa
            df_fornecedores = pd.read_excel(ARQUIVO_FORNECEDORES, dtype={'CNPJ/CPF': str})

            lookup_tipo = {}
            for _, row in df_fornecedores.iterrows():
                cnpj_raw = str(row['CNPJ/CPF']).strip()
                numeros_raw = ''.join(filter(str.isdigit, cnpj_raw))
                tipo = str(row.get('tipo_pessoa', 'PJ')).strip().upper()
                if not numeros_raw:
                    continue
                tipo_final = 'PF' if tipo == 'PF' else 'PJ'
                chave_completa = numeros_raw.zfill(11) if tipo_final == 'PF' else numeros_raw.zfill(14)
                lookup_tipo[chave_completa] = tipo_final
                lookup_tipo[str(int(numeros_raw))] = tipo_final

            def normalizar_cnpj_cpf_planilha(valor):
                if pd.isna(valor) or valor == '':
                    return ''
                numeros = ''.join(filter(str.isdigit, str(valor)))
                if not numeros:
                    return ''
                tipo = (lookup_tipo.get(numeros) or
                        lookup_tipo.get(str(int(numeros))) or
                        'PJ')
                if tipo == 'PF':
                    return numeros.zfill(11)
                else:
                    return numeros.zfill(14)

            df['CNPJ_CPF_NORMALIZADO'] = df['CNPJ_CPF'].apply(normalizar_cnpj_cpf_planilha)
            
            # === BUSCA PRINCIPAL: Por CNPJ/CPF exato ===
            mask_cnpj = df['CNPJ_CPF_NORMALIZADO'] == cnpj_cpf_normalizado
            lancamentos_por_cnpj = df[mask_cnpj]
            
            logger.debug(f"DEBUG: Encontrados {len(lancamentos_por_cnpj)} lançamentos por CNPJ/CPF")
            
            # === BUSCA SECUNDÁRIA: Por nome EXATO (apenas se não encontrou por CNPJ) ===
            if lancamentos_por_cnpj.empty:
                nome_fornecedor_normalizado = str(self.dados_fornecedor['nome']).upper().strip()
                
                mask_nome_exato = (
                    df['NOME'].astype(str).str.upper().str.strip() == nome_fornecedor_normalizado
                )
                lancamentos_por_nome = df[mask_nome_exato]
                
                logger.debug(f"DEBUG: Encontrados {len(lancamentos_por_nome)} lançamentos por nome exato")
                
                # === VALIDAÇÃO CRUZADA COM ALGORITMO ===
                if not lancamentos_por_nome.empty:
                    cnpj_encontrado = lancamentos_por_nome.iloc[0]['CNPJ_CPF_NORMALIZADO']
                    
                    if cnpj_encontrado and cnpj_encontrado != cnpj_cpf_normalizado:
                        # ============================================
                        # VALIDAR SE OS DOCUMENTOS SÃO VÁLIDOS
                        # ============================================
                        doc_buscado_valido = False
                        doc_encontrado_valido = False
                        
                        # Validar documento buscado
                        if len(cnpj_cpf_normalizado) == 11:
                            doc_buscado_valido = validar_cpf(cnpj_cpf_normalizado)
                        elif len(cnpj_cpf_normalizado) == 14:
                            doc_buscado_valido = validar_cnpj(cnpj_cpf_normalizado)
                        
                        # Validar documento encontrado
                        if len(cnpj_encontrado) == 11:
                            doc_encontrado_valido = validar_cpf(cnpj_encontrado)
                        elif len(cnpj_encontrado) == 14:
                            doc_encontrado_valido = validar_cnpj(cnpj_encontrado)
                        
                        logger.debug(f"VALIDAÇÃO ALGORÍTMICA:")
                        logger.debug(f"  Doc buscado ({cnpj_cpf_normalizado}): {'VÁLIDO' if doc_buscado_valido else 'INVÁLIDO'}")
                        logger.debug(f"  Doc encontrado ({cnpj_encontrado}): {'VÁLIDO' if doc_encontrado_valido else 'INVÁLIDO'}")
                        
                        # ============================================
                        # MOSTRAR AVISO APENAS SE AMBOS FOREM VÁLIDOS
                        # ============================================
                        if doc_buscado_valido and doc_encontrado_valido:
                            custom_messagebox("warning", "Divergência de Dados", 
                                            f"ATENÇÃO: Encontrado fornecedor com nome igual mas CNPJ/CPF diferente:\n\n"
                                            f"Nome buscado: {self.dados_fornecedor['nome']}\n"
                                            f"CNPJ/CPF buscado: {self.dados_fornecedor['cnpj_cpf_formatado']} ✓ VÁLIDO\n"
                                            f"CNPJ/CPF encontrado na base: {self.formatar_cnpj_cpf(cnpj_encontrado)} ✓ VÁLIDO\n\n"
                                            f"Os dados podem estar inconsistentes. Verifique o cadastro do fornecedor.")
                        else:
                            # Documento inválido - apenas logar, sem alarme
                            logger.warning(f"Divergência ignorada - documento inválido:")
                            logger.warning(f"  Buscado: {cnpj_cpf_normalizado} ({'válido' if doc_buscado_valido else 'INVÁLIDO'})")
                            logger.warning(f"  Encontrado: {cnpj_encontrado} ({'válido' if doc_encontrado_valido else 'INVÁLIDO'})")
                
                self.df_fornecedor = lancamentos_por_nome.copy()
            else:
                self.df_fornecedor = lancamentos_por_cnpj.copy()
            
            # === VALIDAÇÃO FINAL ===
            if self.df_fornecedor.empty:
                logger.debug(f"DEBUG: Nenhum lançamento encontrado para o fornecedor")
                
                custom_messagebox("info", "Nenhum Lançamento Encontrado", 
                                f"Não foram encontrados lançamentos para:\n\n"
                                f"Fornecedor: {self.dados_fornecedor['nome']}\n"
                                f"CNPJ/CPF: {self.dados_fornecedor['cnpj_cpf_formatado']}\n"
                                f"Cliente: {self.sistema.cliente_atual}\n\n"
                                f"Verifique se:\n"
                                f"• O fornecedor possui lançamentos neste cliente\n"
                                f"• Os dados do fornecedor estão corretos\n"
                                f"• O período de busca está adequado")
            else:
                # Verificar se encontrou o fornecedor correto
                primeiro_lancamento = self.df_fornecedor.iloc[0]
                nome_encontrado = str(primeiro_lancamento['NOME']).upper().strip()
                cnpj_encontrado = primeiro_lancamento['CNPJ_CPF_NORMALIZADO']
                
                logger.debug(f"DEBUG: Fornecedor encontrado:")
                logger.debug(f"       Nome na base: {nome_encontrado}")
                logger.debug(f"       CNPJ/CPF na base: {cnpj_encontrado}")
                logger.debug(f"       Total de lançamentos: {len(self.df_fornecedor)}")
            
            # Salvar dados originais
            if not self.df_fornecedor.empty:
                self.dados_originais = self.df_fornecedor.copy()
                
                # Ordenar por data
                self.df_fornecedor['DATA_REL'] = pd.to_datetime(self.df_fornecedor['DATA_REL'], errors='coerce')
                self.df_fornecedor = self.df_fornecedor.sort_values('DATA_REL', ascending=False)
            else:
                self.dados_originais = pd.DataFrame()
            
            # Aplicar filtros iniciais
            self.aplicar_filtros()
            
        except Exception as e:
            import traceback
            logger.debug(f"Erro ao carregar lançamentos: {traceback.format_exc()}")
            custom_messagebox("error", "Erro", f"Erro ao carregar lançamentos: {str(e)}")                                           

    def calcular_numero_relatorio(self, data_relatorio):
        """
        Calcula o número do relatório quinzenal para uma data específica.
        Usa self.df_completo (todos os lançamentos do cliente) para encontrar
        a primeira data, garantindo consistência com RelatorioHandler.
        """
        try:
            import pandas as pd

            data_ref = pd.to_datetime(data_relatorio).date()

            # Encontrar primeira data em TODOS os lançamentos do cliente
            df_temp = self.df_completo.copy()
            df_temp['DATA_REL'] = pd.to_datetime(df_temp['DATA_REL'], errors='coerce')
            df_temp = df_temp.dropna(subset=['DATA_REL'])

            if df_temp.empty:
                return 1

            if not hasattr(self, '_primeira_data_cache') or self._primeira_data_cache is None:
                self._primeira_data_cache = df_temp['DATA_REL'].min().date()
            primeira_data = self._primeira_data_cache

            # Replicar lógica exata de RelatorioHandler.obter_numero_relatorio
            numero = 1
            data_atual = primeira_data

            while data_atual <= data_ref:
                if data_atual == data_ref:
                    return numero

                if data_atual.day == 5:
                    data_atual = data_atual.replace(day=20)
                else:  # day == 20
                    if data_atual.month == 12:
                        data_atual = data_atual.replace(
                            year=data_atual.year + 1, month=1, day=5
                        )
                    else:
                        data_atual = data_atual.replace(
                            month=data_atual.month + 1, day=5
                        )
                numero += 1

            # Data não cai exatamente em dia 5 ou 20 — retorna o período mais próximo
            return numero

        except Exception as e:
            logger.debug(f"Erro ao calcular número do relatório: {str(e)}")
            return ""
        
    def inicializar_datas_padrao(self):
        """Inicializa as datas padrão dos filtros baseado no sistema (dias 5 e 20)"""
        try:
            from datetime import datetime, timedelta
            from calendar import monthrange
            
            # Data de hoje
            hoje = datetime.now().date()
            dia_atual = hoje.day
            mes_atual = hoje.month
            ano_atual = hoje.year
            
            # LÓGICA DO SISTEMA: Data fim baseada nos dias 5 e 20
            if dia_atual <= 5:
                # Do dia 1 ao 5: data fim = dia 5 do mês atual
                data_fim_padrao = hoje.replace(day=5)
            elif dia_atual <= 20:
                # Do dia 6 ao 20: data fim = dia 20 do mês atual
                data_fim_padrao = hoje.replace(day=20)
            else:
                # Do dia 21 em diante: data fim = dia 5 do próximo mês
                if mes_atual == 12:
                    # Se dezembro, vai para janeiro do próximo ano
                    data_fim_padrao = datetime(ano_atual + 1, 1, 5).date()
                else:
                    # Senão, próximo mês do mesmo ano
                    data_fim_padrao = datetime(ano_atual, mes_atual + 1, 5).date()
            
            # Data de início: 30 dias antes da data fim (mais lógico para o sistema)
            data_inicio_padrao = data_fim_padrao - timedelta(days=185)  # Aproximadamente 6 meses
            
            # Definir as datas nos controles
            self.data_inicio.set_date(data_inicio_padrao)
            self.data_fim.set_date(data_fim_padrao)
            
            logger.debug(f"DEBUG: Datas padrão definidas (sistema dias 5/20):")
            logger.debug(f"       Hoje: {hoje} (dia {dia_atual})")
            logger.debug(f"       Data início: {data_inicio_padrao}")
            logger.debug(f"       Data fim: {data_fim_padrao}")
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao inicializar datas padrão: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            # Fallback para comportamento anterior
            try:
                from dateutil.relativedelta import relativedelta
                data_padrao = datetime.now() - relativedelta(months=6)
                self.data_inicio.set_date(data_padrao.date())
                self.data_fim.set_date(datetime.now().date())
            except:
                pass 

    def toggle_periodo_completo(self):
        """
        Ativa/desativa o modo 'todos os lançamentos'.
        Quando ativado: usa o período máximo e desabilita os DateEntry.
        Quando desativado: reabilita os DateEntry e restaura datas padrão.
        """
        try:
            if self.todos_lancamentos_var.get():
                # 1. Calcular período máximo ANTES de desabilitar
                if hasattr(self, 'df_completo') and not self.df_completo.empty:
                    import pandas as pd
                    df_temp = self.df_completo.copy()
                    df_temp['DATA_REL'] = pd.to_datetime(df_temp['DATA_REL'], errors='coerce')
                    df_temp = df_temp.dropna(subset=['DATA_REL'])

                    if not df_temp.empty:
                        primeira_data = df_temp['DATA_REL'].min().date()
                        self.data_inicio.set_date(primeira_data)
                    else:
                        self.data_inicio.set_date(datetime(2000, 1, 1).date())
                else:
                    self.data_inicio.set_date(datetime(2000, 1, 1).date())

                self.data_fim.set_date(datetime.now().date())

                # 2. Desabilitar DEPOIS de definir as datas
                self.data_inicio.config(state='disabled')
                self.data_fim.config(state='disabled')

            else:
                # 1. Reabilitar ANTES de definir as datas
                self.data_inicio.config(state='normal')
                self.data_fim.config(state='normal')

                # 2. Restaurar datas padrão
                self.inicializar_datas_padrao()

            self.aplicar_filtros()

        except Exception as e:
            logger.debug(f"Erro ao alternar período completo: {str(e)}")

    def aplicar_filtros(self):
        """Aplica os filtros selecionados"""
        try:
            # Limpar tree
            for item in self.tree_lancamentos.get_children():
                self.tree_lancamentos.delete(item)
                
            if self.df_fornecedor.empty:
                self.atualizar_resumo(pd.DataFrame())
                return
            
            df_filtrado = self.df_fornecedor.copy()
            
            # Filtro por período
            data_inicio = self.data_inicio.get_date()
            data_fim = self.data_fim.get_date()
            
            df_filtrado = df_filtrado[
                (df_filtrado['DATA_REL'].dt.date >= data_inicio) &
                (df_filtrado['DATA_REL'].dt.date <= data_fim)
            ]
            
            # Filtro por status
            status_filtro = self.combo_status.get()
            if status_filtro == 'Ativos':
                df_filtrado = df_filtrado[df_filtrado['STATUS'] != 'EXCLUIDO']
            elif status_filtro == 'Excluídos':
                df_filtrado = df_filtrado[df_filtrado['STATUS'] == 'EXCLUIDO']
            
            # Filtro por referência
            referencia_filtro = self.filtro_referencia.get().strip().upper()
            if referencia_filtro:
                df_filtrado = df_filtrado[
                    df_filtrado['REFERÊNCIA'].astype(str).str.upper().str.contains(referencia_filtro, na=False)
                ]
            
            # Preencher tree
            hoje = datetime.now().date()
            limite_recente = hoje - relativedelta(days=30)
            
            self._primeira_data_cache = None  # resetar cache ao filtrar
            for idx, row in df_filtrado.iterrows():
                status = row.get('STATUS', 'ATIVO')
                tag = 'excluido' if status == 'EXCLUIDO' else 'normal'
                
                # Marcar lançamentos recentes
                if pd.notna(row['DATA_REL']) and row['DATA_REL'].date() >= limite_recente:
                    tag = 'recente'
                
                valores = (
                    self.formatar_data(row['DATA_REL']),
                    self.calcular_numero_relatorio(row['DATA_REL']) if pd.notna(row['DATA_REL']) else "",
                    self.formatar_tipo_despesa(row['TP_DESP']),
                    row.get('REFERÊNCIA', ''),
                    row.get('NF', ''),
                    self.formatar_valor(row['VALOR']),
                    self.formatar_data(row['DT_VENCTO']),
                    status,
                    row.get('OBSERVAÇÃO', ''),
                    row.get('ID_LANCAMENTO', 0)  # ID oculto
                )
                
                self.tree_lancamentos.insert('', 'end', values=valores, tags=(tag,))
            
            # Atualizar resumo
            self.atualizar_resumo(df_filtrado)
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao aplicar filtros: {str(e)}")
            
    def busca_incremental(self, event=None):
        """Busca incremental conforme o usuário digita"""
        termo = self.busca_rapida.get().strip().upper()
        
        if not termo:
            self.aplicar_filtros()
            return
            
        # Filtrar dados
        df_busca = self.df_fornecedor.copy()
        
        # Aplicar filtros básicos primeiro
        data_inicio = self.data_inicio.get_date()
        data_fim = self.data_fim.get_date()
        
        df_busca = df_busca[
            (df_busca['DATA_REL'].dt.date >= data_inicio) &
            (df_busca['DATA_REL'].dt.date <= data_fim)
        ]
        
        # Buscar em NF, Observação ou Referência
        mask_busca = (
            df_busca['NF'].astype(str).str.upper().str.contains(termo, na=False) |
            df_busca['OBSERVAÇÃO'].astype(str).str.upper().str.contains(termo, na=False) |
            df_busca['REFERÊNCIA'].astype(str).str.upper().str.contains(termo, na=False)
        )
        
        df_resultado = df_busca[mask_busca]
        
        # Limpar e preencher tree
        for item in self.tree_lancamentos.get_children():
            self.tree_lancamentos.delete(item)
            
        for idx, row in df_resultado.iterrows():
            status = row.get('STATUS', 'ATIVO')
            tag = 'excluido' if status == 'EXCLUIDO' else 'normal'
            
            valores = (
                self.formatar_data(row['DATA_REL']),
                self.calcular_numero_relatorio(row['DATA_REL']) if pd.notna(row['DATA_REL']) else "",
                self.formatar_tipo_despesa(row['TP_DESP']),
                row.get('REFERÊNCIA', ''),
                row.get('NF', ''),
                self.formatar_valor(row['VALOR']),
                self.formatar_data(row['DT_VENCTO']),
                status,
                row.get('OBSERVAÇÃO', ''),
                row.get('ID_LANCAMENTO', 0)
            )
            
            self.tree_lancamentos.insert('', 'end', values=valores, tags=(tag,))
        
        self.atualizar_resumo(df_resultado)
        
    def limpar_filtros(self):
        """Limpa todos os filtros e recarrega"""
        self.inicializar_datas_padrao()
    
        self.filtro_referencia.delete(0, tk.END)
        self.combo_status.set('Ativos')
        self.busca_rapida.delete(0, tk.END)
        
        self.aplicar_filtros()
        
    def atualizar_resumo(self, df_filtrado):
        """Atualiza o resumo com estatísticas"""
        if df_filtrado.empty:
            self.lbl_total_lancamentos.config(text="Total de Lançamentos: 0")
            self.lbl_valor_total.config(text="Valor Total: R$ 0,00")
            self.lbl_ultimo_lancamento.config(text="Último Lançamento: -")
            return
            
        total_lancamentos = len(df_filtrado)
        df_ativos = df_filtrado[df_filtrado['STATUS'] != 'EXCLUIDO']
        valor_total = 0
        
        for _, row in df_ativos.iterrows():
            try:
                valor_raw = row['VALOR']
                if isinstance(valor_raw, str):
                    valor_limpo = valor_raw.replace('R$', '').replace(' ', '').replace(',', '.').strip()
                    if valor_limpo:
                        valor = float(valor_limpo)
                    else:
                        valor = 0
                elif isinstance(valor_raw, (int, float)):
                    valor = float(valor_raw)
                else:
                    valor = float(str(valor_raw).replace(',', '.') if str(valor_raw) else 0)
                
                valor_total += valor
            except (ValueError, TypeError, AttributeError):
                continue
        
        # Último lançamento
        if not df_filtrado.empty:
            ultimo = df_filtrado.iloc[0]
            data_ultimo = self.formatar_data(ultimo['DATA_REL'])
            ref_ultimo = ultimo.get('REFERÊNCIA', '')[:20] + ('...' if len(str(ultimo.get('REFERÊNCIA', ''))) > 20 else '')
            ultimo_texto = f"{data_ultimo} - {ref_ultimo}"
        else:
            ultimo_texto = "-"
        
        self.lbl_total_lancamentos.config(text=f"Total de Lançamentos: {total_lancamentos}")
        self.lbl_valor_total.config(text=f"Valor Total: R$ {valor_total:,.2f}")
        self.lbl_ultimo_lancamento.config(text=f"Último Lançamento: {ultimo_texto}")
        
    def ver_detalhes_lancamento(self, event=None):
        """Mostra detalhes completos do lançamento selecionado"""
        item_selecionado = self.tree_lancamentos.selection()
        if not item_selecionado:
            return
            
        valores = self.tree_lancamentos.item(item_selecionado[0])['values']
        
        janela_detalhes = tk.Toplevel(self.janela)
        janela_detalhes.title("Detalhes do Lançamento")
        janela_detalhes.geometry("600x450")
        janela_detalhes.transient(self.janela)
        
        frame = ttk.Frame(janela_detalhes, padding="15")
        frame.pack(fill='both', expand=True)
        
        ttk.Label(frame, text="Detalhes Completos do Lançamento", 
                 font=('Arial', 14, 'bold')).pack(pady=(0, 15))
        
        info_frame = ttk.Frame(frame)
        info_frame.pack(fill='both', expand=True)
        
        detalhes = [
            ("Fornecedor:", self.dados_fornecedor['nome']),
            ("CNPJ/CPF:", self.dados_fornecedor['cnpj_cpf_formatado']),
            ("Data do Relatório:", valores[0]),
            ("Tipo de Despesa:", valores[1]),
            ("Referência:", valores[2]),
            ("Número da NF:", valores[3]),
            ("Valor:", valores[4]),
            ("Data de Vencimento:", valores[5]),
            ("Status:", valores[6]),
            ("Observação:", valores[7])
        ]
        
        for i, (label, valor) in enumerate(detalhes):
            ttk.Label(info_frame, text=label, font=('Arial', 10, 'bold')).grid(
                row=i, column=0, padx=5, pady=5, sticky='w')
            ttk.Label(info_frame, text=str(valor), font=('Arial', 10)).grid(
                row=i, column=1, padx=15, pady=5, sticky='w')
        
        ttk.Button(frame, text="Fechar", command=janela_detalhes.destroy).pack(pady=15)
        
    def mostrar_estatisticas(self):
        """Mostra estatísticas detalhadas do fornecedor"""
        if self.df_fornecedor.empty:
            custom_messagebox("info", "Estatísticas", "Nenhum lançamento encontrado para este fornecedor.")
            return
            
        janela_stats = tk.Toplevel(self.janela)
        janela_stats.title(f"Estatísticas - {self.dados_fornecedor['nome']}")
        janela_stats.geometry("700x500")
        janela_stats.transient(self.janela)
        
        frame = ttk.Frame(janela_stats, padding="15")
        frame.pack(fill='both', expand=True)
        
        # Calcular estatísticas
        df_ativos = self.df_fornecedor[self.df_fornecedor['STATUS'] != 'EXCLUIDO']
        
        # Por período
        hoje = datetime.now().date()
        ultimos_30 = hoje - relativedelta(days=30)
        ultimos_90 = hoje - relativedelta(days=90)
        ultimo_ano = hoje - relativedelta(years=1)
        
        stats_30 = df_ativos[df_ativos['DATA_REL'].dt.date >= ultimos_30]
        stats_90 = df_ativos[df_ativos['DATA_REL'].dt.date >= ultimos_90]
        stats_ano = df_ativos[df_ativos['DATA_REL'].dt.date >= ultimo_ano]
        
        # Por referência
        ref_counts = df_ativos['REFERÊNCIA'].value_counts().head(5)
        
        # Criar interface
        ttk.Label(frame, text="Estatísticas do Fornecedor", 
                 font=('Arial', 16, 'bold')).pack(pady=(0, 20))
        
        # Notebook para organizar
        notebook = ttk.Notebook(frame)
        notebook.pack(fill='both', expand=True)
        
        # Aba Geral
        aba_geral = ttk.Frame(notebook)
        notebook.add(aba_geral, text="Resumo Geral")
        
        stats_frame = ttk.Frame(aba_geral, padding="10")
        stats_frame.pack(fill='both', expand=True)
        
        stats_info = [
            ("Total de Lançamentos:", len(df_ativos)),
            ("Últimos 30 dias:", len(stats_30)),
            ("Últimos 90 dias:", len(stats_90)),
            ("Último ano:", len(stats_ano)),
            ("", ""),
            ("Valor Total (histórico):", f"R$ {df_ativos['VALOR'].astype(float).sum():,.2f}"),
            ("Valor (últimos 30 dias):", f"R$ {stats_30['VALOR'].astype(float).sum():,.2f}"),
            ("Valor médio por lançamento:", f"R$ {df_ativos['VALOR'].astype(float).mean():,.2f}"),
        ]
        
        for i, (label, valor) in enumerate(stats_info):
            if label:  # Pular linhas vazias
                ttk.Label(stats_frame, text=label, font=('Arial', 11, 'bold')).grid(
                    row=i, column=0, padx=10, pady=5, sticky='w')
                ttk.Label(stats_frame, text=str(valor), font=('Arial', 11)).grid(
                    row=i, column=1, padx=20, pady=5, sticky='w')
        
        # Aba Referências
        aba_ref = ttk.Frame(notebook)
        notebook.add(aba_ref, text="Por Referência")
        
        ref_frame = ttk.Frame(aba_ref, padding="10")
        ref_frame.pack(fill='both', expand=True)
        
        ttk.Label(ref_frame, text="Top 5 Referências:", 
                 font=('Arial', 12, 'bold')).pack(pady=(0, 10))
        
        for ref, count in ref_counts.items():
            valor_ref = df_ativos[df_ativos['REFERÊNCIA'] == ref]['VALOR'].astype(float).sum()
            ttk.Label(ref_frame, 
                     text=f"{ref}: {count} lançamentos (R$ {valor_ref:,.2f})",
                     font=('Arial', 10)).pack(anchor='w', pady=2)
        
        ttk.Button(frame, text="Fechar", command=janela_stats.destroy).pack(pady=15)
        
    def exportar_lista(self):
        """Exporta a lista atual para Excel"""
        try:
            from tkinter import filedialog
            
            # Obter dados visíveis
            dados_exportar = []
            for item in self.tree_lancamentos.get_children():
                valores = self.tree_lancamentos.item(item)['values']
                # Remover ID (último elemento) da exportação
                dados_exportar.append(valores[:-1])
            
            if not dados_exportar:
                custom_messagebox("warning", "Aviso", "Nenhum dado para exportar!")
                return
            
            # Solicitar arquivo
            arquivo = filedialog.asksaveasfilename(
                title="Salvar Lista de Lançamentos",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"lancamentos_{self.sistema.cliente_atual.replace(' ', '_')}_{self.dados_fornecedor['nome'].replace(' ', '_')}.xlsx"
            )
            
            if arquivo:
                # Criar DataFrame — ordem igual à do Treeview, sem o ID
                colunas = ['Data Rel.', 'Nº Rel.', 'Tipo', 'Referência', 'NF', 'Valor', 'Vencimento', 'Status', 'Observação']
                df_export = pd.DataFrame(dados_exportar, columns=colunas)
                
                # Criar workbook com informações detalhadas
                with pd.ExcelWriter(arquivo, engine='openpyxl') as writer:
                    # Aba principal com dados
                    df_export.to_excel(writer, sheet_name='Lançamentos', index=False, startrow=6)
                    
                    # Obter worksheet para adicionar cabeçalho
                    worksheet = writer.sheets['Lançamentos']
                    
                    # Adicionar cabeçalho com informações
                    worksheet['A1'] = f"LANÇAMENTOS DO FORNECEDOR: {self.dados_fornecedor['nome']}"
                    worksheet['A2'] = f"CNPJ/CPF: {self.dados_fornecedor['cnpj_cpf_formatado']}"
                    worksheet['A3'] = f"Cliente: {self.sistema.cliente_atual}"
                    worksheet['A4'] = f"Período: {self.data_inicio.get()} até {self.data_fim.get()}"
                    worksheet['A5'] = f"Exportado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
                    
                    # Formatação do cabeçalho
                    from openpyxl.styles import Font
                    
                    title_font = Font(bold=True, size=14)
                    info_font = Font(bold=True, size=10)
                    
                    worksheet['A1'].font = title_font
                    for row in range(2, 6):
                        worksheet[f'A{row}'].font = info_font
                    
                    # Ajustar largura das colunas
                    # A=Data Rel., B=Nº Rel., C=Tipo, D=Referência, E=NF,
                    # F=Valor,    G=Vencimento, H=Status, I=Observação
                    column_widths = {
                        'A': 12, 'B': 8, 'C': 8, 'D': 25,
                        'E': 15, 'F': 12, 'G': 12, 'H': 10, 'I': 30
                    }
                    for col, width in column_widths.items():
                        worksheet.column_dimensions[col].width = width
                    
                    # Criar aba de resumo se houver dados
                    if not self.df_fornecedor.empty:
                        resumo_data = []
                        
                        df_ativos = self.df_fornecedor[self.df_fornecedor['STATUS'] != 'EXCLUIDO']
                        resumo_data.append(['Estatística', 'Valor'])
                        resumo_data.append(['Total de Lançamentos', len(df_ativos)])
                        resumo_data.append(['Valor Total', f"R$ {df_ativos['VALOR'].astype(float).sum():,.2f}"])
                        resumo_data.append(['Valor Médio', f"R$ {df_ativos['VALOR'].astype(float).mean():,.2f}"])
                        resumo_data.append(['Primeiro Lançamento', df_ativos['DATA_REL'].min().strftime('%d/%m/%Y') if not df_ativos.empty else 'N/A'])
                        resumo_data.append(['Último Lançamento', df_ativos['DATA_REL'].max().strftime('%d/%m/%Y') if not df_ativos.empty else 'N/A'])
                        
                        resumo_data.append(['', ''])
                        resumo_data.append(['TOP REFERÊNCIAS', 'QUANTIDADE'])
                        ref_counts = df_ativos['REFERÊNCIA'].value_counts().head(5)
                        for ref, count in ref_counts.items():
                            resumo_data.append([ref, count])
                        
                        df_resumo = pd.DataFrame(resumo_data)
                        df_resumo.to_excel(writer, sheet_name='Resumo', index=False, header=False)
                
                custom_messagebox("info", "Sucesso", f"Lista exportada com sucesso!\n\nArquivo: {arquivo}")
                
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao exportar: {str(e)}")
    
    def formatar_data(self, data):
        """Formata data para exibição"""
        if pd.isna(data) or data == "":
            return ""
        try:
            if isinstance(data, str):
                return data
            return data.strftime('%d/%m/%Y')
        except:
            return str(data)
    
    def formatar_valor(self, valor):
        """Formata valor para exibição"""
        try:
            if isinstance(valor, str):
                valor_limpo = valor.replace('R$', '').replace(' ', '').replace(',', '.').strip()
                if valor_limpo:
                    valor = float(valor_limpo.replace(',', '.'))
                else:
                    return "0,00"
            elif isinstance(valor, (int, float)):
                valor = float(valor)
            else:
                valor = float(str(valor).replace(',', '.') if str(valor) else 0)
            
            return f"{valor:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        except (ValueError, TypeError, AttributeError):
            return "0,00"
    
    def formatar_tipo_despesa(self, tp_desp):
        """Formata tipo de despesa como inteiro"""
        try:
            if pd.isna(tp_desp) or tp_desp == "":
                return ""
            valor_numerico = float(tp_desp)
            return str(int(valor_numerico))
        except (ValueError, TypeError):
            return str(tp_desp)


class GerenciadorAgenda:
    def __init__(self, sistema_principal):
        self.sistema = sistema_principal
        self.janela = None
        self.tree_agenda = None
        self.dados_agenda = []
        self.filtro_periodo = "quinzena_atual"  # quinzena_atual, mes_atual, periodo_personalizado
        self.itens_marcados = set()  # guarda id_origem dos itens marcados

        # ✅ NOVO: Sistema de cache
        self._cache_especificacoes = {}
        self._cache_fornecedores = {}
        self._cache_valido_ate = None
        self._cache_duracao = 300  # 5 minutos
        
    def _limpar_cache_se_expirado(self):
        """Limpa cache se expirado"""
        if self._cache_valido_ate and datetime.now() > self._cache_valido_ate:
            self._cache_especificacoes = {}
            self._cache_fornecedores = {}
            self._cache_valido_ate = None
    
    def calcular_mes_referencia_compromisso(self, data_rel, tipo_referencia_mes='anterior'):
        """
        Calcula o mês/ano da referência baseado na data do relatório.
        
        Args:
            data_rel: Data do relatório (datetime.date)
            tipo_referencia_mes: 'anterior' ou 'atual'
        
        Returns:
            String no formato "MM/AAAA"
        """
        from dateutil.relativedelta import relativedelta
        
        if tipo_referencia_mes == 'anterior':
            data_ref = data_rel - relativedelta(months=1)
        else:  # 'atual'
            data_ref = data_rel
        
        return data_ref.strftime('%m/%Y')


    def formatar_referencia_auto(self, fornecedor, data_rel, tipo_referencia_mes='anterior'):
        """
        Formata referência completa automaticamente.
        
        Args:
            fornecedor: Nome do fornecedor
            data_rel: Data do relatório
            tipo_referencia_mes: 'anterior' ou 'atual'
        
        Returns:
            String formatada (ex: "FGTS - REF.: 12/2025")
        """
        try:
            # Calcular mês/ano da referência
            mes_ano = self.calcular_mes_referencia_compromisso(data_rel, tipo_referencia_mes)
            
            # ✅ BUSCAR ESPECIFICAÇÃO NA PLANILHA
            especificacao = self._buscar_especificacao_fornecedor(fornecedor)
            
            if especificacao:
                # Se tem especificação cadastrada, usar ela
                # Substituir placeholder {mes_ano} se existir
                referencia = especificacao.replace('{mes_ano}', mes_ano)
                logger.debug(f"Referência com especificação: {referencia}")
                return referencia
            else:
                # Se não tem especificação, usar apenas "REF.: MM/YYYY"
                referencia = f"REF.: {mes_ano}"
                logger.debug(f"Referência sem especificação: {referencia}")
                return referencia
                
        except Exception as e:
            logger.debug(f"Erro ao formatar referência: {e}")
            # Fallback para o formato antigo em caso de erro
            mes_ano = self.calcular_mes_referencia_compromisso(data_rel, tipo_referencia_mes)
            return f"{fornecedor} - REF.: {mes_ano}"


    def _buscar_especificacao_fornecedor(self, fornecedor):
            """✅ VERSÃO COM CACHE - 100x mais rápida"""
            try:
                # Verificar cache
                self._limpar_cache_se_expirado()
                
                fornecedor_upper = fornecedor.strip().upper()
                
                if fornecedor_upper in self._cache_especificacoes:
                    return self._cache_especificacoes[fornecedor_upper]
                
                # Cache miss - carregar TODAS especificações de uma vez
                if not self._cache_especificacoes:
                    self._carregar_todas_especificacoes()
                
                # Retornar do cache (agora populado)
                return self._cache_especificacoes.get(fornecedor_upper)
                
            except Exception as e:
                logger.debug(f"Erro ao buscar especificação: {e}")
                return None

    def _carregar_todas_especificacoes(self):
        """Carrega TODAS as especificações de uma vez (executado 1x)"""
        try:
            import openpyxl
            from src.config.config import ARQUIVO_FORNECEDORES
            
            if not ARQUIVO_FORNECEDORES.exists():
                logger.debug("Planilha base_fornecedores.xlsx não encontrada")
                return
            
            logger.debug("Carregando especificações da planilha...")
            
            wb = openpyxl.load_workbook(ARQUIVO_FORNECEDORES, data_only=True, read_only=True)
            ws = wb.active
            
            count = 0
            duplicatas = 0
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                try:
                    # Coluna C (índice 2) = Razão Social
                    nome_razao = str(row[2]).strip().upper() if len(row) > 2 and row[2] else ""
                    
                    # Coluna D (índice 3) = Nome Fantasia (usado pelo sistema)
                    nome_fantasia = str(row[3]).strip().upper() if len(row) > 3 and row[3] else ""
                    
                    # Coluna M (índice 12) = Especificação
                    especificacao = row[12] if len(row) > 12 else None
                    
                    if especificacao and str(especificacao).strip():
                        especificacao_limpa = str(especificacao).strip()
                        
                        # Indexar por Nome Fantasia (principal - é o que aparece no sistema)
                        if nome_fantasia:
                            self._cache_especificacoes[nome_fantasia] = especificacao_limpa
                            count += 1
                        
                        # Indexar por Razão Social (fallback - para casos especiais)
                        if nome_razao and nome_razao != nome_fantasia:
                            self._cache_especificacoes[nome_razao] = especificacao_limpa
                            duplicatas += 1
                        
                except Exception as e:
                    # Continuar mesmo se uma linha der erro
                    logger.debug(f"Erro ao processar linha: {e}")
                    continue
            
            wb.close()
            self._cache_timestamp = datetime.now()
            
            total_entradas = count + duplicatas
            logger.debug(f"✅ Cache de especificações carregado:")
            logger.debug(f"   - {count} especificações principais (Nome Fantasia)")
            logger.debug(f"   - {duplicatas} aliases (Razão Social)")
            logger.debug(f"   - {total_entradas} entradas totais no cache")
            
        except Exception as e:
            logger.debug(f"Erro ao carregar cache de especificações: {e}")
            import traceback
            traceback.print_exc()
    
    def abrir_agenda(self):
        """Abre a agenda com carregamento otimizado"""
        if not self.sistema.cliente_atual:
            custom_messagebox("error", "Erro", "Selecione um cliente primeiro!")
            return
            
        # Mostrar janela de loading para clientes com muitos dados
        loading_window = self.criar_janela_loading()
        
        try:
            self.janela = tk.Toplevel(self.sistema.root)
            self.janela.title(f"Agenda - {self.sistema.cliente_atual}")
            self.janela.geometry("1200x800")
            
            self.janela.transient(self.sistema.root)
            self.janela.grab_set()
            
            # Atualizar loading
            self.atualizar_loading(loading_window, "Criando interface...")
            self.criar_interface()
            
            # Atualizar loading
            self.atualizar_loading(loading_window, "Carregando dados...")
            self.carregar_dados_agenda()
            
            # Fechar loading
            loading_window.destroy()
            
            # Mostrar alertas se necessário
            self.janela.after(500, self.mostrar_alertas_se_necessario)
            
        except Exception as e:
            if 'loading_window' in locals():
                loading_window.destroy()
            custom_messagebox("error", "Erro", f"Erro ao abrir agenda: {str(e)}")

    def criar_janela_loading(self):
        """Cria janela de loading simples"""
        loading = tk.Toplevel(self.sistema.root)
        loading.title("Carregando Agenda")
        loading.geometry("300x100")
        loading.transient(self.sistema.root)
        loading.grab_set()
        
        # Centralizar
        loading.update_idletasks()
        x = (loading.winfo_screenwidth() // 2) - (300 // 2)
        y = (loading.winfo_screenheight() // 2) - (100 // 2)
        loading.geometry(f"300x100+{x}+{y}")
        
        frame = ttk.Frame(loading, padding="20")
        frame.pack(fill='both', expand=True)
        
        loading.label_status = ttk.Label(frame, text="Iniciando...", font=('TkDefaultFont', 10))
        loading.label_status.pack(pady=10)
        
        # Barra de progresso indeterminada
        progress = ttk.Progressbar(frame, mode='indeterminate')
        progress.pack(fill='x', pady=10)
        progress.start()
        
        loading.update()
        return loading

    def atualizar_loading(self, loading_window, mensagem):
        """Atualiza mensagem da janela de loading"""
        try:
            if loading_window and loading_window.winfo_exists():
                loading_window.label_status.config(text=mensagem)
                loading_window.update()
        except:
            pass
    
    def abrir_configuracoes_agenda(self):
        """Abre configurações específicas da agenda"""
        janela_config = tk.Toplevel(self.janela)
        janela_config.title("Configurações da Agenda")
        janela_config.geometry("500x400")
        janela_config.transient(self.janela)
        janela_config.grab_set()
        
        main_frame = ttk.Frame(janela_config, padding="15")
        main_frame.pack(fill='both', expand=True)
        
        # Configurações de exibição
        frame_exibicao = ttk.LabelFrame(main_frame, text="Configurações de Exibição")
        frame_exibicao.pack(fill='x', pady=(0, 10))
        
        self.var_mostrar_apenas_futuros = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_exibicao, text="Mostrar apenas itens futuros por padrão",
                    variable=self.var_mostrar_apenas_futuros).pack(anchor='w', padx=10, pady=5)
        
        self.var_agrupar_por_semana = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame_exibicao, text="Agrupar itens por semana",
                    variable=self.var_agrupar_por_semana).pack(anchor='w', padx=10, pady=5)
        
        # Configurações de alertas
        frame_alertas = ttk.LabelFrame(main_frame, text="Configurações de Alertas")
        frame_alertas.pack(fill='x', pady=(0, 10))
        
        ttk.Label(frame_alertas, text="Alertar com quantos dias de antecedência:").pack(anchor='w', padx=10, pady=5)
        self.entry_dias_alerta = ttk.Entry(frame_alertas, width=5)
        self.entry_dias_alerta.insert(0, "3")
        self.entry_dias_alerta.pack(anchor='w', padx=10, pady=5)
        
        # Configurações de dados
        frame_dados = ttk.LabelFrame(main_frame, text="Configurações de Dados")
        frame_dados.pack(fill='x', pady=(0, 10))
        
        ttk.Label(frame_dados, text="Carregar últimos X dias do passado:").pack(anchor='w', padx=10, pady=5)
        self.entry_dias_passado = ttk.Entry(frame_dados, width=5)
        self.entry_dias_passado.insert(0, "30")
        self.entry_dias_passado.pack(anchor='w', padx=10, pady=5)
        
        self.var_excluir_mao_obra = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_dados, text="Excluir mão de obra (TP_DESP = 1)",
                    variable=self.var_excluir_mao_obra).pack(anchor='w', padx=10, pady=5)
        
        # Botões
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))
        
        def aplicar_configuracoes():
            try:
                # Aplicar configurações e recarregar
                self.carregar_dados_agenda()
                custom_messagebox("info", "Sucesso", "Configurações aplicadas!")
                janela_config.destroy()
            except Exception as e:
                custom_messagebox("error", "Erro", f"Erro ao aplicar configurações: {str(e)}")
        
        ttk.Button(frame_botoes, text="Aplicar", command=aplicar_configuracoes).pack(side='left', padx=5)
        ttk.Button(frame_botoes, text="Cancelar", command=janela_config.destroy).pack(side='left', padx=5)

    def criar_interface(self):
        """Cria a interface da agenda"""
        # Frame principal
        main_frame = ttk.Frame(self.janela, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # === FRAME SUPERIOR: FILTROS E CONTROLES ===
        frame_controles = ttk.Frame(main_frame)
        frame_controles.pack(fill='x', pady=(0, 10))
        
        frame_periodo = ttk.LabelFrame(frame_controles, text="Período (por Data de Relatório)")
        frame_periodo.pack(side='left', padx=(0, 10), fill='y')

        self.var_periodo = tk.StringVar(value="quinzena_atual")

        ttk.Radiobutton(frame_periodo, text="Próximo Relatório", 
                    variable=self.var_periodo, value="quinzena_atual",
                    command=self.aplicar_filtro_periodo).pack(anchor='w', padx=5)
        ttk.Radiobutton(frame_periodo, text="Próximos 2 Relatórios", 
                    variable=self.var_periodo, value="mes_atual",
                    command=self.aplicar_filtro_periodo).pack(anchor='w', padx=5)
        ttk.Radiobutton(frame_periodo, text="Período Personalizado", 
                    variable=self.var_periodo, value="personalizado",
                    command=self.aplicar_filtro_periodo).pack(anchor='w', padx=5)
        
        # Datas personalizadas (inicialmente ocultas)
        self.frame_datas_personalizado = ttk.Frame(frame_periodo)
        
        ttk.Label(self.frame_datas_personalizado, text="De:").grid(row=0, column=0, padx=2)
        self.data_inicio_personalizada = DateEntry(self.frame_datas_personalizado, width=10, 
                                                  date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_inicio_personalizada.grid(row=0, column=1, padx=2)
        
        ttk.Label(self.frame_datas_personalizado, text="Até:").grid(row=0, column=2, padx=2)
        self.data_fim_personalizada = DateEntry(self.frame_datas_personalizado, width=10, 
                                                date_pattern='dd/mm/yyyy', locale='pt_BR')
        self.data_fim_personalizada.grid(row=0, column=3, padx=2)
        
        ttk.Button(self.frame_datas_personalizado, text="Aplicar", 
                  command=self.aplicar_filtro_periodo).grid(row=0, column=4, padx=5)
        
        # Filtros de status
        frame_origem = ttk.LabelFrame(frame_controles, text="Origem dos Dados")
        frame_origem.pack(side='left', padx=(0, 10), fill='y')
        
        self.var_mostrar_existentes = tk.BooleanVar(value=True)
        self.var_mostrar_pendentes_config = tk.BooleanVar(value=True)
        # self.var_mostrar_vencidos_apenas = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(frame_origem, text="Já Lançados", 
                    variable=self.var_mostrar_existentes,
                    command=self.aplicar_filtros).pack(anchor='w', padx=5)
        ttk.Checkbutton(frame_origem, text="Compromissos Configurados", 
                    variable=self.var_mostrar_pendentes_config,
                    command=self.aplicar_filtros).pack(anchor='w', padx=5)
                
        # Resumo rápido
        frame_resumo = ttk.LabelFrame(frame_controles, text="Resumo Rápido")
        frame_resumo.pack(side='left', padx=(0, 10), fill='y')
        
        self.label_total_periodo = ttk.Label(frame_resumo, text="Total Período: R$ 0,00", 
                                           font=('TkDefaultFont', 9, 'bold'))
        self.label_total_periodo.pack(padx=5, pady=2)
        
        self.label_pendentes = ttk.Label(frame_resumo, text="Pendentes: 0 (R$ 0,00)", 
                                        foreground='orange')
        self.label_pendentes.pack(padx=5, pady=2)
        
        self.label_vencidos = ttk.Label(frame_resumo, text="Vencidos: 0 (R$ 0,00)", 
                                       foreground='red')
        self.label_vencidos.pack(padx=5, pady=2)
        
        # === FRAME PRINCIPAL: LISTA DA AGENDA ===
        frame_lista = ttk.Frame(main_frame)
        frame_lista.pack(fill='both', expand=True)
        
        # Treeview - COLUNAS CORRIGIDAS (SEM CLIENTE)
        colunas = ('Marcar', 'Vencimento', 'Status', 'Fornecedor', 'Referência',
                'Valor', 'Tipo', 'Observação', 'ID_Origem')
        self.tree_agenda = ttk.Treeview(frame_lista, columns=colunas, show='headings',
                                    height=25, selectmode='extended')
 
        # Configurar cabeçalhos
        self.tree_agenda.heading('Marcar', text='☑')
        self.tree_agenda.heading('Vencimento', text='Vencimento')
        self.tree_agenda.heading('Status', text='Status')
        self.tree_agenda.heading('Fornecedor', text='Fornecedor')
        self.tree_agenda.heading('Referência', text='Referência')
        self.tree_agenda.heading('Valor', text='Valor')
        self.tree_agenda.heading('Tipo', text='Tipo')
        self.tree_agenda.heading('Observação', text='Observação')
        self.tree_agenda.heading('ID_Origem', text='ID')
 
        # Configurar larguras
        self.tree_agenda.column('Marcar', width=45, anchor='center', stretch=False)
        self.tree_agenda.column('Vencimento', width=80, anchor='center')
        self.tree_agenda.column('Status', width=100, anchor='center')
        self.tree_agenda.column('Fornecedor', width=200)
        self.tree_agenda.column('Referência', width=260)
        self.tree_agenda.column('Valor', width=100, anchor='e')
        self.tree_agenda.column('Tipo', width=80, anchor='center')
        self.tree_agenda.column('Observação', width=200)
        self.tree_agenda.column('ID_Origem', width=0, stretch=False)  # Oculto
    
        # Scrollbars
        scrolly_agenda = ttk.Scrollbar(frame_lista, orient='vertical', command=self.tree_agenda.yview)
        scrollx_agenda = ttk.Scrollbar(frame_lista, orient='horizontal', command=self.tree_agenda.xview)
        self.tree_agenda.configure(yscrollcommand=scrolly_agenda.set, xscrollcommand=scrollx_agenda.set)
        
        # Posicionar elementos
        self.tree_agenda.grid(row=0, column=0, sticky='nsew')
        scrolly_agenda.grid(row=0, column=1, sticky='ns')
        scrollx_agenda.grid(row=1, column=0, sticky='ew')
        
        # Configurar expansão
        frame_lista.grid_rowconfigure(0, weight=1)
        frame_lista.grid_columnconfigure(0, weight=1)
        
        # Tags para cores
        self.tree_agenda.tag_configure('lancado', background='#e8f5e8')      # Verde claro
        self.tree_agenda.tag_configure('pendente', background='#fff8dc')     # Bege claro
        self.tree_agenda.tag_configure('vencido', background='#ffe4e1')      # Rosa claro
        self.tree_agenda.tag_configure('condicionado', background='#e6f3ff') # Azul claro
        self.tree_agenda.tag_configure('hoje', background='#ffffe0')         # Amarelo claro
        
        # === FRAME INFERIOR: BOTÕES DE AÇÃO (2 LINHAS) ===
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))
 
        # ---------- LINHA 1: ações sobre o item selecionado + navegação ----------
        frame_botoes_linha1 = ttk.Frame(frame_botoes)
        frame_botoes_linha1.pack(fill='x', pady=(0, 5))
 
        ttk.Button(frame_botoes_linha1, text="Novo Lançamento",
                  command=self.novo_lancamento).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha1, text="Editar Selecionado",
                  command=self.editar_selecionado).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha1, text="Confirmar Lançamento",
                  command=self.confirmar_lancamento).pack(side='left', padx=5)
 
        ttk.Separator(frame_botoes_linha1, orient='vertical').pack(side='left', fill='y', padx=10)
 
        ttk.Button(frame_botoes_linha1, text="📅 Gerenciar Compromissos",
                command=self.abrir_gerenciador_compromissos).pack(side='left', padx=5)
 
        ttk.Separator(frame_botoes_linha1, orient='vertical').pack(side='left', fill='y', padx=10)
 
        ttk.Button(frame_botoes_linha1, text="Importar de Excel",
                  command=self.importar_excel).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha1, text="Exportar Período",
                  command=self.exportar_periodo).pack(side='left', padx=5)
 
        ttk.Button(frame_botoes_linha1, text="Fechar",
                  command=self.janela.destroy).pack(side='right', padx=5)
 
        # ---------- LINHA 2: confirmação em lote + manutenção ----------
        frame_botoes_linha2 = ttk.Frame(frame_botoes)
        frame_botoes_linha2.pack(fill='x')
 
        ttk.Button(frame_botoes_linha2, text="☑ Marcar Completos",
                  command=self.marcar_todos_completos).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha2, text="☐ Desmarcar Todos",
                  command=self.desmarcar_todos_marcados).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha2, text="✅ Confirmar Selecionados (Lote)",
                  command=self.confirmar_selecionados_em_massa).pack(side='left', padx=5)
 
        ttk.Separator(frame_botoes_linha2, orient='vertical').pack(side='left', fill='y', padx=10)
 
        ttk.Button(frame_botoes_linha2, text="Atualizar",
                  command=self.carregar_dados_agenda).pack(side='left', padx=5)
 
        ttk.Separator(frame_botoes_linha2, orient='vertical').pack(side='left', fill='y', padx=10)
 
        ttk.Button(frame_botoes_linha2, text="🧹 Limpar Duplicações",
                command=self.limpar_duplicacoes_inteligente).pack(side='left', padx=5)
        ttk.Button(frame_botoes_linha2, text="⚙️ Configurações",
                command=self.abrir_configuracoes_agenda).pack(side='left', padx=5)
 
        # Configurar eventos
        self.tree_agenda.bind('<Double-1>', self.on_double_click)
        self.tree_agenda.bind('<Button-1>', self.on_tree_click)  # clique no checkbox
        self.configurar_atalhos()
    
    def carregar_dados_agenda(self):
        """Carregamento da agenda baseado em DATA_REL - COM DIAGNÓSTICO"""
        try:
            hoje = datetime.now().date()
            
            print("=" * 80)
            print(f"DEBUG AGENDA - DATA: {hoje}")
            print(f"DEBUG AGENDA - ANO: {hoje.year}")
            print(f"DEBUG AGENDA - MÊS: {hoje.month}")
            print(f"DEBUG AGENDA - DIA: {hoje.day}")
            print("=" * 80)
            
            data_inicio, data_fim = self.calcular_periodo_filtro()
            
            print(f"PERÍODO CALCULADO:")
            print(f"  Início: {data_inicio}")
            print(f"  Fim: {data_fim}")
            print("=" * 80)
            
            self.dados_agenda = []
            
            # 1. Carregar lançamentos existentes
            print("1. Carregando lançamentos existentes...")
            self.carregar_lancamentos_existentes()
            print(f"   → {len(self.dados_agenda)} itens carregados")
            
            # 2. Carregar compromissos
            print("2. Carregando compromissos...")
            self.carregar_compromissos_futuros()
            print(f"   → {len(self.dados_agenda)} itens no total")
            
            # 3. Carregar medições
            print("3. Carregando medições pendentes...")
            self.carregar_medicoes_pendentes()
            print(f"   → {len(self.dados_agenda)} itens no total")
            
            # 4. Agrupar medições
            print("4. Agrupando medições...")
            self.agrupar_medicoes_por_fornecedor()
            print(f"   → {len(self.dados_agenda)} itens no total")
            
            # 5. Identificar condicionados
            print("5. Identificando condicionados...")
            self.carregar_lancamentos_condicionados()
            
            # 6. Aplicar filtros
            print("6. Aplicando filtros...")
            self.aplicar_filtros()
            self.atualizar_resumo()
            
            print(f"✅ Carregamento concluído: {len(self.tree_agenda.get_children())} itens na tela")
            print("=" * 80)
            
        except Exception as e:
            print(f"❌ ERRO CRÍTICO: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def carregar_lancamentos_existentes(self):
        """Carrega lançamentos baseados na DATA_REL (data do relatório)"""
        try:
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            if not arquivo_cliente.exists():
                logger.debug("DEBUG: Arquivo do cliente não existe")
                return

            df = pd.read_excel(arquivo_cliente, sheet_name='Dados', converters=CONVERSORES_DADOS)
            df = df.fillna("")

            hoje = datetime.now().date()
            
            # Obter período de filtro baseado em DATA_REL
            data_inicio, data_fim = self.calcular_periodo_filtro()
            
            logger.debug(f"DEBUG: Carregando lançamentos com DATA_REL entre {data_inicio} e {data_fim}")

            for idx, row in df.iterrows():
                if row.get('STATUS', 'ATIVO') == 'EXCLUIDO':
                    continue
                
                # FILTRAR POR DATA_REL (data do relatório)
                try:
                    data_rel = pd.to_datetime(row['DATA_REL'], dayfirst=True).date()
                    
                    # MUDANÇA CRÍTICA: Verificar se DATA_REL está no período desejado
                    if not (data_inicio <= data_rel <= data_fim):
                        continue
                        
                except:
                    logger.debug(f"DEBUG: Data_rel inválida na linha {idx}")
                    continue
                
                # FILTRAR POR TIPO DE DESPESA - EXCLUIR MÃO DE OBRA (tp_desp == 1)
                try:
                    tp_desp = int(float(row.get('TP_DESP', 0)))
                    if tp_desp == 1:  # Pular mão de obra
                        continue
                except (ValueError, TypeError):
                    continue

                # Verificar e validar valor
                try:
                    valor = row.get('VALOR', 0)
                    if pd.isna(valor) or valor == '' or valor == 0:
                        continue  # Pular lançamentos sem valor
                    valor = float(valor)
                except (ValueError, TypeError):
                    logger.debug(f"DEBUG: Valor inválido na linha {idx}: {valor}")
                    continue

                # Determinar status baseado na data de vencimento (para exibição visual)
                try:
                    dt_vencto = pd.to_datetime(row['DT_VENCTO'], dayfirst=True).date()
                    
                    if dt_vencto < hoje:
                        status = "VENCIDO"
                    elif dt_vencto == hoje:
                        status = "VENCE HOJE"
                    else:
                        status = "LANÇADO"
                        
                except:
                    logger.debug(f"DEBUG: Data vencimento inválida na linha {idx}")
                    continue

                item_agenda = {
                    'vencimento': dt_vencto,
                    'data_rel': data_rel,  # ADICIONAR data_rel para comparações
                    'status': status,
                    'fornecedor': row.get('NOME', ''),
                    'referencia': row.get('REFERÊNCIA', ''),
                    'valor': valor,
                    'tipo': tp_desp,
                    'observacao': row.get('OBSERVAÇÃO', ''),
                    'id_origem': row.get('ID_LANCAMENTO', ''),
                    'origem': 'EXISTENTE',
                    'dados_completos': row.to_dict()
                }
                
                self.dados_agenda.append(item_agenda)
                
            logger.debug(f"DEBUG: {len([d for d in self.dados_agenda if d['origem'] == 'EXISTENTE'])} lançamentos existentes carregados")
                    
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao carregar lançamentos existentes: {str(e)}")
    
    def carregar_compromissos_futuros(self):
        """Carrega apenas compromissos das configurações (sem arquivos externos)"""
        try:
            logger.debug("DEBUG: Carregando apenas compromissos das configurações")
            
            # APENAS usar compromissos recorrentes das configurações
            self.gerar_compromissos_recorrentes_config()
            
            # NÃO importar de Agenda.xlsx nem fazer análise histórica
            # Isso simplifica e torna mais previsível
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao carregar compromissos futuros: {str(e)}")

    
    def carregar_medicoes_pendentes(self):
        """✅ VERSÃO CORRIGIDA - Nome do fornecedor (não CNPJ) + leitura de Data_Rel"""
        try:
            logger.debug("=" * 80)
            logger.debug("DEBUG: INICIANDO CARREGAMENTO DE MEDIÇÕES PENDENTES")
            logger.debug("=" * 80)
            
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            if not arquivo_cliente.exists():
                logger.debug("DEBUG: Arquivo do cliente não existe")
                return
            
            import pandas as pd
            
            # Ler planilha
            df_medicoes = pd.read_excel(arquivo_cliente, sheet_name="Medicoes")
            
            # Normalizar colunas
            df_medicoes.columns = df_medicoes.columns.str.strip().str.upper()
            
            logger.debug(f"DEBUG: Colunas encontradas: {list(df_medicoes.columns)}")
            
            # ✅ NOVO: detectar se a coluna Data_Rel existe (planilhas migradas têm;
            # planilhas muito antigas, sem a migração de verificar_aba_medicoes
            # rodada ainda, podem não ter)
            col_data_rel_explicita = 'DATA_REL' if 'DATA_REL' in df_medicoes.columns else None
            if col_data_rel_explicita:
                logger.debug("DEBUG: Coluna DATA_REL encontrada — será usada como fonte primária do período")
            else:
                logger.warning("⚠️ Coluna DATA_REL não encontrada — usando inferência por dia do mês (fallback)")

            # ✅ NOVO: detectar se a coluna Agrupar_Agenda existe (planilhas
            # migradas em gestao_medicoes.verificar_aba_medicoes têm; planilhas
            # antigas, sem essa migração, não têm — nesse caso a medição é
            # tratada como agrupável, preservando o comportamento anterior)
            col_agrupar_explicita = 'AGRUPAR_AGENDA' if 'AGRUPAR_AGENDA' in df_medicoes.columns else None
            if col_agrupar_explicita:
                logger.debug("DEBUG: Coluna AGRUPAR_AGENDA encontrada — será respeitada no agrupamento por fornecedor")
            else:
                logger.debug("DEBUG: Coluna AGRUPAR_AGENDA não encontrada — todas as medições tratadas como agrupáveis")
            
            # Encontrar coluna de status
            col_status = None
            if 'STATUS_MEDICAO' in df_medicoes.columns:
                col_status = 'STATUS_MEDICAO'
            elif 'STATUS' in df_medicoes.columns:
                col_status = 'STATUS'
            else:
                logger.error(f"❌ Coluna de status não encontrada!")
                return
            
            # Filtrar pendentes
            medicoes_pendentes = df_medicoes[
                df_medicoes[col_status].astype(str).str.upper().str.strip() == 'PENDENTE'
            ]
            
            logger.debug(f"DEBUG: {len(medicoes_pendentes)} medições PENDENTES")
            
            if len(medicoes_pendentes) == 0:
                logger.debug("DEBUG: Nenhuma medição PENDENTE encontrada")
                return
            
            novos_itens = []
            
            for idx, row in medicoes_pendentes.iterrows():
                try:
                    # Nome do fornecedor
                    nome_fornecedor = None
                    for col_nome_variacao in ['NOME_FORNECEDOR', 'FORNECEDOR', 'NOME', 'RAZAO_SOCIAL']:
                        if col_nome_variacao in df_medicoes.columns:
                            nome_fornecedor = str(row[col_nome_variacao]).strip()
                            if nome_fornecedor and not nome_fornecedor.isdigit():
                                logger.debug(f"   ✅ Nome encontrado na coluna '{col_nome_variacao}': {nome_fornecedor}")
                                break
                    
                    if not nome_fornecedor or nome_fornecedor.isdigit():
                        logger.warning(f"   ⚠️ Nome não encontrado, usando 'FORNECEDOR DESCONHECIDO'")
                        nome_fornecedor = "FORNECEDOR DESCONHECIDO"
                    
                    # Valor
                    valor_float = float(row['VALOR']) if pd.notna(row['VALOR']) else 0.0
                    if valor_float <= 0:
                        logger.debug(f"   ❌ Linha {idx}: Valor inválido")
                        continue
                    
                    # Data de pagamento
                    dt_pagamento = pd.to_datetime(row['DATA_PAGAMENTO']).date()
                    
                    # ✅ CORRIGIDO: usa Data_Rel gravada diretamente, quando disponível.
                    # Só cai na inferência por dia do mês (fallback) para linhas
                    # antigas, gravadas antes da coluna existir.
                    valor_rel_explicito = row.get(col_data_rel_explicita) if col_data_rel_explicita else None
                    
                    if pd.notna(valor_rel_explicito):
                        data_rel = pd.to_datetime(valor_rel_explicito).date()
                    else:
                        if 6 <= dt_pagamento.day <= 20:
                            data_rel = dt_pagamento.replace(day=20)
                        else:
                            if dt_pagamento.day > 20:
                                from dateutil.relativedelta import relativedelta
                                data_rel = (dt_pagamento + relativedelta(months=1)).replace(day=5)
                            else:
                                data_rel = dt_pagamento.replace(day=5)
                    
                    # Referência
                    referencia = row.get('REFERENCIA', '')
                    if pd.isna(referencia) or str(referencia).strip() == '':
                        referencia = 'SEM REFERÊNCIA'
                    else:
                        referencia = str(referencia).strip()
                    
                    # CNPJ
                    cnpj_fornecedor = str(row['CNPJ_FORNECEDOR']).strip()

                    # ✅ NOVO: flag de agrupamento (coluna Agrupar_Agenda).
                    # Ausência da coluna ou célula vazia = agrupar (True),
                    # mesmo padrão "opt-out" usado para não afetar dados antigos.
                    # Só "NAO" (case-insensitive) desativa o agrupamento.
                    valor_agrupar = row.get(col_agrupar_explicita) if col_agrupar_explicita else None
                    agrupar_flag = (
                        str(valor_agrupar).strip().upper() != 'NAO'
                        if pd.notna(valor_agrupar) else True
                    )

                    item_agenda = {
                        'vencimento': dt_pagamento,
                        'data_rel': data_rel,
                        'status': 'PENDENTE',
                        'fornecedor': nome_fornecedor,
                        'referencia': referencia,
                        'valor': valor_float,
                        'tipo': 'TD2',
                        'observacao': f"Medição pendente - Contrato {row['ID_CONTRATO']}",
                        'id_origem': f"MEDICAO_{row['ID_CONTRATO']}_{row['ID_MEDICAO']}",
                        'origem': 'MEDICAO',
                        'agrupar': agrupar_flag,  # ✅ NOVO
                        'dados_medicao': {
                            'id_contrato': row['ID_CONTRATO'],
                            'id_medicao': row['ID_MEDICAO'],
                            'linha_planilha': int(idx) + 2,
                            'cnpj': cnpj_fornecedor,
                            'data_medicao': pd.to_datetime(row['DATA_MEDICAO']).date() if pd.notna(row['DATA_MEDICAO']) else dt_pagamento,
                            'data_pagamento': dt_pagamento
                        }
                    }
                    
                    novos_itens.append(item_agenda)
                    
                    logger.debug(f"   ✅ Medição adicionada:")
                    logger.debug(f"      Contrato {row['ID_CONTRATO']}, Medição {row['ID_MEDICAO']}")
                    logger.debug(f"      Fornecedor: {nome_fornecedor}")
                    logger.debug(f"      CNPJ: {cnpj_fornecedor}")
                    logger.debug(f"      Data_Rel usada: {data_rel} ({'explícita' if col_data_rel_explicita and pd.notna(valor_rel_explicito) else 'inferida'})")
                    logger.debug(f"      Agrupar_Agenda: {'SIM' if agrupar_flag else 'NAO'}")
                    logger.debug(f"      Valor: R$ {valor_float:,.2f}")
                    
                except Exception as e:
                    logger.error(f"   ❌ Erro linha {idx}: {str(e)}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            self.dados_agenda.extend(novos_itens)
            
            logger.debug("=" * 80)
            logger.debug(f"RESUMO:")
            logger.debug(f"  • Medições PENDENTES: {len(medicoes_pendentes)}")
            logger.debug(f"  • Medições ADICIONADAS: {len(novos_itens)}")
            logger.debug("=" * 80)
            
        except Exception as e:
            logger.error(f"❌ ERRO: {str(e)}")
            import traceback
            traceback.print_exc()

    def agrupar_medicoes_por_fornecedor(self):
        """Agrupa medições pendentes do mesmo fornecedor no mesmo relatório"""
        try:
            logger.debug("=" * 80)
            logger.debug("DEBUG: AGRUPANDO MEDIÇÕES POR FORNECEDOR")
            logger.debug("=" * 80)
            
            # Separar medições das demais origens
            medicoes = [item for item in self.dados_agenda if item['origem'] == 'MEDICAO']
            outros = [item for item in self.dados_agenda if item['origem'] != 'MEDICAO']
            
            logger.debug(f"DEBUG: Total de medições encontradas: {len(medicoes)}")
            logger.debug(f"DEBUG: Outros itens na agenda: {len(outros)}")
            
            if not medicoes:
                logger.debug("DEBUG: Nenhuma medição para agrupar")
                return

            # ✅ NOVO: medições com agrupar=False nunca entram no agrupamento —
            # seguem direto como itens individuais, respeitando a flag
            # Agrupar_Agenda definida na aba Medições (Gestão de Empreiteiros)
            medicoes_agrupaveis = [m for m in medicoes if m.get('agrupar', True)]
            medicoes_isoladas = [m for m in medicoes if not m.get('agrupar', True)]

            logger.debug(f"DEBUG: Medições agrupáveis: {len(medicoes_agrupaveis)}")
            logger.debug(f"DEBUG: Medições marcadas para não agrupar: {len(medicoes_isoladas)}")

            # Agrupar medições por fornecedor e data_rel
            medicoes_agrupadas = {}
            
            for medicao in medicoes_agrupaveis:
                # Criar chave única: fornecedor + data_rel
                chave = f"{medicao['fornecedor']}_{medicao['data_rel'].strftime('%Y%m%d')}"
                
                logger.debug(f"\nDEBUG: Processando medição:")
                logger.debug(f"       Fornecedor: {medicao['fornecedor']}")
                logger.debug(f"       Data REL: {medicao['data_rel']}")
                logger.debug(f"       Chave: {chave}")
                logger.debug(f"       Valor: R$ {medicao['valor']:,.2f}")
                
                if chave not in medicoes_agrupadas:
                    # Criar novo grupo
                    medicoes_agrupadas[chave] = {
                        'vencimento': medicao['vencimento'],
                        'data_rel': medicao['data_rel'],
                        'status': 'PENDENTE',
                        'fornecedor': medicao['fornecedor'],
                        'referencia': '',
                        'valor': 0.0,
                        'tipo': 'TD2',
                        'observacao': '',
                        'id_origem': '',
                        'origem': 'MEDICAO_AGRUPADA',
                        'medicoes_individuais': [],
                        'cnpj_fornecedor': medicao['dados_medicao']['cnpj']  # Guardar CNPJ
                    }
                    logger.debug(f"       → Novo grupo criado")
                
                # Adicionar medição ao grupo
                medicoes_agrupadas[chave]['valor'] += medicao['valor']
                medicoes_agrupadas[chave]['medicoes_individuais'].append({
                    'id_contrato': medicao['dados_medicao']['id_contrato'],
                    'id_medicao': medicao['dados_medicao']['id_medicao'],
                    'linha_planilha': medicao['dados_medicao']['linha_planilha'],
                    'referencia': medicao['referencia'],
                    'valor': medicao['valor'],
                    'data_medicao': medicao['dados_medicao']['data_medicao'],
                    'data_pagamento': medicao['dados_medicao']['data_pagamento']
                })
                
                logger.debug(f"       → Adicionada ao grupo (total no grupo: {len(medicoes_agrupadas[chave]['medicoes_individuais'])})")
            
            # Finalizar grupos - montar referência e observação
            itens_finais = []
            
            for chave, grupo in medicoes_agrupadas.items():
                qtd_medicoes = len(grupo['medicoes_individuais'])
                
                logger.debug(f"\n--- Finalizando grupo: {chave}")
                logger.debug(f"    Quantidade de medições: {qtd_medicoes}")
                logger.debug(f"    Valor total: R$ {grupo['valor']:,.2f}")
                
                if qtd_medicoes == 1:
                    # Se só tem 1 medição, manter como individual
                    med = grupo['medicoes_individuais'][0]
                    
                    item_individual = {
                        'vencimento': grupo['vencimento'],
                        'data_rel': grupo['data_rel'],
                        'status': 'PENDENTE',
                        'fornecedor': grupo['fornecedor'],
                        # ✅ CORREÇÃO: Remover duplicação
                        'referencia': med['referencia'],  # Já vem formatado de carregar_medicoes_pendentes
                        'valor': med['valor'],
                        'tipo': 'TD2',
                        'observacao': f"Medição pendente - Contrato {med['id_contrato']}",
                        'id_origem': f"MEDICAO_{med['id_contrato']}_{med['id_medicao']}",
                        'origem': 'MEDICAO',
                        'dados_medicao': {
                            'id_contrato': med['id_contrato'],
                            'id_medicao': med['id_medicao'],
                            'linha_planilha': med['linha_planilha'],
                            'cnpj': grupo['cnpj_fornecedor'],
                            'data_medicao': med['data_medicao'],
                            'data_pagamento': med['data_pagamento']
                        }
                    }
                    
                    itens_finais.append(item_individual)
                    logger.debug(f"    → Mantida como medição INDIVIDUAL")
                    
                else:
                    # Múltiplas medições - criar grupo
                    
                    # ✅ NOVO: Pegar contratos únicos
                    ids_contratos = sorted(list(set([m['id_contrato'] for m in grupo['medicoes_individuais']])))
                    
                    # ✅ NOVO: Referência mostrando contratos
                    if len(ids_contratos) == 1:
                        # Todas do mesmo contrato
                        grupo['referencia'] = f"{qtd_medicoes} MEDIÇÕES AGRUPADAS (CONTRATO {ids_contratos[0]})"
                    else:
                        # Múltiplos contratos
                        contratos_str = ', '.join([str(c) for c in ids_contratos])
                        grupo['referencia'] = f"{qtd_medicoes} MEDIÇÕES AGRUPADAS (CONTRATOS {contratos_str})"
                    
                    # Observação detalhada (mantém como está)
                    detalhes = []
                    for med in grupo['medicoes_individuais']:
                        detalhes.append(
                            f"Med.{med['id_medicao']}/Contr.{med['id_contrato']} "
                            f"(R$ {med['valor']:,.2f})".replace(',', 'X').replace('.', ',').replace('X', '.')
                        )
                    grupo['observacao'] = " | ".join(detalhes)
                    
                    # ID único para o grupo
                    grupo['id_origem'] = f"MEDICAO_GRUPO_{grupo['fornecedor'].replace(' ', '_')}_{grupo['data_rel'].strftime('%Y%m%d')}_CONTRATOS_{'_'.join(map(str, ids_contratos))}"
                    
                    itens_finais.append(grupo)
                    logger.debug(f"    → Criado GRUPO de {qtd_medicoes} medições")
                    logger.debug(f"       Contratos: {', '.join(map(str, ids_contratos))}")

            # ✅ NOVO: medições marcadas como agrupar=False entram como itens
            # individuais, no mesmo formato que carregar_medicoes_pendentes já
            # produz — nenhuma outra parte do código precisa saber da diferença
            itens_finais.extend(medicoes_isoladas)

            # ✅ Recompor dados_agenda
            self.dados_agenda = outros + itens_finais
            
            logger.debug("=" * 80)
            logger.debug(f"RESUMO DO AGRUPAMENTO:")
            logger.debug(f"  • Medições originais: {len(medicoes)}")
            logger.debug(f"  • Medições isoladas (Agrupar_Agenda=NAO): {len(medicoes_isoladas)}")
            logger.debug(f"  • Grupos criados: {len([g for g in itens_finais if g['origem'] == 'MEDICAO_AGRUPADA'])}")
            logger.debug(f"  • Medições individuais mantidas: {len([g for g in itens_finais if g['origem'] == 'MEDICAO'])}")
            logger.debug(f"  • Total de itens finais: {len(itens_finais)}")
            logger.debug("=" * 80)
            
        except Exception as e:
            logger.debug(f"DEBUG: ❌ Erro ao agrupar medições: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def gerar_compromissos_recorrentes_config(self):
        """✅ VERSÃO OTIMIZADA - Não gera compromissos que já foram lançados"""
        try:
            from src.configuracoes_sistema import GerenciadorConfiguracoes
            
            compromissos_config = GerenciadorConfiguracoes.get_compromissos_recorrentes()
            
            if not compromissos_config:
                return
            
            hoje = datetime.now().date()
            fim_periodo = hoje + relativedelta(months=1)
            
            # ✅ PRÉ-CALCULAR lançamentos existentes
            lancamentos_existentes = set()
            for item in self.dados_agenda:
                if item['origem'] == 'EXISTENTE':
                    data_rel = item.get('data_rel')
                    fornecedor = self.normalizar_nome_fornecedor(item['fornecedor'])
                    lancamentos_existentes.add(f"{data_rel}_{fornecedor}")
            
            # Pré-carregar cache de especificações
            if not self._cache_especificacoes:
                self._carregar_todas_especificacoes()
            
            novos_compromissos = []
            
            for compromisso in compromissos_config:
                try:
                    nome = compromisso.get('nome', 'SEM NOME')
                    nome_normalizado = self.normalizar_nome_fornecedor(nome)
                    tipo_referencia_mes = compromisso.get('tipo_referencia_mes', 'anterior')
                    
                    datas_relatorio = self.calcular_datas_relatorio_recorrencia(
                        compromisso, hoje, fim_periodo
                    )
                    
                    for data_rel in datas_relatorio:
                        # ✅ VERIFICAÇÃO: Pular se já existe lançamento
                        chave_verificacao = f"{data_rel}_{nome_normalizado}"
                        if chave_verificacao in lancamentos_existentes:
                            logger.debug(f"⏭️  Pulando: {nome} - REL {data_rel} (já lançado)")
                            continue
                        
                        dia_venc_config = compromisso.get('dia_vencimento', 5)
                        usar_dia_util = compromisso.get('considerar_dia_util', False)

                        if usar_dia_util:
                            from src.feriados import calcular_enesimo_dia_util  # ✅ agora é função solta, não self.
                            data_vencimento_sugerida = calcular_enesimo_dia_util(
                                data_rel.year, data_rel.month, n=dia_venc_config
                            )
                        else:
                            try:
                                data_vencimento_sugerida = data_rel.replace(day=dia_venc_config)
                            except ValueError:
                                ultimo_dia = calendar.monthrange(data_rel.year, data_rel.month)[1]
                                data_vencimento_sugerida = data_rel.replace(day=min(dia_venc_config, ultimo_dia))
                        
                        referencia_auto = self.formatar_referencia_auto(
                            compromisso['nome'], 
                            data_rel, 
                            tipo_referencia_mes
                        )
                        
                        item_agenda = {
                            'vencimento': data_vencimento_sugerida,
                            'data_rel': data_rel,
                            'status': 'PENDENTE',
                            'cliente': self.sistema.cliente_atual,
                            'fornecedor': compromisso['nome'],
                            'referencia': referencia_auto,
                            'valor': compromisso.get('valor_estimado', 0.0),
                            'tipo': f"TD{compromisso.get('tipo_despesa', 3)}",
                            'observacao': f"{compromisso.get('observacao', 'Compromisso recorrente')}",
                            'id_origem': f"CONFIG_{nome}_{data_rel.strftime('%Y%m%d')}",
                            'origem': 'CONFIGURACAO',
                            'dados_originais': compromisso,
                            'tipo_referencia_mes': tipo_referencia_mes
                        }
                        
                        novos_compromissos.append(item_agenda)
                        
                except Exception as e:
                    logger.debug(f"Erro ao processar {nome}: {e}")
                    continue
            
            self.dados_agenda.extend(novos_compromissos)
            
            logger.debug(f"✅ {len(novos_compromissos)} compromissos gerados (duplicatas ignoradas)")
            
        except Exception as e:
            logger.debug(f"Erro: {e}")

    def calcular_datas_relatorio_recorrencia(self, compromisso, data_inicio, data_fim):
        """
        ✅ VERSÃO COM DEBUG para ver o que está sendo gerado
        """
        from datetime import datetime
        from dateutil.relativedelta import relativedelta
        import calendar
        
        datas_relatorio = []
        recorrencia = compromisso.get('recorrencia', 'mensal').lower()
        
        print(f"\n   🔍 calcular_datas_relatorio_recorrencia")
        print(f"      Recorrência: {recorrencia}")
        print(f"      Período: {data_inicio} até {data_fim}")
        
        # Mês de referência
        mes_referencia = compromisso.get('mes_referencia', None)
        meses_ocorrencias = compromisso.get('meses_ocorrencias', None)
        
        # Começar do próximo relatório a partir de hoje
        hoje = data_inicio
        
        # Para recorrências não-mensais, começar do mês de referência
        if recorrencia in ['trimestral', 'semestral', 'anual'] and mes_referencia:
            ano_atual = hoje.year
            mes_ref_int = int(mes_referencia) if isinstance(mes_referencia, str) else mes_referencia
            
            if hoje.month > mes_ref_int or (hoje.month == mes_ref_int and hoje.day > 20):
                data_atual = datetime(ano_atual + 1, mes_ref_int, 1).date()
            else:
                data_atual = datetime(ano_atual, mes_ref_int, 1).date()
        else:
            data_atual = hoje.replace(day=1)
        
        print(f"      Data inicial de cálculo: {data_atual}")
        
        # Determinar dias de relatório baseado no dia de vencimento
        dia_vencimento = compromisso.get('dia_vencimento', 5)
        
        if dia_vencimento <= 5:
            dias_relatorio = [5]
        elif dia_vencimento <= 20:
            dias_relatorio = [20]
        else:
            dias_relatorio = [5]  # Default
        
        print(f"      Dias de relatório: {dias_relatorio}")
        
        ocorrencias_processadas = 0
        max_ocorrencias = 24
        
        while data_atual <= data_fim and ocorrencias_processadas < max_ocorrencias:
            # Se há meses específicos de ocorrência
            if meses_ocorrencias:
                for mes_ocorrencia in meses_ocorrencias:
                    try:
                        mes_int = int(mes_ocorrencia)
                        data_ocorrencia = datetime(data_atual.year, mes_int, 1).date()
                        
                        if data_ocorrencia > hoje and data_ocorrencia <= data_fim:
                            for dia_rel in dias_relatorio:
                                try:
                                    data_relatorio = data_ocorrencia.replace(day=dia_rel)
                                    if data_relatorio > hoje and data_relatorio <= data_fim:
                                        if data_relatorio not in datas_relatorio:
                                            datas_relatorio.append(data_relatorio)
                                            print(f"      ✅ Adicionada: {data_relatorio}")
                                except ValueError:
                                    continue
                    except (ValueError, TypeError):
                        continue
            else:
                # Lógica normal
                for dia_rel in dias_relatorio:
                    try:
                        data_relatorio = data_atual.replace(day=dia_rel)
                        
                        # ✅ CORREÇÃO CRÍTICA: Incluir datas >= hoje, não só >
                        if data_relatorio >= hoje and data_relatorio <= data_fim:
                            if data_relatorio not in datas_relatorio:
                                datas_relatorio.append(data_relatorio)
                                print(f"      ✅ Adicionada: {data_relatorio}")
                                
                    except ValueError:
                        continue
            
            # Avançar período
            if recorrencia == 'mensal':
                data_atual = data_atual + relativedelta(months=1)
            elif recorrencia == 'bimestral':
                data_atual = data_atual + relativedelta(months=2)
            elif recorrencia == 'trimestral':
                data_atual = data_atual + relativedelta(months=3)
            elif recorrencia == 'semestral':
                data_atual = data_atual + relativedelta(months=6)
            elif recorrencia == 'anual':
                data_atual = data_atual + relativedelta(years=1)
            else:
                data_atual = data_atual + relativedelta(months=1)
            
            ocorrencias_processadas += 1
        
        result = sorted(list(set(datas_relatorio)))
        print(f"      📊 Total de datas geradas: {len(result)}")
        
        return result
    
    def carregar_lancamentos_condicionados(self):
        """Versão simplificada - apenas identificar condicionados nos existentes"""
        try:
            for item in self.dados_agenda:
                if item['origem'] == 'EXISTENTE':
                    observacao = item['observacao'].upper()
                    
                    # Identificar se é condicionado
                    if any(palavra in observacao for palavra in ['CONDICIONADA', 'ENTREGA', 'APROVAÇÃO']):
                        item['status'] = 'CONDICIONADO'
                        item['observacao'] = f"🔒 {item['observacao']}"
                            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao carregar lançamentos condicionados: {str(e)}")
    
    def aplicar_filtro_periodo(self):
        """Aplica filtro de período e preenche datas personalizadas quando necessário"""
        # Lógica de preenchimento automático para período personalizado
        if self.var_periodo.get() == "personalizado":
            hoje = datetime.now().date()
            data_fim_padrao = hoje + timedelta(days=60)
            
            try:
                # Verificar se os campos estão vazios ou com valores muito antigos
                try:
                    inicio_atual = self.data_inicio_personalizada.get_date()
                    fim_atual = self.data_fim_personalizada.get_date()
                    
                    # Se as datas são muito antigas ou iguais, atualizar
                    if (inicio_atual < hoje - timedelta(days=30) or 
                        inicio_atual == fim_atual):
                        self.data_inicio_personalizada.set_date(hoje)
                        self.data_fim_personalizada.set_date(data_fim_padrao)
                except:
                    # Se der erro ao ler, preencher com valores padrão
                    self.data_inicio_personalizada.set_date(hoje)
                    self.data_fim_personalizada.set_date(data_fim_padrao)
                    
            except Exception as e:
                logger.debug(f"DEBUG: Erro ao preencher datas personalizadas: {e}")
            
            # Mostrar frame de datas personalizadas
            self.frame_datas_personalizado.pack(pady=5)
        else:
            # Ocultar frame de datas personalizadas
            self.frame_datas_personalizado.pack_forget()
        
        # Aplicar o filtro (sua lógica existente aqui)
        self.aplicar_filtros()  # ou qualquer método que já existe

    def calcular_periodo_filtro(self):
        """
        Calcula períodos de filtro baseados nas DATAS DE RELATÓRIO (DATA_REL)
        Próximos relatórios: dias 5 e 20 de cada mês
        
        ✅ CORRIGIDO: Lógica para determinar próximo relatório
        """
        from datetime import datetime, timedelta
        from dateutil.relativedelta import relativedelta
        
        hoje = datetime.now().date()
        periodo = self.var_periodo.get()
        
        print("=" * 80)
        print(f"🔍 DEBUG calcular_periodo_filtro")
        print(f"   Hoje: {hoje} (dia {hoje.day})")
        print(f"   Período selecionado: {periodo}")
        print("=" * 80)
        
        if periodo == "quinzena_atual":
            # ✅ CORREÇÃO CRÍTICA: Determinar qual é o PRÓXIMO relatório
            
            if hoje.day <= 5:
                # Estamos ANTES ou NO dia 5
                # Próximo relatório: dia 5 do mês ATUAL
                proximo_relatorio = hoje.replace(day=5)
                print(f"   → Caso 1: Dia {hoje.day} ≤ 5")
                print(f"   → Próximo relatório: {proximo_relatorio}")
                
            elif hoje.day <= 20:
                # Estamos entre dia 6 e 20
                # Próximo relatório: dia 20 do mês ATUAL
                proximo_relatorio = hoje.replace(day=20)
                print(f"   → Caso 2: 6 ≤ Dia {hoje.day} ≤ 20")
                print(f"   → Próximo relatório: {proximo_relatorio}")
                
            else:
                # Estamos DEPOIS do dia 20
                # Próximo relatório: dia 5 do PRÓXIMO mês
                proximo_mes = hoje + relativedelta(months=1)
                proximo_relatorio = proximo_mes.replace(day=5)
                print(f"   → Caso 3: Dia {hoje.day} > 20")
                print(f"   → Próximo relatório: {proximo_relatorio}")
            
            # ✅ IMPORTANTE: Incluir o relatório de hoje se ainda não passou
            data_inicio = hoje
            data_fim = proximo_relatorio
            
            print(f"   📅 Período Final:")
            print(f"      Início: {data_inicio}")
            print(f"      Fim: {data_fim}")
            print("=" * 80)
        
        elif periodo == "mes_atual":
            # ✅ CORREÇÃO: Próximos 2 relatórios
            
            # Determinar qual é o primeiro relatório a considerar
            if hoje.day <= 5:
                # Incluir relatório de 05 E 20 do mês atual
                primeiro_relatorio = hoje.replace(day=5)
                segundo_relatorio = hoje.replace(day=20)
                
            elif hoje.day <= 20:
                # Incluir relatório de 20 do mês atual E 05 do próximo
                primeiro_relatorio = hoje.replace(day=20)
                proximo_mes = hoje + relativedelta(months=1)
                segundo_relatorio = proximo_mes.replace(day=5)
                
            else:
                # Incluir ambos relatórios do próximo mês (05 e 20)
                proximo_mes = hoje + relativedelta(months=1)
                primeiro_relatorio = proximo_mes.replace(day=5)
                segundo_relatorio = proximo_mes.replace(day=20)
            
            data_inicio = hoje
            data_fim = segundo_relatorio
            
            print(f"   📅 Próximos 2 Relatórios:")
            print(f"      1º Relatório: {primeiro_relatorio}")
            print(f"      2º Relatório: {segundo_relatorio}")
            print(f"      Período: {data_inicio} até {data_fim}")
            print("=" * 80)
            
        else:  # personalizado
            # Padrão: até o segundo relatório futuro (aproximadamente 60 dias)
            data_inicio = hoje
            data_fim = hoje + timedelta(days=60)
            
            # Sobrescrever se datas personalizadas foram definidas
            try:
                data_inicio_personalizada = self.data_inicio_personalizada.get_date()
                data_fim_personalizada = self.data_fim_personalizada.get_date()
                
                if (data_inicio_personalizada != hoje or 
                    data_fim_personalizada != hoje + timedelta(days=60)):
                    data_inicio = data_inicio_personalizada
                    data_fim = data_fim_personalizada
                    
                print(f"   📅 Período Personalizado:")
                print(f"      Início: {data_inicio}")
                print(f"      Fim: {data_fim}")
                print("=" * 80)
            except:
                pass
        
        return data_inicio, data_fim

    def aplicar_filtros(self):
        """Filtros baseados em DATA_REL (data do relatório)"""
        try:
            # Limpar tree
            for item in self.tree_agenda.get_children():
                self.tree_agenda.delete(item)
 
            # Determinar período baseado em DATA_REL
            data_inicio, data_fim = self.calcular_periodo_filtro()
 
            logger.debug(f"DEBUG: Aplicando filtros para DATA_REL entre {data_inicio} e {data_fim}")
 
            items_mostrados = 0
            # ✅ NOVO: ids_visiveis serve para "podar" marcações órfãs (itens
            # que saíram do filtro atual não devem continuar marcados)
            ids_visiveis = set()
 
            for item in self.dados_agenda:
                # MUDANÇA CRÍTICA: Filtrar por DATA_REL ao invés de data de vencimento
                data_comparacao = item.get('data_rel', item['vencimento'])
 
                if not (data_inicio <= data_comparacao <= data_fim):
                    continue
 
                # Filtros por origem
                if item['origem'] == 'EXISTENTE' and not self.var_mostrar_existentes.get():
                    continue
                if item['origem'] in ['CONFIGURACAO', 'BASICO'] and not self.var_mostrar_pendentes_config.get():
                    continue
 
                # Determinar tag para cor
                if item['status'] == 'LANÇADO':
                    tag = 'lancado'
                elif item['status'] == 'VENCIDO':
                    tag = 'vencido'
                elif item['status'] == 'VENCE HOJE':
                    tag = 'hoje'
                elif item['status'] == 'CONDICIONADO':
                    tag = 'condicionado'
                else:
                    tag = 'pendente'
 
                # Adicionar indicador de origem e DATA_REL
                tipo_display = str(item['tipo'])
                if item['origem'] == 'CONFIGURACAO':
                    tipo_display += " (CFG)"
                elif item['origem'] == 'BASICO':
                    tipo_display += " (BAS)"
 
                # ✅ NOVO: Checkbox só é elegível para PENDENTE com valor > 0
                id_origem = item['id_origem']
                elegivel_lote = (item['status'] == 'PENDENTE' and item.get('valor', 0) > 0)
 
                if elegivel_lote:
                    ids_visiveis.add(id_origem)
                    marcador = '☑' if id_origem in self.itens_marcados else '☐'
                else:
                    marcador = ''
                    # Item não elegível não pode permanecer marcado
                    self.itens_marcados.discard(id_origem)
 
                # Inserir no tree
                valores = (
                    marcador,
                    item['vencimento'].strftime('%d/%m/%Y'),
                    item['status'],
                    item['fornecedor'],
                    item['referencia'],
                    f"R$ {item['valor']:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'),
                    tipo_display,
                    item['observacao'],
                    item['id_origem']
                )
 
                self.tree_agenda.insert('', 'end', values=valores, tags=(tag,))
                items_mostrados += 1
 
            # ✅ NOVO: remove marcações de itens que deixaram de estar visíveis
            self.itens_marcados = {i for i in self.itens_marcados if i in ids_visiveis}
 
            logger.debug(f"DEBUG: {items_mostrados} itens mostrados após filtros")
 
            # Atualizar resumo
            self.atualizar_resumo()
 
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao aplicar filtros: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())

    def atualizar_resumo(self):
        """Resumo mais claro e útil - CORRIGIDO"""
        try:
            # Contadores
            total_valor = 0
            pendentes_count = 0
            pendentes_valor = 0
            vencidos_count = 0
            vencidos_valor = 0
            lancados_count = 0
            lancados_valor = 0
 
            for child in self.tree_agenda.get_children():
                valores = self.tree_agenda.item(child, 'values')
                status = valores[2]  # ✅ ÍNDICE AJUSTADO (coluna 'Marcar' na posição 0)
 
                # ✅ ÍNDICE AJUSTADO: Valor agora está no índice 5
                valor_str = valores[5].replace('R$ ', '').replace('.', '').replace(',', '.')
                try:
                    valor = float(valor_str)
                except:
                    valor = 0.0
                    logger.debug(f"⚠️ Erro ao converter valor: '{valores[5]}' do item {valores[3]}")
 
                total_valor += valor
 
                if status == 'PENDENTE':
                    pendentes_count += 1
                    pendentes_valor += valor
                elif status in ['VENCIDO', 'VENCE HOJE']:
                    vencidos_count += 1
                    vencidos_valor += valor
                elif status == 'LANÇADO':
                    lancados_count += 1
                    lancados_valor += valor
 
            # Total de itens (todos os status)
            total_itens = lancados_count + pendentes_count + vencidos_count
 
            # Atualizar labels com formatação brasileira
            self.label_total_periodo.config(
                text=f"Total Período: R$ {total_valor:,.2f} ({total_itens} itens)"
                    .replace(',', 'X').replace('.', ',').replace('X', '.')
            )
 
            self.label_pendentes.config(
                text=f"Pendentes: {pendentes_count} (R$ {pendentes_valor:,.2f})"
                    .replace(',', 'X').replace('.', ',').replace('X', '.')
            )
 
            self.label_vencidos.config(
                text=f"Vencidos: {vencidos_count} (R$ {vencidos_valor:,.2f})"
                    .replace(',', 'X').replace('.', ',').replace('X', '.')
            )
 
            logger.debug("=" * 50)
            logger.debug("📊 RESUMO ATUALIZADO:")
            logger.debug(f"   Total: R$ {total_valor:,.2f} ({total_itens} itens)")
            logger.debug(f"   Lançados: {lancados_count} (R$ {lancados_valor:,.2f})")
            logger.debug(f"   Pendentes: {pendentes_count} (R$ {pendentes_valor:,.2f})")
            logger.debug(f"   Vencidos: {vencidos_count} (R$ {vencidos_valor:,.2f})")
            logger.debug("=" * 50)
 
        except Exception as e:
            logger.error(f"❌ Erro ao atualizar resumo: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def calcular_data_rel(self):
        """
        Calcula a data de referência (relatório) seguindo a regra dos dias 5 e 20.
        Esta é a data que determina EM QUAL RELATÓRIO o lançamento aparecerá.
        
        Regra:
        - Dia 1 a 5: Relatório do dia 5 do mês atual
        - Dia 6 a 20: Relatório do dia 20 do mês atual  
        - Dia 21 a 31: Relatório do dia 5 do próximo mês
        
        A data de vencimento (DT_VENCTO) pode ser diferente e editável.
        """
        hoje = datetime.now().date()  # ✅ CORREÇÃO: usar .date() logo no início
        if 6 <= hoje.day <= 20:
            data_rel = hoje.replace(day=20)
        else:
            if hoje.day > 20:
                # Próximo mês, dia 5
                proximo_mes = hoje + relativedelta(months=1)
                data_rel = proximo_mes.replace(day=5)
            else:
                data_rel = hoje.replace(day=5)
        return data_rel

    def novo_lancamento(self):
        """Abre interface para novo lançamento diretamente da agenda"""
        try:
            # Abrir janela de novo lançamento direto
            self.abrir_janela_novo_lancamento()
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir novo lançamento: {str(e)}")
            logger.debug(f"DEBUG: Erro ao abrir novo lançamento: {str(e)}")

    def abrir_janela_novo_lancamento(self):
        """Cria janela para novo lançamento diretamente da agenda"""
        try:
            # Janela de novo lançamento
            janela_novo = tk.Toplevel(self.janela)
            janela_novo.title("Novo Lançamento")
            janela_novo.geometry("700x600")
            janela_novo.transient(self.janela)
            janela_novo.grab_set()
            
            # Frame principal
            main_frame = ttk.Frame(janela_novo, padding="15")
            main_frame.pack(fill='both', expand=True)
            
            # Título
            ttk.Label(main_frame, text=f"Novo Lançamento - {self.sistema.cliente_atual}", 
                    font=('TkDefaultFont', 12, 'bold')).pack(pady=(0, 15))
            
            # === SEÇÃO: DATA ===
            frame_data = ttk.LabelFrame(main_frame, text="Data de Referência")
            frame_data.pack(fill='x', pady=(0, 10))
            
            ttk.Label(frame_data, text="Data do Relatório:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
            data_rel = DateEntry(frame_data, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
            data_rel.set_date(self.calcular_data_rel())  # PRÉ-PREENCHER
            data_rel.grid(row=0, column=1, padx=5, pady=5, sticky='w')
            
            # === SEÇÃO: FORNECEDOR ===
            frame_fornecedor = ttk.LabelFrame(main_frame, text="Dados do Fornecedor")
            frame_fornecedor.pack(fill='x', pady=(0, 10))
            
            # CNPJ/CPF com busca automática
            ttk.Label(frame_fornecedor, text="CNPJ/CPF:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
            cnpj_cpf = ttk.Entry(frame_fornecedor, width=20)
            cnpj_cpf.grid(row=0, column=1, padx=5, pady=5, sticky='w')
            
            # Nome com busca por parte do nome
            ttk.Label(frame_fornecedor, text="Nome:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
            nome = ttk.Entry(frame_fornecedor, width=40)
            nome.grid(row=1, column=1, columnspan=2, padx=5, pady=5, sticky='ew')
            
            # Lista de sugestões para o nome
            lista_sugestoes = tk.Listbox(frame_fornecedor, height=4)
            lista_sugestoes.grid(row=2, column=1, columnspan=2, padx=5, pady=5, sticky='ew')
            lista_sugestoes.grid_remove()  # Inicialmente oculta
            
            def buscar_fornecedor_por_cnpj(event=None):
                """Busca fornecedor pelo CNPJ/CPF"""
                cnpj_digitado = cnpj_cpf.get().strip()
                if len(cnpj_digitado) >= 11:  # CNPJ/CPF completo
                    try:
                        fornecedor_dados = self.sistema.buscar_fornecedor_por_cnpj_agenda(cnpj_digitado)
                        if fornecedor_dados:
                            preencher_dados_fornecedor(fornecedor_dados)
                            logger.debug(f"DEBUG: Fornecedor encontrado por CNPJ: {fornecedor_dados.get('nome', '')}")
                    except Exception as e:
                        logger.debug(f"DEBUG: Erro ao buscar fornecedor por CNPJ: {str(e)}")
            
            def buscar_fornecedor_por_nome(event=None):
                """Busca fornecedor por parte do nome"""
                nome_digitado = nome.get().strip()
                
                if len(nome_digitado) < 3:  # Só buscar com 3+ caracteres
                    lista_sugestoes.grid_remove()
                    return
                    
                try:
                    fornecedores_encontrados = self.sistema.buscar_fornecedores_por_nome_parcial(nome_digitado)
                    
                    if fornecedores_encontrados:
                        # Mostrar lista de sugestões
                        lista_sugestoes.delete(0, tk.END)
                        for fornecedor in fornecedores_encontrados[:10]:  # Máximo 10 sugestões
                            texto = f"{fornecedor['nome']} - {fornecedor['cnpj_cpf']}"
                            lista_sugestoes.insert(tk.END, texto)
                        
                        lista_sugestoes.grid()
                        logger.debug(f"DEBUG: {len(fornecedores_encontrados)} fornecedores encontrados para '{nome_digitado}'")
                    else:
                        lista_sugestoes.grid_remove()
                        logger.debug(f"DEBUG: Nenhum fornecedor encontrado para '{nome_digitado}'")
                        
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao buscar fornecedor por nome: {str(e)}")
                    lista_sugestoes.grid_remove()
            
            def selecionar_fornecedor_da_lista(event=None):
                """Seleciona fornecedor da lista de sugestões - CORRIGIDO"""
                try:
                    selection = lista_sugestoes.curselection()
                    if selection:
                        texto_selecionado = lista_sugestoes.get(selection[0])
                        logger.debug(f"DEBUG: Texto selecionado: {texto_selecionado}")
                        
                        # Extrair CNPJ do texto: "NOME - CNPJ"
                        cnpj_extraido = texto_selecionado.split(' - ')[-1]
                        logger.debug(f"DEBUG: CNPJ extraído: {cnpj_extraido}")
                        
                        # Buscar dados completos do fornecedor
                        fornecedor_dados = self.sistema.buscar_fornecedor_por_cnpj_agenda(cnpj_extraido)
                        if fornecedor_dados:
                            preencher_dados_fornecedor(fornecedor_dados)
                            lista_sugestoes.grid_remove()
                            logger.debug(f"DEBUG: Fornecedor selecionado: {fornecedor_dados.get('nome', '')}")
                        else:
                            logger.debug(f"DEBUG: Dados do fornecedor não encontrados para CNPJ: {cnpj_extraido}")
                    else:
                        logger.debug("DEBUG: Nenhuma seleção na lista")
                            
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao selecionar fornecedor: {str(e)}")
                    import traceback
                    logger.debug(traceback.format_exc())
            
            def selecionar_por_clique(event=None):
                """Seleciona fornecedor por clique simples"""
                try:
                    # Pequeno delay para garantir que a seleção foi processada
                    janela_novo.after(50, selecionar_fornecedor_da_lista)
                except Exception as e:
                    logger.debug(f"DEBUG: Erro no clique: {str(e)}")
            
            def preencher_dados_fornecedor(fornecedor_dados):
                """Preenche todos os campos com dados do fornecedor"""
                try:
                    logger.debug(f"DEBUG: Preenchendo dados do fornecedor: {fornecedor_dados.get('nome', '')}")
                    
                    # Preencher CNPJ/CPF
                    cnpj_cpf.delete(0, tk.END)
                    cnpj_cpf.insert(0, fornecedor_dados.get('cnpj_cpf', ''))
                    
                    # Preencher nome
                    nome.delete(0, tk.END)
                    nome.insert(0, fornecedor_dados.get('nome', ''))
                    
                    # Preencher categoria
                    categoria.delete(0, tk.END)
                    categoria.insert(0, fornecedor_dados.get('categoria', 'FORNECEDOR'))
                    
                    # CORREÇÃO: Preencher dados bancários usando o método do sistema com forma de pagamento
                    dados_bancarios_texto = self.sistema.obter_dados_bancarios_fornecedor(
                        fornecedor_dados.get('cnpj_cpf', ''),
                        forma_pagamento_preferida='PIX'
                    )
                    dados_bancarios_entry.config(state='normal')
                    dados_bancarios_entry.delete(0, tk.END)
                    dados_bancarios_entry.insert(0, dados_bancarios_texto)
                    dados_bancarios_entry.config(state='readonly')
                    
                    logger.debug(f"DEBUG: Dados bancários preenchidos: {dados_bancarios_texto}")
                    
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao preencher dados: {str(e)}")
                    import traceback
                    logger.debug(traceback.format_exc())
            
            def navegar_lista_com_teclado(event):
                """Navega na lista com teclado e seleciona com Enter"""
                try:
                    if event.keysym == 'Down':
                        current = lista_sugestoes.curselection()
                        if current:
                            next_index = min(current[0] + 1, lista_sugestoes.size() - 1)
                        else:
                            next_index = 0
                        lista_sugestoes.selection_clear(0, tk.END)
                        lista_sugestoes.selection_set(next_index)
                        lista_sugestoes.see(next_index)
                        return "break"
                        
                    elif event.keysym == 'Up':
                        current = lista_sugestoes.curselection()
                        if current:
                            next_index = max(current[0] - 1, 0)
                        else:
                            next_index = 0
                        lista_sugestoes.selection_clear(0, tk.END)
                        lista_sugestoes.selection_set(next_index)
                        lista_sugestoes.see(next_index)
                        return "break"
                        
                    elif event.keysym == 'Return':
                        selecionar_fornecedor_da_lista()
                        return "break"
                        
                except Exception as e:
                    logger.debug(f"DEBUG: Erro na navegação: {str(e)}")
            
            def ocultar_sugestoes_ao_sair_foco(event=None):
                """Oculta sugestões quando sai do foco - MELHORADO"""
                # Verificar se o foco foi para a lista de sugestões
                try:
                    widget_foco = janela_novo.focus_get()
                    if widget_foco == lista_sugestoes:
                        return  # Não ocultar se o foco foi para a lista
                    
                    # Delay maior para permitir clique
                    janela_novo.after(300, lambda: lista_sugestoes.grid_remove())
                except:
                    janela_novo.after(300, lambda: lista_sugestoes.grid_remove())
            
            # Bindings para busca
            cnpj_cpf.bind('<KeyRelease>', buscar_fornecedor_por_cnpj)
            cnpj_cpf.bind('<FocusOut>', buscar_fornecedor_por_cnpj)
            
            nome.bind('<KeyRelease>', buscar_fornecedor_por_nome)
            nome.bind('<FocusOut>', ocultar_sugestoes_ao_sair_foco)
            
            # Navegação por teclado no campo nome quando há sugestões
            nome.bind('<Down>', lambda e: lista_sugestoes.focus() if lista_sugestoes.winfo_viewable() else None)
            
            # Bindings da lista - CORRIGIDOS
            lista_sugestoes.bind('<Button-1>', selecionar_por_clique)  # Clique simples
            lista_sugestoes.bind('<Double-Button-1>', selecionar_fornecedor_da_lista)  # Duplo clique
            lista_sugestoes.bind('<KeyPress>', navegar_lista_com_teclado)  # Navegação por teclado
            
            # Permitir que a lista receba foco
            lista_sugestoes.bind('<FocusIn>', lambda e: logger.debug("DEBUG: Lista recebeu foco"))
            lista_sugestoes.bind('<FocusOut>', ocultar_sugestoes_ao_sair_foco)
            
            # Atualizar dados bancários quando CNPJ for alterado E quando forma de pagamento mudar
            # cnpj_cpf.bind('<FocusOut>', lambda e: janela_confirm.after(200, atualizar_dados_bancarios))

            # Categoria
            ttk.Label(frame_fornecedor, text="Categoria:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
            categoria = ttk.Entry(frame_fornecedor, width=20)
            categoria.grid(row=2, column=1, padx=5, pady=5, sticky='w')
            
            # Dados bancários
            ttk.Label(frame_fornecedor, text="Dados Bancários:").grid(row=3, column=0, padx=5, pady=5, sticky='w')
            dados_bancarios_entry = ttk.Entry(frame_fornecedor, width=40, state='readonly')
            dados_bancarios_entry.grid(row=3, column=1, columnspan=2, padx=5, pady=5, sticky='ew')
            
            frame_fornecedor.columnconfigure(1, weight=1)
            
            # === SEÇÃO: DESPESA ===
            frame_despesa = ttk.LabelFrame(main_frame, text="Dados da Despesa")
            frame_despesa.pack(fill='x', pady=(0, 10))
            
            # Tipo de despesa
            ttk.Label(frame_despesa, text="Tipo Despesa:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
            tp_desp = ttk.Combobox(frame_despesa, values=['1', '2', '3', '4', '5', '6'], state='readonly', width=5)
            tp_desp.set('3')  # Padrão
            tp_desp.grid(row=0, column=1, padx=5, pady=5, sticky='w')
            
            # Referência
            ttk.Label(frame_despesa, text="Referência:").grid(row=0, column=2, padx=5, pady=5, sticky='w')
            referencia = ttk.Entry(frame_despesa, width=30)
            referencia.grid(row=0, column=3, padx=5, pady=5, sticky='ew')
            
            # Valor unitário
            ttk.Label(frame_despesa, text="Valor Unitário:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
            vr_unit = ttk.Entry(frame_despesa, width=15)
            vr_unit.grid(row=1, column=1, padx=5, pady=5, sticky='w')
            
            # Dias
            ttk.Label(frame_despesa, text="Dias:").grid(row=1, column=2, padx=5, pady=5, sticky='w')
            dias = ttk.Entry(frame_despesa, width=8)
            dias.insert(0, "1")
            dias.grid(row=1, column=3, padx=5, pady=5, sticky='w')
            
            # Valor total (calculado automaticamente)
            ttk.Label(frame_despesa, text="Valor Total:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
            valor_total = ttk.Entry(frame_despesa, width=15, state='readonly')
            valor_total.grid(row=2, column=1, padx=5, pady=5, sticky='w')
            
            def calcular_valor_total_automatico(event=None):
                try:
                    vr_unit_val = _numero_br(vr_unit.get()) if vr_unit.get() else 0
                    dias_val = _numero_br(dias.get()) if dias.get() else 1
                    total = vr_unit_val * dias_val
                    
                    valor_total.config(state='normal')
                    valor_total.delete(0, tk.END)
                    valor_total.insert(0, f"{total:.2f}".replace('.', ','))
                    valor_total.config(state='readonly')
                except ValueError:
                    pass
            
            vr_unit.bind('<KeyRelease>', calcular_valor_total_automatico)
            dias.bind('<KeyRelease>', calcular_valor_total_automatico)
            
            # Data de vencimento
            ttk.Label(frame_despesa, text="Data Vencimento:").grid(row=2, column=2, padx=5, pady=5, sticky='w')
            dt_vencto = DateEntry(frame_despesa, width=12, date_pattern='dd/mm/yyyy', locale='pt_BR')
            dt_vencto.grid(row=2, column=3, padx=5, pady=5, sticky='w')
            
            # NF
            ttk.Label(frame_despesa, text="NF:").grid(row=3, column=0, padx=5, pady=5, sticky='w')
            nf = ttk.Entry(frame_despesa, width=15)
            nf.grid(row=3, column=1, padx=5, pady=5, sticky='w')
            
            # Observação
            ttk.Label(frame_despesa, text="Observação:").grid(row=3, column=2, padx=5, pady=5, sticky='w')
            observacao = ttk.Entry(frame_despesa, width=30)
            observacao.grid(row=3, column=3, padx=5, pady=5, sticky='ew')
            
            frame_despesa.columnconfigure(3, weight=1)
            
            # === BOTÕES ===
            frame_botoes = ttk.Frame(main_frame)
            frame_botoes.pack(fill='x', pady=(15, 0))
            
            def salvar_lancamento():
                try:
                    # Validações básicas
                    if not cnpj_cpf.get().strip():
                        custom_messagebox("error", "Erro", "CNPJ/CPF é obrigatório!")
                        cnpj_cpf.focus()
                        return
                    
                    if not nome.get().strip():
                        custom_messagebox("error", "Erro", "Nome é obrigatório!")
                        nome.focus()
                        return
                    
                    if not vr_unit.get().strip():
                        custom_messagebox("error", "Erro", "Valor unitário é obrigatório!")
                        vr_unit.focus()
                        return
                    
                    # Preparar dados do lançamento
                    dados_lancamento = {
                        'data_rel': data_rel.get_date(),
                        'tp_desp': tp_desp.get(),
                        'cnpj_cpf': cnpj_cpf.get().strip(),
                        'nome': nome.get().strip().upper(),
                        'categoria': categoria.get().strip().upper() or 'FORNECEDOR',
                        'referencia': referencia.get().strip().upper(),
                        'nf': nf.get().strip().upper(),
                        'valor': _numero_br(valor_total.get()),
                        'vr_unit': _numero_br(vr_unit.get()),
                        'dias': _numero_br(dias.get()) if dias.get() else 1,
                        'dt_vencto': dt_vencto.get_date(),
                        'observacao': observacao.get().strip().upper(),
                        'etapa_obra': '',  # Valores padrão para campos não presentes
                        'insumo': '',
                        'dados_bancarios': dados_bancarios_entry.get(),
                        'forma_pagamento': 'PIX'  # Padrão
                    }
                    
                    # Inserir lançamento - mesmo método usado pela confirmação
                    # em lote (salvar_confirmacao_direta). O método antigo
                    # chamado aqui (inserir_lancamento_completo) nunca existiu.
                    resultado = self.sistema.salvar_confirmacao_direta(dados_lancamento)

                    if resultado and resultado.get('sucesso'):
                        custom_messagebox("info", "Sucesso", "Lançamento criado com sucesso!")
                        janela_novo.destroy()
                        self.carregar_dados_agenda()  # Recarregar agenda
                    # Se não gravou, salvar_confirmacao_direta já mostrou o motivo
                    # (ou o usuário desistiu ao ver a duplicata): a janela fica
                    # aberta para correção, sem uma segunda mensagem de erro.
                        
                except Exception as e:
                    custom_messagebox("error", "Erro", f"Erro ao salvar lançamento: {str(e)}")
                    logger.debug(f"DEBUG: Erro ao salvar lançamento direto: {str(e)}")
            
            ttk.Button(frame_botoes, text="Salvar Lançamento", 
                    command=salvar_lancamento).pack(side='left', padx=5)
            ttk.Button(frame_botoes, text="Cancelar", 
                    command=janela_novo.destroy).pack(side='left', padx=5)
            
            # Focar no primeiro campo
            cnpj_cpf.focus()
            
            logger.debug("DEBUG: Janela de novo lançamento aberta")
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao criar janela de lançamento: {str(e)}")
            logger.debug(f"DEBUG: Erro ao criar janela de lançamento: {str(e)}")
        
    def editar_selecionado(self):
        """Edita apenas a data de vencimento do item selecionado"""
        try:
            selected = self.tree_agenda.selection()
            if not selected:
                custom_messagebox("warning", "Aviso", "Selecione um item para editar")
                return
 
            valores = self.tree_agenda.item(selected[0], 'values')
 
            if len(valores) < 9:  # ✅ AJUSTADO: 9 colunas agora (com 'Marcar')
                custom_messagebox("error", "Erro", "Dados incompletos no item selecionado")
                return
 
            id_origem = valores[8]         # ✅ ÍNDICE AJUSTADO: ID_Origem
            status = valores[2]            # ✅ ÍNDICE AJUSTADO: Status
            fornecedor = valores[3]        # ✅ ÍNDICE AJUSTADO: Fornecedor
            vencimento_atual = valores[1]  # ✅ ÍNDICE AJUSTADO: Data de vencimento atual
 
            # Verificar se é um lançamento existente (ID numérico)
            if not id_origem or id_origem.strip() == "" or id_origem.startswith(('CONFIG_', 'BASICO_', 'REC_', 'TPL_', 'HIST_')):
                custom_messagebox("info", "Edição",
                    "Este é um compromisso configurado.\n"
                    "Use 'Confirmar Lançamento' para criar o lançamento real primeiro.")
                return
 
            try:
                # Verificar se é um ID numérico (lançamento real)
                id_numerico = int(float(id_origem))
            except (ValueError, TypeError):
                custom_messagebox("info", "Edição",
                    "Este item não pode ser editado.\n"
                    "Use 'Confirmar Lançamento' para criar o lançamento real.")
                return
 
            # Abrir dialog de edição da data de vencimento
            self.abrir_editor_vencimento(id_numerico, fornecedor, vencimento_atual, selected[0])
 
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao editar selecionado: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            custom_messagebox("error", "Erro", f"Erro ao editar item: {str(e)}")

    def abrir_editor_vencimento(self, id_lancamento, fornecedor, vencimento_atual, tree_item):
        """Versão simplificada e robusta do editor de vencimento"""
        try:
            logger.debug(f"DEBUG: Abrindo editor para ID {id_lancamento}")
            
            # Criar janela simples
            dialog = tk.Toplevel(self.janela)
            dialog.title("Editar Data de Vencimento")
            dialog.geometry("350x320")
            dialog.transient(self.janela)
            dialog.grab_set()
            
            # Frame principal
            frame = tk.Frame(dialog, padx=20, pady=20)
            frame.pack(fill='both', expand=True)
            
            # Informações
            tk.Label(frame, text=f"ID: {id_lancamento}", font=('Arial', 11, 'bold')).pack(anchor='w', pady=2)
            tk.Label(frame, text=f"Fornecedor: {fornecedor}").pack(anchor='w', pady=2)
            
            # Separador
            tk.Label(frame, text="").pack(pady=5)
            
            # Data atual
            tk.Label(frame, text=f"Data atual: {vencimento_atual}", font=('Arial', 10, 'bold')).pack(anchor='w')
            
            # Espaço
            tk.Label(frame, text="").pack(pady=5)
            
            # Nova data
            tk.Label(frame, text="Nova data (dd/mm/yyyy):").pack(anchor='w')
            entry_data = tk.Entry(frame, font=('Arial', 12), width=12)
            entry_data.pack(anchor='w', pady=5)
            entry_data.insert(0, vencimento_atual)
            
            # Instrução
            tk.Label(frame, text="Exemplo: 25/12/2025", font=('Arial', 9), fg='gray').pack(anchor='w')
            
            # Espaço
            tk.Label(frame, text="").pack(pady=10)
            
            # Botões
            frame_botoes = tk.Frame(frame)
            frame_botoes.pack(fill='x')
            
            def salvar_simples():
                try:
                    nova_data_str = entry_data.get().strip()
                    logger.debug(f"DEBUG: Data digitada: {nova_data_str}")
                    
                    # Validar data
                    try:
                        from datetime import datetime
                        nova_data_obj = datetime.strptime(nova_data_str, '%d/%m/%Y').date()
                        nova_data_formatada = nova_data_obj.strftime('%d/%m/%Y')
                        logger.debug(f"DEBUG: Data validada: {nova_data_formatada}")
                    except ValueError:
                        import tkinter.messagebox as msg
                        msg.showerror("Erro", "Data inválida! Use o formato dd/mm/yyyy")
                        return
                    
                    # Verificar se mudou
                    if nova_data_formatada == vencimento_atual:
                        import tkinter.messagebox as msg
                        msg.showinfo("Informação", "A data não foi alterada.")
                        return
                    
                    # Confirmar
                    import tkinter.messagebox as msg
                    resposta = msg.askyesno("Confirmar", 
                        f"Alterar data de vencimento:\n\n"
                        f"DE: {vencimento_atual}\n"
                        f"PARA: {nova_data_formatada}\n\n"
                        f"Confirma?")
                    
                    logger.debug(f"DEBUG: Resposta: {resposta}")
                    
                    if resposta:
                        # Salvar
                        if self.salvar_nova_data_vencimento(id_lancamento, nova_data_obj):
                            # CORREÇÃO: Atualizar tree ANTES de recarregar
                            valores = list(self.tree_agenda.item(tree_item, 'values'))
                            valores[1] = nova_data_formatada  # ✅ ÍNDICE AJUSTADO (coluna 'Marcar' na posição 0)
                            self.tree_agenda.item(tree_item, values=valores)
                            
                            msg.showinfo("Sucesso", f"Data alterada para {nova_data_formatada}")
                            dialog.destroy()
                            
                            # CORREÇÃO: Recarregar dados da agenda para sincronizar
                            self.carregar_dados_agenda()  # Em vez de aplicar_filtros()
                        else:
                            msg.showerror("Erro", "Falha ao salvar na planilha")
                            
                except Exception as e:
                    logger.debug(f"DEBUG: Erro ao salvar: {e}")
                    import tkinter.messagebox as msg
                    msg.showerror("Erro", f"Erro: {str(e)}")
            
            def cancelar_simples():
                dialog.destroy()
            
            # Botões
            tk.Button(frame_botoes, text="Cancelar", command=cancelar_simples).pack(side='left', padx=5)
            tk.Button(frame_botoes, text="Salvar", command=salvar_simples).pack(side='left', padx=5)
            
            # Focar no campo
            entry_data.focus()
            entry_data.select_range(0, tk.END)
            
            # Bindings
            entry_data.bind('<Return>', lambda e: salvar_simples())
            dialog.bind('<Escape>', lambda e: cancelar_simples())
            
            logger.debug("DEBUG: Editor simples criado")
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao criar editor: {e}")
            import traceback
            logger.debug(traceback.format_exc())

    def salvar_nova_data_vencimento(self, id_lancamento, nova_data):
        """Salva a nova data de vencimento usando o fluxo correto do sistema"""
        logger.debug(f"DEBUG: ==> MÉTODO SALVAR_NOVA_DATA_VENCIMENTO CHAMADO <==")
        logger.debug(f"DEBUG: ID: {id_lancamento}, Nova Data: {nova_data}")
        
        try:
            if not self.sistema.cliente_atual:
                logger.debug("DEBUG: ERRO - Nenhum cliente selecionado")
                return False
            
            # Importações necessárias
            import os
            from pathlib import Path
            from openpyxl import load_workbook
            from datetime import datetime
            
            # Caminho da planilha
            caminho_planilha = Path(PASTA_CLIENTES) / f"{self.sistema.cliente_atual}.xlsx"
            logger.debug(f"DEBUG: Caminho da planilha: {caminho_planilha}")
            
            if not caminho_planilha.exists():
                logger.debug(f"DEBUG: ERRO - Planilha não encontrada: {caminho_planilha}")
                return False
            
            logger.debug("DEBUG: Planilha encontrada, abrindo...")
            
            # Abrir workbook
            wb = load_workbook(caminho_planilha)
            logger.debug(f"DEBUG: Workbook aberto. Abas disponíveis: {wb.sheetnames}")
            
            if 'Dados' not in wb.sheetnames:
                logger.debug("DEBUG: ERRO - Aba 'Dados' não encontrada")
                wb.close()
                return False
            
            ws = wb['Dados']
            logger.debug(f"DEBUG: Aba 'Dados' selecionada. Max row: {ws.max_row}")
            
            # Procurar o ID na coluna O (posição 15)
            linha_encontrada = None
            logger.debug(f"DEBUG: Procurando ID {id_lancamento} na coluna O...")
            
            for row in range(2, ws.max_row + 1):  # Começar da linha 2
                valor_id = ws[f'O{row}'].value  # Coluna O = ID_LANCAMENTO
                
                if valor_id is not None:
                    try:
                        id_convertido = int(valor_id)
                        id_procurado = int(id_lancamento)
                        
                        if id_convertido == id_procurado:
                            linha_encontrada = row
                            logger.debug(f"DEBUG: *** ID {id_lancamento} ENCONTRADO na linha {row} ***")
                            break
                            
                    except (ValueError, TypeError) as e:
                        continue
            
            if not linha_encontrada:
                logger.debug(f"DEBUG: ERRO - ID {id_lancamento} NÃO ENCONTRADO")
                wb.close()
                return False
            
            # Mostrar valor atual da coluna J antes da alteração
            valor_atual = ws[f'J{linha_encontrada}'].value
            logger.debug(f"DEBUG: Valor atual da célula J{linha_encontrada}: {valor_atual}")
            
            # CORREÇÃO: Salvar como objeto datetime, não como string
            if isinstance(nova_data, str):
                nova_data_obj = datetime.strptime(nova_data, '%d/%m/%Y')
            else:
                nova_data_obj = datetime.combine(nova_data, datetime.min.time())
            
            logger.debug(f"DEBUG: Atualizando J{linha_encontrada} com objeto datetime: {nova_data_obj}")
            
            # Salvar como datetime e aplicar formato
            celula = ws[f'J{linha_encontrada}']
            celula.value = nova_data_obj
            celula.number_format = 'DD/MM/YYYY'  # Aplicar formato de data
            
            # Verificar se a atualização funcionou
            valor_depois = ws[f'J{linha_encontrada}'].value
            logger.debug(f"DEBUG: Valor após atualização: {valor_depois}")
            
            # Salvar o arquivo
            logger.debug("DEBUG: Salvando workbook...")
            salvar_planilha_segura(wb, caminho_planilha)
            wb.close()
            
            logger.debug("DEBUG: *** SUCESSO - Data de vencimento alterada com sucesso ***")
            return True
            
        except Exception as e:
            logger.debug(f"DEBUG: *** ERRO CRÍTICO ao salvar nova data: {str(e)} ***")
            import traceback
            logger.debug(traceback.format_exc())
            return False

    def confirmar_lancamento(self):
        """Confirma um lançamento pendente, convertendo-o em lançamento real"""
        selected = self.tree_agenda.selection()
        if not selected:
            custom_messagebox("warning", "Aviso", "Selecione um item para confirmar")
            return
 
        valores = self.tree_agenda.item(selected[0], 'values')
        status = valores[2]  # ✅ ÍNDICE AJUSTADO (coluna 'Marcar' na posição 0)
 
        if status != 'PENDENTE':
            custom_messagebox("info", "Informação", "Apenas itens pendentes podem ser confirmados")
            return
 
        # Abrir interface de confirmação/criação de lançamento
        self.abrir_confirmacao_lancamento(valores)
    
    def on_tree_click(self, event):
        """✅ NOVO: Detecta clique na coluna de checkbox ('Marcar') e alterna a marcação"""
        try:
            region = self.tree_agenda.identify('region', event.x, event.y)
            if region != 'cell':
                return
 
            coluna = self.tree_agenda.identify_column(event.x)  # ex: '#1'
            if coluna != '#1':  # '#1' é a primeira coluna de dados = 'Marcar'
                return
 
            item_id = self.tree_agenda.identify_row(event.y)
            if not item_id:
                return
 
            self.toggle_checkbox(item_id)
 
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao processar clique na tree: {str(e)}")
 
    def toggle_checkbox(self, item_id):
        """✅ NOVO: Alterna a marcação de um item elegível para confirmação em lote"""
        try:
            valores = list(self.tree_agenda.item(item_id, 'values'))
            status = valores[2]
            id_origem = valores[8]
 
            # Só permite marcar itens PENDENTES com valor > 0 (linhas onde
            # o checkbox foi de fato desenhado em aplicar_filtros)
            if status != 'PENDENTE' or valores[0] == '':
                return
 
            if id_origem in self.itens_marcados:
                self.itens_marcados.discard(id_origem)
                valores[0] = '☐'
            else:
                self.itens_marcados.add(id_origem)
                valores[0] = '☑'
 
            self.tree_agenda.item(item_id, values=valores)
 
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao alternar checkbox: {str(e)}")
 
    def marcar_todos_completos(self):
        """✅ NOVO: Marca todos os itens visíveis, PENDENTES e com valor > 0"""
        try:
            marcados_agora = 0
            for item_id in self.tree_agenda.get_children():
                valores = list(self.tree_agenda.item(item_id, 'values'))
                status = valores[2]
                id_origem = valores[8]
 
                if status == 'PENDENTE' and valores[0] != '':
                    self.itens_marcados.add(id_origem)
                    valores[0] = '☑'
                    self.tree_agenda.item(item_id, values=valores)
                    marcados_agora += 1
 
            if marcados_agora == 0:
                custom_messagebox("info", "Marcar Completos",
                    "Nenhum item pendente com valor registrado foi encontrado no período atual.")
            else:
                logger.debug(f"DEBUG: {marcados_agora} itens marcados para confirmação em lote")
 
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao marcar itens: {str(e)}")
 
    def desmarcar_todos_marcados(self):
        """✅ NOVO: Remove todas as marcações atuais"""
        self.itens_marcados.clear()
        for item_id in self.tree_agenda.get_children():
            valores = list(self.tree_agenda.item(item_id, 'values'))
            if valores[0] != '':
                valores[0] = '☐'
                self.tree_agenda.item(item_id, values=valores)
 
    def _obter_cnpj_medicao(self, item):
        """
        ✅ NOVO: Retorna o CNPJ/CPF do fornecedor de um item de medição,
        tratando corretamente tanto medições individuais quanto agrupadas.
 
        - MEDICAO (individual): CNPJ fica em item['dados_medicao']['cnpj']
          (ver carregar_medicoes_pendentes).
        - MEDICAO_AGRUPADA: CNPJ fica em item['cnpj_fornecedor']
          (ver agrupar_medicoes_por_fornecedor) — este item NÃO tem a
          chave 'dados_medicao'.
        """
        if not item:
            return ''
 
        if item.get('origem') == 'MEDICAO_AGRUPADA':
            return str(item.get('cnpj_fornecedor', '') or '').strip()
 
        return str(item.get('dados_medicao', {}).get('cnpj', '') or '').strip()

    def _obter_cnpj_do_item(self, item):
        """✅ Localiza o CNPJ/CPF do fornecedor de um item da agenda"""
        try:
            if item['origem'] in ['MEDICAO', 'MEDICAO_AGRUPADA']:
                # ✅ CORRIGIDO: usa o método que sabe checar a chave certa
                # (dados_medicao.cnpj para individual, cnpj_fornecedor para agrupada)
                cnpj = self._obter_cnpj_medicao(item)
                return cnpj or None
 
            fornecedor_dados = self.sistema.buscar_fornecedor_por_nome_agenda(item['fornecedor'])
            if fornecedor_dados:
                return fornecedor_dados.get('cnpj_cpf', '') or None
            return None
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao obter CNPJ do item: {str(e)}")
            return None
 
    def _validar_item_para_confirmacao_massa(self, item):
        """
        ✅ NOVO: Verifica se um item tem dados suficientes para ser confirmado
        automaticamente, sem abrir a tela de edição manual.
        Retorna None se estiver completo, ou uma string com o motivo da rejeição.
        """
        if item.get('status') != 'PENDENTE':
            return "Status não é PENDENTE"
 
        if not item.get('valor') or item.get('valor') <= 0:
            return "Valor zerado ou ausente"
 
        if not str(item.get('fornecedor', '')).strip():
            return "Fornecedor não identificado"
 
        if not str(item.get('referencia', '')).strip():
            return "Referência não preenchida"
 
        cnpj = self._obter_cnpj_do_item(item)
        if not cnpj:
            return "CNPJ/CPF do fornecedor não localizado no cadastro"
 
        return None
 
    def _montar_dados_lancamento_a_partir_do_item(self, item):
        """
        ✅ NOVO: Monta o dicionário de dados de lançamento a partir de um item
        da agenda já validado, sem intervenção manual do usuário.
 
        ⚠️ IMPORTANTE — DECISÃO QUE PRECISA DA SUA CONFIRMAÇÃO:
        'etapa_obra' é enviado em branco, pois este fluxo em lote não passa
        por nenhuma tela onde o usuário escolha a etapa da obra (diferente
        de abrir_confirmacao_lancamento, que tem o combobox etapa_obra_combo).
        Se a classificação por etapa de obra for obrigatória no seu fluxo
        contábil/financeiro, ajuste este método para:
          a) buscar a etapa em item['dados_originais'] quando origem for
             'CONFIGURACAO' (se você cadastrar uma etapa padrão por
             compromisso recorrente), ou
          b) pedir uma etapa padrão ao usuário uma única vez, antes de
             confirmar_selecionados_em_massa() processar o lote inteiro.
        Sem esse ajuste, os lançamentos em lote sairão sem etapa de obra.
        """
        cnpj = self._obter_cnpj_do_item(item)
        nome_fornecedor = item['fornecedor']
        categoria = 'FORNECEDOR'
 
        if item['origem'] in ['MEDICAO', 'MEDICAO_AGRUPADA']:
            fornecedor_dados = self.sistema.buscar_fornecedor_por_cnpj_agenda(cnpj) if cnpj else None
        else:
            fornecedor_dados = self.sistema.buscar_fornecedor_por_nome_agenda(item['fornecedor'])
 
        if fornecedor_dados:
            nome_fornecedor = fornecedor_dados.get('nome', item['fornecedor'])
            categoria = fornecedor_dados.get('categoria', 'FORNECEDOR')
            cnpj = fornecedor_dados.get('cnpj_cpf', cnpj)
 
        dados_bancarios = ''
        if cnpj:
            try:
                dados_bancarios = self.sistema.obter_dados_bancarios_fornecedor(
                    cnpj, forma_pagamento_preferida='PIX'
                )
            except Exception as e:
                logger.debug(f"DEBUG: Erro ao obter dados bancários em lote: {str(e)}")
 
        tipo_despesa = '2'
        if item['origem'] == 'CONFIGURACAO' and item.get('dados_originais'):
            tipo_despesa = str(item['dados_originais'].get('tipo_despesa', 2))
        elif isinstance(item.get('tipo'), str) and item['tipo'].startswith('TD'):
            tipo_despesa = item['tipo'].replace('TD', '')
 
        return {
            'data_rel': item['data_rel'],
            'tp_desp': tipo_despesa,
            'cnpj_cpf': cnpj or '',
            'nome': nome_fornecedor.strip().upper(),
            'categoria': categoria.upper(),
            'referencia': item['referencia'].strip().upper(),
            'nf': '',
            'valor': float(item['valor']),
            'dt_vencto': item['vencimento'],
            'observacao': f"CONFIRMADO EM LOTE - {item['referencia']}",
            'forma_pagamento': 'PIX',
            'dados_bancarios': dados_bancarios,
            'vr_unit': float(item['valor']),
            'dias': 1,
            'etapa_obra': '',
            'insumo': ''
        }
 
    def confirmar_selecionados_em_massa(self):
        """
        ✅ NOVO: Confirma em lote todos os itens marcados via checkbox.
        Só confirma automaticamente os que estiverem completos (ver
        _validar_item_para_confirmacao_massa); os demais são listados
        ao usuário para tratamento manual, e nada é gravado silenciosamente.
        """
        if not self.itens_marcados:
            custom_messagebox("warning", "Aviso", "Nenhum item marcado para confirmação.\n\n"
                "Marque os itens desejados clicando no checkbox da primeira coluna, "
                "ou use o botão 'Marcar Completos'.")
            return
 
        itens_marcados_dados = [
            item for item in self.dados_agenda
            if item.get('id_origem') in self.itens_marcados and item.get('status') == 'PENDENTE'
        ]
 
        if not itens_marcados_dados:
            custom_messagebox("warning", "Aviso", "Os itens marcados não estão mais disponíveis "
                "(provavelmente a agenda foi recarregada). Marque novamente.")
            self.itens_marcados.clear()
            return
 
        itens_validos = []
        itens_invalidos = []
        for item in itens_marcados_dados:
            motivo = self._validar_item_para_confirmacao_massa(item)
            if motivo:
                itens_invalidos.append((item, motivo))
            else:
                itens_validos.append(item)
 
        if not itens_validos:
            detalhes = "\n".join(f"• {i['fornecedor']}: {m}" for i, m in itens_invalidos)
            custom_messagebox("warning", "Nada a confirmar",
                "Nenhum dos itens marcados está completo o suficiente para confirmação "
                f"automática:\n\n{detalhes}")
            return
 
        valor_total = sum(i['valor'] for i in itens_validos)
        resumo_linhas = [
            f"• {i['fornecedor']} — R$ {i['valor']:,.2f} — {i['referencia']}"
                .replace(',', 'X').replace('.', ',').replace('X', '.')
            for i in itens_validos
        ]
 
        msg = (f"Confirmar {len(itens_validos)} lançamento(s), totalizando "
               f"R$ {valor_total:,.2f}?\n\n".replace(',', 'X').replace('.', ',').replace('X', '.'))
        msg += "\n".join(resumo_linhas[:15])
        if len(resumo_linhas) > 15:
            msg += f"\n... e mais {len(resumo_linhas) - 15} item(ns)"
        if itens_invalidos:
            msg += (f"\n\n⚠️ {len(itens_invalidos)} item(ns) marcado(s) ficarão de fora por "
                    "estarem incompletos (detalhes ao final).")
 
        if not custom_messagebox("yesno", "Confirmar Lançamentos em Lote", msg):
            return
 
        sucesso_count = 0
        falha_count = 0
        detalhes_falha = []
 
        for item in itens_validos:
            try:
                dados_lancamento = self._montar_dados_lancamento_a_partir_do_item(item)
                resultado = self.sistema.salvar_confirmacao_direta(dados_lancamento)
 
                if resultado and resultado.get('sucesso'):
                    sucesso_count += 1
 
                    if item['origem'] in ['MEDICAO', 'MEDICAO_AGRUPADA']:
                        try:
                            self.atualizar_status_medicoes_lancadas(item)
                        except Exception as e:
                            logger.error(f"Erro ao atualizar status de medição em lote: {e}")
 
                    self.remover_compromisso_confirmado(item['id_origem'])
                    self.itens_marcados.discard(item['id_origem'])
 
                    lancamento_real = {
                        'vencimento': dados_lancamento['dt_vencto'],
                        'data_rel': dados_lancamento['data_rel'],
                        'status': 'LANÇADO',
                        'fornecedor': dados_lancamento['nome'],
                        'referencia': dados_lancamento['referencia'],
                        'valor': dados_lancamento['valor'],
                        'tipo': dados_lancamento['tp_desp'],
                        'observacao': dados_lancamento['observacao'],
                        'id_origem': resultado.get('id_lancamento', ''),
                        'origem': 'EXISTENTE',
                        'dados_completos': dados_lancamento
                    }
                    self.dados_agenda.append(lancamento_real)
                else:
                    falha_count += 1
                    detalhes_falha.append(f"{item['fornecedor']}: falha ao salvar no sistema")
 
            except Exception as e:
                falha_count += 1
                detalhes_falha.append(f"{item.get('fornecedor', '?')}: {str(e)}")
                logger.error(f"Erro ao confirmar em lote item {item.get('id_origem')}: {e}")
 
        self.aplicar_filtros()
 
        resultado_msg = f"✅ {sucesso_count} lançamento(s) confirmado(s) com sucesso."
        if falha_count:
            resultado_msg += f"\n\n⚠️ {falha_count} falharam ao salvar:\n" + "\n".join(detalhes_falha[:10])
        if itens_invalidos:
            resultado_msg += "\n\n📋 Ignorados por dados incompletos (confirme manualmente):\n" + \
                "\n".join(f"• {i['fornecedor']}: {m}" for i, m in itens_invalidos[:10])
 
        custom_messagebox("info", "Resultado da Confirmação em Lote", resultado_msg)

    def limpar_duplicacoes_inteligente(self):
        """Remove compromissos configurados que já foram lançados (baseado em DATA_REL)"""
        try:
            if not custom_messagebox("yesno", "Limpeza Inteligente", 
                "Esta função vai remover da visualização os compromissos configurados "
                "que já possuem lançamentos correspondentes no mesmo relatório (DATA_REL).\n\n"
                "Continuar?"):
                return
            
            removidos = 0
            agenda_limpa = []
            
            # ✅ Criar índice de lançamentos existentes para busca rápida
            lancamentos_existentes = {}
            for item in self.dados_agenda:
                if item['origem'] == 'EXISTENTE':
                    data_rel = item.get('data_rel')
                    fornecedor_normalizado = self.normalizar_nome_fornecedor(item['fornecedor'])
                    chave = f"{data_rel}_{fornecedor_normalizado}"
                    lancamentos_existentes[chave] = True
            
            for item in self.dados_agenda:
                if item['origem'] in ['CONFIGURACAO', 'BASICO']:
                    data_rel_item = item.get('data_rel')
                    fornecedor_normalizado = self.normalizar_nome_fornecedor(item['fornecedor'])
                    chave = f"{data_rel_item}_{fornecedor_normalizado}"
                    
                    if chave in lancamentos_existentes:
                        removidos += 1
                        logger.debug(f"DEBUG: Removido: {item['fornecedor']} - REL {data_rel_item}")
                        continue
                
                agenda_limpa.append(item)
            
            # Atualizar dados
            self.dados_agenda = agenda_limpa
            self.aplicar_filtros()
            
            custom_messagebox("info", "Limpeza Concluída", 
                f"Foram removidos {removidos} compromissos configurados duplicados.")
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro na limpeza: {str(e)}")

    def normalizar_nome_fornecedor(self, nome):
        """Normaliza nome do fornecedor para comparação"""
        import re
        # Remove espaços extras, pontuação e converte para maiúsculas
        nome_limpo = re.sub(r'[^\w\s]', '', nome.upper())
        nome_limpo = ' '.join(nome_limpo.split())
        return nome_limpo

    def abrir_gerenciador_compromissos(self):
        """
        Abre a aba 'Agenda - Compromissos' da tela oficial de Configurações
        do Sistema, em vez de uma janela própria da Agenda.

        ✅ REDESENHO: a versão anterior construía uma tela duplicada, que foi
        divergindo da tela real de Configurações do Sistema (faltavam campos
        como Mês de Referência, indicação "(Dez) *1x" etc.). Agora a Agenda
        abre exatamente a mesma tela usada em Configurações — qualquer campo
        novo (como o de dia útil) passa a existir aqui automaticamente,
        sem precisar manter duas interfaces sincronizadas à mão.
        """
        try:
            from src.configuracoes_sistema import GerenciadorConfiguracoes

            janela_config = GerenciadorConfiguracoes(parent=self.janela)

            # Seleciona direto a aba "Agenda - Compromissos", sem obrigar o
            # usuário a navegar por Café, Bancos, Categorias etc.
            for tab_id in janela_config.notebook.tabs():
                if janela_config.notebook.tab(tab_id, 'text') == 'Agenda - Compromissos':
                    janela_config.notebook.select(tab_id)
                    break

            # Bloqueia aqui até a janela de configurações ser fechada (pelo X
            # ou por "Voltar ao Menu Principal") e só então recarrega a
            # Agenda, refletindo qualquer alteração feita nos compromissos.
            self.janela.wait_window(janela_config.root)
            self.carregar_dados_agenda()

        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao abrir gerenciador de compromissos: {str(e)}")
            logger.debug(f"DEBUG: Erro ao abrir gerenciador de compromissos: {str(e)}")

    def importar_excel(self):
        """Importa agenda de arquivo Excel"""
        try:
            arquivo = filedialog.askopenfilename(
                title="Selecionar arquivo de agenda",
                filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
            )
            
            if not arquivo:
                return
            
            # Implementar lógica de importação
            custom_messagebox("info", "Importação", "Funcionalidade de importação será implementada")
            
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao importar: {str(e)}")
    
    def exportar_periodo(self):
        """Exporta período atual para Excel com mais detalhes"""
        try:
            # Preparar dados para exportação
            dados_exportacao = []
 
            for child in self.tree_agenda.get_children():
                valores = self.tree_agenda.item(child, 'values')
                # Índices atuais (coluna 'Marcar' na posição 0):
                # 0=Marcar, 1=Vencimento, 2=Status, 3=Fornecedor, 4=Referência,
                # 5=Valor, 6=Tipo, 7=Observação, 8=ID_Origem
 
                # Buscar dados originais para mais detalhes
                # ✅ CORRIGIDO: comparava fornecedor com a Referência (índice
                # errado); agora compara fornecedor com fornecedor.
                item_original = None
                for item in self.dados_agenda:
                    if (item['vencimento'].strftime('%d/%m/%Y') == valores[1] and
                            item['fornecedor'] == valores[3]):
                        item_original = item
                        break
 
                linha_excel = {
                    'Vencimento': valores[1],
                    'Status': valores[2],
                    'Fornecedor': valores[3],
                    # ✅ CORRIGIDO: a chave 'Cliente' foi removida — não existe
                    # coluna de cliente na tabela (o valor gravado antes era,
                    # na prática, o Fornecedor duplicado).
                    'Referência': valores[4],
                    'Valor': valores[5],
                    'Tipo': valores[6],
                    'Observação': valores[7],
                    'Origem': item_original['origem'] if item_original else 'N/A',
                    'ID_Sistema': valores[8]
                }
 
                dados_exportacao.append(linha_excel)
 
            if not dados_exportacao:
                custom_messagebox("warning", "Aviso", "Nenhum dado para exportar no período atual")
                return
 
            # Salvar arquivo
            from tkinter import filedialog
            data_atual = datetime.now().strftime('%Y%m%d_%H%M')
            nome_padrao = f"Agenda_{self.sistema.cliente_atual}_{data_atual}.xlsx"
 
            arquivo = filedialog.asksaveasfilename(
                title="Salvar agenda",
                defaultextension=".xlsx",
                initialvalue=nome_padrao,
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
            )
 
            if arquivo:
                df_export = pd.DataFrame(dados_exportacao)
 
                # Adicionar resumo
                total_valor = sum(float(d['Valor'].replace('R$ ', '').replace('.', '').replace(',', '.'))
                                for d in dados_exportacao)
 
                resumo = {
                    'Total_Itens': len(dados_exportacao),
                    'Total_Valor': f"R$ {total_valor:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'),
                    'Periodo_Inicio': self.data_inicio_personalizada.get(),
                    'Periodo_Fim': self.data_fim_personalizada.get(),
                    'Data_Exportacao': datetime.now().strftime('%d/%m/%Y %H:%M:%S'),
                    'Cliente': self.sistema.cliente_atual
                }
 
                with pd.ExcelWriter(arquivo, engine='openpyxl') as writer:
                    df_export.to_excel(writer, sheet_name='Agenda', index=False)
 
                    # Adicionar resumo em aba separada
                    df_resumo = pd.DataFrame([resumo])
                    df_resumo.to_excel(writer, sheet_name='Resumo', index=False)
 
                custom_messagebox("info", "Sucesso", f"Agenda exportada para:\n{arquivo}")
 
        except Exception as e:
            custom_messagebox("error", "Erro", f"Erro ao exportar: {str(e)}")
    
    def verificar_alertas_inteligentes(self):
        """Verifica alertas baseados em padrões reais"""
        alertas = []
        hoje = datetime.now().date()
        
        try:
            # Alertar sobre vencimentos de hoje
            venc_hoje = [item for item in self.dados_agenda if item['vencimento'] == hoje]
            if venc_hoje:
                valor_hoje = sum(item['valor'] for item in venc_hoje)
                alertas.append({
                    'tipo': 'URGENTE',
                    'titulo': f'{len(venc_hoje)} vencimento(s) HOJE',
                    'descricao': f'Total: R$ {valor_hoje:,.2f}',
                    'itens': [f"• {item['fornecedor']}" for item in venc_hoje]
                })
            
            # Alertar sobre vencidos
            vencidos = [item for item in self.dados_agenda if item['vencimento'] < hoje and item['status'] != 'LANÇADO']
            if vencidos:
                valor_vencido = sum(item['valor'] for item in vencidos)
                alertas.append({
                    'tipo': 'ATENCAO',
                    'titulo': f'{len(vencidos)} item(ns) vencido(s)',
                    'descricao': f'Total: R$ {valor_vencido:,.2f}',
                    'itens': [f"• {item['fornecedor']} ({item['vencimento'].strftime('%d/%m')})" for item in vencidos[:5]]
                })
            
            # Alertar sobre alto volume nos próximos 7 dias
            proximos_7_dias = hoje + timedelta(days=7)
            proximos = [item for item in self.dados_agenda 
                    if hoje < item['vencimento'] <= proximos_7_dias]
            
            if proximos:
                valor_proximo = sum(item['valor'] for item in proximos)
                if valor_proximo > 50000:  # Configurável
                    alertas.append({
                        'tipo': 'INFO',
                        'titulo': f'Alto volume próximos 7 dias',
                        'descricao': f'R$ {valor_proximo:,.2f} em {len(proximos)} itens',
                        'itens': []
                    })
            
            return alertas
            
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao verificar alertas: {str(e)}")
            return []

    def mostrar_alertas_se_necessario(self):
        """Mostra alertas inteligentes se houver itens importantes"""
        alertas = self.verificar_alertas_inteligentes()
        
        if not alertas:
            return
        
        # Mostrar apenas se houver alertas urgentes ou de atenção
        alertas_importantes = [a for a in alertas if a['tipo'] in ['URGENTE', 'ATENCAO']]
        
        if not alertas_importantes:
            return
        
        # Criar janela de alerta discreta
        janela_alerta = tk.Toplevel(self.janela)
        janela_alerta.title("Alertas da Agenda")
        janela_alerta.geometry("400x300")
        janela_alerta.attributes('-topmost', True)
        
        frame_main = ttk.Frame(janela_alerta, padding="10")
        frame_main.pack(fill='both', expand=True)
        
        ttk.Label(frame_main, text="Alertas da Agenda", 
                font=('TkDefaultFont', 12, 'bold')).pack(pady=(0, 10))
        
        for alerta in alertas_importantes:
            frame_alerta = ttk.LabelFrame(frame_main, text=alerta['titulo'])
            frame_alerta.pack(fill='x', pady=5)
            
            ttk.Label(frame_alerta, text=alerta['descricao']).pack(anchor='w', padx=5, pady=2)
            
            for item in alerta.get('itens', [])[:3]:  # Máximo 3 itens
                ttk.Label(frame_alerta, text=item, font=('TkDefaultFont', 8)).pack(anchor='w', padx=15, pady=1)
        
        # Botões
        frame_botoes = ttk.Frame(frame_main)
        frame_botoes.pack(fill='x', pady=(10, 0))
        
        ttk.Button(frame_botoes, text="OK", command=janela_alerta.destroy).pack(side='right')

    def abrir_confirmacao_lancamento(self, valores_item, dados_pre_extraidos=None):
        """
        ✅ VERSÃO CORRIGIDA - Campos editáveis corretos + Combobox Etapa Obra
        """
        from src.config.utils import custom_messagebox
        from src.configuracoes_sistema import GerenciadorConfiguracoes
        # from src.widgets.combobox_autocompletar import ComboboxAutocompletar  # ✅ NOVO IMPORT
        
        # Buscar dados do item
        item_agenda = None
        for item in self.dados_agenda:
            if (item['fornecedor'] == valores_item[3] and
            item['vencimento'].strftime('%d/%m/%Y') == valores_item[1]):
                item_agenda = item
                break
        
        eh_medicao_agrupada = (item_agenda and 
                            item_agenda['origem'] == 'MEDICAO_AGRUPADA' and 
                            'medicoes_individuais' in item_agenda)
        
        # ========== JANELA COMPACTA ==========
        janela_confirm = tk.Toplevel(self.janela)
        janela_confirm.title("⚡ Confirmação Rápida")
        janela_confirm.geometry("700x600")
        janela_confirm.transient(self.janela)
        janela_confirm.grab_set()
        
        main_frame = ttk.Frame(janela_confirm, padding="15")
        main_frame.pack(fill='both', expand=True)
        
        # Cabeçalho
        frame_header = ttk.Frame(main_frame)
        frame_header.pack(fill='x', pady=(0, 10))
        
        ttk.Label(frame_header, text="⚡ Confirmação Rápida", 
                font=('TkDefaultFont', 12, 'bold'), 
                foreground='#2563eb').pack(side='left')
        
        ttk.Label(frame_header, text="📋 Ref. Editável", 
                font=('TkDefaultFont', 9), 
                foreground='#16a34a').pack(side='right')
        
        # ========== DADOS CONFIRMADOS (APENAS PARA REFERÊNCIA) ==========
        frame_info = ttk.LabelFrame(main_frame, text="ℹ️ Informação Original", padding="8")
        frame_info.pack(fill='x', pady=(0, 10))
        
        ttk.Label(frame_info, text=f"📅 Vencimento Original: {valores_item[1]}", 
                font=('TkDefaultFont', 9)).pack(anchor='w', padx=5, pady=2)
        ttk.Label(frame_info, text=f"📋 Referência Sugerida: {valores_item[4]}", 
                font=('TkDefaultFont', 9)).pack(anchor='w', padx=5, pady=2)
        
        # Alerta de medições
        if eh_medicao_agrupada:
            frame_med = ttk.LabelFrame(main_frame, text="📦 Medições", padding="5")
            frame_med.pack(fill='x', pady=(0, 10))
            qtd = len(item_agenda['medicoes_individuais'])
            ttk.Label(frame_med, 
                    text=f"✅ {qtd} medições em um lançamento",
                    font=('TkDefaultFont', 9)).pack(padx=5, pady=2)
        
        # ========== FORMULÁRIO EDITÁVEL ==========
        frame_form = ttk.LabelFrame(main_frame, text="📝 Dados Editáveis", padding="10")
        frame_form.pack(fill='both', expand=True, pady=(0, 10))
        
        # ✅ LINHA 0: Data Relatório (READONLY) e Tipo (EDITÁVEL)
        ttk.Label(frame_form, text="📊 Data Relatório:", 
                font=('TkDefaultFont', 9, 'bold'), 
                foreground='#dc2626').grid(row=0, column=0, padx=5, pady=5, sticky='w')
        data_rel = DateEntry(frame_form, width=12, date_pattern='dd/mm/yyyy', 
                        locale='pt_BR', state='readonly')
        if item_agenda and 'data_rel' in item_agenda:
            data_rel.set_date(item_agenda['data_rel'])
        else:
            data_rel.set_date(self.calcular_data_rel())
        data_rel.grid(row=0, column=1, padx=5, pady=5, sticky='w')
        
        ttk.Label(frame_form, text="🏷️ Tipo:", font=('TkDefaultFont', 9)).grid(
            row=0, column=2, padx=5, pady=5, sticky='w')
        tp_desp = ttk.Combobox(frame_form, values=['2', '3', '5', '6'], 
                            state='readonly', width=5)
        if item_agenda and item_agenda.get('dados_originais'):
            tp_desp.set(str(item_agenda['dados_originais'].get('tipo_despesa', 2)))
        else:
            tp_desp.set('2')
        tp_desp.grid(row=0, column=3, padx=5, pady=5, sticky='w')
        
        # ✅ LINHA 1: CNPJ/CPF (READONLY)
        ttk.Label(frame_form, text="🆔 CNPJ/CPF:", 
                font=('TkDefaultFont', 9, 'bold'), 
                foreground='#dc2626').grid(row=1, column=0, padx=5, pady=5, sticky='w')
        cnpj_cpf = ttk.Entry(frame_form, width=20, state='readonly')
        cnpj_cpf.grid(row=1, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
        
        # ✅ LINHA 2: Nome (EDITÁVEL)
        ttk.Label(frame_form, text="👤 Nome:", font=('TkDefaultFont', 9, 'bold')).grid(
            row=2, column=0, padx=5, pady=5, sticky='w')
        nome = ttk.Entry(frame_form, width=40)
        nome.grid(row=2, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
        
        # Lista de sugestões (compacta)
        lista_sugestoes = tk.Listbox(frame_form, height=3)
        lista_sugestoes.grid(row=3, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
        lista_sugestoes.grid_remove()
        
        # ✅ LINHA 4: Categoria (EDITÁVEL)
        ttk.Label(frame_form, text="📁 Categoria:", font=('TkDefaultFont', 9, 'bold')).grid(
            row=4, column=0, padx=5, pady=5, sticky='w')
        categoria_entry = ttk.Entry(frame_form, width=15)
        categoria_entry.grid(row=4, column=1, padx=5, pady=5, sticky='w')
        
        # ✅ LINHA 5: Referência (EDITÁVEL) 
        ttk.Label(frame_form, text="📋 Referência:", font=('TkDefaultFont', 9, 'bold')).grid(
            row=5, column=0, padx=5, pady=5, sticky='w')
        referencia_entry = ttk.Entry(frame_form, width=40)
        referencia_entry.insert(0, valores_item[4])
        referencia_entry.grid(row=5, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
        
        # ✅ LINHA 6: Valor (EDITÁVEL)
        ttk.Label(frame_form, text="💰 Valor:", font=('TkDefaultFont', 9, 'bold')).grid(
            row=6, column=0, padx=5, pady=5, sticky='w')
        valor_entry = ttk.Entry(frame_form, width=15)
        valor_entry.grid(row=6, column=1, padx=5, pady=5, sticky='w')
        
        # Preencher valor inicial
        try:
            valor_inicial = valores_item[5].replace('R$ ', '').replace('.', '').replace(',', '.')
            valor_float = float(valor_inicial)
            valor_entry.insert(0, f"{valor_float:.2f}".replace('.', ','))
        except:
            valor_entry.insert(0, "0,00")
        
        # ✅ LINHA 6 (continuação): Data Vencimento (EDITÁVEL)
        ttk.Label(frame_form, text="📅 Vencimento:", font=('TkDefaultFont', 9)).grid(
            row=6, column=2, padx=5, pady=5, sticky='w')
        dt_vencto = DateEntry(frame_form, width=12, date_pattern='dd/mm/yyyy', 
                            locale='pt_BR')
        try:
            dt_vencto.set_date(datetime.strptime(valores_item[1], '%d/%m/%Y').date())
        except:
            dt_vencto.set_date(datetime.now().date())
        dt_vencto.grid(row=6, column=3, padx=5, pady=5, sticky='w')
        
        # ✅ NOVO: se veio de importação de guia, sobrescrever valor e vencimento
        # com o dado real extraído do PDF (a Agenda só tinha valor estimado 0,00)
        if dados_pre_extraidos:
            valor_entry.delete(0, tk.END)
            valor_entry.insert(0, f"{dados_pre_extraidos['valor']:.2f}".replace('.', ','))

            if dados_pre_extraidos.get('vencimento'):
                try:
                    dt_vencto.set_date(datetime.strptime(dados_pre_extraidos['vencimento'], '%d/%m/%Y').date())
                except ValueError:
                    pass

            frame_origem_pdf = ttk.LabelFrame(main_frame, text="📄 Origem: Guia Importada")
            frame_origem_pdf.pack(fill='x', pady=(0, 10), before=frame_form)
            ttk.Label(frame_origem_pdf,
                text=f"Valor e vencimento preenchidos automaticamente a partir do PDF ({dados_pre_extraidos['tipo']}).",
                font=('TkDefaultFont', 9), foreground='#16a34a').pack(padx=5, pady=3)

        # ✅ LINHA 7: NF e Forma Pagamento (EDITÁVEL)
        ttk.Label(frame_form, text="📄 NF:", font=('TkDefaultFont', 9)).grid(
            row=7, column=0, padx=5, pady=5, sticky='w')
        nf = ttk.Entry(frame_form, width=15)
        nf.grid(row=7, column=1, padx=5, pady=5, sticky='w')
        
        ttk.Label(frame_form, text="💳 Pagto:", font=('TkDefaultFont', 9)).grid(
            row=7, column=2, padx=5, pady=5, sticky='w')
        forma_pagamento = ttk.Combobox(frame_form, 
                                    values=['PIX', 'TED', 'DINHEIRO'], 
                                    state='readonly', width=10)
        forma_pagamento.set('PIX')
        forma_pagamento.grid(row=7, column=3, padx=5, pady=5, sticky='w')
        
        # ✅ LINHA 8: Etapa da Obra (COMBOBOX AUTOCOMPLETAR)
        ttk.Label(frame_form, text="🏗️ Etapa Obra:", font=('TkDefaultFont', 9)).grid(
            row=8, column=0, padx=5, pady=5, sticky='w')
        
        etapas_obra = GerenciadorConfiguracoes.get_etapas_obra()  # ✅ Carregar etapas
        etapa_obra_combo = ComboboxAutocompletar(
            frame_form,
            values=etapas_obra,
            config_key='etapas_obra',
            config_manager=GerenciadorConfiguracoes,
            font=('TkDefaultFont', 9),
            width=38,
            state='normal'
        )
        etapa_obra_combo.grid(row=8, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
 
        # ✅ CORRIGIDO: funções de dados bancários definidas ANTES dos
        # widgets da Linha 9, para que o botão já encontre o nome pronto
 
        # controla se o usuário já editou manualmente os dados bancários
        # neste lançamento (para não sobrescrever a edição)
        edicao_manual_bancaria = {'ativo': False}
 
        def atualizar_dados_bancarios(forcar=False):
            try:
                if forcar:
                    edicao_manual_bancaria['ativo'] = False
 
                if edicao_manual_bancaria['ativo']:
                    # não sobrescreve edição manual do usuário
                    return
 
                cnpj_atual = cnpj_cpf.get().strip()
                forma_atual = forma_pagamento.get()
 
                if not cnpj_atual or len(cnpj_atual) < 11:
                    dados_bancarios_entry.delete(0, tk.END)
                    dados_bancarios_entry.insert(0, "PREENCHA CNPJ")
                    return
 
                dados_banc = self.sistema.obter_dados_bancarios_fornecedor(
                    cnpj_atual, forma_pagamento_preferida=forma_atual
                )
 
                dados_bancarios_entry.delete(0, tk.END)
                dados_bancarios_entry.insert(0, dados_banc)
            except Exception as e:
                dados_bancarios_entry.delete(0, tk.END)
                dados_bancarios_entry.insert(0, f"ERRO: {str(e)}")
 
        def on_dados_bancarios_editado(event=None):
            """marca que o usuário editou manualmente este campo"""
            edicao_manual_bancaria['ativo'] = True
 
        def restaurar_dados_bancarios_cadastro():
            """descarta a edição manual e busca o dado oficial de novo"""
            atualizar_dados_bancarios(forcar=True)
 
        # ✅ LINHA 9: Dados bancários (EDITÁVEL - pontual para este lançamento)
        ttk.Label(frame_form, text="🏦 Dados Bancários:", font=('TkDefaultFont', 9)).grid(
            row=9, column=0, padx=5, pady=5, sticky='w')
 
        frame_bancarios = ttk.Frame(frame_form)
        frame_bancarios.grid(row=9, column=1, columnspan=3, padx=5, pady=5, sticky='ew')
 
        dados_bancarios_entry = ttk.Entry(frame_bancarios, width=32)
        dados_bancarios_entry.pack(side='left', fill='x', expand=True)
 
        ttk.Button(frame_bancarios, text="🔄 Restaurar do Cadastro",
                command=restaurar_dados_bancarios_cadastro).pack(side='left', padx=(5, 0))
 
        ttk.Label(frame_form,
                text="📝 Editável apenas para este lançamento — não altera o cadastro do fornecedor.",
                font=('TkDefaultFont', 8), foreground='gray').grid(
                    row=10, column=0, columnspan=4, sticky='w', padx=5)
 
        dados_bancarios_entry.bind('<KeyRelease>', on_dados_bancarios_editado)
 
        frame_form.columnconfigure(1, weight=1)
 
        # ✅ FALTAVA: definição da função chamada logo abaixo em
        # buscar_fornecedor_por_nome / selecionar_fornecedor_da_lista /
        # preenchimento inicial do fornecedor
        def preencher_dados_fornecedor(fornecedor_dados):
            """✅ Preencher campos com dados do fornecedor"""
            try:
                # CNPJ (readonly)
                cnpj_cpf.config(state='normal')
                cnpj_cpf.delete(0, tk.END)
                cnpj_cpf.insert(0, fornecedor_dados.get('cnpj_cpf', '').strip())
                cnpj_cpf.config(state='readonly')
 
                # Nome (editável)
                nome.delete(0, tk.END)
                nome.insert(0, fornecedor_dados.get('nome', '').strip())
 
                # Categoria (editável)
                categoria = fornecedor_dados.get('categoria', 'FORNECEDOR')
                categoria_entry.delete(0, tk.END)
                categoria_entry.insert(0, categoria)
 
                # trocou de fornecedor -> qualquer edição bancária manual
                # anterior deixa de fazer sentido; volta a puxar o dado
                # oficial do fornecedor recém-selecionado
                edicao_manual_bancaria['ativo'] = False
 
                # Dados bancários
                janela_confirm.after(200, atualizar_dados_bancarios)
            except Exception as e:
                logger.error(f"Erro ao preencher dados: {e}")
 
        def buscar_fornecedor_por_nome(event=None):
            nome_digitado = nome.get().strip()
            if len(nome_digitado) < 3:
                lista_sugestoes.grid_remove()
                return
            try:
                fornecedores = self.sistema.buscar_fornecedores_por_nome_parcial(nome_digitado)
                if fornecedores:
                    lista_sugestoes.delete(0, tk.END)
                    for f in fornecedores[:5]:
                        lista_sugestoes.insert(tk.END, f"{f['nome']} - {f['cnpj_cpf']}")
                    lista_sugestoes.grid()
                else:
                    lista_sugestoes.grid_remove()
            except:
                lista_sugestoes.grid_remove()
 
        def selecionar_fornecedor_da_lista(event=None):
            try:
                selection = lista_sugestoes.curselection()
                if selection:
                    texto = lista_sugestoes.get(selection[0])
                    cnpj_extraido = texto.split(' - ')[-1]
                    fornecedor_dados = self.sistema.buscar_fornecedor_por_cnpj_agenda(cnpj_extraido)
                    if fornecedor_dados:
                        preencher_dados_fornecedor(fornecedor_dados)
                        lista_sugestoes.grid_remove()
            except:
                pass
 
        # Bindings
        nome.bind('<KeyRelease>', buscar_fornecedor_por_nome)
        lista_sugestoes.bind('<Button-1>', lambda e: janela_confirm.after(50, selecionar_fornecedor_da_lista))
        forma_pagamento.bind('<<ComboboxSelected>>', lambda e: atualizar_dados_bancarios())
 
        # ✅ Preencher fornecedor inicial
        try:
            if item_agenda and item_agenda['origem'] in ['MEDICAO', 'MEDICAO_AGRUPADA']:
                cnpj_medicao = self._obter_cnpj_medicao(item_agenda)  # ✅ CORRIGIDO
 
                if cnpj_medicao:
                    fornecedor_dados = self.sistema.buscar_fornecedor_por_cnpj_agenda(cnpj_medicao)
 
                    if fornecedor_dados:
                        preencher_dados_fornecedor(fornecedor_dados)
                    else:
                        nome.insert(0, item_agenda['fornecedor'])
                        cnpj_cpf.config(state='normal')
                        cnpj_cpf.insert(0, cnpj_medicao)
                        cnpj_cpf.config(state='readonly')
                else:
                    nome.insert(0, item_agenda['fornecedor'])
            else:
                fornecedor_dados = self.sistema.buscar_fornecedor_por_nome_agenda(valores_item[3])
                if fornecedor_dados:
                    preencher_dados_fornecedor(fornecedor_dados)
                else:
                    nome.insert(0, valores_item[3])
 
        except Exception as e:
            logger.debug(f"DEBUG: Erro ao buscar fornecedor inicial: {e}")
            if item_agenda:
                nome.insert(0, item_agenda.get('fornecedor', valores_item[3]))
            else:
                nome.insert(0, valores_item[3])

        # ========== CONFIRMAÇÃO RÁPIDA ==========
        def confirmar_rapido():
            """⚡ CONFIRMAÇÃO COM CAMPOS EDITÁVEIS"""
            try:
                # Validação básica
                erros = []
                if not nome.get().strip():
                    erros.append("Nome obrigatório")
                if not cnpj_cpf.get().strip():
                    erros.append("CNPJ obrigatório")
                
                categoria_valor = categoria_entry.get().strip()
                if not categoria_valor:
                    erros.append("Categoria obrigatória")
                
                try:
                    valor_str = valor_entry.get().replace(',', '.')
                    valor_float = float(valor_str)
                    if valor_float <= 0:
                        erros.append("Valor deve ser maior que zero")
                except:
                    erros.append("Valor inválido")
                    valor_float = 0.0
                
                if erros:
                    custom_messagebox("error", "Validação", "\n".join(erros))
                    return
                
                # ✅ Preparar dados com campos editáveis
                data_rel_usar = data_rel.get_date()
                if item_agenda and 'data_rel' in item_agenda:
                    data_rel_usar = item_agenda['data_rel']
                
                referencia_final = referencia_entry.get().strip().upper()
                etapa_obra_valor = etapa_obra_combo.get().strip().upper()  # ✅ Obter do combobox
                
                dados_lancamento = {
                    'data_rel': data_rel_usar,
                    'tp_desp': tp_desp.get(),
                    'cnpj_cpf': cnpj_cpf.get().strip(),
                    'nome': nome.get().strip().upper(),
                    'categoria': categoria_valor.upper(),
                    'referencia': referencia_final,
                    'nf': nf.get().strip().upper(),
                    'valor': valor_float,
                    'dt_vencto': dt_vencto.get_date(),
                    'observacao': f"CONFIRMADO - {referencia_final}",
                    'forma_pagamento': forma_pagamento.get(),
                    'dados_bancarios': dados_bancarios_entry.get(),
                    'vr_unit': valor_float,
                    'dias': 1,
                    'etapa_obra': etapa_obra_valor,  # ✅ Usar valor do combobox
                    'insumo': ''
                }
                
                # Salvar
                resultado = self.sistema.salvar_confirmacao_direta(dados_lancamento)
                
                if resultado and resultado.get('sucesso'):
                    if item_agenda and item_agenda['origem'] in ['MEDICAO', 'MEDICAO_AGRUPADA']:
                        try:
                            self.atualizar_status_medicoes_lancadas(item_agenda)
                        except Exception as e:
                            logger.error(f"Erro ao atualizar medição: {e}")
                    
                    if item_agenda:
                        self.remover_compromisso_confirmado(item_agenda['id_origem'])
                        
                        lancamento_real = {
                            'vencimento': dados_lancamento['dt_vencto'],
                            'data_rel': dados_lancamento['data_rel'],
                            'status': 'LANÇADO',
                            'fornecedor': dados_lancamento['nome'],
                            'referencia': dados_lancamento['referencia'],
                            'valor': dados_lancamento['valor'],
                            'tipo': dados_lancamento['tp_desp'],
                            'observacao': dados_lancamento['observacao'],
                            'id_origem': resultado.get('id_lancamento', ''),
                            'origem': 'EXISTENTE',
                            'dados_completos': dados_lancamento
                        }
                        self.dados_agenda.append(lancamento_real)
                        self.aplicar_filtros()
                    
                    janela_confirm.destroy()
                    
                    custom_messagebox("info", "✅ Confirmado!", 
                        f"📋 {dados_lancamento['nome']}\n"
                        f"📁 {categoria_valor}\n"
                        f"🔖 {referencia_final}\n"
                        f"🏗️ {etapa_obra_valor if etapa_obra_valor else 'Sem etapa'}\n"
                        f"💰 R$ {valor_float:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.'))
                else:
                    custom_messagebox("error", "Erro", "Falha ao salvar lançamento!")
                    
            except Exception as e:
                logger.error(f"Erro na confirmação: {e}")
                custom_messagebox("error", "Erro", f"{str(e)}")
        
        # ========== BOTÕES ==========
        frame_botoes = ttk.Frame(main_frame)
        frame_botoes.pack(fill='x', pady=(10, 0))
        
        btn_confirmar = ttk.Button(frame_botoes, text="✅ CONFIRMAR LANÇAMENTO", 
                                command=confirmar_rapido)
        btn_confirmar.pack(side='left', padx=5, fill='x', expand=True)
        
        ttk.Button(frame_botoes, text="❌ Cancelar", 
                command=janela_confirm.destroy).pack(side='right', padx=5)
        
        # Atalhos
        janela_confirm.bind('<Return>', lambda e: confirmar_rapido())
        janela_confirm.bind('<Escape>', lambda e: janela_confirm.destroy())
        
        # Focar no primeiro campo editável (Nome)
        nome.focus()

    def remover_compromisso_confirmado(self, item_id_origem):
        """Remove compromisso da lista após confirmação"""
        try:
            # Remover da lista de dados
            self.dados_agenda = [
                item for item in self.dados_agenda 
                if item.get('id_origem') != item_id_origem
            ]
            
            # Reaplicar filtros para atualizar visualização
            self.aplicar_filtros()
            
            logger.debug(f"✅ Compromisso {item_id_origem} removido da agenda")
            
        except Exception as e:
            logger.error(f"Erro ao remover compromisso: {e}")

    
    def atualizar_status_medicoes_lancadas(self, item_agenda):
        """
        VERSÃO CORRIGIDA — atualiza diretamente pela linha física da planilha
        (linha_planilha), em vez de varrer a aba inteira procurando por
        (Contrato, ID_Medicao). Isso elimina o risco de marcar como LANÇADO uma
        linha antiga já EXCLUÍDA que, por coincidência, compartilhe a mesma
        chave com a medição nova (cenário possível desde que o ID_Medicao passou
        a poder ser reaproveitado, por decisão de negócio, para não deixar
        buracos no relatório).
        """
        try:
            logger.debug("=" * 80)
            logger.debug("🔄 INICIANDO ATUALIZAÇÃO DE STATUS DAS MEDIÇÕES")
            logger.debug("=" * 80)
    
            if not item_agenda.get('origem') in ['MEDICAO', 'MEDICAO_AGRUPADA']:
                logger.debug("DEBUG: Item não é uma medição, pulando atualização")
                return True
    
            arquivo_cliente = PASTA_CLIENTES / f"{self.sistema.cliente_atual}.xlsx"
            if not arquivo_cliente.exists():
                logger.error("❌ Arquivo do cliente não existe")
                return False
    
            from openpyxl import load_workbook
            from datetime import datetime
    
            wb = load_workbook(arquivo_cliente)
    
            if "Medicoes" not in wb.sheetnames:
                logger.error("❌ Aba Medicoes não encontrada")
                wb.close()
                return False
    
            ws_medicoes = wb["Medicoes"]
            data_lancamento = datetime.now()
    
            # Lista de medições a atualizar, agora carregando também a linha
            # física de origem (linha_planilha), quando disponível.
            medicoes_atualizar = []
    
            if item_agenda['origem'] == 'MEDICAO':
                medicoes_atualizar.append({
                    'id_contrato': item_agenda['dados_medicao']['id_contrato'],
                    'id_medicao': item_agenda['dados_medicao']['id_medicao'],
                    'linha_planilha': item_agenda['dados_medicao'].get('linha_planilha')
                })
                logger.debug(f"DEBUG: Medição INDIVIDUAL")
                logger.debug(f"       Contrato {item_agenda['dados_medicao']['id_contrato']}, "
                            f"Medição {item_agenda['dados_medicao']['id_medicao']}")
    
            elif item_agenda['origem'] == 'MEDICAO_AGRUPADA':
                for med in item_agenda.get('medicoes_individuais', []):
                    medicoes_atualizar.append({
                        'id_contrato': med['id_contrato'],
                        'id_medicao': med['id_medicao'],
                        'linha_planilha': med.get('linha_planilha')
                    })
                logger.debug(f"DEBUG: Medições AGRUPADAS - {len(medicoes_atualizar)} medições")
    
            if not medicoes_atualizar:
                logger.warning("⚠️ Nenhuma medição para atualizar")
                wb.close()
                return False
    
            # Identificar colunas dinamicamente (mantido como no original)
            cabecalhos = {}
            for idx, cell in enumerate(ws_medicoes[1], start=1):
                if cell.value:
                    nome_normalizado = str(cell.value).strip().upper()
                    cabecalhos[nome_normalizado] = idx
    
            try:
                col_id_contrato = cabecalhos.get('ID_CONTRATO', 1)
                col_id_medicao = cabecalhos.get('ID_MEDICAO', cabecalhos.get('ID_MEDIÇÃO', 2))
    
                col_status = None
                if 'STATUS_MEDICAO' in cabecalhos:
                    col_status = cabecalhos['STATUS_MEDICAO']
                elif 'STATUS' in cabecalhos:
                    col_status = cabecalhos['STATUS']
                else:
                    raise KeyError("Coluna de STATUS não encontrada")
    
                col_data_lanc = cabecalhos.get('DATA_LANCAMENTO', 10)
            except KeyError as e:
                logger.error(f"❌ Coluna essencial não encontrada: {e}")
                wb.close()
                return False
    
            # ===== ATUALIZAÇÃO PELA LINHA FÍSICA (CORREÇÃO PRINCIPAL) =====
            medicoes_atualizadas = 0
            avisos_linha_ausente = []
    
            for medicao in medicoes_atualizar:
                linha = medicao.get('linha_planilha')
    
                if not linha:
                    # Fallback defensivo apenas para itens antigos sem
                    # linha_planilha registrada: busca por chave, mas agora
                    # RESPEITANDO o Status e parando no primeiro não-excluído
                    # — como as demais telas do sistema já fazem.
                    avisos_linha_ausente.append(medicao)
                    for idx in range(2, ws_medicoes.max_row + 1):
                        status_val = str(ws_medicoes.cell(row=idx, column=col_status).value or '').strip().upper()
                        if status_val in ('EXCLUÍDO', 'EXCLUIDO'):
                            continue
                        if (ws_medicoes.cell(row=idx, column=col_id_contrato).value == medicao['id_contrato'] and
                                ws_medicoes.cell(row=idx, column=col_id_medicao).value == medicao['id_medicao']):
                            linha = idx
                            break
                    if not linha:
                        logger.warning(f"⚠️ Medição Contrato {medicao['id_contrato']} / "
                                    f"#{medicao['id_medicao']} não encontrada (sem linha física "
                                    f"e nenhuma linha ativa correspondente)")
                        continue
    
                # Confirma que a linha ainda corresponde à medição esperada e
                # que não foi excluída nesse meio-tempo (ex.: outra sessão do
                # sistema mexeu nela entre o carregamento da Agenda e este clique).
                contrato_na_linha = ws_medicoes.cell(row=linha, column=col_id_contrato).value
                id_medicao_na_linha = ws_medicoes.cell(row=linha, column=col_id_medicao).value
                status_na_linha = str(ws_medicoes.cell(row=linha, column=col_status).value or '').strip().upper()
    
                if (contrato_na_linha != medicao['id_contrato'] or
                        id_medicao_na_linha != medicao['id_medicao']):
                    logger.warning(f"⚠️ Linha {linha} não corresponde mais a Contrato "
                                f"{medicao['id_contrato']} / Medição {medicao['id_medicao']} "
                                f"(planilha pode ter mudado) — pulando por segurança")
                    continue
    
                if status_na_linha in ('EXCLUÍDO', 'EXCLUIDO'):
                    logger.warning(f"⚠️ Linha {linha} (Contrato {medicao['id_contrato']} / "
                                f"Medição {medicao['id_medicao']}) já está EXCLUÍDA — pulando "
                                f"para não reverter uma exclusão válida")
                    continue
    
                ws_medicoes.cell(row=linha, column=col_status).value = 'LANÇADO'
                cell_data = ws_medicoes.cell(row=linha, column=col_data_lanc)
                cell_data.value = data_lancamento
                cell_data.number_format = 'DD/MM/YYYY HH:MM:SS'
    
                medicoes_atualizadas += 1
    
                logger.debug(f"   ✅ Linha {linha} atualizada:")
                logger.debug(f"      Contrato {medicao['id_contrato']}, "
                            f"Medição {medicao['id_medicao']}")
                logger.debug(f"      STATUS → LANÇADO")
                logger.debug(f"      DATA_LANCAMENTO → {data_lancamento.strftime('%d/%m/%Y %H:%M:%S')}")
    
            if avisos_linha_ausente:
                logger.warning(f"⚠️ {len(avisos_linha_ausente)} medição(ões) sem linha física "
                            f"registrada usaram busca por chave (fallback) — considere "
                            f"recarregar a Agenda antes de confirmar")
    
            try:
                salvar_planilha_segura(wb, arquivo_cliente)
                logger.info("✅ Arquivo salvo com sucesso")
            except Exception as e:
                logger.error(f"❌ Erro ao salvar arquivo: {e}")
                wb.close()
                return False
            finally:
                wb.close()
    
            sucesso = (medicoes_atualizadas == len(medicoes_atualizar))
    
            logger.debug("=" * 80)
            logger.debug(f"RESUMO DA ATUALIZAÇÃO:")
            logger.debug(f"  • Medições a atualizar: {len(medicoes_atualizar)}")
            logger.debug(f"  • Medições atualizadas: {medicoes_atualizadas}")
            logger.debug(f"  • Status: {'✅ SUCESSO' if sucesso else '⚠️ PARCIAL'}")
            logger.debug("=" * 80)
    
            return sucesso
    
        except Exception as e:
            logger.error(f"❌ ERRO CRÍTICO ao atualizar medições: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    
    def on_double_click(self, event):
        """Trata duplo clique nos itens"""
        selected = self.tree_agenda.selection()
        if selected:
            valores = self.tree_agenda.item(selected[0], 'values')
            status = valores[2]  # ✅ ÍNDICE AJUSTADO (coluna 'Marcar' na posição 0)
 
            if status == 'PENDENTE':
                self.confirmar_lancamento()
            elif status in ['LANÇADO', 'VENCIDO', 'VENCE HOJE']:
                self.editar_selecionado()
    
    def configurar_atalhos(self):
        """Configura atalhos de teclado para a agenda"""
        try:
            # Enter: Confirmar lançamento (se pendente) ou editar (se lançado)
            def on_enter(event):
                selected = self.tree_agenda.selection()
                if selected:
                    valores = self.tree_agenda.item(selected[0], 'values')
                    status = valores[2]  # ✅ ÍNDICE AJUSTADO (coluna 'Marcar' na posição 0)
 
                    if status == 'PENDENTE':
                        self.confirmar_lancamento()
                    else:
                        self.editar_selecionado()
                return "break"
 
            self.tree_agenda.bind('<Return>', on_enter)
            self.janela.bind('<Return>', on_enter)
 
            # F5: Atualizar
            def on_f5(event):
                self.carregar_dados_agenda()
                return "break"
 
            self.janela.bind('<F5>', on_f5)
            self.tree_agenda.bind('<F5>', on_f5)
 
            # Ctrl+N: Novo lançamento
            def on_ctrl_n(event):
                self.novo_lancamento()
                return "break"
 
            self.janela.bind('<Control-n>', on_ctrl_n)
 
            # Escape: Fechar
            def on_escape(event):
                self.janela.destroy()
                return "break"
 
            self.janela.bind('<Escape>', on_escape)
 
            logger.debug("DEBUG: Atalhos da agenda configurados")
            logger.debug("       Enter: Confirmar/Editar item selecionado")
            logger.debug("       F5: Atualizar agenda")
            logger.debug("       Ctrl+N: Novo lançamento")
            logger.debug("       Escape: Fechar")
 
        except Exception as e:
            logger.debug(f"Erro ao configurar atalhos da agenda: {str(e)}")

if __name__ == "__main__":
    logger.info("Iniciando aplicação...")
    app = SistemaEntradaDados()
    
    logger.info("Atualizando interface...")
    app.root.update_idletasks()
    
    logger.info("Iniciando mainloop...")
    app.root.mainloop()
    
    logger.info("Aplicação finalizada")
